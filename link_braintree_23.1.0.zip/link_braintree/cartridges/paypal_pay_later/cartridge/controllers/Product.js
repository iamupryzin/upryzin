'use strict';

var page = module.superModule;
var server = require('server');

server.extend(page);

server.append('Show', function (_, res, next) {
    var StringUtils = require('dw/util/StringUtils');
    var creditMessageAvailable = require('dw/system/Site').current.getCustomPreferenceValue('PP_Show_On_PDP');
    var { vaultMode } = require('*/cartridge/config/braintreePreferences');
    var { isPaypalButtonEnabled } = require('*/cartridge/scripts/braintree/helpers/paymentHelper');
    var { productDetailMessageConfig } = require('../config/creditMessageConfig');
    var { getClientId } = require('~/cartridge/scripts/helper/payLaterHelper');
    var { braintree } = res.getViewData();

    if (vaultMode && braintree && braintree.payPalButtonConfig) {
        this.on('route:BeforeComplete', function () {
            var paypalOptions = braintree.payPalButtonConfig.options;
            paypalOptions.flow = 'checkout';
            paypalOptions.requestBillingAgreement = true;
            paypalOptions.billingAgreementDetails = {
                description: paypalOptions.billingAgreementDescription
            };
        });
    }

    if (!creditMessageAvailable) {
        return next();
    }

    res.setViewData({
        paypal: {
            bannerConfig: productDetailMessageConfig
        },
        creditMessageAvailable: creditMessageAvailable,
        isPDPButtonEnabled: isPaypalButtonEnabled('pdp'),
        paypalSdkUrl: StringUtils.format('https://www.paypal.com/sdk/js?client-id={0}&components=messages', getClientId())
    });

    return next();
});

module.exports = server.exports();
