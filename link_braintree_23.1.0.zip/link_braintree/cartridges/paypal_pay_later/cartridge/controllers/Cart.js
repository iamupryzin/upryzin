/* eslint-disable no-shadow */
'use strict';

var page = module.superModule;
var server = require('server');

server.extend(page);

server.append('Show', function (_, res, next) {
    var Site = require('dw/system/Site');
    var StringUtils = require('dw/util/StringUtils');
    var creditMessageAvailable = Site.current.getCustomPreferenceValue('PP_Show_On_Cart');
    var basket = require('dw/order/BasketMgr').getCurrentBasket();
    var { vaultMode } = require('*/cartridge/config/braintreePreferences');
    var { braintree } = res.getViewData();

    if (!basket) {
        return next();
    }

    if (creditMessageAvailable || vaultMode) {
        this.on('route:BeforeComplete', function () {
            var { isPaypalButtonEnabled } = require('*/cartridge/scripts/braintree/helpers/paymentHelper');
            var { cartMessageConfig } = require('~/cartridge/config/creditMessageConfig');
            var { getClientId } = require('~/cartridge/scripts/helper/payLaterHelper');

            if (vaultMode && braintree && braintree.payPalButtonConfig) {
                var paypalOptions = res.getViewData().braintree.payPalButtonConfig.options;
                paypalOptions.flow = 'checkout';
                paypalOptions.requestBillingAgreement = true;
                paypalOptions.billingAgreementDetails = {
                    description: paypalOptions.billingAgreementDescription
                };
            }

            res.setViewData({
                paypalAmount: basket.totalGrossPrice.value,
                bannerConfig: cartMessageConfig,
                creditMessageAvailable: creditMessageAvailable,
                isCartButtonEnabled: isPaypalButtonEnabled('cart'),
                paypalSdkUrl: StringUtils.format('https://www.paypal.com/sdk/js?client-id={0}&components=messages', getClientId())
            });
        });
    }

    return next();
});

server.append('MiniCartShow', function (_, res, next) {
    var { vaultMode } = require('*/cartridge/config/braintreePreferences');
    var { braintree } = res.getViewData();

    if (vaultMode && braintree && braintree.payPalButtonConfig) {
        this.on('route:BeforeComplete', function () {
            var viewData = res.getViewData();
            viewData.braintree.payPalButtonConfig.options.flow = 'checkout';
            viewData.braintree.payPalButtonConfig.options.requestBillingAgreement = true;
        });
    }

    return next();
});

module.exports = server.exports();
