'use strict';

var page = module.superModule;
var server = require('server');

var currentSite = require('dw/system/Site').getCurrent();

var creditMessageAvailable = currentSite.getCustomPreferenceValue('PP_Show_On_Category');

server.extend(page);

server.append('Show', function (req, res, next) {
    if (!creditMessageAvailable) {
        return next();
    }

    var { categoryMessageConfig } = require('~/cartridge//config/creditMessageConfig');
    var basket = require('dw/order/BasketMgr').getCurrentBasket();
    var clientToken = require('*/cartridge/scripts/braintree/braintreeAPI/braintreeBusinessLogic').getClientToken(currentSite.getDefaultCurrency());

    res.setViewData({
        paypal: {
            bannerConfig: categoryMessageConfig,
            clientToken: clientToken,
            paypalAmount: (basket && basket.totalGrossPrice.value) || 0
        },
        creditMessageAvailable: creditMessageAvailable
    });

    return next();
});

module.exports = server.exports();
