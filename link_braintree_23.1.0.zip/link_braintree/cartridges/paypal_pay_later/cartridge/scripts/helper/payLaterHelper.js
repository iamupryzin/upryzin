'use strict';

var payLaterHelper = {};

/**
 * Gets client id from cache if it exists or creates it, saves to cache and returns from cache
 *
 * @returns {string} with client id
 */
payLaterHelper.getClientId = function () {
    const prefsCache = require('dw/system/CacheMgr').getCache('braintreePreferences');
    const serviceName = 'int_paypal.http.rest.credit';
    var clientId = prefsCache.get('clientId');

    if (clientId) {
        return clientId;
    }

    const restService = require('dw/svc/LocalServiceRegistry').createService(serviceName, {});
    clientId = restService.configuration.credential.user;
    prefsCache.put('clientId', clientId);

    return clientId;
};

module.exports = payLaterHelper;
