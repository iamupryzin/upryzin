'use strict';

/**
 * Returns preferences object for the BM PayPal Configuration.
 *
 * @returns {Object} An object with preferences.
 */
module.exports = {
    googlePaySDK: 'https://pay.google.com/gp/p/js/pay.js',
    applePayButtonSdk: 'https://applepay.cdn-apple.com/jsapi/v1/apple-pay-sdk.js'
};
