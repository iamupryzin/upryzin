/**
 * Variables
 */
const $colorButton = document.getElementById('color_button');
const $shapeButton = document.getElementById('shape_button');
const $label = document.getElementById('label');
const $locationButton = document.getElementById('location_button');
const $smartbuttonConfigForm = document.getElementById('smartbutton-config-form');
const paypalCartButtonSelector = '.paypal-cart-button';
const $heightFormControlRange = document.getElementById('height__formControlRange');
const $heightFormControlNumber = document.getElementById('height__formControlNumber');
const $layoutButton = document.getElementById('layout_button');
const $taglineButton = document.getElementById('tagline_button');
const $smartBtnAlertDiv = document.getElementById('smart-button-alert-message');

/**
 * Appends Alerts message
 *
 * Avaible alerts types:
 * primary,  secondary, success, danger, warning, info, alert, dark
 * @param {Object} alert Alerts and type messages
 */
function showSmartButtonAlertMessage(alert) {
    $smartBtnAlertDiv.innerHTML = `<h5>${alert.message}</h5>`;
    $smartBtnAlertDiv.className = `alert alert-${alert.type} show`;

    window.scrollTo(0, 0);
}

/**
 * Fades Alerts message
 */
function fadeSmartButtonAlertMessage() {
    $smartBtnAlertDiv.innerHTML = '';
    $smartBtnAlertDiv.className = 'alert alert-success fade';
}

/**
 * Return style configurations for Pay Pal smart button
 * Available values:
 * color: (string) gold, blue, silver, black, white,
 * shape: (string) pill, rect
 * label: (string) paypal, pay, checkout
 *
 * @returns {Object} button styles
*/
function getSmartButtonStyleConfigs() {
    return {
        height: Math.floor($heightFormControlRange.value),
        color: $colorButton.value,
        shape: $shapeButton.value,
        layout: $layoutButton.value,
        label: $label.value,
        tagline: JSON.parse($taglineButton.value)
    };
}

/**
 * Update html option's with saved Pay Pal smart button  values from custom pref PP_API_Smart_Button_Styles
 *
 * @param {Object} savedSmartStyles object with color, shape, label, location configs
*/
function updateValuesWithStyleConfigs(savedSmartStyles) {
    $colorButton.value = savedSmartStyles.color;
    $shapeButton.value = savedSmartStyles.shape;
    $label.value = savedSmartStyles.label;
    $locationButton.value = savedSmartStyles.location;
    $heightFormControlRange.value = savedSmartStyles.height;
    $heightFormControlNumber.value = savedSmartStyles.height;
    $layoutButton.value = savedSmartStyles.layout;
    $taglineButton.value = savedSmartStyles.tagline;
}

/**
 * Render PayPal Buttons
 *
 * @param {Object} styleConfiguration button style config
 * @returns {void}
 */
function paypalButtonsRender(styleConfiguration) {
    // eslint-disable-next-line new-cap
    window.paypal.Buttons({
        onInit: (_, actions) => {
            return actions.disable();
        },
        createOrder: () => { },
        onApprove: () => { },
        onCancel: () => { },
        onError: () => { },
        style: styleConfiguration
    }).render(paypalCartButtonSelector);
}

document.addEventListener('DOMContentLoaded', function () {
    let pageType = 'billing';
    const params = (new URLSearchParams(window.location.search));

    if (params.has('savedButtonStyle')) {
        pageType = params.get('savedButtonStyle');
        window.history.replaceState(null, null, window.location.pathname);
    }

    const smartButtonConfig = JSON.parse($smartbuttonConfigForm.getAttribute('data-smart-styles'))[pageType];

    smartButtonConfig.location = pageType;

    updateValuesWithStyleConfigs(smartButtonConfig);
    paypalButtonsRender(smartButtonConfig);
});

/**
 * Re-render buttons with a new styles
 * @returns {void}
 */
function updatePayPalButtonRender() {
    document.querySelector(paypalCartButtonSelector).innerHTML = '';

    fadeSmartButtonAlertMessage();
    paypalButtonsRender(getSmartButtonStyleConfigs());
}

/**
 * Handles the tagline or layout change. Shows an alert message is case of a not allowed tagline and layout combination
 * @param {Object} e An event Object
 */
function hanlePayPalBtnTaglineAndLayout(e) {
    fadeSmartButtonAlertMessage();

    // vertical layout is not allowed for active tagline
    const isTaglineButton = JSON.parse($taglineButton.value);
    const isLayoutVertical = $layoutButton.value === 'vertical';

    if (isTaglineButton && isLayoutVertical) {
        const isTaglineChanged = e.target === $taglineButton;
        const alertMessage = isTaglineChanged ?
            window.resourcesAlertMessages.tagline :
            window.resourcesAlertMessages.layout;

        if (isTaglineChanged) {
            $layoutButton.value = 'horizontal';
        } else {
            $taglineButton.value = false;
        }

        showSmartButtonAlertMessage(alertMessage);
    }

    document.querySelector(paypalCartButtonSelector).innerHTML = '';

    paypalButtonsRender(getSmartButtonStyleConfigs());
}

/**
 * Handles a height form control range
 */
function handleHeightFormControlRange() {
    updatePayPalButtonRender();

    $heightFormControlNumber.value = $heightFormControlRange.value;
}

/**
 * Handles a height form control number
 */
function handleHeightFormControlNumber() {
    fadeSmartButtonAlertMessage();

    $heightFormControlRange.value = $heightFormControlNumber.value;

    const event = document.createEvent('Event');

    event.initEvent('change', true, true);
    // Dispatch the event
    $heightFormControlRange.dispatchEvent(event);
}

// Inits all 'change' events for PayPal button parameters

$colorButton.addEventListener('change', updatePayPalButtonRender);

$label.addEventListener('change', updatePayPalButtonRender);

$shapeButton.addEventListener('change', updatePayPalButtonRender);

$heightFormControlRange.addEventListener('change', handleHeightFormControlRange);

$heightFormControlNumber.addEventListener('change', handleHeightFormControlNumber);

$layoutButton.addEventListener('change', hanlePayPalBtnTaglineAndLayout);

$taglineButton.addEventListener('change', hanlePayPalBtnTaglineAndLayout);

$locationButton.addEventListener('change', () => {
    document.querySelector(paypalCartButtonSelector).innerHTML = '';
    fadeSmartButtonAlertMessage();

    const savedSmartStyles = JSON.parse($smartbuttonConfigForm.getAttribute('data-smart-styles'));
    const locationButton = $locationButton.value;
    const currentSavedSmartStyles = savedSmartStyles[locationButton];

    currentSavedSmartStyles.location = locationButton;

    updateValuesWithStyleConfigs(currentSavedSmartStyles);

    // eslint-disable-next-line new-cap
    window.paypal.Buttons({
        onInit: (_, actions) => {
            return actions.disable();
        },
        createOrder: () => { },
        onApprove: () => { },
        onCancel: () => { },
        onError: () => { },
        style: currentSavedSmartStyles
    }).render(paypalCartButtonSelector).then(function () {
        window.scrollTo(0, 0);
    });
});

$smartbuttonConfigForm.addEventListener('submit', (e) => {
    e.preventDefault();

    // eslint-disable-next-line no-undef
    jQuery.post(e.currentTarget.action, e.currentTarget.serialize())
        .done(function (data) {
            location.href = data.redirectUrl;
        })
        .fail(function (err) {
            showSmartButtonAlertMessage({
                message: err.responseText,
                type: 'danger'
            });
        });

    return false;
});
