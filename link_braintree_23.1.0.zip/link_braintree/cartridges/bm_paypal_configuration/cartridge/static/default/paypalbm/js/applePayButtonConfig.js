'use strict';
((win, doc, $) => {
    const $alert = doc.getElementById('ap-alert');
    const $loader = doc.getElementById('ap-loader');
    const $location = doc.getElementById('ap-location');
    const $buttonStyle = doc.getElementById('ap-button-style');
    const $buttonType = doc.getElementById('ap-type');

    const $form = doc.getElementById('apple-pay-config-form');
    const $container = doc.getElementById('apple-pay-container');

    const currentButtonStyles = JSON.parse($form.getAttribute('data-button-styles'));

    const getButtonConfigs = () => {
        return {
            buttonStyle: $buttonStyle.value,
            type: $buttonType.value
        };
    };

    const rebuildApplePayButton = buttonStyles => {
        const $applePayButton = document.getElementById('apple-pay-btn');

        $applePayButton.setAttribute('type', buttonStyles.type);
        $applePayButton.setAttribute('buttonstyle', buttonStyles.buttonStyle);
    };

    const updateButtonView = () => {
        rebuildApplePayButton(getButtonConfigs());
    };

    const showAlertMessage = (message) => {
        $alert.textContent = message;
        $alert.classList.remove('d-none');

        setTimeout(() => {
            $alert.textContent = '';
            $alert.classList.add('d-none');
        }, 5000);
    };

    const updateButtonOptions = buttonStyles => {
        $buttonStyle.value = buttonStyles.buttonStyle;
        $buttonType.value = buttonStyles.type;
    };

    const handleLocation = () => {
        updateButtonOptions(currentButtonStyles[$location.value]);

        updateButtonView();
    };

    const handleSubmitForm = (event) => {
        event.preventDefault();

        $loader.classList.remove('d-none');

        $.post(event.currentTarget.action, event.currentTarget.serialize())
            .done((reponse) => {
                win.location.href = reponse.redirectUrl;
            })
            .fail((error) => {
                showAlertMessage(error.responseText);
            })
            .always(() => {
                $loader.classList.add('d-none');
            });
    };

    const applePayInit = () => {
        if ($container) {
            const params = new URLSearchParams(win.location.search);
            const location = params.get('tab') === 'apple-pay' && params.has('location') ? params.get('location') : 'billing';
            const buttonStylesByLocation = currentButtonStyles[location];

            $location.value = location;

            updateButtonOptions(buttonStylesByLocation);

            rebuildApplePayButton(buttonStylesByLocation);

            $location.addEventListener('change', handleLocation);
            $buttonStyle.addEventListener('change', updateButtonView);
            $buttonType.addEventListener('change', updateButtonView);

            $form.addEventListener('submit', handleSubmitForm);
        }
    };

    doc.addEventListener('DOMContentLoaded', applePayInit);
})(window, document, window.jQuery);
