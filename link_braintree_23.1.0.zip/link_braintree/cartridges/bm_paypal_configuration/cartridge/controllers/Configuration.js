'use strict';

/**
 * @namespace Configuration
 */

/**
 * Gets client id from cache if it exists or creates it, saves to cache and returns from cache
 *
 * @returns {string} with client id
 */
function getClientId() {
    const prefsCache = require('dw/system/CacheMgr').getCache('braintreePreferences');
    const serviceName = 'int_paypal.http.rest.credit';

    let clientId = prefsCache.get('clientId');

    if (clientId) {
        return clientId;
    }

    const restService = require('dw/svc/LocalServiceRegistry').createService(serviceName, {});

    clientId = restService.configuration.credential.user;
    prefsCache.put('clientId', clientId);

    return clientId;
}

/**
 * Renders configuration template with required configurations and parameters
 */
function start() {
    const StringUtils = require('dw/util/StringUtils');

    const paypalSDK = StringUtils.format(
        'https://www.paypal.com/sdk/js?client-id={0}&components=buttons,messages',
        getClientId()
    );

    require('dw/template/ISML').renderTemplate('buttons/configurationBoard', {
        paypalSDK: paypalSDK
    });
}

start.public = true;

exports.Start = start;
