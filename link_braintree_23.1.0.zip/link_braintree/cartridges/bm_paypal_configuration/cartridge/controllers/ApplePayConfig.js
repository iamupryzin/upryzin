'use strict';

/**
 * @namespace ApplePayConfig
 */

/* global dw request response empty */

const Site = require('dw/system/Site');
const Transaction = require('dw/system/Transaction');
const Resource = require('dw/web/Resource');

const possibleApplePayButtonTypes = [
    Resource.msg('applepay.type.option.plain', 'paypalbmconfiguration', null),
    Resource.msg('applepay.type.option.addMoney', 'paypalbmconfiguration', null),
    Resource.msg('applepay.type.option.book', 'paypalbmconfiguration', null),
    Resource.msg('applepay.type.option.buy', 'paypalbmconfiguration', null),
    Resource.msg('applepay.type.option.checkOut', 'paypalbmconfiguration', null),
    Resource.msg('applepay.type.option.continue', 'paypalbmconfiguration', null),
    Resource.msg('applepay.type.option.contribute', 'paypalbmconfiguration', null),
    Resource.msg('applepay.type.option.donate', 'paypalbmconfiguration', null),
    Resource.msg('applepay.type.option.order', 'paypalbmconfiguration', null),
    Resource.msg('applepay.type.option.pay', 'paypalbmconfiguration', null),
    Resource.msg('applepay.type.option.reload', 'paypalbmconfiguration', null),
    Resource.msg('applepay.type.option.rent', 'paypalbmconfiguration', null),
    Resource.msg('applepay.type.option.setUp', 'paypalbmconfiguration', null),
    Resource.msg('applepay.type.option.subscribe', 'paypalbmconfiguration', null),
    Resource.msg('applepay.type.option.support', 'paypalbmconfiguration', null),
    Resource.msg('applepay.type.option.tip', 'paypalbmconfiguration', null),
    Resource.msg('applepay.type.option.topUp', 'paypalbmconfiguration', null)
];
const possibleApplePayButtonColors = [
    Resource.msg('applepay.color.option.black', 'paypalbmconfiguration', null),
    Resource.msg('applepay.color.option.white', 'paypalbmconfiguration', null),
    Resource.msg('applepay.color.option.white-outline', 'paypalbmconfiguration', null)
];

/**
 * Renders configuration template with required configurations and parameters
 */
function start() {
    const PaymentMgr = require('dw/order/PaymentMgr');
    const paypalConfigurationPreferences = require('~/cartridge/config/paypalConfigurationPreferences');

    const applePayPaymentMethod = PaymentMgr.getPaymentMethod('ApplePay');
    const buttonStyles = Site.current.getCustomPreferenceValue('AP_API_Button_Styles') || '';
    const cartButtonEnabled = Site.current.getCustomPreferenceValue('BRAINTREE_APPLEPAY_Visibility_Button_On_Cart');

    require('dw/template/ISML').renderTemplate('buttons/applepay/configuration', {
        buttonStyles: buttonStyles,
        cartButtonEnabled: cartButtonEnabled,
        isPaymentMethodEnabled: applePayPaymentMethod && applePayPaymentMethod.active,
        possibleApplePayButtonsType: possibleApplePayButtonTypes,
        possibleApplePayButtonColors: possibleApplePayButtonColors,
        applePayButtonSdk: paypalConfigurationPreferences.applePayButtonSdk,
        locale: Site.current.defaultLocale
    });
}

/**
 * Save Button configuration to Custom Preference value: AP_API_Button_Styles
 */
function saveButton() {
    response.setContentType('application/json');

    try {
        const AP_API_BUTTON_STYLES = 'AP_API_Button_Styles';
        const params = request.httpParameterMap;
        const data = JSON.parse(Site.current.getCustomPreferenceValue(AP_API_BUTTON_STYLES)) || {};

        const buttonStyle = {
            buttonStyle: params.buttonStyle.value,
            type: params.type.value
        };

        data[params.location.value] = buttonStyle;

        Transaction.wrap(function () {
            Site.current.setCustomPreferenceValue(AP_API_BUTTON_STYLES, JSON.stringify(data));
        });

        response.setStatus(200);
        response.writer.print(JSON.stringify({
            options: buttonStyle,
            redirectUrl: require('dw/web/URLUtils').https(
                'Configuration-Start',
                'tab', 'apple-pay',
                'location', params.location.value
            ).toString()
        }));
    } catch (error) {
        response.setStatus(500);
        response.writer.print(error.message);
    }
}

start.public = true;
saveButton.public = true;

exports.Start = start;
exports.SaveButton = saveButton;
