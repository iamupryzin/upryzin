/* global dw request response empty */

/**
 * @namespace PaypalConfig
 */

var Site = require('dw/system/Site');
var Transaction = require('dw/system/Transaction');

/**
 * Gets active paypal credit messaging Site Pref metadata
 *
 * @returns {Object} with cart, product, category enabled flag
 */
function getBannerConfigPages() {
    const customPreferenceNaming = ['PP_Show_On_Cart', 'PP_Show_On_PDP', 'PP_Show_On_Category'];
    const customPreferenceValues = {};

    Array
        .forEach(customPreferenceNaming, function (name) {
            const value = Site.current.getCustomPreferenceValue(name);
            if (value) {
                customPreferenceValues[name.split('_')[3].toLocaleLowerCase()] = value;
            }
            return false;
        });

    return customPreferenceValues;
}

/**
 * Check if Paypal button is enabled
 * @param {string} targetPage button location value
 * @return {boolean} disabled or enabled
 */
function isPaypalButtonEnabled(targetPage) {
    var paypalButtonLocation = Site.current.getCustomPreferenceValue('BRAINTREE_PAYPAL_Button_Location').getValue();
    var displayPages = paypalButtonLocation.toLowerCase();
    if (displayPages === 'none' || !targetPage) {
        return false;
    }
    return displayPages.indexOf(targetPage) !== -1;
}

/**
 * Renders configurationBoard template with required configurations and parameters
 * */
function start() {
    const PaymentMgr = require('dw/order/PaymentMgr');
    const payPalPaymentMethod = PaymentMgr.getPaymentMethod('PayPal');

    require('dw/template/ISML').renderTemplate('buttons/paypal/configuration', {
        cartButtonEnabled: isPaypalButtonEnabled('cart'),
        minicartButtonEnabled: isPaypalButtonEnabled('minicart'),
        pdpButtonEnabled: isPaypalButtonEnabled('pdp'),
        savedSBLocation: request.httpParameterMap.savedButtonStyle.stringValue,
        savedBSLocation: request.httpParameterMap.savedBannerStyles.stringValue,
        savedSmartStyles: Site.current.getCustomPreferenceValue('PP_API_Smart_Button_Styles'),
        savedBannerConfigs: Site.current.getCustomPreferenceValue('PP_API_Credit_Banner_Styles'),
        bannerConfigs: getBannerConfigPages(),
        isPaymentMethodEnabled: payPalPaymentMethod && payPalPaymentMethod.active
    });
}

/**
 * Save smart Button configuration to Custom Preference value: PP_API_Smart_Button_Styles
 *
 * sucess response: (status code 200) with redirect url
 * error response: (status code 500) with error message
 * */
function saveSmartButton() {
    const params = request.httpParameterMap;
    const jsonContentType = 'application/json';

    let data;
    let smartButtonStyle;

    response.setContentType(jsonContentType);

    try {
        data = JSON.parse(Site.current.getCustomPreferenceValue('PP_API_Smart_Button_Styles'));

        smartButtonStyle = {
            color: params.color.value,
            shape: params.shape.value,
            label: params.label.value,
            layout: params.layout.value,
            tagline: params.tagline.booleanValue,
            height: params.heightFormControlRange.intValue
        };

        data[params.location.value] = smartButtonStyle;

        Transaction.wrap(function () {
            Site.current.setCustomPreferenceValue('PP_API_Smart_Button_Styles', JSON.stringify(data));
        });

        response.setStatus(200);
        response.writer.print(JSON.stringify({
            redirectUrl: require('dw/web/URLUtils').https(
                'Configuration-Start',
                'savedButtonStyle', params.location.value,
                'tab', 'paypal'
            ).toString()
        }));
    } catch (error) {
        response.setStatus(500);
        response.writer.print(error.message);
    }
}

/**
 * Save banner configuration to Custom Preference value: PP_API_Credit_Banner_Styles
 *
 * sucess response: (status code 200) with redirect url
 * error response: (status code 500) with error message
 * */
function saveCreditBanner() {
    const params = request.httpParameterMap;
    const jsonContentType = 'application/json';

    let data;
    let bannerStyle;

    response.setContentType(jsonContentType);

    try {
        data = JSON.parse(Site.current.getCustomPreferenceValue('PP_API_Credit_Banner_Styles'));
        bannerStyle = {
            styleColor: params.styleColor.value,
            styleRatio: params.styleRatio.value,
            styleLayout: params.layout.value,
            styleTextColor: params.textColor.value,
            styleLogoPosition: params.logoPosition.value,
            styleLogoType: params.logoType.value
        };
        data[params.placement.value] = bannerStyle;
        Transaction.wrap(function () {
            Site.current.setCustomPreferenceValue('PP_API_Credit_Banner_Styles', JSON.stringify(data));
        });
        response.setStatus(200);
        response.writer.print(JSON.stringify({
            redirectUrl: require('dw/web/URLUtils').https(
                'Configuration-Start',
                'savedBannerStyles', params.placement.value,
                'tab', 'paypal'
            ).toString()
        }));
    } catch (error) {
        response.setStatus(500);
        response.writer.print(error.message);
    }
}

start.public = true;
saveSmartButton.public = true;
saveCreditBanner.public = true;

exports.Start = start;
exports.SaveSmartButton = saveSmartButton;
exports.SaveCreditBanner = saveCreditBanner;
