'use strict';
/**
 * @namespace GooglePayConfig
 */

/* global request response */
const Site = require('dw/system/Site');

/**
 * Renders configuration template with required configurations and parameters
 */
function start() {
    const PaymentMgr = require('dw/order/PaymentMgr');
    const paypalConfigurationPreferences = require('~/cartridge/config/paypalConfigurationPreferences');

    const googlePayPaymentMethod = PaymentMgr.getPaymentMethod('GooglePay');

    const buttonStyles = Site.current.getCustomPreferenceValue('GP_API_Button_Styles') || '';
    const cartButtonEnabled = Site.current.getCustomPreferenceValue('BRAINTREE_GOOGLEPAY_Visibility_Button_On_Cart');

    require('dw/template/ISML').renderTemplate('buttons/googlepay/configuration.isml', {
        googlePaySDK: paypalConfigurationPreferences.googlePaySDK,
        buttonStyles: buttonStyles,
        pdpButtonEnabled: false,
        minicartButtonEnabled: false,
        cartButtonEnabled: cartButtonEnabled,
        isPaymentMethodEnabled: googlePayPaymentMethod && googlePayPaymentMethod.active
    });
}

/**
 * Save Button configuration to Custom Preference value: GP_API_Button_Styles
 */
function saveButton() {
    const Transaction = require('dw/system/Transaction');
    const helper = require('~/cartridge/scripts/helpers/helper');

    response.setContentType('application/json');

    try {
        const params = request.httpParameterMap;
        const data = helper.parseCustomPreference(Site.current.getCustomPreferenceValue('GP_API_Button_Styles'));

        const buttonStyle = {
            buttonType: params.buttonType.value,
            buttonSizeMode: params.buttonSizeMode.value
        };

        data[params.location.value] = buttonStyle;

        Transaction.wrap(function () {
            Site.current.setCustomPreferenceValue('GP_API_Button_Styles', JSON.stringify(data));
        });

        response.setStatus(200);
        response.writer.print(JSON.stringify({
            options: buttonStyle,
            redirectUrl: require('dw/web/URLUtils').https(
                'Configuration-Start',
                'tab', 'google-pay',
                'location', params.location.value
            ).toString()
        }));
    } catch (error) {
        response.setStatus(500);
        response.writer.print(JSON.stringify(error.message));
    }
}

start.public = true;
saveButton.public = true;

exports.Start = start;
exports.SaveButton = saveButton;
