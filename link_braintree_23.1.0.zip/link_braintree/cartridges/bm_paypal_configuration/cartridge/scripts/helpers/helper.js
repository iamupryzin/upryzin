'use strict';

/**
 * It takes a JSON and tries to parse it. If it fails, it returns an empty object.
 * @param {Object} customPreference - This is the custom preference you try to parse.
 * @returns {Object} An object.
 */
function parseCustomPreference(customPreference) {
    try {
        return JSON.parse(customPreference);
    } catch (error) {
        const Logger = require('dw/system/Logger');
        Logger.error(error);

        return {};
    }
}

module.exports = {
    parseCustomPreference: parseCustomPreference
};
