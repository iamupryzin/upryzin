CHANGELOG
=========
## 18.3.0
* Update SDK version to 3.46.0
* SFRA support up to 4.2.1 and SG up to 104.3.1
* Speed-up component creation by remove client instance creation
* Merchant Id no longer needed if ECBT is in use
* Last 4 digit of card revealed instead of last 2
* Add level 2, 3 processing https://developers.braintreepayments.com/reference/general/level-2-and-3-processing/overview
* After PayPal account was selected customer can change order amount or shipping address without the need to choose PayPal account again
