const $lpmFallback = document.querySelector('.js-lpm-fallback');
const $lpmLoader = document.querySelector('.js-braintree-loader-container');
const $processingMsg = document.querySelector('.js-processing-msg');
const $finalProcessingMsg = document.querySelector('.js-final-processing-msg');
const lpmData = JSON.parse($lpmFallback.getAttribute('data-braintree-lpm'));
const HIDE_BLOCK_CLASS = 'hide-block';

/**
 * LPM fallback process
 */
const process = () => {
    braintree.client.create({
        authorization: lpmData.clientToken
    })
        .then(clientInstance => {
            $lpmLoader.style.display = 'block';

            return braintree.localPayment.create({
                client: clientInstance
            });
        })
        .then(localPaymentInstance => {
            localPaymentInstance.tokenize()
                .then(function ({ nonce, details }) {
                    const buyerAddressDetails = Object.keys(details).length ? details : { email: lpmData.customerEmail };

                    $processingMsg.classList.add(HIDE_BLOCK_CLASS);
                    $finalProcessingMsg.classList.remove(HIDE_BLOCK_CLASS);

                    fetch(lpmData.paymentConfirmUrl, {
                        method: 'POST',
                        body: JSON.stringify({
                            nonce: nonce,
                            lpmName: lpmData.lpmName,
                            details: buyerAddressDetails
                        }),
                        headers: { 'Content-Type': 'application/json' }
                    })
                    .then(response => response.json())
                    .then(data => {
                        const lpmPaymentProcessorHelper = require('../local/helpers/lpmPaymentProcessorHelper');

                        lpmPaymentProcessorHelper.processLpmConfirmForm(data.redirectUrl);
                    });
                })
            .catch(() => {
                const lpmError = document.querySelector('.js-lpm-error');

                $lpmLoader.classList.add(HIDE_BLOCK_CLASS);
                $processingMsg.classList.add(HIDE_BLOCK_CLASS);
                $finalProcessingMsg.classList.add(HIDE_BLOCK_CLASS);
                lpmError.classList.remove(HIDE_BLOCK_CLASS);
            });
        });
};

module.exports = {
    process
};

