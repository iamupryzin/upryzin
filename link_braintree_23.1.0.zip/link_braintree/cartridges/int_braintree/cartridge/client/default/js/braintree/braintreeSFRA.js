'use strict';

/**
 * Inits credit card functionality on Storefront
 * @returns {void}
 */
function initCreditCardFunctionality() {
    const creditCardOnAccountEnabled = Boolean(document.querySelector('.js-braintree-add-credit-card-form'));
    const creditCardEnabledOnCheckout = Boolean(document.querySelector('.js_braintree_creditCardContent'));

    let creditCardBusinessLogic;

    if (creditCardOnAccountEnabled || creditCardEnabledOnCheckout) {
        creditCardBusinessLogic = require('./creditcard/creditCard');
        creditCardBusinessLogic.init();
    }

    if (creditCardOnAccountEnabled) {
        creditCardBusinessLogic.initAccount();
    }

    if (creditCardEnabledOnCheckout) {
        creditCardBusinessLogic.initCheckout();
    }
}

/**
 * Inits PayPal functionality on Storefront
 * @param {Promise} clientTokenPromise promise with Braintree Client Instance
 * @returns {void}
 */
function initPayPalFunctionality(clientTokenPromise) {
    const payPalBusinessLogic = require('./paypal/payPal');

    const payPalEnabledOnCheckout = Boolean(document.querySelector('.js_braintree_paypalContent'));
    const payPalEnabledOnProduct = Boolean(document.querySelector('.prices-add-to-cart-actions .js_braintree_paypal_cart_button'));
    const payPalEnabledOnCart = Boolean(document.querySelector('.cart-page .js_braintree_paypal_cart_button'));
    const payPalEnabledOnAccountPage = Boolean(document.querySelector('.paypal-accounts'));

    payPalBusinessLogic.init(clientTokenPromise);

    if (payPalEnabledOnCheckout) {
        payPalBusinessLogic.initCheckout();
    }

    if (payPalEnabledOnProduct) {
        payPalBusinessLogic.initProduct();
    }

    // Validation on enabled/disabled PayPal button for MiniCart located isinside MiniCart component
    payPalBusinessLogic.initMiniCart();

    if (payPalEnabledOnCart) {
        payPalBusinessLogic.initCart();
    }

    if (payPalEnabledOnAccountPage) {
        payPalBusinessLogic.initAccount();
    }
}

/**
 * Inits GooglePay functionality on Storefront
 * @returns {void}
 */
function initGooglePayFunctionality() {
    const googlePayBusinnessLogic = require('./googlepay/googlePay');

    const googlePayEnabledOnCheckout = Boolean(document.querySelector('.js_braintree_googlepayContent'));
    const googlePayEnabledOnCart = Boolean(document.querySelector('.braintree-cart-google-button'));

    googlePayBusinnessLogic.init();

    if (googlePayEnabledOnCheckout) {
        googlePayBusinnessLogic.initCheckout();
    }

    if (googlePayEnabledOnCart) {
        googlePayBusinnessLogic.initCart();
    }
}

/**
 * Inits ApplePay functionality on Storefront
 * @returns {void}
 */
function initApplePayFunctionality() {
    const applePayBusinessLogic = require('./applepay/applePay');

    const applePayEnabledOnCheckout = Boolean(document.querySelector('.js_braintree_applepayContent'));
    const applePayEnabledOnCart = Boolean(document.querySelector('.braintree-cart-apple-button'));

    applePayBusinessLogic.init();

    if (applePayEnabledOnCart) {
        applePayBusinessLogic.initCart();
    }

    if (applePayEnabledOnCheckout) {
        applePayBusinessLogic.initCheckout();
    }
}

/**
 * Inits Venmo functionality on Storefront
 * @returns {void}
 */
function initVenmoFunctionality() {
    const venmoBusinessLogic = require('./venmo/venmo');

    const isVenmoEnabledOnAccountPage = Boolean(document.querySelector('.venmo-accounts'));
    const isVenmoEnabledOnBillingPage = Boolean(document.querySelector('.js_braintree_venmoContent'));

    venmoBusinessLogic.init();

    if (isVenmoEnabledOnAccountPage) {
        venmoBusinessLogic.initAccount();
    }

    if (isVenmoEnabledOnBillingPage) {
        venmoBusinessLogic.initBillingCheckout();
    }
}

/**
 * Inits SRC functionality on Storefront
 * @returns {void}
 */
function initSRCFunctionality() {
    const srcBusinessLogic = require('./src/src');

    const isSrcEnabledOnAccountPage = Boolean(document.querySelector('.js-braintree-account-add-src'));
    const isSrcEnabledOnCartPage = Boolean(document.querySelector('.braintree-cart-src-button'));
    const isSrcEnabledOnBillingPage = Boolean(document.querySelector('.js_braintree_srcContent'));

    srcBusinessLogic.init();

    if (isSrcEnabledOnAccountPage) {
        srcBusinessLogic.initAccount();
    }

    if (isSrcEnabledOnCartPage) {
        srcBusinessLogic.initCartCheckout();
    }

    if (isSrcEnabledOnBillingPage) {
        srcBusinessLogic.initBillingCheckout();
    }
}

/**
 * Inits LPM functionality on Storefront
 * @returns {void}
 */
function initLPMFunctionality() {
    const lpmBusinessLogic = require('./local/lpm');
    const isLpmEnebledOnBillingPage = Boolean(document.querySelector('.js_braintree-lpmContent'));

    if (isLpmEnebledOnBillingPage) {
        lpmBusinessLogic.init();
    }

    // LPM fallback process
    if (document.querySelector('.js-lpm-fallback')) {
        const lpmFallback = require('../braintree/local/lpmFallback');

        lpmFallback.process();
    }
}

/**
 * Inits APMA functionality on Storefront
 * @returns {void}
 */
function initAPMAFunctionality() {
    const apmaBusinessLogic = require('./apma');
    const isApmaEnebled = Boolean(document.getElementById('js-apma-button-paypal'));

    if (isApmaEnebled) {
        apmaBusinessLogic.init();
    }
}

module.exports = function () {
    // Used only for Paypal. In future "client token" generation approach will be refactored
    const paymentMethodGeneral = require('./paymentMethodGeneral');

    // General global variables
    const isCheckoutPage = Boolean(document.getElementById('checkout-main'));
    const isAccountPage = Boolean(document.querySelector('.js-account-dashboard'));

    /* ------------------------General Account functionality------------------------ */
    if (isAccountPage) {
        const btAccountBusinessLogic = require('./braintreeAccount');
        // Common Credit Card and SRC Account functionality
        btAccountBusinessLogic.initAccount();
    }

    /* ------------------------General Checkout functionality----------------------- */
    if (isCheckoutPage) {
        paymentMethodGeneral.fillPaymentSammaryContainer();
        paymentMethodGeneral.initPaymentMethodTabClickBehavior();
        paymentMethodGeneral.initChangeShippingBehavior();
        paymentMethodGeneral.initBillingSelectorChangeFunctionality();
    }

    /* ------------------------Credit Card------------------------ */

    initCreditCardFunctionality();

    /* --------------------------PayPal-------------------------- */

    initPayPalFunctionality(paymentMethodGeneral.createGeneralClientInstancePromise());

    /* --------------------------GooglePay------------------------- */

    initGooglePayFunctionality();

    /* --------------------------ApplePay------------------------- */

    initApplePayFunctionality();

    /* --------------------------Venmo---------------------------- */

    initVenmoFunctionality();

    /* --------------------------SRC------------------------------ */

    initSRCFunctionality();

    /* --------------------------LPM-------------------------- */

    initLPMFunctionality();

    /* --------------------------APMA-------------------------- */

    initAPMAFunctionality();
};
