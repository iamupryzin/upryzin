'use strict';

const $continueButton = document.querySelector('button.submit-payment');

const cssClass = {
    D_NONE: 'd-none',
    FONT_WEIGHT_BOLD: 'font-weight-bold'
};

const INVALID_CLASSNAME = 'is-invalid';

/**
 * Depends on the value flag, sets style.display to the $continueButton
 * @param {boolean} flag Boolean value
 * @returns {void}
 */
function continueButtonToggle(flag) {
    const stage = window.location.hash.substring(1);

    if (stage === 'placeOrder' || stage === 'shipping' || stage === null || stage === '') {
        return;
    }

    $continueButton.style.display = flag ? 'none' : '';
}

/**
 * Return payment method name in lovercase
 * @param {string} paymentMethodName Payment method name
 * @returns {string} Paymnet method name
 */
function getPaymentMethodToLowerCase(paymentMethodName) {
    let paymentMethod = paymentMethodName.split('_');
    if (paymentMethod.length === 1) {
        return paymentMethodName;
    }
    paymentMethod = paymentMethod.map(function (element) {
        return element.charAt(0) + element.slice(1).toLocaleLowerCase();
    });
    return `${paymentMethod[0]} ${paymentMethod[1]}`;
}

/**
 * Returns HTML for given paymentMethodId
 * @param {string} paymentMethodId Payment method id
 * @param {Object} selectedPaymentInstrument Current payment instrument
 * @returns {string} HTML result
 */
function getHtmlFromPaymentMethodId(paymentMethodId, selectedPaymentInstrument) {
    let htmlResult = '';

    if (paymentMethodId === window.braintreeConstants.PAYMENT_METHOD_ID_PAYPAL) {
        htmlResult += `<div>${selectedPaymentInstrument.braintreePaypalEmail}</div>`;
    }

    if (paymentMethodId === window.braintreeConstants.PAYMENT_METHOD_ID_VENMO) {
        htmlResult += `<div>${selectedPaymentInstrument.braintreeVenmoUserId}</div>`;
    }

    return htmlResult;
}

/**
 * Updates checkout view
 * @param {Object} e Event object
 * @param {Object} data Data object
 */
function updateCheckoutView(e, data) {
    const $paymentSummary = document.querySelector('.summary-details .braintree-payment-details');
    const order = data.order;
    const payment = order.billing.payment;

    let htmlToAppend = '';

    if (payment && payment.selectedPaymentInstruments
        && payment.selectedPaymentInstruments.length > 0) {
        payment.selectedPaymentInstruments.forEach(selectedPaymentInstrument => {
            const paymentMethodId = selectedPaymentInstrument.paymentMethod;
            const fundingSource = selectedPaymentInstrument.fundingSource;

            if (fundingSource === window.braintreeConstants.PP_FUNDING_SOURCE_PAYLATER) {
                htmlToAppend += `<div>${window.braintreeConstants.PP_PAYLATER_PAYMENT_TYPE}</div>`;
            } else if (fundingSource === window.braintreeConstants.PP_FUNDING_SOURCE_CARD) {
                htmlToAppend += `<div>${window.braintreeConstants.PP_DEBIT_CREDIT_PAYMENT_TYPE}</div>`;
            } else {
                htmlToAppend += `<div>${getPaymentMethodToLowerCase(paymentMethodId)}</div>`;
            }

            if (selectedPaymentInstrument.maskedCreditCardNumber) {
                htmlToAppend += `<div>${selectedPaymentInstrument.maskedCreditCardNumber}</div>`;
            }

            htmlToAppend += getHtmlFromPaymentMethodId(paymentMethodId, selectedPaymentInstrument);

            if (selectedPaymentInstrument.type) {
                htmlToAppend += `<div>${selectedPaymentInstrument.type}</div>`;
            }
            htmlToAppend += `<div>${order.priceTotal.charAt(0)}${selectedPaymentInstrument.amount}</div>`;
        });
    }

    if ($paymentSummary) {
        $paymentSummary.innerHTML = htmlToAppend;
    }
}

/**
 * Validates whether input field is valid
 * @param {Object} field Input filed
 * @returns {boolean} true/false
 */
function isValidInputField(field) {
    if (!field.checkValidity()) {
        if (!field.classList.contains(INVALID_CLASSNAME)) {
            field.classList.add(INVALID_CLASSNAME);
        }

        return false;
    }

    if (field.checkValidity() && field.classList.contains(INVALID_CLASSNAME)) {
        field.classList.remove(INVALID_CLASSNAME);
    }

    return true;
}

/**
 * Gets Billing Address Form Values
 *
 * @returns {Object} with Billing Address
 */
function getBillingAddressFormValues() {
    return $('#dwfrm_billing').serialize().split('&')
        .map(function (el) {
            return el.split('=');
        })
        .reduce(function (accumulator, item) {
            let elem = item[0].lastIndexOf('_');
            if (elem < 0) {
                accumulator[item[0]] = item[1];
            } else {
                elem = item[0].substring(elem + 1);
                accumulator[elem] = item[1];
            }
            return accumulator;
        }, {});
}

/**
 * Gets Nonce depending on payment method name
 *
 * @param {string} paymentMethodName - payment method name
 * @returns {boolean} nonce exist
 */

function isNonceExist(paymentMethodName) {
    // Payment method name
    let pmName = paymentMethodName;

    // Сhange 'CREDIT_CARD' to 'CreditCard' in order to get braintreewCreditCardNonce input
    if (paymentMethodName === 'CREDIT_CARD') {
        pmName = 'CreditCard';
    }

    const $nonce = document.querySelector(`#braintree${pmName}Nonce`);

    if (!$nonce) {
        return false;
    }

    const nonceValue = $nonce.value;
    const $tab = document.querySelector(`.${pmName.toLowerCase()}-tab`);
    let isActiveTab;
    if ($tab) {
        isActiveTab = $tab.classList.contains('active');
    }

    return !isActiveTab && nonceValue;
}


/**
 * Removing BT payment from account page
 * @param {Object} e Event object
 * @returns {void}
 */
function removeBtPayment(e) {
    const loaderInstance = require('./loaderHelper');

    const target = e.target;

    const $loaderContainter = document.getElementById(target.getAttribute('data-loader'));
    const accountsLoader = loaderInstance($loaderContainter);
    accountsLoader.show();

    $.get(`${window.braintreeUrls.deletePaymentUrl}?UUID=${target.getAttribute('data-id')}`)
        .then((data => {
            $('#uuid-' + data.UUID).remove();
            if (data.newDefaultAccount) {
                document.querySelector(`#uuid-${data.newDefaultAccount} span`).classList.add(cssClass.FONT_WEIGHT_BOLD);
                document.querySelector(`#uuid-${data.newDefaultAccount} button.js-braintree-make-default-card`).classList.add(cssClass.D_NONE);
            }
            $('body').trigger('cart:update');
            accountsLoader.hide();
        }))
        .fail(() => {
            location.reload();
            accountsLoader.hide();
        });
}

/**
 * Create formData from fields data
 *
 * @param {Object} paymentFields fields data values
 * @param {Object} fieldsData fields data values
 * @returns {Object} cart billing form data
 */
function createPaymentFormData(paymentFields, fieldsData) {
    let paymentFieldsParsed;

    if (typeof paymentFields === 'object') {
        paymentFieldsParsed = paymentFields;
    } else {
        paymentFieldsParsed = JSON.parse(paymentFields);
    }

    return Object.entries(paymentFieldsParsed).reduce(function (formData, entry) {
        const [key, field] = entry;
        if (typeof field === 'object') {
            formData.append(field.name, fieldsData && fieldsData[key] !== null ? fieldsData[key] : field.value);
        }
        return formData;
    }, new FormData());
}

function setDefaultProperty(params) {
    return $.get(`${params.url}?UUID=${params.id}&pmID=${params.paymentMethodID}`)
        .then((data) => {
            document.querySelector(`#uuid-${data.newDefaultProperty} span`).classList.add(cssClass.FONT_WEIGHT_BOLD);
            document.querySelector(`.js-braintree-make-default-card.uuid-${data.newDefaultProperty}`).classList.add(cssClass.D_NONE);
            document.querySelector(`#uuid-${data.toRemoveDefaultProperty} span`).classList.remove(cssClass.FONT_WEIGHT_BOLD);
            document.querySelector(`.js-braintree-make-default-card.uuid-${data.toRemoveDefaultProperty}`).classList.remove(cssClass.D_NONE);
            params.loader.hide();
        })
        .fail(() => {
            params.loader.hide();
        });
}

/**
 * Checks authenticated customer, account list for default Payment Method
 *
 * @param {string} selector - querySelector
 * @returns {Object} default data attribute or null
 */
function getOptionByDataDefault(selector) {
    if (!document.querySelector(selector)) {
        return null;
    }

    return Array.apply(null, document.querySelector(selector).options).find(function (el) {
        return el.getAttribute('data-default') ? JSON.parse(el.getAttribute('data-default')) : null;
    });
}

/**
 * Checks authenticated customer, account list for session Account
 *
 * @param {Object} params querySelector + el.id
 * @returns {Object} session account object
 */
function getSessionAccountOption(params) {
    return Array.apply(null, document.querySelector(params.querySelector).options).find(function (el) {
        return el.id === params.id && JSON.parse(el.getAttribute('data-session-account'));
    });
}

/**
 * This method is called to remove active session account but just in case
 * if tab of currently active session payment isn't active (buyer submited another payment method)
 * @returns {void}
 */
function removeActiveSessionPayment() {
    const activePaymentMethods = [];
    document.querySelectorAll('.payment-options[role=tablist] li').forEach(function (el) {
        activePaymentMethods.push(el.dataset.methodId);
    });
    const helpers = {
        PayPal: require('./paypal/components/payPalSessionAccount'),
        Venmo: require('./venmo/components/venmoSessionAccount'),
        GooglePay: require('./googlepay/components/googlePaySessionAccount'),
        CREDIT_CARD: require('./creditcard/components/creditCardSessionAccount'),
        SRC: require('./src/components/srcSessionAccount'),
        ApplePay: require('./applepay/helpers/applePayHelper')
    };
    const activePM = activePaymentMethods.find(function (el) {
        return isNonceExist(el);
    });
    if (activePM) {
        helpers[activePM].removeSessionNonce();
    }
}

/**
 * Update Checkout Billing form values
 *
 * @param {Object} billingData fields data values
 */
function updateBillingFormValues(billingData) {
    const $billingFormFields = document.querySelectorAll('.billing-address select, .billing-address input, .contact-info-block input');

    $billingFormFields.forEach(function (el) {
        if (billingData[el.name]) {
            el.value = billingData[el.name];
        }
    });
}

/**
 * Returns selected option from select container
 * @param {Object} $selectContainer Select container
 * @returns {Object} Selected option
 */
function getSelectedOption($selectContainer) {
    const selectedOptionIndex = $selectContainer.selectedIndex;

    return $selectContainer.options[selectedOptionIndex];
}

/**
 * Returns payment field data to be send on backend
 * @param {Object} addressData Address data to be set
 * @param {string} paymentMethodName Payment method name
 * @returns {Object} payment data
 */
function getPaymentFieldsData(addressData, paymentMethodName) {
    return {
        firstName: addressData.firstName,
        lastName: addressData.lastName,
        address1: addressData.streetAddress,
        address2: addressData.extendedAddress || '',
        city: addressData.locality,
        postalCode: decodeURIComponent(addressData.postalCode),
        stateCode: addressData.stateCode || addressData.region,
        country: addressData.countryCodeAlpha2,
        phone: addressData.phone,
        paymentMethod: paymentMethodName
    };
}

function getUpdatedStoreFrontBillingData(billingAddress) {
    const storeFrontBillingData = JSON.parse(document.querySelector('.braintree-billing-payment-wrap').getAttribute('data-billing-form-fields-names'));

    storeFrontBillingData.dwfrm_billing_addressFields_firstName = billingAddress.firstName;
    storeFrontBillingData.dwfrm_billing_addressFields_lastName = billingAddress.lastName;
    storeFrontBillingData.dwfrm_billing_addressFields_address1 = billingAddress.streetAddress;
    storeFrontBillingData.dwfrm_billing_addressFields_address2 = billingAddress.extendedAddress || '';
    storeFrontBillingData.dwfrm_billing_addressFields_city = billingAddress.locality;
    storeFrontBillingData.dwfrm_billing_addressFields_postalCode = decodeURIComponent(billingAddress.postalCode);
    storeFrontBillingData.dwfrm_billing_addressFields_states_stateCode = billingAddress.stateCode || billingAddress.region;
    storeFrontBillingData.dwfrm_billing_addressFields_country = billingAddress.countryCodeAlpha2;
    storeFrontBillingData.dwfrm_billing_contactInfoFields_phone = billingAddress.phone;

    return storeFrontBillingData;
}

/**
 * Remove all validation. Should be called every time before revalidating form
 * @param {HTMLFormElement} form - Form to be cleared
 * @returns {void}
 */
function clearForm(form) {
    Array.from(form.querySelectorAll('input, select')).forEach((element) => {
        if (element.classList.contains(INVALID_CLASSNAME)) {
            element.classList.remove(INVALID_CLASSNAME);
        }
    });
}

/**
 * Validate whole form
 * @param {HTMLFormElement} form - Form elemenent
 * @returns {boolean} - true if valid otherwise false
 */
function validateForm(form) {
    if (form.checkValidity && !form.checkValidity()) {
        Array.from(form.querySelectorAll('input, select')).forEach((element) => {
            if (!element.validity.valid) {
                element.classList.add(INVALID_CLASSNAME);
            }
        });

        return false;
    }

    return true;
}

module.exports = {
    continueButtonToggle,
    updateCheckoutView,
    isValidInputField,
    getBillingAddressFormValues,
    removeBtPayment,
    createPaymentFormData,
    isNonceExist,
    setDefaultProperty,
    getOptionByDataDefault,
    removeActiveSessionPayment,
    getSessionAccountOption,
    updateBillingFormValues,
    getSelectedOption,
    getPaymentFieldsData,
    getUpdatedStoreFrontBillingData,
    clearForm,
    validateForm
};
