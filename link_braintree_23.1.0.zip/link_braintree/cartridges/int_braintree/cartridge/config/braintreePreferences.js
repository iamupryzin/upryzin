'use strict';

/**
 * SFCC API inclusions.
 */
const PaymentMgr = require('dw/order/PaymentMgr');
const LocalServiceRegistry = require('dw/svc/LocalServiceRegistry');
const site = require('dw/system/Site').getCurrent();
const cacheBraintreePreferences = require('dw/system/CacheMgr').getCache('braintreePreferences');

/**
 * Custom API inclusions.
 */
const paypalButtonConfigs = require('~/cartridge/scripts/braintree/configuration/paypalButtonConfigs');
const SRCButtonConfig = require('../scripts/braintree/configuration/SRCButtonConfig');
const SDKEnableFundingHelper = require('../scripts/braintree/helpers/SDKEnableFundingHelper');

/**
 * Global constants.
 */
const serviceName = 'int_braintree.http.graphql.payment.Braintree';
const allowedProcessorsId = 'BRAINTREE_PAYPAL';
const btLoggingMode = 'all';
const btFraudToolsEnabled = true;
const btPaypalFraudToolsEnabled = true;
const btCreditCardDescriptorPhone = '';
const btCreditCardDescriptorName = '';
const btCreditCardDescriptorUrl = '';
const btPaypalDescriptor = '';
const connectWithPaypalStaticImageLink = 'https://www.paypalobjects.com/webstatic/en_US/developer/docs/login/connectwithpaypalbutton.png';

/**
 * Gets from credentials and returns tokenization key
 *
 * @returns {string} with tokenization key
 */
const getTokenizationKey = function () {
    const braintreeService = LocalServiceRegistry.createService(serviceName, {});

    return braintreeService.configuration.credential.custom.BRAINTREE_Tokenization_Key;
};

/**
 * Returns BT PayPal payment method ID
 *
 * @returns {string} active PayPal payment method ID
 */
const getBTPaypalPaymentProcessorId = function () {
    const activePaymentMethods = PaymentMgr.getActivePaymentMethods();
    let btPaypalPaymentProcessorID;

    Array.some(activePaymentMethods, function (paymentMethod) {
        if (paymentMethod.paymentProcessor.ID === allowedProcessorsId) {
            btPaypalPaymentProcessorID = paymentMethod.paymentProcessor.ID;
            return true;
        }
        return false;
    });

    return btPaypalPaymentProcessorID;
};

/**
 * Returns all custom site preferences
 *
 * @returns {Object} statis preferences
 */
const getCustomSitePreferencies = function () {
    return {
        merchantAccountIDs: site.getCustomPreferenceValue('BRAINTREE_Merchant_Account_IDs'),
        vaultMode: site.getCustomPreferenceValue('BRAINTREE_Vault_Mode'),
        isSettle: site.getCustomPreferenceValue('BRAINTREE_SETTLE'),
        isL2L3: site.getCustomPreferenceValue('BRAINTREE_L2_L3'),
        customFields: site.getCustomPreferenceValue('BRAINTREE_Custom_Fields'),

        is3DSecureEnabled: site.getCustomPreferenceValue('BRAINTREE_3DSecure_Enabled').getValue() === 'enabled',
        is3DSecureFallback: site.getCustomPreferenceValue('BRAINTREE_3DSecure_Fallback').getValue() === 'enabled',
        is3DSecureSkipClientValidationResult: site.getCustomPreferenceValue('BRAINTREE_3DSecure_Skip_Client_Validation_Result').getValue() === 'enabled',
        isCcReVerifyEnabled: site.getCustomPreferenceValue('BRAINTREE_CREDIT_REVERIFY_ENABLED'),
        is3DSecureVerificationAccountPage: site.getCustomPreferenceValue('BRAINTREE_3DSecure_Verification_Account_Page').getValue() === 'enabled',

        creditCardComplexBrandCodes: ['American Express', 'Maestro', 'UnionPay'],

        paypalDisplayName: site.getCustomPreferenceValue('BRAINTREE_PAYPAL_Display_Name'),
        paypalOrderIntent: site.getCustomPreferenceValue('BRAINTREE_PAYPAL_Is_Order_Intent'),
        paypalBillingAgreementDescription: site.getCustomPreferenceValue('BRAINTREE_PAYPAL_Billing_Agreement_Description'),
        paypalButtonLocation: site.getCustomPreferenceValue('BRAINTREE_PAYPAL_Button_Location').getValue(),
        changePMButtonEnabled: site.getCustomPreferenceValue('BRAINTREE_PAYPAL_ChangePaymentMethodButton_Enabled'),
        enableFundingList: SDKEnableFundingHelper.filterEnableFundingList(site.getCustomPreferenceValue('BRAINTREE_PAYPAL_Enable_Funding_List')),
        disableFundingList: site.getCustomPreferenceValue('BRAINTREE_PAYPAL_Disable_Funding_List'),

        applepayDisplayName: site.getCustomPreferenceValue('BRAINTREE_APPLEPAY_Display_Name'),
        applepayVisibilityOnCart: site.getCustomPreferenceValue('BRAINTREE_APPLEPAY_Visibility_Button_On_Cart'),

        venmoDisplayName: site.getCustomPreferenceValue('BRAINTREE_VENMO_Display_Name'),
        venmoAvailabilityCountries: ['US'],

        googlepayDisplayName: site.getCustomPreferenceValue('BRAINTREE_GOOGLEPAY_Display_Name'),
        googlepayVisibilityOnCart: site.getCustomPreferenceValue('BRAINTREE_GOOGLEPAY_Visibility_Button_On_Cart'),
        googleMerchantId: site.getCustomPreferenceValue('BRAINTREE_GOOGLEPAY_Google_Merchant_Id'),

        srcDisplayName: site.getCustomPreferenceValue('BRAINTREE_SRC_Display_Name'),
        srcVisibilityOnCart: site.getCustomPreferenceValue('BRAINTREE_SRC_Visibility_Button_On_Cart'),
        srcAvailabilityCountries: ['AE', 'AR', 'AU', 'BR', 'CA', 'CL', 'CN', 'CO', 'ES', 'FR', 'GB', 'HK', 'IE',
            'IN', 'KW', 'MX', 'MY', 'NZ', 'QA', 'PE', 'PL', 'SA', 'SG', 'UA', 'US', 'ZA'],

        isPayPalCreditEnabledInDropIn: site.getCustomPreferenceValue('BRAINTREE_Dropin_UI_Paypal_Credit_Button_Visibility'),
        /* CWPP - Connect with PayPal */
        cwppStaticImageLink: connectWithPaypalStaticImageLink,
        cwppButtonEnabled: site.getCustomPreferenceValue('BRAINTREE_PAYPAL_CWPP_Button_Enabled'),
        cwppButtonUrl: site.getCustomPreferenceValue('BRAINTREE_PAYPAL_CWPP_Button_Url'),
        cwppAgentLogin: site.getCustomPreferenceValue('BRAINTREE_PAYPAL_CWPP_Agent_Login'),
        cwppAgentPassword: site.getCustomPreferenceValue('BRAINTREE_PAYPAL_CWPP_Agent_Password'),
        apmaEnabled: site.getCustomPreferenceValue('BRAINTREE_PAYPAL_APMA_Enabled')
    };
};

/**
 * Adds _whiteList object property with preferences which would be shown on client side
 *
 * @param {Object} prefs - site custom preferences
 */
const addPrefsToWhiteList = function (prefs) {
    prefs._whiteListedForStorefront = {};

    // List of custom preferences keys that should be visible on client side
    const whiteList = ['paymentMethods'];

    // Make prefs from whiteList visible on client side
    whiteList.forEach(function (key) {
        prefs._whiteListedForStorefront[key] = JSON.parse(JSON.stringify(prefs[key]));
    });
};

const getPreference = function () {
    const cacheResult = cacheBraintreePreferences.get('btPreference');
    if (cacheResult) {
        return cacheResult;
    }

    const prefs = getCustomSitePreferencies();

    // Hardcoded preferences:
    prefs.loggingMode = btLoggingMode;
    prefs.isFraudToolsEnabled = btFraudToolsEnabled;
    prefs.isPaypalFraudToolsEnabled = btPaypalFraudToolsEnabled;
    prefs.creditCardDescriptorPhone = btCreditCardDescriptorPhone;
    prefs.creditCardDescriptorName = btCreditCardDescriptorName;
    prefs.creditCardDescriptorUrl = btCreditCardDescriptorUrl;
    prefs.paypalDescriptorName = btPaypalDescriptor;

    prefs.paypalIntent = prefs.isSettle ? 'capture' : 'authorize';
    prefs.paypalBillingAgreementDescription = empty(prefs.paypalBillingAgreementDescription) ? '' : prefs.paypalBillingAgreementDescription.slice(0, 249);
    prefs.btPaypalPaymentMethodId = getBTPaypalPaymentProcessorId();

    // PayPal Configs preferences:
    prefs.tokenizationKey = getTokenizationKey();
    prefs.paypalCartButtonConfig = paypalButtonConfigs.PAYPAL_Cart_Button_Config;
    prefs.paypalBillingButtonConfig = paypalButtonConfigs.PAYPAL_Billing_Button_Config;
    prefs.paypalMiniCartButtonConfig = paypalButtonConfigs.PAYPAL_MiniCart_Button_Config;
    prefs.paypalPdpButtonConfig = paypalButtonConfigs.PAYPAL_PDP_Button_Config;
    prefs.SRCBillingButtonConfig = SRCButtonConfig.SRC_Billing_Button_Config;
    prefs.SRCCartButtonConfig = SRCButtonConfig.SRC_Cart_Button_Config;
    prefs.SRCAccountButtonConfig = SRCButtonConfig.SRC_Account_Button_Config;

    if (prefs.paypalCartButtonConfig === null) {
        prefs.paypalCartButtonConfig = {};
    }

    if (prefs.paypalBillingButtonConfig === null) {
        prefs.paypalBillingButtonConfig = {};
    }
    if (prefs.paypalMiniCartButtonConfig === null) {
        prefs.paypalMiniCartButtonConfig = {};
    }
    if (prefs.paypalPdpButtonConfig === null) {
        prefs.paypalPdpButtonConfig = {};
    }

    // Hardcoded values that may not be configured in BM:
    prefs.apiVersion = 4;
    prefs.SRCImageLink = 'https://sandbox.secure.checkout.visa.com/wallet-services-web/xo/button.png';
    prefs.paymentMethods = require('~/cartridge/scripts/braintree/helpers/paymentHelper').getActivePaymentMethods();
    prefs.currencyCode = site.getDefaultCurrency();
    prefs.braintreeChannel = 'SFCC_BT_SFRA_23_1_0';
    prefs.userAgent = 'Braintree DW_Braintree 23.1.0';

    addPrefsToWhiteList(prefs);

    cacheBraintreePreferences.put('btPreference', prefs);
    return prefs;
};

module.exports = getPreference();
