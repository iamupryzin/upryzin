'use strict';

const SDKVersion = '3.85.3';
const dropinSDKVersion = '1.32.1';
const btGateWaySDKUrl = 'https://js.braintreegateway.com/web/' + SDKVersion;
const btGateWaySDKDropinUrl = 'https://js.braintreegateway.com/web/dropin/' + dropinSDKVersion;

module.exports = {
    clientSdk3ClientUrl: btGateWaySDKUrl + '/js/client.min.js',
    clientSdk3HostedFieldsUrl: btGateWaySDKUrl + '/js/hosted-fields.min.js',
    clientSdk3ThreeDSecureUrl: btGateWaySDKUrl + '/js/three-d-secure.min.js',
    clientSdk3DataCollectorUrl: btGateWaySDKUrl + '/js/data-collector.min.js',
    clientSdk3PayPalUrl: btGateWaySDKUrl + '/js/paypal.min.js',
    clientSdk3PayPalCheckoutUrl: btGateWaySDKUrl + '/js/paypal-checkout.min.js',
    clientVaultManagerUrl: btGateWaySDKUrl + '/js/vault-manager.min.js',
    clientSdk3ApplePayUrl: btGateWaySDKUrl + '/js/apple-pay.min.js',
    clientSdk3VenmoUrl: btGateWaySDKUrl + '/js/venmo.min.js',
    clientSdkLocalPaymentUrl: btGateWaySDKUrl + '/js/local-payment.min.js',
    googlePaySdkUrl: 'https://pay.google.com/gp/p/js/pay.js',
    braintreeGooglePaySdkUrl: btGateWaySDKUrl + '/js/google-payment.min.js',
    srcSdkUrl: 'https://sandbox-assets.secure.checkout.visa.com/checkout-widget/resources/js/integration/v1/sdk.js',
    braintreeSrcSdkUrl: btGateWaySDKUrl + '/js/visa-checkout.min.js',
    clientSdkDropinUrl: btGateWaySDKDropinUrl + '/js/dropin.min.js',
    applePayBtnSdk: 'https://applepay.cdn-apple.com/jsapi/v1/apple-pay-sdk.js'
};
