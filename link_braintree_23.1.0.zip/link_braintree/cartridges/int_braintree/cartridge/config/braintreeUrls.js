'use strict';

const URLUtils = require('dw/web/URLUtils');

module.exports = {
    accountShow: URLUtils.https('Account-Show').toString(),
    checkoutSubmitPayment: URLUtils.https('CheckoutServices-SubmitPayment').toString(),
    makePaymentMethodDefaultUrl: URLUtils.https('Braintree-MakePaymentMethodDefault').toString(),
    deleteDuplicateCreditCardUrl: URLUtils.url('Braintree-DeleteDuplicateCreditCard').toString(),
    placeOrderUrl: URLUtils.url('Checkout-Begin', 'stage', 'placeOrder').toString(),
    submitCustomerUrl: URLUtils.url('CheckoutServices-SubmitCustomer').toString(),
    deletePaymentUrl: URLUtils.url('PaymentInstruments-DeletePayment').toString(),
    paypalAddAccountHandlerUrl: URLUtils.url('Braintree-AccountAddPaypalHandle').toString(),
    checkoutFromCartUrl: URLUtils.https('CheckoutServices-SubmitPayment', 'fromCart', 'true').toString(),
    savePaypalDefaultAddressUrl: URLUtils.url('Braintree-SavePaypalDefaultAddress').toString()
};
