'use strict';

module.exports = {
    // flows
    FLOW_CHECKOUT: 'checkout',
    FLOW_VAULT: 'vault',
    // Pages flows
    PAGE_FLOW_CHECKOUT: 'checkout',
    PAGE_FLOW_ACCOUNT: 'account',
    PAGE_FLOW_CART: 'cart',
    PAGE_FLOW_MINICART: 'minicart',
    PAGE_FLOW_PDP: 'pdp',
    // Intents
    INTENT_TYPE_ORDER: 'order',
    // PayPal button configs
    BUTTON_CONFIG_OPTIONS_STYLE_LAYOUT_HORIZONTAL: 'horizontal',
    BUTTON_CONFIG_OPTIONS_STYLE_SHAPE_RECT: 'rect',
    BUTTON_CONFIG_OPTIONS_STYLE_SIZE_MEDIUM: 'medium',
    BUTTON_CONFIG_OPTIONS_STYLE_SIZE_SMALL: 'small',
    BUTTON_CONFIG_PAYPAL: 'paypal',
    // Endpoint names
    ENDPOINT_ACCOUNT_ADD_SRC_HANDLE_NAME: 'AccountAddSrcHandle',
    ENDPOINT_ACCOUNT_ADD_GOOGLE_PAY_HANDLE_NAME: 'AccountAddGooglePayHandle',
    ENDPOINT_ACCOUNT_ADD_CREDIT_CARD_HANDLE_NAME: 'AccountAddCreditCardHandle',
    ENDPOINT_ACCOUNT_ADD_VENMO_HANDLE_NAME: 'AccountAddVenmoHandle',
    // Params
    PARAM_NONCE: 'Nonce',
    // Payment processor IDs
    PAYMENT_PROCCESSOR_ID_BRAINTREE_CREDIT: 'BRAINTREE_CREDIT',
    PAYMENT_PROCCESSOR_ID_BRAINTREE_PAYPAL: 'BRAINTREE_PAYPAL',
    PAYMENT_PROCCESSOR_ID_BRAINTREE_APPLEPAY: 'BRAINTREE_APPLEPAY',
    PAYMENT_PROCCESSOR_ID_BRAINTREE_VENMO: 'BRAINTREE_VENMO',
    PAYMENT_PROCCESSOR_ID_BRAINTREE_SRC: 'BRAINTREE_SRC',
    PAYMENT_PROCCESSOR_ID_BRAINTREE_LOCAL: 'BRAINTREE_LOCAL',
    PAYMENT_PROCCESSOR_ID_BRAINTREE_GOOGLEPAY: 'BRAINTREE_GOOGLEPAY',
    // Payment method IDs
    PAYMENT_METHOD_ID_PAYPAL: 'PayPal',
    PAYMENT_METHOD_ID_VENMO: 'Venmo',
    PAYMENT_METHOD_ID_GOOGLEPAY: 'GooglePay',
    PAYMENT_METHOD_ID_SRC: 'SRC',
    PAYMENT_METHOD_ID_APPLEPAY: 'ApplePay',
    PAYMENT_METHOD_ID_LPM: 'LPM',
    PAYMENT_METHOD_ID_CREDIT_CARD: 'CREDIT_CARD',
    // GraphQl call query names
    QUERY_NAME_LEGACY_ID_CONVERTER: 'legacyIdConverter',
    QUERY_NAME_SEARCH_TRANSACTION: 'searchTransaction',
    QUERY_NAME_CLIENT_ID: 'clientId',
    QUERY_NAME_VAULT_PAYMENT_METHOD: 'vaultPaymentMethod',
    QUERY_NAME_VAULT_CREDIT_CARD: 'vaultCreditCard',
    QUERY_NAME_DELETE_PAYMENT_METHOD: 'deletePaymentMethodFromVault',
    QUERY_NAME_SEARCH_CUSTOMER: 'searchCustomer',
    QUERY_NAME_CREATE_CUSTOMER: 'createCustomer',
    QUERY_NAME_SALE: 'sale',
    QUERY_NAME_AUTHORIZATION: 'authorization',
    QUERY_NAME_PAYPAL_SALE: 'chargePaypal',
    QUERY_NAME_PAYPAL_AUTHORIZATION: 'authorizePaypal',
    QUERY_NAME_UPDATE_CREDIT_CARD_BILLING_ADDRESS: 'updateCreditCardBillingAddress',
    QUERY_NAME_CHARGE_CREDIT_CARD: 'chargeCreditCard',
    QUERY_NAME_AUTHORIZE_CREDIT_CARD: 'authorizeCreditCard',
    QUERY_NAME_VERIFY_CREDIT_CARD: 'verifyCreditCard',
    QUERY_NAME_UPDATE_CUSTUMER: 'updateCustomer',
    // Legacy ID types for graphQL calls
    LEGACY_ID_TYPE_CUSTOMER: 'CUSTOMER',
    LEGACY_ID_TYPE_PAYMENT_METHOD: 'PAYMENT_METHOD',
    LEGACY_ID_TYPE_TRANSACTION: 'TRANSACTION',
    // Card types
    CREDIT_CARD_TYPE_VISA: 'visa',
    GOOGLEPAY_TYPE_ANDROID_PAY_CARD: 'AndroidPayCard',
    // Input values
    NEW_ACCOUNT: 'newaccount',
    SESSION_CARD: 'sessioncard',
    // Transaction statuses
    TRANSACTION_STATUS_SETTLING: 'SETTLING',
    TRANSACTION_STATUS_SUBMITTED_FOR_SETTLEMENT: 'SUBMITTED_FOR_SETTLEMENT',
    TRANSACTION_STATUS_AUTHORIZED: 'AUTHORIZED',
    TRANSACTION_STATUS_SETTLED: 'SETTLED',
    TRANSACTION_STATUS_SETTLEMENT_PENDING: 'SETTLEMENT_PENDING',
    // BT webHooks notification types
    TYPE_PAYMENT_METHOD_REVOKED_BY_CUSTOMER: 'payment_method_revoked_by_customer',
    // etc.
    TRANSACTION_VAULT_ON_SUCCESS: 'ON_SUCCESSFUL_TRANSACTION',
    LINE_ITEMS_KIND: 'DEBIT',
    // 'Payment method details' types from Braintree
    PAYPAL_ACCOUNT_DETAILS_TYPE: 'PayPalAccountDetails',
    CREDIT_CARD_DETAILS_TYPE: 'CreditCardDetails',
    // Instance types
    DEVELOPMENT_SYSTEM_TYPE: 'TEST',
    PRODUCTION_SYSTEM_TYPE: 'PRODUCTION',
    // GraphQl PaymentMethodOrigin types
    APPLE_PAY_ORIGIN_TYPE: 'APPLE_PAY',
    GOOGLE_PAY_ORIGIN_TYPE: 'GOOGLE_PAY',
    // Payment methods
    PAYMENT_METHOD_CREDIT_CARD: 'CREDIT_CARD',
    // BT PayPal Smart Buttons funding sources types
    PP_FUNDING_SOURCE_CARD: 'card',
    PP_FUNDING_SOURCE_PAYLATER: 'paylater',
    // BT PayPal Smart Buttons payments types
    PP_DEBIT_CREDIT_PAYMENT_TYPE: 'PayPal Debit/Credit Card',
    PP_PAYLATER_PAYMENT_TYPE: 'PayPal Paylater',
    // Verification statuses
    VERIFICATION_GATEWAY_REJECTED_STATUS: 'GATEWAY_REJECTED',
    // Route statuses
    SERVER_SUBSCRIPTION_ROUTE_COMPLETE: 'route:Complete',
    // Flash message types
    FLASH_MESSAGE_SUCCESS: 'success',
    FLASH_MESSAGE_INFO: 'info',
    FLASH_MESSAGE_DANGER: 'danger',
    // Endpoint names
    ENDPOINT_BRAINTREE_APMA: 'Braintree-APMA',
    ENDPOINT_HOME_SHOW: 'Home-Show',
    // Connect with PayPal
    LOGIN_PAYPAL: 'login-PayPal',
    CWPP_DEFAULT_PHONE: 'Not provided',
    // APMA (Automatic Payment Method Adding)
    APMA_STAGE_COMPLETE: 'complete',
    APMA_STAGE_ADDRESS: 'address',
    APMA_STAGE_ACCOUNT: 'account',
    APMA_QUERY_PARAMETER_TRUE: '?isAPMAFlow=true',
    BILLING_ADDRESS_ID: 'Billing address',
    SHIPPING_ADDRESS_ID: 'Shipping address'
};
