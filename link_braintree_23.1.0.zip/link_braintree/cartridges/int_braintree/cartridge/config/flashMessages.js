'use strict';

/* global session */

const flashMessages = {};

/**
 * checks if exists custom attribute by key
 * @param {string} key A custom attribute key
 * @returns {boolean} Returns whether the custom attribute is set in the session.
 */
flashMessages.has = function (key) {
    return !empty(session.custom[key]);
};

/**
 * Store a custom attribute value by key
 * @param {string} key A custom attribute key
 * @param {string} value A custom attribute value
 * @returns {void}
 */
flashMessages.put = function (key, value) {
    session.custom[key] = value;
};

/**
 * Delete a custom attribute by key
 * @param {string} key A custom attribute key
 * @returns {void}
 */
flashMessages.delete = function (key) {
    if (this.has(key)) {
        delete session.custom[key];
    }
};

/**
 * Get a custom attribute value
 * @param {string} key A custom attribute key
 * @returns {mixed} Returns the custom attribute value by key
 */
flashMessages.get = function (key) {
    if (this.has(key)) {
        const value = session.custom[key];

        this.delete(key);

        return value;
    }

    return false;
};

module.exports = flashMessages;
