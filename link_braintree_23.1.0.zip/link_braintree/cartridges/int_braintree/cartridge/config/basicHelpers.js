'use strict';

const basicHelpers = {};

/**
 * @param {mixed} value object key
 * @param {mixed} defaultValue default value
 * @returns {mixed} return current or default value
 */
basicHelpers.getValueOr = function (value, defaultValue) {
    return value || defaultValue;
};

/**
 * @param {Object} object object
 * @param {mixed} key object key
 * @param {mixed} defaultValue default value
 * @returns {mixed} return value by key or default value
 */
basicHelpers.getValueByKey = function (object, key, defaultValue) {
    if (typeof key === 'string' && key.indexOf('.') > 0) {
        const keys = key.split('.');
        const newObject = object[keys.shift()];

        if (!newObject) {
            return defaultValue;
        }

        return this.getValueByKey(newObject, keys.join('.'), defaultValue);
    }

    return this.getValueOr(object[key], defaultValue);
};

/**
 * @param {string} brandCode credit card brand code
 * @returns {string} properly formatted variant of credit card brand code
 */
basicHelpers.formatComplexCCBrandCode = function (brandCode) {
    const braintreePreferences = require('~/cartridge/config/braintreePreferences');
    const creditCardComplexBrandCode = braintreePreferences.creditCardComplexBrandCodes.find(function (formattedBrandCode) {
        return brandCode.replace(/_/g, ' ').includes(formattedBrandCode.toLowerCase()) || brandCode.replace(/_/g, '').includes(formattedBrandCode.toLowerCase());
    });
    // TODO test if there's same error of not showing up on account page with JCB as with UnionPay/Maestro once JCB is added to default mechant id as acceptable payment method

    return creditCardComplexBrandCode || brandCode.replace(brandCode.charAt(0), brandCode.charAt(0).toUpperCase());
};

module.exports = basicHelpers;
