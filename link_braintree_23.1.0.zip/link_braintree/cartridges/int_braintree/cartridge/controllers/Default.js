'use strict';

/**
 * @namespace Default
 */
const server = require('server');
server.extend(module.superModule);

/**
 * Custom API inclusions.
 */
const cache = require('*/cartridge/scripts/middleware/cache');
const consentTracking = require('*/cartridge/scripts/middleware/consentTracking');

server.append('Start', consentTracking.consent, cache.applyDefaultCache, function (req, res, next) {
    res.setViewData({
        action: 'Home-Show'
    });

    next();
});

module.exports = server.exports();
