'use strict';

/**
 * @namespace Product
 */
const server = require('server');
server.extend(module.superModule);

/**
 * Custom API inclusions.
 */
const customerHelper = require('~/cartridge/scripts/braintree/helpers/customerHelper');
const paymentHelper = require('~/cartridge/scripts/braintree/helpers/paymentHelper');
const buttonConfigHelper = require('~/cartridge/scripts/braintree/helpers/buttonConfigHelper');
const btBusinessLogic = require('~/cartridge/scripts/braintree/braintreeAPI/braintreeBusinessLogic');
const csrfProtection = require('*/cartridge/scripts/middleware/csrf');
const prefs = require('~/cartridge/config/braintreePreferences');
const braintreeSDK = require('*/cartridge/config/braintreeSDK');
const braintreeConstants = require('~/cartridge/config/braintreeConstants');

server.append('Show', csrfProtection.generateToken, function (req, res, next) {
    var isSetProductType = !empty(res.getViewData().product.individualProducts);

    if (!paymentHelper.isPaypalButtonEnabled('pdp') || isSetProductType) {
        next();
        return;
    }

    var BasketMgr = require('dw/order/BasketMgr');
    var basket = BasketMgr.getCurrentOrNewBasket();

    var clientToken = btBusinessLogic.getClientToken(basket.getCurrencyCode());
    var payPalButtonConfig = null;
    var defaultPaypalAddress = null;
    var isBasketEmpty = basket.getProductLineItems().isEmpty();
    var isCustomerEmailEmpty = empty(basket.getCustomerEmail());
    var dafaultPaypalShippingAddress = null;

    if (prefs.paymentMethods.BRAINTREE_PAYPAL.isActive) {
        payPalButtonConfig = buttonConfigHelper.createBraintreePayPalButtonConfig(basket, clientToken, braintreeConstants.PAGE_FLOW_PDP);

        if (res.getViewData().product.price.sales) {
            payPalButtonConfig.options.amount = parseFloat(res.getViewData().product.price.sales.decimalPrice);
        }

        var customerPaypalInstruments = customerHelper.getDefaultCustomerPaypalPaymentInstrument();

        if (customerPaypalInstruments) {
            defaultPaypalAddress = customer.getAddressBook().getPreferredAddress();

            // Creates the shipping address for 'ChangePM' button behavior
            if (!empty(defaultPaypalAddress) && payPalButtonConfig.changePMButtonEnabled) {
                dafaultPaypalShippingAddress = customerHelper.getDefaultCustomerShippingAddress(defaultPaypalAddress);
            }
        }
    }

    var braintree = {
        prefs: prefs,
        sdkUrls: braintreeSDK,
        payPalButtonConfig: payPalButtonConfig,
        cartQuantity: basket.productQuantityTotal,
        sfraCheckoutFormFields: paymentHelper.getSFRACheckoutFormFields(),
        sfraCustomerFormFields: paymentHelper.getSFRACustomerFormFields(),
        clientToken: clientToken,
        isBasketEmpty: isBasketEmpty,
        isCustomerEmailEmpty: isCustomerEmailEmpty,
        // An Address for change PM button behavior
        dafaultPaypalShippingAddress: dafaultPaypalShippingAddress
    };

    res.setViewData({
        braintree: braintree,
        addressForm: server.forms.getForm('address')
    });

    next();
});

module.exports = server.exports();
