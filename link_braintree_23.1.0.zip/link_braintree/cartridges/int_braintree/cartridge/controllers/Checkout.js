'use strict';

/**
 * @namespace Checkout
 */
const server = require('server');
server.extend(module.superModule);

/**
 * SFCC API inclusions.
 */
const Resource = require('dw/web/Resource');

/**
 * Custom API inclusions.
 */
const buttonConfigHelper = require('~/cartridge/scripts/braintree/helpers/buttonConfigHelper');
const paymentConfigHelper = require('~/cartridge/scripts/braintree/helpers/paymentConfigHelper');
const paymentHelper = require('~/cartridge/scripts/braintree/helpers/paymentHelper');
const customerHelper = require('~/cartridge/scripts/braintree/helpers/customerHelper');
const btBusinessLogic = require('~/cartridge/scripts/braintree/braintreeAPI/braintreeBusinessLogic');
const prefs = require('~/cartridge/config/braintreePreferences');
const braintreeSDK = require('*/cartridge/config/braintreeSDK');
const braintreeConstants = require('~/cartridge/config/braintreeConstants');

/**
* Gets Array with SFRA Checkout, Form Fields Names
* @returns {Function} Array with valid checkout Form Fields Names
*/
function getSFRABillingFormFieldsNames() {
    return paymentHelper.getAccountNameFields(paymentHelper.createBillingFormFields(), {
        firstName: '',
        lastName: '',
        address1: '',
        address2: '',
        city: '',
        postalCode: '',
        stateCode: '',
        country: '',
        email: '',
        phone: ''
    });
}

/**
* Creates config Brantree hosted fields
* @param {Response} res Response system object
* @param {string} clientToken Braintree clientToken
* @returns {Object} hosted fields config object
*/
function createHostedFieldsConfig(res, clientToken) {
    const Site = require('dw/system/Site');
    const isEnable3dSecure = prefs.is3DSecureEnabled;
    const billingData = res.getViewData();
    const cardForm = billingData.forms.billingForm.creditCardFields;
    const currentCurrencyCode = paymentHelper.findCurrentSiteCurrency(Site.current.allowedCurrencies.toArray()) || Site.current.getDefaultCurrency();

    return {
        merchantAccountId: paymentHelper.getMerchantAccountID(currentCurrencyCode),
        paymentMethodName: prefs.paymentMethods.BRAINTREE_CREDIT.paymentMethodId,
        is3dSecureEnabled: isEnable3dSecure,
        is3dSecureFallback: prefs.is3DSecureFallback,
        isFraudToolsEnabled: prefs.isFraudToolsEnabled,
        isSkip3dSecureLiabilityResult: prefs.is3DSecureSkipClientValidationResult,
        isCcReVerifyEnabled: prefs.isCcReVerifyEnabled,
        isSavedCreditCard: customer.authenticated && paymentHelper.getApplicableCreditCardPaymentInstruments().length !== 0,
        clientToken: clientToken,
        messages: {
            validation: Resource.msg('braintree.creditcard.error.validation', 'locale', null),
            secure3DFailed: Resource.msg('braintree.creditcard.error.secure3DFailed', 'locale', null),
            HOSTED_FIELDS_FIELDS_EMPTY: Resource.msg('braintree.creditcard.error.HOSTED_FIELDS_FIELDS_EMPTY', 'locale', null),
            HOSTED_FIELDS_FIELDS_INVALID: Resource.msg('braintree.creditcard.error.HOSTED_FIELDS_FIELDS_INVALID', 'locale', null),
            HOSTED_FIELDS_FAILED_TOKENIZATION: Resource.msg('braintree.creditcard.error.HOSTED_FIELDS_FAILED_TOKENIZATION', 'locale', null),
            HOSTED_FIELDS_TOKENIZATION_NETWORK_ERROR: Resource.msg('braintree.creditcard.error.HOSTED_FIELDS_TOKENIZATION_NETWORK_ERROR', 'locale', null),
            CLIENT_REQUEST_TIMEOUT: Resource.msg('braintree.error.CLIENT_REQUEST_TIMEOUT', 'locale', null),
            CLIENT_GATEWAY_NETWORK: Resource.msg('braintree.error.CLIENT_GATEWAY_NETWORK', 'locale', null),
            CLIENT_REQUEST_ERROR: Resource.msg('braintree.error.CLIENT_REQUEST_ERROR', 'locale', null),
            CLIENT_MISSING_GATEWAY_CONFIGURATION: Resource.msg('braintree.error.CLIENT_MISSING_GATEWAY_CONFIGURATION', 'locale', null)
        },
        amount: 0,
        fieldsConfig: {
            initOwnerValue: '',
            ownerHtmlName: cardForm.cardOwner.htmlName,
            typeHtmlName: cardForm.cardType.htmlName,
            numberHtmlName: cardForm.cardNumber.htmlName,
            expirationMonth: cardForm.expirationMonth.htmlName,
            expirationYear: cardForm.expirationYear.htmlName,
            cvvToDisplayInnerHtml: Resource.msg('braintree.creditcard.cvv.todisplay.innerhtml', 'locale', null)
        },
        customMessages: {
            WROND_CHECKOUT_FLOW: Resource.msg('braintree.credit.error.wrong.WROND_CHECKOUT_FLOW', 'locale', null),
            TOTAL_BASKET_AMOUNT_INVALID: Resource.msg('braintree.credit.error.total.basket.amount.invalid', 'locale', null),
            REVERIFY_CC: Resource.msg('braintree.creditcard.HOSTED_FIELDS_CVV_REVERIFY_MSG', 'locale', null),
            HOSTED_FIELDS_INSTANCE_NOT_DEFINE: Resource.msg('braintree.creditcard.HOSTED_FIELDS_INSTANCE_NOT_DEFINE', 'locale', null),
            VALIDATION_INVALID: Resource.msg('braintree.error.validation.invalid', 'locale', null)
        },
        vaultCreditCardUrl: require('dw/web/URLUtils').url('Braintree-VaultCreditCard').toString()
    };
}

server.append('Begin', function (req, res, next) {
    const BasketMgr = require('dw/order/BasketMgr');
    const basket = BasketMgr.getCurrentBasket();

    if (!basket) {
        next();
        return;
    }

    const viewData = res.getViewData();
    const orderModel = viewData.order;
    const selectedBillingAddress = orderModel.billing.billingAddress.address;
    customerHelper.formatCustomerName(viewData.order.shipping);

    const clientToken = btBusinessLogic.getClientToken(basket.getCurrencyCode());
    let paymentMethod;
    let payPalButtonConfig = null;
    let applePayButtonConfig = null;
    let venmoButtonConfig = null;
    let lpmButtonConfig = null;
    let googlepayButtonConfig = null;
    let googlepayConfig = {};
    let paypalConfig = {};
    let creditCardConfig = {};
    let venmoConfig = {};
    let hostedFieldsConfig = {};
    let srcConfig = {};
    let srcButtonConfig = {};
    let lpmPaymentOptions;
    let isActiveLpmPaymentOptions;
    let isSettle;

    if (customer.authenticated) {
        // Remove payment instruments in case they was removed from BT side
        paymentHelper.deleteNotVaultedPaymentInstruments(customer);
    }

    if (prefs.paymentMethods.BRAINTREE_PAYPAL.isActive) {
        payPalButtonConfig = buttonConfigHelper.createBraintreePayPalButtonConfig(basket, clientToken, braintreeConstants.PAGE_FLOW_CHECKOUT);
        paymentMethod = basket.getPaymentInstruments(prefs.paymentMethods.BRAINTREE_PAYPAL.paymentMethodId);
        paypalConfig = paymentConfigHelper.createPaypalConfig(paymentMethod);
    }

    if (prefs.paymentMethods.BRAINTREE_VENMO.isActive) {
        venmoButtonConfig = buttonConfigHelper.createBraintreeVenmoButtonConfig(basket, clientToken);
        paymentMethod = basket.getPaymentInstruments(prefs.paymentMethods.BRAINTREE_VENMO.paymentMethodId);
        venmoConfig = paymentConfigHelper.createVenmoConfig(paymentMethod);
    }

    if (prefs.paymentMethods.BRAINTREE_APPLEPAY.isActive) {
        applePayButtonConfig = buttonConfigHelper.createBraintreeApplePayButtonConfig(basket, clientToken, braintreeConstants.PAGE_FLOW_CHECKOUT);
    }

    if (prefs.paymentMethods.BRAINTREE_CREDIT.isActive) {
        paymentMethod = basket.getPaymentInstruments(require('dw/order/PaymentInstrument').METHOD_CREDIT_CARD);
        creditCardConfig = paymentConfigHelper.createCreditCardConfig(paymentMethod);
        hostedFieldsConfig = createHostedFieldsConfig(res, clientToken);
    }

    if (prefs.paymentMethods.BRAINTREE_LOCAL.isActive) {
        isActiveLpmPaymentOptions = prefs.paymentMethods.BRAINTREE_LOCAL.isActive;
        isSettle = prefs.isSettle;
        lpmButtonConfig = buttonConfigHelper.createBraintreeLocalPaymentMethodButtonConfig(basket, clientToken);
        lpmPaymentOptions = require('~/cartridge/scripts/braintree/helpers/paymentHelper').getApplicableLocalPaymentMethods({
            applicablePaymentMethods: res.viewData.order.billing.payment.applicablePaymentMethods,
            paymentMethodIds: prefs.paymentMethods.BRAINTREE_LOCAL.paymentMethodIds
        });
    }

    if (prefs.paymentMethods.BRAINTREE_GOOGLEPAY.isActive) {
        googlepayButtonConfig = buttonConfigHelper.createBraintreeGooglePayButtonConfig(basket, clientToken, braintreeConstants.PAGE_FLOW_CHECKOUT);
        paymentMethod = basket.getPaymentInstruments(prefs.paymentMethods.BRAINTREE_GOOGLEPAY.paymentMethodId);
        googlepayConfig = paymentConfigHelper.createGooglepayConfig(paymentMethod);
    }

    if (prefs.paymentMethods.BRAINTREE_SRC.isActive) {
        srcButtonConfig = buttonConfigHelper.createBraintreeSrcButtonConfig(basket, clientToken, braintreeConstants.PAGE_FLOW_CHECKOUT);
        paymentMethod = basket.getPaymentInstruments(prefs.paymentMethods.BRAINTREE_SRC.paymentMethodId);
        srcConfig = paymentConfigHelper.createSrcConfig(paymentMethod);
    }

    res.setViewData({
        braintree: {
            prefs: prefs,
            sdkUrls: braintreeSDK,
            currency: basket.getCurrencyCode(),
            paypalConfig: paypalConfig,
            payPalButtonConfig: payPalButtonConfig,
            applePayButtonConfig: applePayButtonConfig,
            venmoButtonConfig: venmoButtonConfig,
            venmoConfig: venmoConfig,
            hostedFieldsConfig: hostedFieldsConfig,
            creditCardConfig: creditCardConfig,
            lpmPaymentOptions: lpmPaymentOptions,
            isActiveLpmPaymentOptions: isActiveLpmPaymentOptions,
            isSettle: isSettle,
            lpmButtonConfig: lpmButtonConfig,
            googlepayButtonConfig: googlepayButtonConfig,
            googlepayConfig: googlepayConfig,
            srcConfig: srcConfig,
            srcButtonConfig: srcButtonConfig,
            sfraBillingFormFieldsNames: getSFRABillingFormFieldsNames(),
            clientToken: clientToken,
            selectedBillingAddress: selectedBillingAddress
        }
    });

    next();
});

module.exports = server.exports();
