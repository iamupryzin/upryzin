'use strict';

/**
 * @namespace Account
 */
const server = require('server');
server.extend(module.superModule);

/**
 * SFCC API inclusions.
 */
const Resource = require('dw/web/Resource');
const site = require('dw/system/Site').current;

/**
 * Models.
 */
const AccountModel = require('*/cartridge/models/account');

/**
 * Custom API inclusions.
 */
const prefs = require('~/cartridge/config/braintreePreferences');
const sdkUrls = require('*/cartridge/config/braintreeSDK');
const btBusinessLogic = require('~/cartridge/scripts/braintree/braintreeAPI/braintreeBusinessLogic');
const csrfProtection = require('*/cartridge/scripts/middleware/csrf');
const userLoggedIn = require('*/cartridge/scripts/middleware/userLoggedIn');
const consentTracking = require('*/cartridge/scripts/middleware/consentTracking');
const paymentHelper = require('~/cartridge/scripts/braintree/helpers/paymentHelper');
const accountButtonConfigHelper = require('~/cartridge/scripts/braintree/helpers/accountButtonConfigHelper');
const customerHelper = require('~/cartridge/scripts/braintree/helpers/customerHelper');

/**
 * Global constants.
 */
const currentCurrency = paymentHelper.findCurrentSiteCurrency(site.allowedCurrencies.toArray()) || site.defaultCurrency;
const clientToken = btBusinessLogic.getClientToken(currentCurrency);

/**
* Creates config for hosted fields
* @param {Object} cardForm The string to repeat.
* @returns {Object} configuration object
*/
function createHostedFieldsConfig(cardForm) {
    return {
        merchantAccountId: paymentHelper.getMerchantAccountID(currentCurrency),
        paymentMethodName: prefs.paymentMethods.BRAINTREE_CREDIT.paymentMethodId,
        is3dSecureEnabled: prefs.is3DSecureEnabled,
        is3dSecureFallback: prefs.is3DSecureFallback,
        is3DSecureVerificationAccountPage: prefs.is3DSecureVerificationAccountPage,
        isFraudToolsEnabled: prefs.isFraudToolsEnabled,
        isSkip3dSecureLiabilityResult: prefs.is3DSecureSkipClientValidationResult,
        clientToken: clientToken,
        // Read-only value. Is used to separate initialization of the hosted fields on the Account and Checkout pages
        isCcReVerifyEnabled: false,
        messages: {
            validation: Resource.msg('braintree.creditcard.error.validation', 'locale', null),
            secure3DFailed: Resource.msg('braintree.creditcard.error.secure3DFailed', 'locale', null),
            HOSTED_FIELDS_FIELDS_EMPTY: Resource.msg('braintree.creditcard.error.HOSTED_FIELDS_FIELDS_EMPTY', 'locale', null),
            HOSTED_FIELDS_FIELDS_INVALID: Resource.msg('braintree.creditcard.error.HOSTED_FIELDS_FIELDS_INVALID', 'locale', null),
            HOSTED_FIELDS_FAILED_TOKENIZATION: Resource.msg('braintree.creditcard.error.HOSTED_FIELDS_FAILED_TOKENIZATION', 'locale', null),
            HOSTED_FIELDS_TOKENIZATION_NETWORK_ERROR: Resource.msg('braintree.creditcard.error.HOSTED_FIELDS_TOKENIZATION_NETWORK_ERROR', 'locale', null),
            CLIENT_REQUEST_TIMEOUT: Resource.msg('braintree.error.CLIENT_REQUEST_TIMEOUT', 'locale', null),
            CLIENT_GATEWAY_NETWORK: Resource.msg('braintree.error.CLIENT_GATEWAY_NETWORK', 'locale', null),
            CLIENT_REQUEST_ERROR: Resource.msg('braintree.error.CLIENT_REQUEST_ERROR', 'locale', null),
            CLIENT_MISSING_GATEWAY_CONFIGURATION: Resource.msg('braintree.error.CLIENT_MISSING_GATEWAY_CONFIGURATION', 'locale', null)
        },
        amount: 1,
        fieldsConfig: {
            initOwnerValue: '',
            ownerHtmlName: cardForm.cardOwner.htmlName,
            typeHtmlName: cardForm.cardType.htmlName,
            numberHtmlName: cardForm.cardNumber.htmlName
        },
        customMessages: {
            CARD_ALREADY_EXIST_ERROR_MESSAGE: Resource.msg('braintree.account.error.existentCard', 'locale', null),
            REVERIFY_CC: Resource.msg('braintree.creditcard.HOSTED_FIELDS_CVV_REVERIFY_MSG', 'locale', null),
            CARD_VERIFY_ERROR_MESSAGE: Resource.msg('braintree.account.error.verifyCard', 'locale', null),
            VALIDATION_INVALID: Resource.msg('braintree.error.validation.invalid', 'locale', null)
        }
    };
}

server.append(
    'Show',
    csrfProtection.generateToken,
    consentTracking.consent,
    userLoggedIn.validateLoggedIn,
    function (req, res, next) {
        // SFCC API inclusions
        const CustomerModel = require('*/cartridge/models/customer');
        const URLUtils = require('dw/web/URLUtils');
        const Locale = require('dw/util/Locale');

        const customerInstance = new CustomerModel(customer);
        const cwppAddress = customerInstance.getCWPPCustomerAddress();

        // Updates a customer address from 'Connect with PayPal' with phone number
        // as 'Not Provided' in case if phone === null
        if (cwppAddress && cwppAddress.phone === null) {
            const Transaction = require('dw/system/Transaction');

            Transaction.wrap(function () {
                customerInstance.setPhone(Resource.msg('braintree.account.address.phonenumber.notprovided', 'locale', null));
            });

            res.viewData.account.addresses.forEach(function (address) {
                if (address.ID === cwppAddress.ID) {
                    address.phone = cwppAddress.phone;
                }
            });

            if (res.viewData.account.preferredAddress.address.ID === cwppAddress.ID) {
                res.viewData.account.preferredAddress.address.phone = cwppAddress.phone;
            }
        }

        // Remove payment instruments in case they was removed from BT side
        paymentHelper.deleteNotVaultedPaymentInstruments(customer);

        const CREDIT_CARD = require('dw/order/PaymentInstrument').METHOD_CREDIT_CARD;
        const creditCardPaymentInstruments = AccountModel.getCustomerPaymentInstruments(customerHelper.getCustomerPaymentInstruments(CREDIT_CARD));
        const paypalPaymentInstruments = AccountModel.getCustomerPaymentInstruments(customerHelper.getCustomerPaymentInstruments(prefs.paymentMethods.BRAINTREE_PAYPAL.paymentMethodId));
        const venmoPaymentInstruments = AccountModel.getCustomerPaymentInstruments(customerHelper.getCustomerPaymentInstruments(prefs.paymentMethods.BRAINTREE_VENMO.paymentMethodId));
        const srcPaymentInstruments = AccountModel.getCustomerPaymentInstruments(customerHelper.getCustomerPaymentInstruments(prefs.paymentMethods.BRAINTREE_SRC.paymentMethodId));

        let customerSavedCreditCards = creditCardPaymentInstruments.concat(srcPaymentInstruments);

        customerSavedCreditCards.map(function (el) {
            el.creditCardExpirationYearShort = el.creditCardExpirationYear.toString().slice(-2);

            return el;
        });

        const formKeys = {
            email: '',
            nonce: '',
            addresses: '',
            shippingAddress: '',
            userId: ''
        };
        const paypalAccounttForm = server.forms.getForm('braintreepaypalaccount');
        const paypalAccountFormFields = paymentHelper.getAccountFormFields(paypalAccounttForm, formKeys);
        const isPaypalVaultAllowed = prefs.vaultMode && !prefs.paypalOrderIntent;

        const venmoAccounttForm = server.forms.getForm('braintreevenmoaccount');
        const venmoAccountFormFields = paymentHelper.getAccountFormFields(venmoAccounttForm, formKeys);

        const isCreditCardActive = prefs.paymentMethods.BRAINTREE_CREDIT && prefs.paymentMethods.BRAINTREE_CREDIT.isActive;
        const isCreditCardBlockShown = isCreditCardActive && (prefs.vaultMode || !empty(creditCardPaymentInstruments));

        const isSRCAvailableInCurrentCountry = prefs.srcAvailabilityCountries.includes(Locale.getLocale(req.locale.id).country);
        const isVenmoAvailableInCurrentCountry = prefs.venmoAvailabilityCountries.includes(Locale.getLocale(req.locale.id).country);

        const billingAddressForm = server.forms.getForm('address');

        billingAddressForm.clear();

        const flashMessages = require('~/cartridge/config/flashMessages');
        const customerInfoCreditCard = customerHelper.getCustomerInfoCreditCard(customer);

        res.setViewData({
            braintree: {
                customerInfoCreditCard: customerInfoCreditCard,
                customerSavedCreditCards: customerSavedCreditCards,
                paypalPaymentInstruments: paypalPaymentInstruments,
                venmoPaymentInstruments: venmoPaymentInstruments,
                sdkUrls: sdkUrls,
                prefs: prefs,
                paypal: {
                    hasDefaultPaypalPaymentMethod: !empty(paypalPaymentInstruments),
                    isPaypalVaultAllowed: isPaypalVaultAllowed,
                    paypalAccountButtonConfig: accountButtonConfigHelper.createPaypalAccountButtonConfig(),
                    paypalAccountFormFields: paypalAccountFormFields,
                    isPaypalBlockShown: prefs.paymentMethods.BRAINTREE_PAYPAL &&
                        prefs.paymentMethods.BRAINTREE_PAYPAL.isActive &&
                        (isPaypalVaultAllowed || !empty(paypalPaymentInstruments))
                },
                venmo: {
                    hasDefaultVenmoPaymentMethod: !empty(venmoPaymentInstruments),
                    venmoAddAccountHandler: URLUtils.url('Braintree-AccountAddVenmoHandle'),
                    venmoAccountButtonConfig: accountButtonConfigHelper.createAccountVenmoButtonConfig(),
                    venmoAccountFormFields: venmoAccountFormFields,
                    isVenmoBlockShown: isVenmoAvailableInCurrentCountry &&
                        prefs.paymentMethods.BRAINTREE_VENMO &&
                        prefs.paymentMethods.BRAINTREE_VENMO.isActive &&
                        (prefs.vaultMode || !empty(venmoPaymentInstruments))
                },
                creditcardPaymentForm: server.forms.getForm('creditCard'),
                billingAddressForm: billingAddressForm,
                srcPaymentForm: server.forms.getForm('braintreesecureremotecommerceaccount'),
                hostedFieldsConfig: createHostedFieldsConfig(server.forms.getForm('creditCard')),
                accountSrcButtonConfig: accountButtonConfigHelper.createAccountSrcButtonConfig(),
                isCreditCardSavingAllowed: prefs.paymentMethods.BRAINTREE_CREDIT && prefs.paymentMethods.BRAINTREE_CREDIT.isActive && prefs.vaultMode,
                isSrcSavingAllowed: isSRCAvailableInCurrentCountry && prefs.paymentMethods.BRAINTREE_SRC && prefs.paymentMethods.BRAINTREE_SRC.isActive && prefs.vaultMode,
                isSRCBlockShown: prefs.paymentMethods.BRAINTREE_SRC && prefs.paymentMethods.BRAINTREE_SRC.isActive && (prefs.vaultMode || !empty(srcPaymentInstruments)),
                isCreditCardBlockShown: isCreditCardBlockShown,
                clientToken: clientToken
            },
            flashMessage: flashMessages.get('message')
        });

        next();
    });

server.append('Login', function (req, res, next) {
    let customerVaultData;

    if (customer.authenticated) {
        customerVaultData = btBusinessLogic.isCustomerInVault(customer);

        // If DW customer doesn't have Braintree customer record - create one
        if (!customerVaultData.isCustomerInVault && !customerVaultData.error) {
            btBusinessLogic.createCustomerOnBraintreeSide();
        }
    }

    next();
});

server.append('SubmitRegistration', function (req, res, next) {
    this.on('route:BeforeComplete', function (_, res) { // eslint-disable-line no-shadow
        if (customer.authenticated && res.viewData.validForm) {
            btBusinessLogic.createCustomerOnBraintreeSide();
        }
    });

    next();
});

module.exports = server.exports();
