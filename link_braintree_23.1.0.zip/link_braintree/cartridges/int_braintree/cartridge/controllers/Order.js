'use strict';

/**
 * @namespace Order
 */
const server = require('server');
server.extend(module.superModule);

/**
 * Custom API inclusions.
 */
const paymentHelper = require('~/cartridge/scripts/braintree/helpers/paymentHelper');
const customerHelper = require('~/cartridge/scripts/braintree/helpers/customerHelper');
const btBusinessLogic = require('~/cartridge/scripts/braintree/braintreeAPI/braintreeBusinessLogic');

server.append('Confirm', function (req, res, next) {
    var OrderMgr = require('dw/order/OrderMgr');
    var order = OrderMgr.getOrder(req.form.orderID, req.form.orderToken);
    var viewData = res.getViewData();

    customerHelper.formatCustomerName(viewData.order.shipping);

    res.setViewData({
        braintree: {
            summaryEmail: null,
            currency: order.getCurrencyCode(),
            lpmActivePaymentMethod: paymentHelper.getActiveLocalPaymentMethod(order),
            googlepayCardDescription: paymentHelper.getGooglepayCardDescriprionFromOrder(order)
        }
    });
    next();
});

server.append('Details', function (req, res, next) {
    res.setViewData({
        braintree: {
            summaryEmail: null
        }
    });
    next();
});

server.append('CreateAccount', function (req, res, next) {
    this.on('route:BeforeComplete', function () { // eslint-disable-line no-shadow
        if (customer.authenticated) {
            btBusinessLogic.createCustomerOnBraintreeSide();
        }
    });

    next();
});

module.exports = server.exports();
