'use strict';

/**
 * @namespace Cart
 */
const server = require('server');
server.extend(module.superModule);

/**
 * Custom API inclusions.
 */
const customerHelper = require('~/cartridge/scripts/braintree/helpers/customerHelper');
const paymentHelper = require('~/cartridge/scripts/braintree/helpers/paymentHelper');
const buttonConfigHelper = require('~/cartridge/scripts/braintree/helpers/buttonConfigHelper');
const btBusinessLogic = require('~/cartridge/scripts/braintree/braintreeAPI/braintreeBusinessLogic');
const csrfProtection = require('*/cartridge/scripts/middleware/csrf');
const prefs = require('~/cartridge/config/braintreePreferences');
const braintreeSDK = require('*/cartridge/config/braintreeSDK');
const braintreeConstants = require('~/cartridge/config/braintreeConstants');

server.append('Show',
    csrfProtection.generateToken,
    function (req, res, next) {
        var BasketMgr = require('dw/order/BasketMgr');
        var basket = BasketMgr.getCurrentBasket();

        if (!basket) {
            next();
            return;
        }

        var clientToken = btBusinessLogic.getClientToken(basket.getCurrencyCode());
        var payPalButtonConfig = null;
        var applePayButtonConfig = null;
        var googlepayButtonConfig = null;
        var srcButtonConfig = null;
        var defaultPaypalAddress = null;
        var dafaultPaypalShippingAddress = null;

        if (prefs.paymentMethods.BRAINTREE_PAYPAL.isActive && paymentHelper.isPaypalButtonEnabled(braintreeConstants.PAGE_FLOW_CART)) {
            payPalButtonConfig = buttonConfigHelper.createBraintreePayPalButtonConfig(basket, clientToken, braintreeConstants.PAGE_FLOW_CART);

            var customerPaypalInstruments = customerHelper.getDefaultCustomerPaypalPaymentInstrument();

            if (customerPaypalInstruments) {
                defaultPaypalAddress = customer.getAddressBook().getPreferredAddress();

                if (!empty(defaultPaypalAddress) && payPalButtonConfig.changePMButtonEnabled) {
                    dafaultPaypalShippingAddress = customerHelper.getDefaultCustomerShippingAddress(defaultPaypalAddress);
                }
            }
        }

        if (prefs.paymentMethods.BRAINTREE_APPLEPAY.isActive && prefs.applepayVisibilityOnCart) {
            applePayButtonConfig = buttonConfigHelper.createBraintreeApplePayButtonConfig(basket, clientToken, braintreeConstants.PAGE_FLOW_CART);
        }

        if (prefs.paymentMethods.BRAINTREE_GOOGLEPAY.isActive && prefs.googlepayVisibilityOnCart) {
            googlepayButtonConfig = buttonConfigHelper.createBraintreeGooglePayButtonConfig(basket, clientToken, braintreeConstants.PAGE_FLOW_CART);
        }

        if (prefs.paymentMethods.BRAINTREE_SRC.isActive && prefs.srcVisibilityOnCart) {
            srcButtonConfig = buttonConfigHelper.createBraintreeSrcButtonConfig(basket, clientToken, braintreeConstants.PAGE_FLOW_CART);
        }

        res.setViewData({
            braintree: {
                prefs: prefs,
                sdkUrls: braintreeSDK,
                payPalButtonConfig: payPalButtonConfig,
                applePayButtonConfig: applePayButtonConfig,
                googlepayButtonConfig: googlepayButtonConfig,
                srcButtonConfig: srcButtonConfig,
                sfraCheckoutFormFields: paymentHelper.getSFRACheckoutFormFields(),
                sfraCustomerFormFields: paymentHelper.getSFRACustomerFormFields(),
                clientToken: clientToken,
                isCustomerEmailEmpty: empty(basket.getCustomerEmail()),
                dafaultPaypalShippingAddress: dafaultPaypalShippingAddress
            },
            addressForm: server.forms.getForm('address')
        });

        next();
    });

server.append('MiniCartShow', csrfProtection.generateToken, function (req, res, next) {
    if (!paymentHelper.isPaypalButtonEnabled(braintreeConstants.PAGE_FLOW_MINICART)) {
        next();
        return;
    }

    var BasketMgr = require('dw/order/BasketMgr');
    var basket = BasketMgr.getCurrentBasket();
    var dafaultPaypalShippingAddress = null;

    if (!basket) {
        next();
        return;
    }

    var clientToken = btBusinessLogic.getClientToken(basket.getCurrencyCode());
    var payPalButtonConfig = null;
    var defaultPaypalAddress = null;

    if (prefs.paymentMethods.BRAINTREE_PAYPAL.isActive) {
        payPalButtonConfig = buttonConfigHelper.createBraintreePayPalButtonConfig(basket, clientToken, braintreeConstants.PAGE_FLOW_MINICART);

        var customerPaypalInstruments = customerHelper.getDefaultCustomerPaypalPaymentInstrument();

        if (customerPaypalInstruments && payPalButtonConfig) {
            defaultPaypalAddress = customer.getAddressBook().getPreferredAddress();

            // Creates the shipping address for 'ChangePM' button behavior
            if (!empty(defaultPaypalAddress) && payPalButtonConfig.changePMButtonEnabled) {
                dafaultPaypalShippingAddress = customerHelper.getDefaultCustomerShippingAddress(defaultPaypalAddress);
            }
        }
    } else {
        next();
        return;
    }

    res.setViewData({
        braintree: {
            payPalButtonConfig: payPalButtonConfig,
            sfraCheckoutFormFields: paymentHelper.getSFRACheckoutFormFields(),
            sfraCustomerFormFields: paymentHelper.getSFRACustomerFormFields(),
            clientToken: clientToken,
            isCustomerEmailEmpty: empty(basket.getCustomerEmail()),
            // An Address for change PM button behavior
            dafaultPaypalShippingAddress: dafaultPaypalShippingAddress
        },
        addressForm: server.forms.getForm('address')
    });

    next();
});

module.exports = server.exports();
