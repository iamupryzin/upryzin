'use strict';

/**
 * @namespace CheckoutShippingServices
 */
const server = require('server');
server.extend(module.superModule);

server.append('SubmitShipping', function (req, res, next) {
    const braintreeConstants = require('~/cartridge/config/braintreeConstants');
    const braintreePreferences = require('~/cartridge/config/braintreePreferences');

    const shippingAddressForm = server.forms.getForm('shipping');
    const shippingAddress = shippingAddressForm.toObject().shippingAddress.addressFields;
    const phoneNumber = shippingAddress.phone;

    // Updates a customer address from 'Connect with PayPal feature' with phone number
    if (braintreePreferences.cwppButtonEnabled && braintreePreferences.apmaEnabled &&
        customer.registered && phoneNumber && phoneNumber !== braintreeConstants.CWPP_DEFAULT_PHONE) {
        const CustomerModel = require('*/cartridge/models/customer');

        const customerInstance = new CustomerModel(customer);
        const cwppAddress = customerInstance.getCWPPCustomerAddress();
        const isCWPPAddressUsed = customerInstance.isCWPPAddressUsedOnCheckoutPage(shippingAddress);

        if (isCWPPAddressUsed && cwppAddress.phone === null) {
            const Transaction = require('dw/system/Transaction');

            Transaction.wrap(function () {
                customerInstance.setPhone(phoneNumber);
            });
        }
    }

    next();
});

module.exports = server.exports();
