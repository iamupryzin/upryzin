'use strict';

/**
 * @namespace Braintree
 */
const server = require('server');

/**
 * SFCC API inclusions.
 */
const URLUtils = require('dw/web/URLUtils');
const Resource = require('dw/web/Resource');
const StringUtils = require('dw/util/StringUtils');
const Transaction = require('dw/system/Transaction');
const Logger = require('dw/system/Logger');
const site = require('dw/system/Site').getCurrent();

/**
 * Models.
 */
const CustomerModel = require('*/cartridge/models/customer');
const Encoding = require('dw/crypto/Encoding');

/**
 * Custom API inclusions.
 */
const csrfProtection = require('*/cartridge/scripts/middleware/csrf');
const userLoggedIn = require('*/cartridge/scripts/middleware/userLoggedIn');
const consentTracking = require('*/cartridge/scripts/middleware/consentTracking');
const middleware = require('~/cartridge/scripts/braintree/middleware');
const paymentHelper = require('~/cartridge/scripts/braintree/helpers/paymentHelper');
const customerHelper = require('~/cartridge/scripts/braintree/helpers/customerHelper');
const accountButtonConfigHelper = require('~/cartridge/scripts/braintree/helpers/accountButtonConfigHelper');
const formErrors = require('*/cartridge/scripts/formErrors');
const processorHelper = require('~/cartridge/scripts/hooks/payment/processor/processorHelper');
const btBusinessLogic = require('~/cartridge/scripts/braintree/braintreeAPI/braintreeBusinessLogic');
const prefs = require('~/cartridge/config/braintreePreferences');
const braintreeSDK = require('*/cartridge/config/braintreeSDK');
const braintreeConstants = require('~/cartridge/config/braintreeConstants');
const braintreeUrls = require('~/cartridge/config/braintreeUrls');

const btRenderAccountsListURLAction = 'Braintree-RenderAccountsList';

server.post('AccountAddCreditCardHandle',
    userLoggedIn.validateLoggedIn,
    middleware.validateFormField,
    middleware.validateBraintreePaymentMethodNonce,
    function (req, res, next) {
        const httpParameterMap = request.httpParameterMap;
        const paymentMethodNonce = httpParameterMap.braintreePaymentMethodNonce.stringValue;

        const paymentForm = server.forms.getForm('creditCard');
        const billingAddressForm = server.forms.getForm('address');

        if (!billingAddressForm.valid) {
            res.json({
                success: false,
                fields: formErrors.getFormErrors(billingAddressForm),
                error: Resource.msg('braintree.creditcard.error.validation', 'locale', null)
            });

            return next();
        }

        try {
            const createPaymentMethodResponseData = btBusinessLogic.createPaymentMethodOnBraintreeSide(paymentMethodNonce);

            if (createPaymentMethodResponseData.error) {
                throw createPaymentMethodResponseData.error;
            }

            const card = processorHelper.saveCustomerCreditCard(createPaymentMethodResponseData, paymentForm.cardOwner.value);

            if (card.error) {
                throw card.error;
            }

            const billingAddress = processorHelper.saveCustomerBillingAddress(card.customerPaymentInstrument, billingAddressForm);

            if (billingAddress.error) {
                throw billingAddress.error;
            }
        } catch (error) {
            res.json({
                success: false,
                error: error
            });

            return next();
        }

        paymentForm.clear();
        billingAddressForm.clear();

        res.json({
            success: true,
            renderAccountsUrl: URLUtils.url(btRenderAccountsListURLAction, 'paymentType', 'credit').toString(),
            redirectUrl: braintreeUrls.accountShow
        });

        return next();
    });

server.get('MakePaymentMethodDefault',
    userLoggedIn.validateLoggedIn,
    function (req, res, next) {
        var array = require('*/cartridge/scripts/util/array');

        var UUID = req.querystring.UUID;
        var paymentMethodIds = req.querystring.pmID;
        var savedPaymentInstruments = paymentMethodIds === 'CARD' ?
            paymentHelper.getApplicableCreditCardPaymentInstruments() :
            customer.getProfile().getWallet().getPaymentInstruments(paymentMethodIds);
        var newDefaultProperty = array.find(savedPaymentInstruments, function (payment) {
            return UUID === payment.UUID;
        });
        var toRemoveDefaultProperty = customerHelper.clearDefaultProperty(savedPaymentInstruments);

        Transaction.wrap(function () {
            newDefaultProperty.custom.braintreeDefaultCard = true;
        });

        res.json({
            newDefaultProperty: newDefaultProperty.UUID,
            toRemoveDefaultProperty: toRemoveDefaultProperty.UUID
        });

        next();
    });

server.post('AccountAddPaypalHandle',
    userLoggedIn.validateLoggedIn,
    middleware.validateBraintreePaypalAccountForm,
    middleware.validatePaypalCustomerEmail,
    function (req, res, next) {
        const requestBodyAsString = request.httpParameterMap.requestBodyAsString;
        const decodedFormData = Encoding.fromBase64(requestBodyAsString);
        const parsedFormData = JSON.parse(decodedFormData);
        const paypal = {
            email: parsedFormData.dwfrm_braintreepaypalaccount_email,
            nonce: parsedFormData.dwfrm_braintreepaypalaccount_nonce,
            billingAddress: parsedFormData.dwfrm_braintreepaypalaccount_addresses,
            shippingAddress: parsedFormData.dwfrm_braintreepaypalaccount_shippingAddress
        };
        let paypalAccount;

        const isAPMAFlow = req.querystring && req.querystring.isAPMAFlow;

        const responseObject = {
            renderAccountsUrl: URLUtils.url(btRenderAccountsListURLAction, 'paymentType', 'paypal').toString()
        };

        const isPaymentInstrumentsExist = processorHelper.checkForPaymentInstruments(prefs.paymentMethods.BRAINTREE_PAYPAL.paymentMethodId);
        try {
            const createPaymentMethodResponseData = btBusinessLogic.createPaymentMethodOnBraintreeSide(paypal.nonce);

            if (createPaymentMethodResponseData.error) {
                throw createPaymentMethodResponseData.error;
            }

            paypalAccount = processorHelper.savePaypalAccount(createPaymentMethodResponseData.paymentMethod, paypal.billingAddress);
            const customerInstance = new CustomerModel(customer);

            if (isAPMAFlow) {
                const messageType = paypalAccount.error ? CustomerModel.FLASH_MESSAGE_DANGER : CustomerModel.FLASH_MESSAGE_SUCCESS;

                Transaction.wrap(function () {
                    customerInstance.addFlashMessage(
                        Resource.msg(['braintree.account.apma.paymentmethod.notification.', messageType].join(''), 'locale', null),
                        messageType
                    );
                });
            }

            if (paypalAccount.error) {
                throw paypalAccount.error;
            }
        } catch (err) {
            responseObject.success = false;
            responseObject.error = err;

            res.json(responseObject);
            res.setStatusCode(500);

            return next();
        }

        if (!isPaymentInstrumentsExist) {
            // Makes PayPal account as default payment method
            customerHelper.setBraintreeDefaultCard(paypalAccount.token);
        }

        responseObject.success = true;
        res.json(responseObject);

        return next();
    });

server.get(
    'RenderAccountsList',
    csrfProtection.generateToken,
    consentTracking.consent,
    userLoggedIn.validateLoggedIn,
    function (req, res, next) {
        const paymentType = req.querystring.paymentType.toLowerCase();
        const paymentTypeConstant = ['BRAINTREE', paymentType.toUpperCase()].join('_');
        const paymentMethodId = prefs.paymentMethods[paymentTypeConstant].paymentMethodId;
        const AccountModel = require('*/cartridge/models/account');
        const paymentTypeKey = [paymentType, 'PaymentInstruments'].join('');
        let paymentInstruments;
        let template;

        const renderData = {
            braintree: {
                deletePaymentUrl: URLUtils.url('PaymentInstruments-DeletePayment').toString(),
                makePaymentMethodDefaultUrl: URLUtils.https('Braintree-MakePaymentMethodDefault').toString()
            }
        };

        if (paymentType === 'credit' || paymentType === 'src') {
            const creditCardPaymentMethodId = 'CREDIT_CARD';
            const srcPaymentMethodId = 'SRC';
            const srcPaymentInstruments = AccountModel.getCustomerPaymentInstruments(customerHelper.getCustomerPaymentInstruments(srcPaymentMethodId), customer);

            paymentInstruments = AccountModel.getCustomerPaymentInstruments(customerHelper.getCustomerPaymentInstruments(creditCardPaymentMethodId), customer);

            if (srcPaymentInstruments) {
                paymentInstruments = paymentInstruments.concat(srcPaymentInstruments);
            }

            template = 'braintree/account/creditCardsLoop';
            renderData.braintree.customerSavedCreditCards = paymentInstruments;
        } else {
            paymentInstruments = AccountModel.getCustomerPaymentInstruments(customerHelper.getCustomerPaymentInstruments(paymentMethodId), customer);
            template = StringUtils.format('braintree/account/{0}AccountsLoop', paymentType);
            renderData.braintree[paymentTypeKey] = paymentInstruments;
        }

        res.render(template, renderData);
        next();
    }
);

server.post('AccountAddVenmoHandle',
    userLoggedIn.validateLoggedIn,
    middleware.validateFormField,
    function (req, res, next) {
        const requestBodyAsString = request.httpParameterMap.requestBodyAsString;
        const decodedFormData = Encoding.fromBase64(requestBodyAsString);
        const parsedFormData = JSON.parse(decodedFormData);
        const venmo = {
            nonce: parsedFormData.dwfrm_braintreevenmoaccount_nonce,
            userId: parsedFormData.dwfrm_braintreevenmoaccount_userId
        };
        let venmoAccount;

        const responseObject = {
            renderAccountsUrl: URLUtils.url(btRenderAccountsListURLAction, 'paymentType', 'venmo').toString()
        };

        const isPaymentInstrumentsExist = processorHelper.checkForPaymentInstruments(prefs.paymentMethods.BRAINTREE_VENMO.paymentMethodId);

        try {
            const createPaymentMethodResponseData = btBusinessLogic.createPaymentMethodOnBraintreeSide(venmo.nonce);

            if (createPaymentMethodResponseData.error) {
                throw createPaymentMethodResponseData.error;
            }

            venmoAccount = processorHelper.saveVenmoAccount(createPaymentMethodResponseData, venmo.userId);

            if (venmoAccount.error) {
                throw venmoAccount.error;
            }
        } catch (err) {
            responseObject.success = false;
            responseObject.error = err;

            res.json(responseObject);
            res.setStatusCode(500);

            return next();
        }

        if (!isPaymentInstrumentsExist) {
            // Makes Venmo account as default payment method
            customerHelper.setBraintreeDefaultCard(venmoAccount.token);
        }

        responseObject.success = true;
        res.json(responseObject);

        return next();
    });

server.get('GetOrderInfo', function (req, res, next) {
    const BasketMgr = require('dw/order/BasketMgr');
    const basket = BasketMgr.getCurrentBasket();
    const basketShippingAddress = basket.getDefaultShipment().getShippingAddress();
    const matchingAddressId = customerHelper.getAssociatedAddress(basket, customer);
    let shippingAddress = null;

    if (!empty(basketShippingAddress)) {
        const shippingInfo = paymentHelper.createAddressData(basketShippingAddress);
        const firstName = shippingInfo.firstName || '';
        const lastName = shippingInfo.lastName || '';
        shippingAddress = {
            recipientName: [firstName, lastName].join(' '),
            line1: shippingInfo.streetAddress || '',
            line2: shippingInfo.extendedAddress || '',
            city: shippingInfo.locality || '',
            countryCode: (shippingInfo.countryCodeAlpha2).toUpperCase() || '',
            postalCode: decodeURIComponent(shippingInfo.postalCode) || '',
            state: shippingInfo.region || '',
            phone: shippingInfo.phoneNumber || ''
        };
    }
    res.json({
        amount: paymentHelper.getAmountPaid(basket).getValue(),
        shippingAddress: shippingAddress,
        matchingBillingAddressId: matchingAddressId
    });

    next();
});

server.post('PaymentConfirm', server.middleware.https, function (req, res, next) {
    var basket = require('dw/order/BasketMgr').getCurrentBasket();
    var technicalErrorMsg = Resource.msg('error.technical', 'checkout', null);
    var COHelpers = require('*/cartridge/scripts/checkout/checkoutHelpers');
    var { copyCustomerAddressToShipment } = require('*/cartridge/scripts/checkout/checkoutHelpers');

    var lpmTransactionSale = null;
    var { nonce, details, lpmName, deviceData } = req.body && JSON.parse(req.body);

    paymentHelper.updateOrderBillingAddress(basket, details);

    if (basket.giftCertificateLineItems.length >= 1 &&
        basket.productLineItems.length === 0 &&
        basket.billingAddress &&
        empty(basket.defaultShipment.shippingAddress)) {
        copyCustomerAddressToShipment(basket.billingAddress);
    }

    var order = COHelpers.createOrder(basket);

    if (!order) {
        res.setStatusCode(500);
        res.print(technicalErrorMsg);

        return next();
    }

    try {
        lpmTransactionSale = require('~/cartridge/scripts/braintree/processors/processorLpm').setLpmTransactionSale(order, {
            nonce: nonce,
            lpmName: lpmName,
            deviceData: deviceData
        });
    } catch (error) {
        paymentHelper.getLogger().error(error);

        res.setStatusCode(500);
        res.print(error.message);

        return next();
    }

    if (!lpmTransactionSale || lpmTransactionSale.error) {
        res.setStatusCode(500);
        res.print(lpmTransactionSale.message);

        return next();
    }

    var fraudDetectionStatus = { status: 'success' };
    // Need to use COHelpers.placeOrder because it exists in plugin_giftcertificate cartridge.
    var placeOrderResult = COHelpers.placeOrder(order, fraudDetectionStatus);

    if (placeOrderResult.error) {
        res.setStatusCode(500);
        res.print(technicalErrorMsg);

        return next();
    }

    if (order.getCustomerEmail()) {
        COHelpers.sendConfirmationEmail(order, req.locale.id);
    }

    res.json({
        redirectUrl: URLUtils.url('Order-Confirm', 'orderID', order.orderNo, 'orderToken', order.orderToken).toString()
    });

    return next();
});

server.get('FallbackProcess', server.middleware.https, function (req, res, next) {
    var basket = require('dw/order/BasketMgr').getCurrentBasket();
    var clientToken = btBusinessLogic.getClientToken(basket.currencyCode);
    var paymentConfirmUrl = URLUtils.url('Braintree-PaymentConfirm').toString();
    var lpmName = request.httpParameterMap.lpmName.value;
    var customerEmail = request.httpParameterMap.email.value;

    res.render('/braintree/checkout/lpmFallback', {
        braintree: {
            clientToken: clientToken,
            paymentConfirmUrl: paymentConfirmUrl,
            lpmName: lpmName,
            prefs: prefs,
            sdkUrls: braintreeSDK,
            email: customerEmail
        }
    });

    return next();
});

server.post('AccountAddSrcHandle',
    userLoggedIn.validateLoggedIn,
    middleware.validateFormField,
    function (req, res, next) {
        const requestBodyAsString = request.httpParameterMap.requestBodyAsString;
        const decodedFormData = Encoding.fromBase64(requestBodyAsString);
        const parsedFormData = JSON.parse(decodedFormData);
        const srcNonce = parsedFormData.dwfrm_braintreesecureremotecommerceaccount_nonce;

        try {
            const createPaymentMethodResponseData = btBusinessLogic.createPaymentMethodOnBraintreeSide(srcNonce, true);

            if (createPaymentMethodResponseData.error) {
                throw createPaymentMethodResponseData.error;
            }

            const srcAccount = processorHelper.saveSrcAccount(createPaymentMethodResponseData);

            if (srcAccount.error) {
                throw Resource.msg('braintree.cart.defaulterror', 'locale', null);
            }
        } catch (err) {
            res.json({
                success: false,
                error: err
            });
            return next();
        }

        res.json({
            success: true,
            renderAccountsUrl: URLUtils.url(btRenderAccountsListURLAction, 'paymentType', 'src').toString(),
            redirectUrl: braintreeUrls.accountShow
        });

        return next();
    });

server.post('PaymentMethodHook',
    function (req, res, next) {
        var PaymentMethodWhMgr = require('~/cartridge/models/paymentMethodWhMgr');
        var body = request.httpParameterMap;
        var btPayload = body.bt_payload.value;
        var paymentMethodWhMgr = new PaymentMethodWhMgr();
        var parsedPayload;

        try {
            // Validates signature. In case if signature is not valid an error will be thrown
            paymentMethodWhMgr.validateSignature(body.bt_signature.value, btPayload);

            // Parse payload and return a notification object. In case if payload is not valid an error will be thrown
            parsedPayload = paymentMethodWhMgr.parsePayload(btPayload);

            if (parsedPayload.notification.kind === braintreeConstants.TYPE_PAYMENT_METHOD_REVOKED_BY_CUSTOMER) {
                // Deletes revoked payment method when a customer canceled their PayPal billing agreement
                paymentMethodWhMgr.deleteRevokedPaymentMethod(parsedPayload.notification.subject.paypalAccount);
            } else {
                var error = Resource.msg('braintree.paymentMethod.webhook.notification.type.doesnot.match', 'locale', 'null');
                paymentHelper.getLogger().error(error);
            }
        } catch (err) {
            res.json({
                success: false,
                error: err
            });

            paymentHelper.getLogger().error(err);

            return next();
        }

        res.json({
            success: true
        });

        return next();
    });

server.post(
    'VaultCreditCard',
    csrfProtection.validateAjaxRequest,
    userLoggedIn.validateLoggedIn,
    middleware.validateFormField,
    function (req, res, next) {
        try {
            const basicHelpers = require('*/cartridge/config/basicHelpers');

            const nonce = req.httpParameterMap.nonce.value;
            const response = btBusinessLogic.vaultCreditCard(nonce);
            const keys = 'paymentMethod.details.threeDSecure.authenticationInsight.customerAuthenticationRegulationEnvironment';
            const regulationEnvironment = basicHelpers.getValueByKey(response, keys, false);

            if (!regulationEnvironment) {
                throw new Error(Resource.msg('error.authinsight.regulationenv', 'error', null));
            }

            res.json({
                success: true,
                regulationEnvironment: regulationEnvironment.toLowerCase()
            });
        } catch (error) {
            paymentHelper.getLogger().error(error);

            res.setStatusCode(500);
            res.json({ success: false, error: error, regulationEnvironment: 'not found' });
        }

        return next();
    }
);

server.get('RenderCWPP',
    server.middleware.include,
    function (req, res, next) {
        const PayPalRESTModel = require('~/cartridge/models/payPalREST');
        const payPalREST = new PayPalRESTModel();

        res.render('/braintree/components/cwppButton', {
            cwppButtonEnabled: prefs.cwppButtonEnabled,
            cwppStaticImageLink: prefs.cwppStaticImageLink,
            cwppButtonUrl: payPalREST.getConnectWithPaypalURL(res.viewData.queryString),
            cwppStaticImageAlt: Resource.msg('braintree.connect.with.paypal.image.alt', 'locale', null)
        });

        return next();
    }
);

server.get('HandleCWPP',
    server.middleware.https,
    function (req, res, next) {
        const accountHelpers = require('*/cartridge/scripts/helpers/accountHelpers');
        // req.httpParameterMap.state.stringValue - oAuth reentry endpoint(Account - 1 or Checkout - 2)
        const oauthReentryEndpoint = req.httpParameterMap.state.stringValue;

        if (req.httpParameterMap.code.empty) {
            // Sets redirect endpoint depands of 'Connect with PayPal' button location
            res.redirect(accountHelpers.getLoginRedirectURL(oauthReentryEndpoint, req.session.privacyCache, false));
            return next();
        }

        const PayPalRESTModel = require('~/cartridge/models/payPalREST');
        const payPalREST = new PayPalRESTModel();

        try {
            // Gets the access token according to the authentification code
            const accessToken = payPalREST.getAccessTokenByAuthorizationCode(req.httpParameterMap.code.stringValue);
            // Gets the Paypal customer information according to the access token
            const payPalCustomerInfo = payPalREST.getCustomerInfo(accessToken);
            const errorMessage = Resource.msg('error.oauth.login.failure', 'login', null);

            if (!payPalCustomerInfo) {
                throw errorMessage;
            }

            const customerEmail = payPalCustomerInfo.email;
            let newlyRegisteredUser = false;
            let customerInstance = CustomerModel.get(customerEmail);

            if (!customerInstance) {
                // SFCC customer creation in case the customer with the current email does not already exist
                Transaction.wrap(function () {
                    customerInstance = CustomerModel.create(customerEmail);
                    customerInstance.setEmail(customerEmail);
                    customerInstance.setFirstName(payPalCustomerInfo.firstName);
                    customerInstance.setLastName(payPalCustomerInfo.lastName);
                    customerInstance.setPhone(Resource.msg('braintree.account.address.phonenumber.notprovided', 'locale', null));

                    newlyRegisteredUser = true;
                    // Create customer on Braintree side
                    btBusinessLogic.createCwppCustomerOnBraintreeSide(customerInstance);
                    // Send email with customer password
                    customerInstance.sendRegistrationEmail();
                });
            } else if (!customerInstance.isShowedMessageCWPP()) {
                // Customer notifying in case of the customer with the current email does already exist and if this
                // notification was not shown before
                Transaction.wrap(function () {
                    customerInstance.addFlashMessage(
                        Resource.msg('account.already.exist', 'notifications', null),
                        CustomerModel.FLASH_MESSAGE_INFO
                    );
                    customerInstance.messageCWPPShowed();
                });
            }

            const AgentUserMgr = require('dw/customer/AgentUserMgr');
            const BasketMgr = require('dw/order/BasketMgr');
            const requestLocale = request.getLocale();
            const guestBasket = BasketMgr.getCurrentBasket();

            if (AgentUserMgr.loginAgentUser(prefs.cwppAgentLogin, prefs.cwppAgentPassword).error) {
                throw errorMessage;
            }

            if (AgentUserMgr.loginOnBehalfOfCustomer(customerInstance.dw).error) {
                throw errorMessage;
            }

            if (!customerInstance.getPreferredLocale()) {
                request.setLocale(requestLocale);
            }

            if (guestBasket) {
                Transaction.wrap(function () {
                    customerInstance.restoreBasket(guestBasket);
                });
            }

            const redirectURL = accountHelpers.getLoginRedirectURL(oauthReentryEndpoint, req.session.privacyCache, newlyRegisteredUser);
            // Automatic payment method adding flow
            if (prefs.apmaEnabled && customerInstance.isEnabledFeatureAPMA()) {
                const urlArgs = [
                    braintreeConstants.ENDPOINT_BRAINTREE_APMA,
                    'redirectURL', redirectURL,
                    'addressObject', encodeURIComponent(JSON.stringify(payPalCustomerInfo.addressObjectFromPayPal))
                ];
                res.redirect(URLUtils.url.apply(null, urlArgs));
            } else {
                res.redirect(redirectURL);
            }
        } catch (err) {
            res.render('/error', {
                message: err
            });

            Logger.error(err);
        }

        return next();
    }
);

server.get('APMA', server.middleware.https, csrfProtection.generateToken, userLoggedIn.validateLoggedIn,
    function (req, res, next) {
        if (!req.querystring.redirectURL || !req.querystring.addressObject) {
            res.redirect(URLUtils.url(braintreeConstants.ENDPOINT_HOME_SHOW));
            return next();
        }

        const customerInstance = new CustomerModel(customer);
        const hasBillingAgreement = customerInstance.hasPaymentInstrument();
        const addressObjectString = decodeURIComponent(req.querystring.addressObject);
        const hasAddress = customerInstance.hasAddress(JSON.parse(addressObjectString));

        if (!customerInstance.isEnabledFeatureAPMA() || (hasBillingAgreement && hasAddress)) {
            res.redirect(req.querystring.redirectURL);
            return next();
        }

        Transaction.wrap(function () {
            customerInstance.disableFeatureAPMA();
        });

        let addingStage = braintreeConstants.APMA_STAGE_COMPLETE;

        if (hasBillingAgreement || prefs.paypalOrderIntent || (prefs.cwppButtonEnabled && !prefs.btPaypalPaymentMethodId && !prefs.apmaEnabled)) {
            addingStage = braintreeConstants.APMA_STAGE_ADDRESS;
        }

        if (hasAddress) {
            addingStage = braintreeConstants.APMA_STAGE_ACCOUNT;
        }

        const formKeys = {
            email: '',
            nonce: '',
            addresses: '',
            shippingAddress: '',
            userId: ''
        };
        const paypalAccountForm = server.forms.getForm('braintreepaypalaccount');
        const currentCurrency = paymentHelper.findCurrentSiteCurrency(site.allowedCurrencies.toArray()) || site.getDefaultCurrency();

        res.render('braintree/components/apmaPrompt', {
            braintree: {
                clientSdk3ClientUrl: braintreeSDK.clientSdk3ClientUrl,
                clientSdk3PayPalUrl: braintreeSDK.clientSdk3PayPalUrl,
                clientSdk3PayPalCheckoutUrl: braintreeSDK.clientSdk3PayPalCheckoutUrl,
                clientToken: btBusinessLogic.getClientToken(currentCurrency),
                paypal: {
                    paypalAddAccountHandler: URLUtils.url('Braintree-AccountAddPaypalHandle'),
                    paypalAccountButtonConfig: accountButtonConfigHelper.createPaypalAccountButtonConfig(),
                    paypalAccountFormFields: paymentHelper.getAccountFormFields(paypalAccountForm, formKeys)
                }
            },
            addingStage: addingStage,
            addressObject: addressObjectString,
            redirectURL: req.querystring.redirectURL
        });

        return next();
    }
);


/**
 * Uses only for 'Automatic payment method adding' flow due Connect with PayPal button
 */
server.post('SavePaypalDefaultAddress', server.middleware.https,
    function (req, res, next) {
        try {
            const data = req.body && JSON.parse(req.body);
            res.parsedBody = data;
        } catch (error) {
            Logger.error(error);
            res.setStatusCode(500);
            return res.print(error);
        }

        const customerInstance = new CustomerModel(customer);

        try {
            const resourceMessage = res.parsedBody.isAccountPage ?
                Resource.msg('braintree.account.shippingaddressadded.notification.msg', 'locale', null) :
                Resource.msg('braintree.checkout.shippingaddressadded.notification.msg', 'locale', null);
            // Creates a customer address from the address provided by 'Connect with PayPal' feature
            Transaction.wrap(function () {
                customerInstance.addAddress(res.parsedBody.addressObject);

                customerInstance.addFlashMessage(
                    resourceMessage,
                    CustomerModel.FLASH_MESSAGE_SUCCESS
                );
            });
        } catch (err) {
            Transaction.wrap(function () {
                customerInstance.addFlashMessage(
                    Resource.msg('braintree.account.shippingaddressnotadded.notification.msg', 'locale', null),
                    CustomerModel.FLASH_MESSAGE_DANGER
                );
            });

            Logger.error(err);
        }

        res.json({});

        return next();
    }
);

server.get('IncludeConstants', server.middleware.include, function (req, res, next) {
    res.render('common/braintreeConstants', {
        braintreeConstantsAsString: JSON.stringify(braintreeConstants)
    });

    next();
});

server.get('IncludePreferences', server.middleware.include, function (req, res, next) {
    res.render('common/braintreePreferences', {
        braintreePreferencesAsString: JSON.stringify(prefs._whiteListedForStorefront)
    });

    next();
});

server.get('IncludeUrls', server.middleware.include, function (req, res, next) {
    res.render('common/braintreeUrls', {
        braintreeUrlsAsString: JSON.stringify(braintreeUrls)
    });

    next();
});

server.post(
    'ValidateAddresses',
    server.middleware.https,
    csrfProtection.validateAjaxRequest,
    function (req, res, next) {
        try {
            const addressHelpers = require('*/cartridge/scripts/braintree/helpers/addressHelpers');

            const data = JSON.parse(req.httpParameterMap.requestBodyAsString);
            const addressForm = server.forms.getForm('address');

            const shippingData = addressHelpers.prepareShippingAddressData(data);
            const shippingFields = addressHelpers.validateAddressForm(addressForm, shippingData);

            if (Object.keys(shippingFields).length) {
                res.json({
                    error: true,
                    fields: shippingFields,
                    message: Resource.msg('error.paypal.shipping_address.invalid', 'error', null)
                });

                return next();
            }

            const billingData = addressHelpers.prepareBillingAddressData(data);
            const billingFields = addressHelpers.validateAddressForm(addressForm, billingData);

            if (Object.keys(billingFields).length) {
                res.json({
                    error: true,
                    fields: billingFields,
                    message: Resource.msg('error.paypal.billing_address.invalid', 'error', null)
                });

                return next();
            }
        } catch (error) {
            paymentHelper.getLogger().error(error);

            res.setStatusCode(500);

            res.json({
                error: true,
                message: Resource.msg('braintree.server.error', 'locale', null)
            });

            return next();
        }

        res.json({
            success: true
        });

        return next();
    }
);

module.exports = server.exports();
