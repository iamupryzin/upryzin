'use strict';

/* global customer request */

/**
 * @namespace PaymentInstruments
 */
const server = require('server');
server.extend(module.superModule);

/**
 * SFCC API inclusions.
 */
const Resource = require('dw/web/Resource');
const URLUtils = require('dw/web/URLUtils');

/**
 * Custom API inclusions.
 */
const formErrors = require('*/cartridge/scripts/formErrors');
const csrfProtection = require('*/cartridge/scripts/middleware/csrf');
const userLoggedIn = require('*/cartridge/scripts/middleware/userLoggedIn');
const paymentHelper = require('~/cartridge/scripts/braintree/helpers/paymentHelper');
const customerHelper = require('~/cartridge/scripts/braintree/helpers/customerHelper');
const processorHelper = require('~/cartridge/scripts/hooks/payment/processor/processorHelper');
const braintreeBusinessLogic = require('~/cartridge/scripts/braintree/braintreeAPI/braintreeBusinessLogic');
const braintreeUrls = require('*/cartridge/config/braintreeUrls');

server.append('DeletePayment', function (req, res, next) {
    let newDefaultAccount;
    const UUID = req.querystring.UUID;
    const paymentToDelete = {
        payment: customerHelper.getCustomerPaymentInstrument(UUID)
    };

    paymentToDelete.paymentMethod = paymentToDelete.payment.paymentMethod;
    paymentToDelete.isDefaultCard = paymentToDelete.payment.custom.braintreeDefaultCard;

    const isPaymentMethodRemoveAllowed = customerHelper.isPaymentMethodRemoveAllowed(paymentToDelete.payment);

    if (!isPaymentMethodRemoveAllowed) {
        res.json({ error: { message: Resource.msg('braintree.error.account.PAYMENT_METHOD_REMOVAL_IS_NOT_ALLOWED', 'locale', null) } });
        // Unsubscribe from 'route:BeforeComplete' event used in app_storefront_base
        this.off('route:BeforeComplete');
    } else {
        // Delete Payment Method from Braintree && Customer Payment Instruments
        braintreeBusinessLogic.deletePaymentMethod(paymentToDelete);

        if (paymentToDelete.isDefaultCard) {
            newDefaultAccount = paymentHelper.setAndReturnNewDefaultCard(paymentToDelete.paymentMethod);

            if (empty(newDefaultAccount)) {
                return next();
            }

            res.json({ newDefaultAccount: newDefaultAccount[0].UUID });
        }
    }
    return next();
});

server.get(
    'UpdateBillingAddress',
    csrfProtection.generateToken,
    userLoggedIn.validateLoggedIn,
    function (req, res, next) {
        const UUID = req.querystring.UUID;
        const customerPaymentInstrument = customerHelper.getCustomerPaymentInstrument(UUID);

        if (!customerPaymentInstrument) {
            res.setStatusCode(404);
            res.render('error/notFound');

            return next();
        }

        const billingAddressForm = server.forms.getForm('address');
        const billingAddress = JSON.parse(customerPaymentInstrument.custom.braintreeCreditCardBillingAddress);

        billingAddressForm.clear();

        // Fills form in case if billing address exist and leave it empty if not
        if (billingAddress) {
            billingAddressForm.copyFrom({
                firstName: billingAddress.firstName,
                lastName: billingAddress.lastName,
                address1: billingAddress.address1,
                address2: billingAddress.address2,
                city: billingAddress.city,
                postalCode: billingAddress.postalCode,
                country: billingAddress.country,
                stateCode: billingAddress.stateCode,
                phone: billingAddress.phone
            });
        }

        const breadcrumbs = [
            {
                htmlValue: Resource.msg('global.home', 'common', null),
                url: URLUtils.home().toString()
            },
            {
                htmlValue: Resource.msg('page.title.myaccount', 'account', null),
                url: braintreeUrls.accountShow
            },
            {
                htmlValue: Resource.msg('page.title.billingaddress', 'account', null),
                url: URLUtils.url('PaymentInstruments-UpdateBillingAddress', 'UUID', UUID).toString()
            }
        ];

        res.render('braintree/account/billing/billingAddress', {
            UUID: UUID,
            breadcrumbs: breadcrumbs,
            braintree: {
                billingAddressForm: billingAddressForm
            }
        });

        return next();
    }
);

server.post(
    'SaveBillingAddress',
    userLoggedIn.validateLoggedIn,
    csrfProtection.validateAjaxRequest,
    function (req, res, next) {
        const UUID = request.httpParameterMap.uuid.value;
        const errorMessage = Resource.msg('braintree.creditcard.error.validation', 'locale', null);
        const customerPaymentInstrument = customerHelper.getCustomerPaymentInstrument(UUID);

        if (!customerPaymentInstrument) {
            res.json({
                success: false,
                error: [errorMessage]
            });

            return next();
        }

        const billingAddressForm = server.forms.getForm('address');

        if (!billingAddressForm.valid) {
            res.json({
                success: false,
                error: [errorMessage],
                fields: formErrors.getFormErrors(billingAddressForm)
            });

            return next();
        }

        try {
            const billingAddress = processorHelper.saveCustomerBillingAddress(customerPaymentInstrument, billingAddressForm);

            if (billingAddress.error) {
                throw billingAddress.error;
            }
        } catch (error) {
            res.json({
                success: false,
                error: error
            });

            return next();
        }

        billingAddressForm.clear();

        const flashMessages = require('~/cartridge/config/flashMessages');

        flashMessages.put('message', Resource.msg('message.billingaddress.successfulupdate', 'account', null));

        res.json({
            success: true,
            redirectUrl: braintreeUrls.accountShow
        });

        return next();
    }
);

module.exports = server.exports();
