'use strict';

/**
 * SFCC API inclusions.
 */
const LocalServiceRegistry = require('dw/svc/LocalServiceRegistry');

const payPalRestServiceName = 'int_braintree.http.rest.Paypal';

const payPalRestConfigs = {
    getAccessTokenByAuthorizationCode: {
        requestType: 'POST',
        requestURL: 'oauth2/token',
        requestHeaders: {
            authHeader: 'Basic ',
            contentTypeHeader: 'application/x-www-form-urlencoded;charset=UTF-8'
        }
    },
    getCustomerInfo: {
        requestType: 'GET',
        requestURL: 'identity/oauth2/userinfo?schema=paypalv1.1',
        requestHeaders: {
            authHeader: 'Bearer ',
            contentTypeHeader: 'application/json'
        }
    }
};

/**
 * This is a function that is used to set the service configurations
 * @param {dw.svc.Service} service current service object
 * @param {Object} configs call configurations
 * @param {Object} request call request
 */
function setServiceConfigs(service, configs, request) {
    service.setURL(service.configuration.credential.URL + configs.requestURL);
    service.setRequestMethod(configs.requestType);

    if (request.accessToken) {
        service.addHeader('Authorization', configs.requestHeaders.authHeader + request.accessToken);
    } else {
        const Encoding = require('dw/crypto/Encoding');
        const Bytes = require('dw/util/Bytes');

        const authCredentials = [service.configuration.credential.user, service.configuration.credential.password].join(':');
        const basicToken = Encoding.toBase64(new Bytes(authCredentials));

        service.addHeader('Authorization', configs.requestHeaders.authHeader + basicToken);
    }

    service.addHeader('Content-Type', configs.requestHeaders.contentTypeHeader);
}

module.exports = function () {
    let payPalRESTService = null;

    try {
        payPalRESTService = LocalServiceRegistry.createService(payPalRestServiceName, {

            createRequest: function (service, request) {
                setServiceConfigs(service, payPalRestConfigs[request.requestId], request);

                if (request.requestBody) {
                    return Object.keys(request.requestBody).map(function (key) {
                        return [key, request.requestBody[key]].join('=');
                    }).join('&');
                }
                return '';
            },
            parseResponse: function (service, response) {
                return response.statusCode === 200 ? JSON.parse(response.text) : null;
            }
        });
    } catch (error) {
        const Logger = require('dw/system/Logger');
        Logger.error(error);
    }

    return payPalRESTService;
};
