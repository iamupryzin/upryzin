'use strict';

const BTGraphQLSdk = require('*/cartridge/models/btGraphQLSdk');
const btGraphQLSdk = new BTGraphQLSdk();

/**
 * This function is to handle the post payment authorization customizations
 * @param {Object} result - Authorization Result
 * @param {Order} order - order
 * @param {Object} options - Handle custom processing post authorization req, res
 * @returns {Object} response Braintree Error response or {}
 */
function postAuthorization(result, order, options) { // eslint-disable-line no-unused-vars
    const paymentHelper = require('~/cartridge/scripts/braintree/helpers/paymentHelper');

    const paymentInstrument = paymentHelper.getBraintreePaymentInstrument(order);

    // Updates customer if he is a guest.
    if (!order.customer.authenticated && paymentInstrument.paymentTransaction.accountID) {
        btGraphQLSdk.updateCustomer({
            customerId: paymentInstrument.paymentTransaction.accountID,
            firstName: order.shipments[0].shippingAddress.firstName,
            lastName: order.shipments[0].shippingAddress.lastName,
            phoneNumber: order.shipments[0].shippingAddress.phone,
            email: order.customerEmail
        });
    }

    if (result.error && session.privacy.braintreeErrorMsg) {
        const response = {
            error: true,
            errorStage: {
                stage: 'payment',
                step: 'paymentInstrument'
            },
            errorMessage: session.privacy.braintreeErrorMsg
        };

        session.privacy.braintreeErrorMsg = null;

        return response;
    }

    return {};
}

exports.postAuthorization = postAuthorization;
