'use strict';

var {
    updateShippingAddress,
    updateBillingForm,
    getBillingAddressFromStringValue
} = require('~/cartridge/scripts/hooks/payment/processor/processorHelper');

/**
 * SRC form processor:
 * Updating Shipping Address (only from Cart Checkout)
 * Adding paymentMethod to viewData
 *
 * @param {Object} req the request object
 * @param {Object} paymentForm - the payment form
 * @param {Object} viewFormData - object contains billing form data
 * @returns {Object} an object that has payment information
 */
function processForm(req, paymentForm, viewFormData) {
    const BasketMgr = require('dw/order/BasketMgr');
    const currentBasket = BasketMgr.getCurrentBasket();
    const httpParameterMap = req.httpParameterMap;
    const viewData = viewFormData;
    const usingMultiShipping = false; // Current integration support only single shpping

    // All needed parameters for billing address update
    const updateBillingObject = {
        data: {
            req: req,
            paymentForm: paymentForm,
            viewData: viewData
        },
        nonce: httpParameterMap.braintreeSrcNonce.stringValue,
        billingAddress: getBillingAddressFromStringValue(httpParameterMap.braintreeSrcBillingAddress)
    };

    req.session.privacyCache.set('usingMultiShipping', usingMultiShipping);

    // Error handling
    if (empty(httpParameterMap.braintreeSrcNonce.stringValue) && empty(httpParameterMap.accountUUID.stringValue)) {
        return { error: true };
    }

    viewData.paymentMethod = {
        value: paymentForm.paymentMethod.value
    };

    // Shipping handling
    if (httpParameterMap.pageFlowCart.stringValue) {
        updateShippingAddress(httpParameterMap.braintreeSrcShippingAddress.stringValue, currentBasket.getDefaultShipment());
    }

    // Handle Billing Form
    // To be update when customer changed a billing address of session account on billing page
    updateBillingForm(updateBillingObject);

    return {
        error: false,
        viewData: viewData
    };
}

exports.processForm = processForm;
