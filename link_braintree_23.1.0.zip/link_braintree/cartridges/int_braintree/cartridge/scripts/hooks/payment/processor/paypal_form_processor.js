'use strict';

var {
    getSavedPayPalPaymentInstrumentByUUID
} = require('~/cartridge/scripts/braintree/helpers/customerHelper');
var {
    createPreferredAddressObj,
    updateShippingAddress,
    getBillingAddressFromBasket,
    isSessionPayPalAccountUsed,
    billingAddressHasBeenChanged,
    updateBillingAddressFileds
} = require('~/cartridge/scripts/hooks/payment/processor/processorHelper');
var {
    getAmountPaid
} = require('~/cartridge/scripts/braintree/helpers/paymentHelper');

/**
 * Getting Preferred Shipping Address, Checkout from Cart scenario
 *
 * if user has default shipping info on store and saved PayPal account,
 * then use default shipping info from store otherwise use shipping from PayPal
 *
 * @param {Object} req the request object
 * @returns {Object} an object that has customer shipping address
 */
function getPreferredShippingAddress(req) {
    let preferredShippingAddress = req.httpParameterMap.braintreePaypalShippingAddress.stringValue;

    if (!preferredShippingAddress && customer.profile && customer.profile.addressBook.preferredAddress) {
        preferredShippingAddress = createPreferredAddressObj(customer.profile.addressBook.preferredAddress);
    }

    return preferredShippingAddress;
}

/**
 * Update Billing Form
 *
 * Checkout scenarios: PDP, Minicart, Cart, Billing page
 *
 * Authenticated scenario
 *      - Saved Billing data
 *      - New PayPal account (new billing data)
 *
 * Unauthenticated scenario
 *      - New PayPal account (new billing data)
 *
 * @param {Object} data req, paymentForm, viewFormData
 */
function updateBillingForm(data) {
    var BasketMgr = require('dw/order/BasketMgr');
    var basket = BasketMgr.getCurrentBasket();
    var httpParameterMap = data.req.httpParameterMap;
    var customerPaymentInstrument = null;
    var billingAddressToUpdate = null;
    var isSessionAccountUsed = isSessionPayPalAccountUsed(httpParameterMap.braintreePaypalNonce.stringValue);
    var isBillingAddressChanged;

    // Session scenario
    if (isSessionAccountUsed) {
        isBillingAddressChanged = billingAddressHasBeenChanged(
            basket,
            httpParameterMap.braintreePaypalNonce.stringValue,
            httpParameterMap.braintreePaypalBillingAddress.stringValue
        );

        if (isBillingAddressChanged) {
            billingAddressToUpdate = getBillingAddressFromBasket(basket);
            updateBillingAddressFileds(billingAddressToUpdate, data);
        }
    // Stored account scenario
    } else {
        customerPaymentInstrument = getSavedPayPalPaymentInstrumentByUUID(httpParameterMap);

        if (customerPaymentInstrument) {
            billingAddressToUpdate = JSON.parse(customerPaymentInstrument.custom.braintreePaypalAccountAddresses);
            updateBillingAddressFileds(billingAddressToUpdate, data);
        }
    }
}

/**
 * PayPal form processor:
 * - Validating basket amount
 * - Updating Shipping Address (only from Cart Checkout)
 * - Adding paymentMethod to viewData
 * - Updating Billing Form
 *
 * @param {Object} req the request object
 * @param {Object} paymentForm - the payment form
 * @param {Object} viewFormData - object contains billing form data
 * @returns {Object} an object that has payment information
 */
function processForm(req, paymentForm, viewFormData) {
    const BasketMgr = require('dw/order/BasketMgr');
    const Resource = require('dw/web/Resource');
    const currentBasket = BasketMgr.getCurrentBasket();
    const currentBasketAmount = getAmountPaid(currentBasket).value;
    const viewData = viewFormData;
    const usingMultiShipping = false; // Current integration support only single shpping
    req.session.privacyCache.set('usingMultiShipping', usingMultiShipping);

    if (currentBasketAmount === 0) {
        // respond with custom PP error
        return {
            fieldErrors: [],
            serverErrors: [Resource.msg('error.paypal.zeroamount', 'error', null)],
            error: true
        };
    }

    viewData.paymentMethod = {
        value: paymentForm.paymentMethod.value
    };

    // Shipping handling
    if (req.httpParameterMap.expressCheckoutFlow.stringValue) {
        updateShippingAddress(getPreferredShippingAddress(req), currentBasket.getDefaultShipment());
    }

    // Handle Billing Form
    // To be update when customer changed a billing address of session account on billing page or use a saved paypal account
    updateBillingForm({ req: req, paymentForm: paymentForm, viewData: viewData });

    return {
        error: false,
        viewData: viewData
    };
}

exports.processForm = processForm;
