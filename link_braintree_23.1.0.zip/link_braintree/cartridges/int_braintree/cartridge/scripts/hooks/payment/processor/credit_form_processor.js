'use strict';

const paymentHelper = require('~/cartridge/scripts/braintree/helpers/paymentHelper');

/**
 * Verify a saved credit card with a given CvvOnlyNonce
 * Depends on verification result the function returns an object with error = false or
 * a general handle hook error object with an appropriate error messages
 * @param {Object} dataToVerify An object represented a credit cart token and cvvOnlyConce need to be verify
 * @param {Object} requestErrorObject A general Handle hook object
 * @returns {Object} An object
 */
function reVerifyCreditCard(dataToVerify, requestErrorObject) {
    const Resource = require('dw/web/Resource');
    const braintreeConstants = require('*/cartridge/config/braintreeConstants');
    const BTGraphQLSdk = require('*/cartridge/models/btGraphQLSdk');
    const btGraphQLSdk = new BTGraphQLSdk();

    const reVerifyResult = btGraphQLSdk.verifyCreditCard({
        paymentMethodId: dataToVerify.paymentMethodId,
        tokenizedCvv: dataToVerify.tokenizedCvv
    });

    if (reVerifyResult.status === braintreeConstants.VERIFICATION_GATEWAY_REJECTED_STATUS) {
        const reVerifyErrMsg = Resource.msg('braintree.creditcard.verification.failed', 'locale', null);

        paymentHelper.getLogger().error(reVerifyErrMsg);
        requestErrorObject.serverErrors = [reVerifyErrMsg];

        return requestErrorObject;
    }

    return {
        error: false
    };
}

/**
 * Credit Card form processor:
 * Adding paymentMethod to viewData
 *
 * @param {Object} req the request object
 * @param {Object} paymentForm - the payment form
 * @param {Object} viewFormData - object contains billing form data
 * @returns {Object} an object that has payment information
 */
function processForm(req, paymentForm, viewFormData) {
    const customerHelper = require('~/cartridge/scripts/braintree/helpers/customerHelper');
    const processorHelper = require('~/cartridge/scripts/hooks/payment/processor/processorHelper');
    const prefs = require('~/cartridge/config/braintreePreferences');
    const httpParameterMap = req.httpParameterMap;
    const selectedCreditCardUuid = httpParameterMap.braintreeCreditCardList.stringValue;
    const clientRequestErrorObj = {
        error: true,
        fieldErrors: []
    };

    const usingMultiShipping = false; // Current integration support only single shipping
    req.session.privacyCache.set('usingMultiShipping', usingMultiShipping);

    const viewData = viewFormData;
    viewData.paymentMethod = {
        value: paymentForm.paymentMethod.value,
        htmlName: paymentForm.paymentMethod.value
    };

    // Saved Credit card re-verification
    if (processorHelper.isUsedSavedCardMethod(selectedCreditCardUuid)) {
        try {
            const customerPaymentInstrument = customerHelper.getCustomerPaymentInstrument(selectedCreditCardUuid);
            const cvvOnlyNonce = httpParameterMap.get('braintreeCvvOnlyNonce').getStringValue();

            if (prefs.isCcReVerifyEnabled && cvvOnlyNonce) {
                const reVerifyCardResult = reVerifyCreditCard({
                    paymentMethodId: customerPaymentInstrument.creditCardToken,
                    tokenizedCvv: cvvOnlyNonce
                }, clientRequestErrorObj);

                if (reVerifyCardResult.error) {
                    return reVerifyCardResult;
                }
            }
        } catch (error) {
            paymentHelper.getLogger().error(error.message);

            clientRequestErrorObj.serverErrors = [error.message];

            return clientRequestErrorObj;
        }
    }

    if (httpParameterMap.braintreePaymentMethodNonce.empty) {
        // Handle Billing Form
        processorHelper.updateBillingAddressFileds(
            processorHelper.getBillingAddressFromStringValue(httpParameterMap.braintreeCardBillingAddress),
            {
                viewData: viewData
            }
        );
    }

    return {
        error: false,
        viewData: viewData
    };
}

exports.processForm = processForm;
