var {
    updateShippingAddress,
    updateBillingForm,
    getBillingAddressFromStringValue
} = require('~/cartridge/scripts/hooks/payment/processor/processorHelper');

/**
 * GooglePay form processor:
 * Adding paymentMethod to viewData
 * Updating Shipping Address (only from Cart Checkout)
 *
 * @param {Object} req the request object
 * @param {Object} paymentForm - the payment form
 * @param {Object} viewFormData - object contains billing form data
 * @returns {Object} an object that has payment information
 */
function processForm(req, paymentForm, viewFormData) {
    const BasketMgr = require('dw/order/BasketMgr');
    const currentBasket = BasketMgr.getCurrentBasket();
    const viewData = viewFormData;
    const usingMultiShipping = false; // Current integration support only single shpping
    const httpParameterMap = req.httpParameterMap;

    // All needed parameters for billing address update
    const updateBillingObject = {
        data: {
            req: req,
            paymentForm: paymentForm,
            viewData: viewData
        },
        nonce: httpParameterMap.braintreeGooglePayNonce.stringValue,
        billingAddress: getBillingAddressFromStringValue(httpParameterMap.braintreeGooglePayBillingAddress)
    };
    req.session.privacyCache.set('usingMultiShipping', usingMultiShipping);

    viewData.paymentMethod = {
        value: paymentForm.paymentMethod.value
    };

    // Shipping handling
    if (httpParameterMap.pageFlowCart.stringValue) {
        updateShippingAddress(httpParameterMap.braintreeGooglePayShippingAddress.stringValue, currentBasket.getDefaultShipment());
    }

    // Handle Billing Form
    // To be update when customer changed a billing address of session account on the Billing Page
    updateBillingForm(updateBillingObject);

    return {
        error: false,
        viewData: viewData
    };
}

exports.processForm = processForm;
