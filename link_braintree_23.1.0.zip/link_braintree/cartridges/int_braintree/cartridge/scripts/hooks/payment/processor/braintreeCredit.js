'use strict';

var Transaction = require('dw/system/Transaction');
var OrderMgr = require('dw/order/OrderMgr');
var PaymentMgr = require('dw/order/PaymentMgr');
var PaymentInstrument = require('dw/order/PaymentInstrument');
var Resource = require('dw/web/Resource');

var prefs = require('~/cartridge/config/braintreePreferences');
var {
    deleteBraintreePaymentInstruments,
    getNonGiftCertificateAmount,
    getLogger,
    handleErrorCode
} = require('~/cartridge/scripts/braintree/helpers/paymentHelper');
var {
    saveGeneralTransactionData,
    createBaseSaleTransactionData,
    verifyTransactionStatus,
    saveCustomerCreditCard,
    isUsedSessionCreditCard,
    isUsedSavedCardMethod,
    isSessionCardAlreadyUsed,
    getUsedCreditCardFromForm,
    checkForPaymentInstruments,
    createCcBaForBt
} = require('~/cartridge/scripts/hooks/payment/processor/processorHelper');
var {
    setBraintreeDefaultCard,
    getCustomerPaymentInstrument,
    getCustomerPaymentInstrumentByCreditCardToken
} = require('~/cartridge/scripts/braintree/helpers/customerHelper');

var BTGraphQLSdk = require('*/cartridge/models/btGraphQLSdk');
var btGraphQLSdk = new BTGraphQLSdk();

/**
 * Creates a request data for updateCreditCardBillingAddress graphQl call
 * @param  {dw.order.OrderPaymentInstrument} paymentInstrument Used payment instrument
 * @return {Object} An Object
 */
function createUpdateCreditCardBaRequestData(paymentInstrument) {
    try {
        const billingAddress = JSON.parse(paymentInstrument.custom.braintreeCreditCardBillingAddress);

        return {
            paymentMethodId: paymentInstrument.creditCardToken,
            billingAddress: createCcBaForBt(billingAddress)
        };
    } catch (error) {
        getLogger().error(error);

        throw error;
    }
}

/**
 * Perform API call to create new(sale) transaction
 * @param  {dw.order.Order} order Current order
 * @param  {dw.order.OrderPaymentInstrument} paymentInstrument Used payment instrument
 * @returns {Object} Response data from API call
 */
function createSaleTransactionData(order, paymentInstrument) {
    if (empty(paymentInstrument.custom.braintreePaymentMethodNonce) && empty(paymentInstrument.creditCardToken)) {
        throw new Error('paymentInstrument.custom.braintreePaymentMethodNonce or paymentInstrument.creditCardToken are empty');
    }

    var data = createBaseSaleTransactionData(order, paymentInstrument, prefs);

    data.descriptor = {
        name: prefs.creditCardDescriptorName || '',
        phone: prefs.creditCardDescriptorPhone || '',
        url: prefs.creditCardDescriptorUrl || ''
    };
    data.isCreditCard = true;

    if (prefs.isFraudToolsEnabled) {
        data.deviceData = paymentInstrument.custom.braintreeFraudRiskData;
    }

    return data;
}

/**
 * Write info about failed order into payment instrument, and mark customer as Braintree customer
 * @param {dw.order.Order} orderRecord Current order
 * @param {dw.order.OrderPaymentInstrument} paymentInstrumentRecord Used payment instrument
 * @param {string} braintreeError Error text
 * @return {Object} Error object indicator
 */
function authorizeFailedFlow(orderRecord, paymentInstrumentRecord, braintreeError) {
    Transaction.wrap(function () {
        orderRecord.custom.isBraintree = true;
        paymentInstrumentRecord.custom.braintreeFailReason = braintreeError;
        paymentInstrumentRecord.custom.braintreeSaveCreditCard = null;
        paymentInstrumentRecord.custom.braintreeDefaultCard = null;
    });

    handleErrorCode(braintreeError);

    return { error: true };
}

/**
 * Save result of the success sale transaction
 * @param {dw.order.Order} orderRecord Current order
 * @param {dw.order.OrderPaymentInstrument} paymentInstrumentRecord Current payment instrument
 * @param {Object} responseTransaction Response data from API call
 * @param {Object} requestData Request data to API call
 */
function saveTransactionData(orderRecord, paymentInstrumentRecord, responseTransaction, requestData) {
    var threeDSecureInfo = responseTransaction.paymentMethodSnapshot.threeDSecure;

    Transaction.wrap(function () {
        // Save token for lightning order managment
        if (!empty(responseTransaction.paymentMethod) && empty(paymentInstrumentRecord.creditCardToken)) {
            paymentInstrumentRecord.creditCardToken = responseTransaction.paymentMethod.legacyId;
        }

        saveGeneralTransactionData(orderRecord, paymentInstrumentRecord, responseTransaction, requestData);

        paymentInstrumentRecord.custom.braintree3dSecureStatus = threeDSecureInfo.authenticationStatus || null;
    });
}

/**
 * Create Braintree payment instrument
 * @param {Object} basket Arguments of the HTTP call
 * @returns {Object} handle call result
 */
function Handle(basket) {
    var paymentInstrument = null;
    var result = { success: true };
    var httpParameterMap = request.httpParameterMap;
    var selectedCreditCardUuid = httpParameterMap.braintreeCreditCardList.stringValue;
    var braintreePaymentMethodNonce = httpParameterMap.braintreePaymentMethodNonce.stringValue;
    var isbraintreePaymentMethodNonceExist = braintreePaymentMethodNonce && braintreePaymentMethodNonce !== '';
    var creditCardBasketPaymentInstrument = basket.getPaymentInstruments(PaymentInstrument.METHOD_CREDIT_CARD);
    var clientRequestErrorObj = {
        error: true,
        fieldErrors: [],
        serverErrors: [
            Resource.msg('braintree.error.CLIENT_REQUEST_ERROR', 'locale', null)
        ]
    };

    // Marks not saved credit card in account
    session.privacy.braintree3dSecureNonce = false;

    var paymentMethodId = prefs.paymentMethods['BRAINTREE_' + httpParameterMap.braintreeCardPaymentMethod].paymentMethodId;
    var paymentProcessor = PaymentMgr.getPaymentMethod(paymentMethodId).getPaymentProcessor();

    // New/session credit card cases
    if (isUsedSessionCreditCard(selectedCreditCardUuid)) {
        if (!isbraintreePaymentMethodNonceExist) {
            return clientRequestErrorObj;
        }
        // When proceed with already used session card (no changes needed for payment instrument, except saving flag)
        if (isSessionCardAlreadyUsed(braintreePaymentMethodNonce, creditCardBasketPaymentInstrument)) {
            // Update of braintreeSaveCreditCard property is needed in case when customer is registered and vault mode is enabled
            Transaction.wrap(function () {
                creditCardBasketPaymentInstrument[0].custom.braintreeSaveCreditCard = httpParameterMap.braintreeSaveCreditCard.booleanValue;
            });
        } else { // When proceed with new card
            var creditCard = getUsedCreditCardFromForm(session.forms.billing.creditCardFields);

            Transaction.wrap(function () {
                try {
                    deleteBraintreePaymentInstruments(basket);

                    paymentInstrument = basket.createPaymentInstrument(paymentMethodId, getNonGiftCertificateAmount(basket));
                    paymentInstrument.paymentTransaction.setPaymentProcessor(paymentProcessor);
                    paymentInstrument.creditCardType = creditCard.creditCardType;
                    paymentInstrument.creditCardNumber = creditCard.creditCardNumber;
                    paymentInstrument.creditCardHolder = creditCard.creditCardHolder;
                    paymentInstrument.setCreditCardExpirationMonth(creditCard.creditCardExpirationMonth);
                    paymentInstrument.setCreditCardExpirationYear(creditCard.creditCardExpirationYear);

                    // Payment instrument custom attributes saving
                    paymentInstrument.custom.braintreeCreditCardBillingAddress = httpParameterMap.braintreeCardBillingAddress.stringValue;
                    paymentInstrument.custom.braintreePaymentMethodNonce = braintreePaymentMethodNonce;
                    paymentInstrument.custom.braintreeSaveCreditCard = httpParameterMap.braintreeSaveCreditCard.booleanValue;
                    paymentInstrument.custom.braintreeIs3dSecureRequired = httpParameterMap.braintreeIs3dSecureRequired.booleanValue;
                    paymentInstrument.custom.braintreeFraudRiskData = httpParameterMap.braintreeDeviceData.stringValue;
                } catch (error) {
                    getLogger().error(error);

                    result = clientRequestErrorObj;
                }
            });
        }
        // Saved card case (Credit Card/SRC Card)
    } else if (isUsedSavedCardMethod(selectedCreditCardUuid)) {
        if (httpParameterMap.braintreeIs3dSecureRequired.booleanValue && !isbraintreePaymentMethodNonceExist) {
            return clientRequestErrorObj;
        }

        // Marks saved credit card in account
        session.privacy.braintree3dSecureNonce = true;
        var customerPaymentInstrument = getCustomerPaymentInstrument(selectedCreditCardUuid);

        Transaction.wrap(function () {
            deleteBraintreePaymentInstruments(basket);

            paymentInstrument = basket.createPaymentInstrumentFromWallet(customerPaymentInstrument, getNonGiftCertificateAmount(basket));
            paymentInstrument.paymentTransaction.setPaymentProcessor(paymentProcessor);

            // Payment instrument custom attributes saving
            if (!paymentInstrument.custom.braintreeCreditCardBillingAddress) {
                paymentInstrument.custom.braintreeCreditCardBillingAddress = httpParameterMap.braintreeCardBillingAddress.stringValue;
            }

            paymentInstrument.custom.braintreeIs3dSecureRequired = httpParameterMap.braintreeIs3dSecureRequired.booleanValue;
            paymentInstrument.custom.braintreeFraudRiskData = httpParameterMap.braintreeDeviceData.stringValue;
        });
    }

    return result;
}

/**
 * Authorize payment function
 * @param {string} orderNumber Order Number
 * @param {Object} paymentInstrument Payment Instrument
 * @returns {Object} success object
 */
function Authorize(orderNumber, paymentInstrument) {
    const order = OrderMgr.getOrder(orderNumber);

    if (paymentInstrument && paymentInstrument.getPaymentTransaction().getAmount().getValue() > 0) {
        try {
            let isPaymentInstrumentsExist;

            if (customer.authenticated) {
                isPaymentInstrumentsExist = checkForPaymentInstruments(prefs.paymentMethods.BRAINTREE_CREDIT.paymentMethodId);
            }

            const saleTransactionRequestData = createSaleTransactionData(order, paymentInstrument);
            const responseData = btGraphQLSdk.createTransaction(saleTransactionRequestData).transaction;

            const customerPaymentInstrument = getCustomerPaymentInstrumentByCreditCardToken(
                paymentInstrument.creditCardToken
            );

            // throw error in case of unsuccessful status
            verifyTransactionStatus(responseData, paymentInstrument, order);
            saveTransactionData(order, paymentInstrument, responseData, saleTransactionRequestData);

            // Flow with the already saved payment method
            if (customerPaymentInstrument) {
                // Saves a billing address on customer payment instrument level as well as on
                // Braintree side if current credit card does not have a saved billing address
                if (!customerPaymentInstrument.custom.braintreeCreditCardBillingAddress) {
                    // Billing address will be save for this Credit card on the Braintree side
                    btGraphQLSdk.updateCreditCardBillingAddress(createUpdateCreditCardBaRequestData(paymentInstrument));

                    Transaction.wrap(function () {
                        // Saves a credit card billing address on the customer payment instument level
                        customerPaymentInstrument.custom.braintreeCreditCardBillingAddress = paymentInstrument.custom.braintreeCreditCardBillingAddress;

                        paymentInstrument.custom.braintreeCreditCardBillingAddress = null;
                    });
                }
            }

            // Flow with the new credit card
            if (paymentInstrument.custom.braintreeSaveCreditCard) {
                const savedCreditCardPiObject = saveCustomerCreditCard(
                    responseData,
                    paymentInstrument.creditCardHolder
                );
                const paymentMethod = responseData.paymentMethod;

                // Billing address will be save for this Credit card on the Braintree side
                btGraphQLSdk.updateCreditCardBillingAddress(createUpdateCreditCardBaRequestData(paymentInstrument));

                // Case when this is first payment instrument, then set it to default
                if (!isPaymentInstrumentsExist) {
                    setBraintreeDefaultCard(paymentMethod.legacyId);
                }

                Transaction.wrap(function () {
                    if (!customer.authenticated && prefs.vaultMode) {
                        paymentInstrument.paymentTransaction.accountID = responseData.customer.id;
                    }

                    paymentInstrument.custom.braintreeSaveCreditCard = null;

                    if (!savedCreditCardPiObject.error) {
                        // Saves a credit card billing address on the customer payment instument level
                        savedCreditCardPiObject.customerPaymentInstrument.custom.braintreeCreditCardBillingAddress = paymentInstrument.custom.braintreeCreditCardBillingAddress;

                        paymentInstrument.custom.braintreeCreditCardBillingAddress = null;
                    }
                });
            }
        } catch (error) {
            getLogger().error(error);

            var err = error.customMessage || error.message;

            return authorizeFailedFlow(order, paymentInstrument, err);
        }
    } else {
        Transaction.wrap(function () {
            order.removePaymentInstrument(paymentInstrument);
        });
    }

    return { authorized: true };
}

exports.Handle = Handle;
exports.Authorize = Authorize;
