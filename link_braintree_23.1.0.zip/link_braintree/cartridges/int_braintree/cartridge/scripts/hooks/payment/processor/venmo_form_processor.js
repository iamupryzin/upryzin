'use strict';

const processorHelper = require('~/cartridge/scripts/hooks/payment/processor/processorHelper');

/**
 * Creates billing address object from shipping address
 *
 * @param {dw.order.OrderAddress} shippingAddress an object that represents shipping address
 * @returns {Object} an object that represents billing address
 */
function createBillingAddressFromShippingAddress(shippingAddress) {
    return {
        firstName: shippingAddress.firstName,
        lastName: shippingAddress.lastName,
        streetAddress: shippingAddress.address1,
        extendedAddress: shippingAddress.address2,
        locality: shippingAddress.city,
        postalCode: shippingAddress.postalCode,
        countryCodeAlpha2: shippingAddress.countryCode.value,
        region: shippingAddress.stateCode,
        phone: shippingAddress.phone
    };
}

/**
 * Venmo form processor:
 * Adding paymentMethod to viewData and updating billing address
 *
 * @param {Object} req the request object
 * @param {Object} paymentForm - the payment form
 * @param {Object} viewFormData - object contains billing form data
 * @returns {Object} an object that has payment information
 */
function processForm(req, paymentForm, viewFormData) {
    const basket = require('dw/order/BasketMgr').currentBasket;
    const shippingAddress = basket.defaultShipment.shippingAddress;
    const billingAddressToUpdate = createBillingAddressFromShippingAddress(shippingAddress);
    const viewData = viewFormData;
    const usingMultiShipping = false; // Current integration support only single shipping

    req.session.privacyCache.set('usingMultiShipping', usingMultiShipping);

    if (!processorHelper.isBillingAddressesEqual(basket, billingAddressToUpdate)) {
        processorHelper.updateBillingAddressFileds(
            billingAddressToUpdate,
            { req: req, paymentForm: paymentForm, viewData: viewData }
        );
    }

    viewData.paymentMethod = {
        value: paymentForm.paymentMethod.value,
        htmlName: paymentForm.paymentMethod.htmlName
    };

    return {
        error: false,
        viewData: viewData
    };
}

exports.processForm = processForm;
