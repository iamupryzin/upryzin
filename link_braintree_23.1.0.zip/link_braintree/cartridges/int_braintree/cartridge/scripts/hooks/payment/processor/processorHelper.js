'use strict';

const Transaction = require('dw/system/Transaction');
const PaymentInstrument = require('dw/order/PaymentInstrument');

const prefs = require('~/cartridge/config/braintreePreferences');

const braintreeConstants = require('~/cartridge/config/braintreeConstants');
const customerHelper = require('~/cartridge/scripts/braintree/helpers/customerHelper');
const paymentHelper = require('~/cartridge/scripts/braintree/helpers/paymentHelper');

/**
 * Parse customer name from single string
 * @param {string} name name string
 * @return {Object} name object
 */
function createFullName(name) {
    const nameNoLongSpaces = name.trim().replace(/\s+/g, ' ').split(' ');

    if (nameNoLongSpaces.length === 1) {
        return {
            firstName: name,
            secondName: null,
            lastName: null
        };
    }
    const firstName = nameNoLongSpaces.shift();
    const lastName = nameNoLongSpaces.pop();
    const secondName = nameNoLongSpaces.join(' ');

    return {
        firstName: firstName,
        secondName: secondName.length ? secondName : null,
        lastName: lastName
    };
}

/**
 * Returns a prepared custom fields string
 * @param {dw.order.Order} order Order
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument Order payment instrument
 * @return {string} custom fields string
 */
function getCustomFields(order, paymentInstrument) {
    const HookMgr = require('dw/system/HookMgr');

    const paymentProcessorId = paymentInstrument.getPaymentTransaction().getPaymentProcessor().ID;
    const prefsCustomFields = prefs.customFields;
    const hookMethodName = paymentProcessorId.split('_')[1].toLowerCase();
    const cfObject = {};

    Object.keys(prefsCustomFields).forEach(function (fName) {
        const fArr = prefsCustomFields[fName].split(':');
        cfObject[fArr[0]] = fArr[1];
    });

    if (HookMgr.hasHook('braintree.customFields')) {
        const cfs = HookMgr.callHook('braintree.customFields', hookMethodName, { order: order, paymentInstrument: paymentInstrument });

        Object.keys(cfs).forEach(function (field) {
            cfObject[field] = cfs[field];
        });
    }

    return Object.keys(cfObject).reduce(function (resultStr, field2) {
        return resultStr + ['<', field2, '>', cfObject[field2], '</', field2, '>'].join('');
    }, '');
}

/** Returns a three-letter abbreviation for this Locale's country, or an empty string if no country has been specified for the Locale
 *
 * @param {string} localeId locale id
 * @return {string} a three-letter abbreviation for this lLocale's country, or an empty string
 */
function getISO3Country(localeId) {
    return require('dw/util/Locale').getLocale(localeId).getISO3Country();
}

/**
 * Create customer data for API call
 * @param {dw.order.Order} order Order object
 * @return {Object} Customer data for request
 */
function createGuestCustomerData(order) {
    const billingAddress = order.getBillingAddress();
    const shippingAddress = order.getDefaultShipment().getShippingAddress();

    return {
        id: null,
        firstName: billingAddress.getFirstName(),
        lastName: billingAddress.getLastName(),
        email: order.getCustomerEmail(),
        phone: billingAddress.getPhone() || shippingAddress.getPhone(),
        company: '',
        fax: ''
    };
}

/**
 * isCountryCodesUpperCase()
 * true - if SFRA uses uppercase for country code values
 * false - if SFRA uses lowercase for country code values
 * @returns {boolean} is country upper case
 */
function isCountryCodesUpperCase() {
    const billingForm = session.forms.billing;
    let countryOptions = null;
    let isCountryUpperCase = true;

    if (billingForm && billingForm.addressFields && billingForm.addressFields.country) {
        countryOptions = billingForm.addressFields.country.getOptions();

        isCountryUpperCase = Object.keys(countryOptions).every(function (optionName) {
            const option = countryOptions[optionName];

            return option.value && option.value.trim() !== '' && option.value !== option.value.toLowerCase();
        });
    }

    return isCountryUpperCase;
}

/**
 * Update Shipping Address
 * @param {Object} braintreeShippingAddress - shipping address
 * @param {dw.order.Basket} orderShippingAddress basket - Current users's basket Default Shipment
 */
function updateShippingAddress(braintreeShippingAddress, orderShippingAddress) {
    let shipping;
    const newShipping = typeof braintreeShippingAddress === 'string' ? JSON.parse(braintreeShippingAddress) : braintreeShippingAddress;
    newShipping.getProp = function (prop) {
        return this[prop] || '';
    };

    const countryCode = isCountryCodesUpperCase() ?
        newShipping.countryCodeAlpha2.toUpperCase() :
        newShipping.countryCodeAlpha2.toLowerCase();

    if (newShipping.recipientName) {
        const fullName = createFullName(newShipping.recipientName);

        newShipping.firstName = fullName.firstName;
        newShipping.secondName = fullName.secondName;
        newShipping.lastName = fullName.lastName;
    }

    Transaction.wrap(function () {
        shipping = orderShippingAddress.getShippingAddress() || orderShippingAddress.createShippingAddress();
        shipping.setCountryCode(countryCode);
        shipping.setCity(newShipping.getProp('locality'));
        shipping.setAddress1(newShipping.getProp('streetAddress'));
        shipping.setAddress2(newShipping.getProp('extendedAddress'));
        shipping.setPostalCode(decodeURIComponent(newShipping.getProp('postalCode')) || '');
        shipping.setStateCode(newShipping.getProp('region'));
        shipping.setPhone(newShipping.getProp('phone'));

        if (!empty(newShipping.firstName)) {
            shipping.setFirstName(newShipping.getProp('firstName'));
        }
        if (!empty(newShipping.secondName)) {
            shipping.setSecondName(newShipping.getProp('secondName'));
        }
        if (!empty(newShipping.lastName)) {
            shipping.setLastName(newShipping.getProp('lastName'));
        }
    });
}

/**
 * Save General Transaction Data
 * @param  {dw.order.Order} order Order
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument Order payment instrument
 * @param  {Object} responseTransaction - response transaction
 * @param  {Object} requestTransaction - request transaction
 */
function saveGeneralTransactionData(order, paymentInstrument, responseTransaction, requestTransaction) {
    const Money = require('dw/value/Money');
    const PT = require('dw/order/PaymentTransaction');
    const paymentTransaction = paymentInstrument.getPaymentTransaction();

    if (typeof responseTransaction === 'string') {
        // eslint-disable-next-line no-param-reassign
        responseTransaction = JSON.parse(responseTransaction);
    }

    const transaction = responseTransaction.transaction || responseTransaction;
    const transactionStatus = transaction.status;

    paymentTransaction.setTransactionID(transaction.legacyId);
    paymentTransaction.setAmount(new Money(transaction.amount.value, order.getCurrencyCode()));

    order.custom.isBraintree = true;
    order.custom.braintreePaymentStatus = transactionStatus;

    paymentTransaction.custom.braintreeRequest = typeof requestTransaction === 'string' ? requestTransaction : JSON.stringify(requestTransaction);
    paymentTransaction.custom.braintreeResponse = JSON.stringify(responseTransaction);

    paymentInstrument.custom.braintreePaymentMethodNonce = null;

    if (!prefs.isSettle && transactionStatus === braintreeConstants.TRANSACTION_STATUS_AUTHORIZED) {
        paymentTransaction.setType(PT.TYPE_AUTH);
    } else if (prefs.isSettle &&
        (transactionStatus === braintreeConstants.TRANSACTION_STATUS_SETTLING ||
            transactionStatus === braintreeConstants.TRANSACTION_STATUS_SUBMITTED_FOR_SETTLEMENT)) {
        paymentTransaction.setType(PT.TYPE_CAPTURE);
    }
}

/**
 * Adjust data if vault mode is allowed
 * @param {Object} preferences - preferencies data settings
 * @param {Object} data - data to adjust
 * @returns {void}
 */
function updateDataIfVaultModeAllowed(preferences, data) {
    const isVaultingAllowed = preferences.vaultMode;

    if (isVaultingAllowed) {
        data.vaultPaymentMethodAfterTransacting = {
            when: braintreeConstants.TRANSACTION_VAULT_ON_SUCCESS
        };
    }
}

/**
 * Create Base Sale Transaction Data
 * @param  {dw.order.Order} order Order
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument Order payment instrument
 * @param {Object} prefsData preferencies data settings
 * @returns {Object} data fields
 */
function createBaseSaleTransactionData(order, paymentInstrument, prefsData) {
    const customer = order.getCustomer();
    const isCustomerAuthentificated = customer.isAuthenticated();
    const creditCardToken = paymentInstrument.creditCardToken;
    const newPaymentMethodNonce = paymentInstrument.custom.braintreePaymentMethodNonce;

    const data = {
        orderId: order.getOrderNo(),
        amount: paymentHelper.getAmountPaid(order).getValue(),
        currencyCode: order.getCurrencyCode(),
        customFields: getCustomFields(order, paymentInstrument),
        options: {
            submitForSettlement: prefsData.isSettle
        },
        merchantAccountId: paymentHelper.getMerchantAccountID(order.getCurrencyCode())
    };

    // Case when customer is auth and used stored payment method
    // Nonce is taken from vault namager
    if (isCustomerAuthentificated && creditCardToken) {
        data.customerId = null;
        data.paymentMethodToken = creditCardToken;
        // Case when customer is auth and new payment method is used
    } else if (isCustomerAuthentificated && newPaymentMethodNonce) {
        data.customerId = customerHelper.getCustomerId(customer);
        data.paymentMethodNonce = newPaymentMethodNonce;
        // Add partial capturing functionality for BM (vaultPaymentMethodAfterTransacting property is need for token creation)
        updateDataIfVaultModeAllowed(prefsData, data);

        // Case when customer is guest
    } else {
        data.customerId = null;
        data.paymentMethodNonce = paymentInstrument.custom.braintreePaymentMethodNonce;
        // Add partial capturing functionality for BM (vaultPaymentMethodAfterTransacting property is need for token creation)
        updateDataIfVaultModeAllowed(prefsData, data);
    }

    const orderShippingAddress = order.getDefaultShipment().getShippingAddress();
    const shipping = paymentHelper.createShippingAddressData(orderShippingAddress);
    const orderLocale = order.getCustomerLocaleID();
    const orderCountry = orderLocale.split('_')[1];
    const orderCountryToLowCase = orderCountry ? orderCountry.toLowerCase() : null;
    const customerShippingAddressCountry = shipping.countryCode.toLowerCase();

    if (orderCountryToLowCase === customerShippingAddressCountry) {
        shipping.countryCode = getISO3Country(order.getCustomerLocaleID());
    }

    data.shipping = shipping;

    if (prefsData.isL2L3) {
        data.taxAmount = order.getTotalTax().toNumberString();

        if (paymentInstrument.paymentMethod === braintreeConstants.PAYMENT_METHOD_ID_PAYPAL) {
            /** Rounding issues due to discounts, removed from scope due to bug on PayPal / BT end.
                * No ETA on bug fix and not in roadmap.
                *
                * data.shippingAmount = order.getShippingTotalPrice().value;
                * data.discountAmount = getOrderLevelDiscountTotal(order);
                * data.lineItems = getLineItems(order.productLineItems);
            */
        } else {
            data.shippingAmount = order.getShippingTotalPrice().toNumberString();
            data.discountAmount = paymentHelper.getOrderLevelDiscountTotal(order);
            data.lineItems = paymentHelper.getLineItems(order);
        }
    }

    return data;
}

/**
* @param {Object} createPaymentMethodResponseData Payment method response data from Braintree response
* @returns {Object} Card name
 */
function createOwnerName(createPaymentMethodResponseData) {
    const { firstName, lastName } = createPaymentMethodResponseData.customer;

    return [firstName || '', lastName || ''].join(' ');
}

/**
 * It checks if the customer has a payment instrument in wallet for the payment method ID passed in
 * @param {string} paymentMethodId - The payment method ID for check.
 * @returns {boolean} - identifying whether there is payment instrument
 */
function checkForPaymentInstruments(paymentMethodId) {
    const customerWallet = customer.getProfile().getWallet();

    if (paymentMethodId === prefs.paymentMethods.BRAINTREE_SRC.paymentMethodId ||
        paymentMethodId === prefs.paymentMethods.BRAINTREE_CREDIT.paymentMethodId) {
        const creditCardPaymentInstruments = customerWallet.getPaymentInstruments(prefs.paymentMethods.BRAINTREE_CREDIT.paymentMethodId);
        const srcPaymentInstruments = customerWallet.getPaymentInstruments(prefs.paymentMethods.BRAINTREE_SRC.paymentMethodId);

        return Boolean(creditCardPaymentInstruments.length + srcPaymentInstruments.length);
    }
    return Boolean(customerWallet.getPaymentInstruments(paymentMethodId).length);
}

/**
* Saves parameters of the credit card
* @param {Object} createPaymentMethodResponseData Payment method response data from Braintree response
* @param {string} paymentMethodId Payment method id
* @param {string} creditOwner Credit card owner
* @returns {Object} Object with token
*/
function saveGeneralPaymentMethodParameters(createPaymentMethodResponseData, paymentMethodId, creditOwner) {
    const basicHelpers = require('~/cartridge/config/basicHelpers');

    let customerPaymentInstrumentObject;
    let makeCardDefault = true;

    const paymentMethodData = createPaymentMethodResponseData.paymentMethod;
    const response = createPaymentMethodResponseData.paymentMethodSnapshot || paymentMethodData.details;
    const customerWallet = customer.getProfile().getWallet();
    // modify card type to appropriate format
    const cardType = basicHelpers.formatComplexCCBrandCode(response.brandCode.toLowerCase());

    const card = {
        expirationMonth: response.expirationMonth,
        expirationYear: response.expirationYear,
        number: Date.now().toString().substr(0, 11) + response.last4,
        type: cardType,
        paymentMethodToken: paymentMethodData.legacyId,
        owner: creditOwner || createOwnerName(paymentMethodData)
    };

    const isPaymentInstrumentsExist = checkForPaymentInstruments(paymentMethodId);

    if (isPaymentInstrumentsExist) {
        makeCardDefault = false;
    }

    Transaction.wrap(function () {
        const customerPaymentInstrument = customerWallet.createPaymentInstrument(paymentMethodId);
        customerPaymentInstrument.setCreditCardHolder(card.owner);
        customerPaymentInstrument.setCreditCardNumber(card.number);
        customerPaymentInstrument.setCreditCardExpirationMonth(parseInt(card.expirationMonth, 10));
        customerPaymentInstrument.setCreditCardExpirationYear(parseInt(card.expirationYear, 10));
        customerPaymentInstrument.setCreditCardType(card.type);
        customerPaymentInstrument.creditCardToken = card.paymentMethodToken;
        customerPaymentInstrument.custom.braintreeDefaultCard = makeCardDefault;
        customerPaymentInstrumentObject = customerPaymentInstrument;
    });

    return {
        customerPaymentInstrument: customerPaymentInstrumentObject,
        error: false
    };
}

/**
* Saves SRC account
* @param {Object} createPaymentMethodResponseData Response from BT API
* @returns {Object} Object
*/
function saveSrcAccount(createPaymentMethodResponseData) {
    return saveGeneralPaymentMethodParameters(createPaymentMethodResponseData, prefs.paymentMethods.BRAINTREE_SRC.paymentMethodId);
}

/**
* Save credit cart as customer payment method
* @param {Object} createPaymentMethodResponseData Response from BT API
* @param {string} creditOwner Credit card owner.
* @returns {Object} Object with token
*/
function saveCustomerCreditCard(createPaymentMethodResponseData, creditOwner) {
    return saveGeneralPaymentMethodParameters(createPaymentMethodResponseData, PaymentInstrument.METHOD_CREDIT_CARD, creditOwner);
}

/**
 * Creates and returns a Credit card billing address object for Braintree mutations
 * @param {Object} billingAddress The billing address object created from dw billing form
 * @returns {Object} A Braintree Credit card billing address object
 */
function createCcBaForBt(billingAddress) {
    return {
        firstName: billingAddress.firstName,
        lastName: billingAddress.lastName,
        streetAddress: billingAddress.address1,
        locality: billingAddress.city,
        extendedAddress: billingAddress.address2,
        region: billingAddress.stateCode,
        postalCode: billingAddress.postalCode,
        countryCodeAlpha2: billingAddress.countryCode || billingAddress.country
    };
}

/**
 * Save billing address to credit cart as customer payment method
 * @param {dw.customer.CustomerPaymentInstrument} customerPaymentInstrument payment instrument
 * @param {Object} billingAddressForm data from billing address form
 * @returns {Object} with customer payment instrument
 */
function saveCustomerBillingAddress(customerPaymentInstrument, billingAddressForm) {
    const Resource = require('dw/web/Resource');
    const BTGraphQLSdk = require('*/cartridge/models/btGraphQLSdk');
    const btGraphQLSdk = new BTGraphQLSdk();

    const billingAddress = {
        firstName: billingAddressForm.firstName.value || '',
        lastName: billingAddressForm.lastName.value || '',
        city: decodeURIComponent(billingAddressForm.city.value || ''),
        address1: decodeURIComponent(billingAddressForm.address1.value || ''),
        address2: decodeURIComponent(billingAddressForm.address2.value || ''),
        countryCode: decodeURIComponent(billingAddressForm.country.value || ''),
        stateCode: billingAddressForm.states.stateCode.value || '',
        postalCode: decodeURIComponent(billingAddressForm.postalCode.value || ''),
        phone: billingAddressForm.phone.value || ''
    };

    const btBillingAddress = createCcBaForBt(billingAddress);

    try {
        btGraphQLSdk.updateCreditCardBillingAddress({
            paymentMethodId: customerPaymentInstrument.creditCardToken,
            billingAddress: btBillingAddress
        });

        Transaction.wrap(function () {
            customerPaymentInstrument.custom.braintreeCreditCardBillingAddress = JSON.stringify(billingAddress);
        });
    } catch (error) {
        return {
            customerPaymentInstrument: customerPaymentInstrument,
            error: Resource.msg('error.creditcard.savebillingaddress', 'error', null)
        };
    }

    return {
        customerPaymentInstrument: customerPaymentInstrument,
        error: false
    };
}

/**
* Saves PayPal account
* @param {Object} createPaymentMethodResponseData payment method response data
* @param  {string} accountAddresses Braintree paypal account addresses
* @param  {string} paypalToken token - is passed from PP processor in case of checkout from PDP/minicart/cart
* @returns {Object} Object with token
*/
function savePaypalAccount(createPaymentMethodResponseData, accountAddresses, paypalToken) {
    // token passed from processor || token taken from response in case of saving on account page
    const token = paypalToken || createPaymentMethodResponseData.legacyId;
    const paypalEmail = createPaymentMethodResponseData.details ? createPaymentMethodResponseData.details.email :
        createPaymentMethodResponseData.transaction.paymentMethodSnapshot.payer.email;

    Transaction.wrap(function () {
        const customerPaymentInstrument = customer.getProfile().getWallet().createPaymentInstrument(prefs.paymentMethods.BRAINTREE_PAYPAL.paymentMethodId);
        customerPaymentInstrument.setCreditCardType(braintreeConstants.CREDIT_CARD_TYPE_VISA); // hack for MFRA account.js line 99 (paymentInstrument.creditCardType.toLowerCase())
        customerPaymentInstrument.creditCardToken = token;
        customerPaymentInstrument.custom.braintreePaypalAccountEmail = paypalEmail;
        customerPaymentInstrument.custom.braintreePaypalAccountAddresses = accountAddresses;
    });

    return {
        token: token
    };
}

/**
* Update stored PayPal account billing address
* @param {Object} createPaymentMethodResponseData payment method response data
* @param  {string} accountAddresses Braintree paypal account addresses
*/
function updatePaypalAccountBillingAddress(createPaymentMethodResponseData, accountAddresses) {
    const paypalEmail = createPaymentMethodResponseData.details ? createPaymentMethodResponseData.details.email :
        createPaymentMethodResponseData.transaction.paymentMethodSnapshot.payer.email;
    const customerPayPalPaymentInstruments = customer.getProfile().getWallet().getPaymentInstruments(prefs.paymentMethods.BRAINTREE_PAYPAL.paymentMethodId).toArray();

    // Find current buyer's PayPal account and update its billing address
    customerPayPalPaymentInstruments.forEach(function (payPalPaymentInstrument) {
        if (payPalPaymentInstrument.custom.braintreePaypalAccountEmail === paypalEmail) {
            Transaction.wrap(function () {
                payPalPaymentInstrument.custom.braintreePaypalAccountAddresses = accountAddresses;
            });
        }
    });
}

/**
 * Extract passed billing address from httpParamMap
 * @param {string} newBillingAddressAsString httpParameterMap.{billing address}.stringValue
 * @returns {Object|boolean} object or false in case if no new billing address
 */
function getBillingAddressFromStringValue(newBillingAddressAsString) {
    let result;

    try {
        if (newBillingAddressAsString && newBillingAddressAsString !== '{}') {
            result = JSON.parse(newBillingAddressAsString);
        }
    } catch (error) {
        result = false;
    }

    return result;
}

/**
 * Identify if session paypal account is used.
 * @param {string} nonce braintreePaypalNonce value
 * @returns {boolean} true in case we have nonce on paramMap. false otherwise
 */
function isSessionPayPalAccountUsed(nonce) {
    return nonce !== null && nonce.length !== 0;
}

/**
* Saves Venmo account
* @param {Object} createPaymentMethodResponseData payment method response data
* @param {string} venmoUserId BT venmo user Id
* @returns {Object} Object with token
*/
function saveVenmoAccount(createPaymentMethodResponseData, venmoUserId) {
    const paymentMethodResponseData = createPaymentMethodResponseData.paymentMethodSnapshot || createPaymentMethodResponseData.paymentMethod.details;
    const paymentMethodData = createPaymentMethodResponseData.paymentMethod;

    Transaction.wrap(function () {
        const customerPaymentInstrument = customer.getProfile().getWallet().createPaymentInstrument(prefs.paymentMethods.BRAINTREE_VENMO.paymentMethodId);
        customerPaymentInstrument.setCreditCardType(braintreeConstants.CREDIT_CARD_TYPE_VISA); // hack for MFRA account.js line 99 (paymentInstrument.creditCardType.toLowerCase())
        customerPaymentInstrument.creditCardToken = paymentMethodData.legacyId;
        customerPaymentInstrument.custom.braintreeVenmoUserId = venmoUserId || paymentMethodResponseData.venmoUserId;
    });

    return {
        token: paymentMethodData.legacyId
    };
}

/**
 * Create Preferred Address object from CustomerAddress Class
 * @param  {dw.customer.CustomerAddress} customerAddress - Current customer's address that has been defined as the customer's preferred address.
 * @returns {Object} Preferred Address obj
 */
function createPreferredAddressObj(customerAddress) {
    return {
        recipientName: customerAddress.getFullName(),
        firstName: customerAddress.getFirstName(),
        secondName: customerAddress.getSecondName(),
        lastName: customerAddress.getLastName(),
        countryCodeAlpha2: customerAddress.getCountryCode().value,
        locality: customerAddress.getCity(),
        streetAddress: customerAddress.getAddress1(),
        extendedAddress: customerAddress.getAddress2(),
        postalCode: decodeURIComponent(customerAddress.getPostalCode()),
        region: customerAddress.getStateCode(),
        phone: customerAddress.getPhone()
    };
}

/**
 * Verifies if transaction status refers to successful
 * @param {Object} responseTransaction transaction response
 * @param {Object} paymentInstrument Payment instrument
 * @param {Object} order current order
 */
function verifyTransactionStatus(responseTransaction, paymentInstrument, order) {
    const successfulStatuses = [
        braintreeConstants.TRANSACTION_STATUS_AUTHORIZED,
        braintreeConstants.TRANSACTION_STATUS_SETTLED,
        braintreeConstants.TRANSACTION_STATUS_SETTLEMENT_PENDING,
        braintreeConstants.TRANSACTION_STATUS_SETTLING,
        braintreeConstants.TRANSACTION_STATUS_SUBMITTED_FOR_SETTLEMENT
    ];
    const transaction = responseTransaction.transaction || responseTransaction;
    const legacyId = transaction.legacyId;
    const transactionStatus = transaction.status;

    if (successfulStatuses.indexOf(transactionStatus) === -1) {
        if (legacyId) {
            Transaction.wrap(function () {
                const paymentTransaction = paymentInstrument.getPaymentTransaction();
                paymentTransaction.setTransactionID(legacyId);
                order.custom.braintreePaymentStatus = transactionStatus;
            });
        }

        throw new Error(transactionStatus);
    }
}

/**
 * Checks if used card is session (new) card
 * @param {string} selectedCreditCardUuid card value
 * @returns {boolean} value whether used card is session (new) card
 */
function isUsedSessionCreditCard(selectedCreditCardUuid) {
    return !empty(selectedCreditCardUuid) && selectedCreditCardUuid === braintreeConstants.SESSION_CARD;
}

/**
 * Checks if used card is already saved card
 * @param {string} selectedCreditCardUuid card value
 * @returns {boolean} value whether used card is saved card
 */
function isUsedSavedCardMethod(selectedCreditCardUuid) {
    return !isUsedSessionCreditCard(selectedCreditCardUuid);
}

/**
 * Checks if used session card is already saved to basket's payment instrument
 * @param {Object} braintreePaymentMethodNonce request.httpParameterMap.braintreePaymentMethodNonce
 * @param {dw.order.PaymentInstrument} creditCardBasketPaymentInstrument basket.getPaymentInstruments(PaymentInstrument.METHOD_CREDIT_CARD)
 * @returns {boolean} whether used session card is already saved to basket PI
 */
function isSessionCardAlreadyUsed(braintreePaymentMethodNonce, creditCardBasketPaymentInstrument) {
    return !empty(creditCardBasketPaymentInstrument) && creditCardBasketPaymentInstrument[0].custom.braintreePaymentMethodNonce === braintreePaymentMethodNonce;
}

/**
 * Returns object with data from credit card form
 * @param {Object} creditCardForm session.forms.billing.creditCardFields
 * @returns {Object} credit card data
 */
function getUsedCreditCardFromForm(creditCardForm) {
    return {
        creditCardType: creditCardForm.cardType.value,
        creditCardNumber: creditCardForm.cardNumber.value,
        creditCardHolder: creditCardForm.cardOwner.value,
        creditCardExpirationMonth: parseInt(creditCardForm.expirationMonth.htmlValue, 10),
        creditCardExpirationYear: parseInt(new Date().getFullYear().toString().substr(0, 2) + creditCardForm.expirationYear.htmlValue, 10)
    };
}

/**
 * Creates the billing from basket
 * @param {dw.order.Basket} basket Current Basket
 * @returns {Object} Billing address object
 */
function getBillingAddressFromBasket(basket) {
    const billingAddress = basket.billingAddress;

    return {
        firstName: billingAddress.firstName,
        lastName: billingAddress.lastName,
        streetAddress: billingAddress.address1,
        extendedAddress: billingAddress.address2,
        locality: billingAddress.city,
        postalCode: decodeURIComponent(billingAddress.postalCode),
        countryCodeAlpha2: billingAddress.countryCode.value,
        region: billingAddress.stateCode,
        phone: billingAddress.phone,
        email: basket.customerEmail
    };
}

/**
 * Checks whether the new billing address equal the billing address from basket
 * @param {dw.order.Basket} basket Basket instance
 * @param {Object} newBillingAddress Billing address from payment method
 * @returns {boolean} Treu/False
 */
function isBillingAddressesEqual(basket, newBillingAddress) {
    if (!newBillingAddress) {
        return false;
    }

    const billingAddressFormBasket = getBillingAddressFromBasket(basket);
    const newBillingAddressKeys = Object.keys(newBillingAddress).sort();
    const billingAddressFormBasketKeys = Object.keys(billingAddressFormBasket).sort();

    if (newBillingAddressKeys.length !== billingAddressFormBasketKeys.length) {
        return false;
    }

    const isBillingAddressesDifferent = newBillingAddressKeys.some(function (billingAddressKey) {
        return newBillingAddress[billingAddressKey] !== billingAddressFormBasket[billingAddressKey];
    });

    return !isBillingAddressesDifferent;
}

/**
 * Checks weather customer updated the session billing address on storefront
 * @param {dw.order.Basket} basket Basket instance
 * @param {string} nonce Payment method nonce
 * @param {Object} billingAddress Billing addreess object from payment method
 * @returns {boolean} true/false
 */
function billingAddressHasBeenChanged(basket, nonce, billingAddress) {
    const paypalBasketPaymentInstruments = basket.getPaymentInstruments(prefs.paymentMethods.BRAINTREE_PAYPAL.paymentMethodId);

    return !(empty(paypalBasketPaymentInstruments) ||
        paypalBasketPaymentInstruments[0].custom.braintreePaymentMethodNonce !== nonce ||
        isBillingAddressesEqual(basket, billingAddress));
}

/**
 * Updates billing address from fields
 * @param {Object} billingAddress Billing address
 * @param {Object} data req, paymentForm, viewFormData
 * @returns {boolean} true/false
 */
function updateBillingAddressFileds(billingAddress, data) {
    // Do not update a billing address in case a new payment account
    if (!billingAddress) {
        return false;
    }

    data.viewData.address = {
        firstName: { value: billingAddress.firstName },
        lastName: { value: billingAddress.lastName },
        address1: { value: billingAddress.streetAddress || billingAddress.address1 },
        address2: { value: billingAddress.extendedAddress || billingAddress.address2 || '' },
        city: { value: billingAddress.locality || billingAddress.city },
        postalCode: { value: decodeURIComponent(billingAddress.postalCode) },
        countryCode: { value: billingAddress.countryCodeAlpha2 || billingAddress.countryCode || billingAddress.country },
        stateCode: { value: billingAddress.region || billingAddress.stateCode }
    };
    data.viewData.phone = {
        value: billingAddress.phone
    };

    return true;
}

/**
 * Update Billing Form for payment method checkout from cart and billing page only when
 * billing address from form isn't equal to the address from basket and passed nonce isn't equal to the nonce from basket
 * @param {Object} updateBillingObject The helping object for the updating billing address
 */
function updateBillingForm(updateBillingObject) {
    const BasketMgr = require('dw/order/BasketMgr');
    const basket = BasketMgr.getCurrentBasket();
    let billingAddressFromBasket = null;
    const isBillingAddressChanged = billingAddressHasBeenChanged(basket, updateBillingObject.nonce, updateBillingObject.billingAddress);

    if (isBillingAddressChanged) {
        billingAddressFromBasket = getBillingAddressFromBasket(basket);
        updateBillingAddressFileds(billingAddressFromBasket, updateBillingObject.data);
    }
}

/**
 * Creates a billing address object suitable for the transaction request
 * @param {Object} billingAddress The billing address
 * @returns {Object} A billing address object
 */
function createTransactionBillingAddress(billingAddress) {
    return {
        firstName: billingAddress.firstName,
        lastName: billingAddress.lastName,
        addressLine1: billingAddress.streetAddress,
        locality: billingAddress.locality,
        region: billingAddress.stateCode,
        postalCode: billingAddress.postalCode,
        countryCode: billingAddress.countryCodeAlpha2
    };
}

module.exports = {
    updateShippingAddress: updateShippingAddress,
    saveGeneralTransactionData: saveGeneralTransactionData,
    createBaseSaleTransactionData: createBaseSaleTransactionData,
    createGuestCustomerData: createGuestCustomerData,
    isCountryCodesUpperCase: isCountryCodesUpperCase,
    saveSrcAccount: saveSrcAccount,
    saveCustomerCreditCard: saveCustomerCreditCard,
    saveCustomerBillingAddress: saveCustomerBillingAddress,
    savePaypalAccount: savePaypalAccount,
    updatePaypalAccountBillingAddress: updatePaypalAccountBillingAddress,
    saveVenmoAccount: saveVenmoAccount,
    createPreferredAddressObj: createPreferredAddressObj,
    verifyTransactionStatus: verifyTransactionStatus,
    isSessionPayPalAccountUsed: isSessionPayPalAccountUsed,
    getBillingAddressFromStringValue: getBillingAddressFromStringValue,
    isUsedSessionCreditCard: isUsedSessionCreditCard,
    isUsedSavedCardMethod: isUsedSavedCardMethod,
    isSessionCardAlreadyUsed: isSessionCardAlreadyUsed,
    getUsedCreditCardFromForm: getUsedCreditCardFromForm,
    getBillingAddressFromBasket: getBillingAddressFromBasket,
    billingAddressHasBeenChanged: billingAddressHasBeenChanged,
    updateBillingAddressFileds: updateBillingAddressFileds,
    updateBillingForm: updateBillingForm,
    createTransactionBillingAddress: createTransactionBillingAddress,
    isBillingAddressesEqual: isBillingAddressesEqual,
    checkForPaymentInstruments: checkForPaymentInstruments,
    createCcBaForBt: createCcBaForBt
};
