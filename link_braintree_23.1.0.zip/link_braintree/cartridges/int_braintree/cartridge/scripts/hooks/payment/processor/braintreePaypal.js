'use strict';

var OrderMgr = require('dw/order/OrderMgr');
var PaymentMgr = require('dw/order/PaymentMgr');
var Transaction = require('dw/system/Transaction');
var Resource = require('dw/web/Resource');

var {
    getPaypalCustomerPaymentInstrumentByEmail,
    setBraintreeDefaultCard,
    getSavedPayPalPaymentInstrumentByUUID
} = require('~/cartridge/scripts/braintree/helpers/customerHelper');
var {
    saveGeneralTransactionData,
    createBaseSaleTransactionData,
    verifyTransactionStatus,
    savePaypalAccount,
    updatePaypalAccountBillingAddress,
    isSessionPayPalAccountUsed,
    checkForPaymentInstruments
} = require('~/cartridge/scripts/hooks/payment/processor/processorHelper');
var {
    getAmountPaid,
    deleteBraintreePaymentInstruments,
    getLogger,
    handleErrorCode
} = require('~/cartridge/scripts/braintree/helpers/paymentHelper');
var btBusinessLogic = require('~/cartridge/scripts/braintree/braintreeAPI/braintreeBusinessLogic');
var prefs = require('~/cartridge/config/braintreePreferences');

var BTGraphQLSdk = require('*/cartridge/models/btGraphQLSdk');
var btGraphQLSdk = new BTGraphQLSdk();

/**
 * Perform API call to create new(sale) transaction
 * @param {dw.order.Order} order Current order
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument Used payment instrument
 * @return {Object} Response data from API call
 */
function createSaleTransactionData(order, paymentInstrument) {
    if (empty(paymentInstrument.custom.braintreePaymentMethodNonce) && empty(paymentInstrument.creditCardToken)) {
        throw new Error('paymentInstrument.custom.braintreePaymentMethodNonce or paymentInstrument.creditCardToken are empty');
    }

    var data = createBaseSaleTransactionData(order, paymentInstrument, prefs);
    data.descriptor = { name: prefs.paypalDescriptorName || '' };
    // Flag to recognize PayPal transaction
    data.isPaypal = true;

    if (prefs.isPaypalFraudToolsEnabled) {
        data.deviceData = paymentInstrument.custom.braintreeFraudRiskData;
    }

    return data;
}

/**
 * Create billing address for PayPal account
 * @param {dw.order.Order} order Current order
 * @return {Object} Object with billing address
 */
function createPaypalBillingAddress(order) {
    const billingAddress = order.getBillingAddress();
    return {
        firstName: billingAddress.getFirstName(),
        lastName: billingAddress.getLastName(),
        countryCodeAlpha2: billingAddress.getCountryCode().value,
        locality: billingAddress.getCity(),
        streetAddress: billingAddress.getAddress1(),
        extendedAddress: billingAddress.getAddress2(),
        postalCode: decodeURIComponent(billingAddress.getPostalCode()),
        region: billingAddress.getStateCode(),
        phone: billingAddress.getPhone()
    };
}

/**
 * Save result of the success sale transaction
 * @param {dw.order.Order} orderRecord Current order
 * @param {dw.order.OrderPaymentInstrument} paymentInstrumentRecord Current payment instrument
 * @param {Object} response Response data from API call
 * @param {Object} requestData Request data to API call
 */
function saveTransactionData(orderRecord, paymentInstrumentRecord, response, requestData) {
    var paypalTransactionData = response.transaction;
    var paypalPaymentMethodData = paypalTransactionData.paymentMethod || response.billingAgreementWithPurchasePaymentMethod;

    Transaction.wrap(function () {
        // Save token for lightning order managment
        if (!empty(paypalPaymentMethodData) && empty(paymentInstrumentRecord.creditCardToken)) {
            paymentInstrumentRecord.creditCardToken = paypalPaymentMethodData.legacyId;
        }

        saveGeneralTransactionData(orderRecord, paymentInstrumentRecord, paypalTransactionData, requestData);
    });
}

/**
 * Perform API call to create new(sale) transaction
 * @param {dw.order.Order} order Current order
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument Used payment instrument
 * @return {Object} PayPal data
 */
function mainFlow(order, paymentInstrument) {
    const saleTransactionRequestData = createSaleTransactionData(order, paymentInstrument);
    const paypalData = btGraphQLSdk.createTransaction(saleTransactionRequestData);
    const paypalTransactionData = paypalData.transaction;
    let paypalPaymentMethodData = paypalTransactionData.paymentMethod || paypalData.billingAgreementWithPurchasePaymentMethod;

    // Throw error in case of unsuccessful status
    verifyTransactionStatus(paypalTransactionData, paymentInstrument, order);
    saveTransactionData(order, paymentInstrument, paypalData, saleTransactionRequestData);

    if (customer.authenticated && prefs.vaultMode) {
        const isPaymentInstrumentsExist = checkForPaymentInstruments(prefs.paymentMethods.BRAINTREE_PAYPAL.paymentMethodId);
        var customerPaymentInstrument = getPaypalCustomerPaymentInstrumentByEmail(paypalTransactionData.paymentMethodSnapshot.payer.email);

        if (paymentInstrument.custom.braintreeSaveCreditCard) {
            var payPalBillingAddress = JSON.stringify(createPaypalBillingAddress(order));

            // Case when buyer procceed with new PayPal account
            if (!customerPaymentInstrument) {
                // Case when 'ChangePM' button used and payment method field is null
                if (!paypalPaymentMethodData) {
                    paypalPaymentMethodData = btBusinessLogic.getPaypalCustomerPmDataFromBraintree();
                }

                var token = paypalPaymentMethodData.legacyId;

                savePaypalAccount(paypalData, payPalBillingAddress, token);

                // Case when this is first payment instrument, then set it to default
                if (!isPaymentInstrumentsExist) {
                    setBraintreeDefaultCard(token);
                }
            } else {
                // Case when buyer go with new PayPal account with the same email as already stored
                updatePaypalAccountBillingAddress(paypalData, payPalBillingAddress);
            }
        }
    }

    Transaction.wrap(function () {
        if (!customer.authenticated && prefs.vaultMode) {
            paymentInstrument.paymentTransaction.accountID = paypalTransactionData.customer.id;
        }

        paymentInstrument.custom.braintreeSaveCreditCard = null;
    });

    return { paypalData: paypalData };
}

/**
 * Perform API call to create new(sale) transaction
 * @param {dw.order.Order} order Current order
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument Used payment instrument
 */
function intentOrderFlow(order, paymentInstrument) {
    var paymentMethodToken = paymentInstrument.creditCardToken || btBusinessLogic.createPaymentMethod(paymentInstrument.custom.braintreePaymentMethodNonce, order);

    Transaction.wrap(function () {
        order.custom.isBraintree = true;
        order.custom.isBraintreeIntentOrder = true;
        paymentInstrument.custom.braintreeFraudRiskData = null;
        // Save token for lightning order managment
        if (!paymentInstrument.creditCardToken) {
            paymentInstrument.creditCardToken = paymentMethodToken;
        }
    });
}

/**
 * Write info about failed order into payment instrument, and mark customer as Braintree customer
 * @param {dw.order.Order} order Current order
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument Used payment instrument
 * @param {string} braintreeError Error text
 * @returns {Object} Error indicator
 */
function authorizeFailedFlow(order, paymentInstrument, braintreeError) {
    Transaction.wrap(function () {
        order.custom.isBraintree = true;
        paymentInstrument.custom.braintreeFailReason = braintreeError;
    });

    handleErrorCode(braintreeError);

    return { error: true };
}

/**
 * Create Braintree payment instrument and update billing address
 * @param {Object} basket Arguments of the HTTP call
 * @returns {Object} handle call result
 */
function Handle(basket) {
    var httpParameterMap = request.httpParameterMap;
    var paymentProcessor = PaymentMgr.getPaymentMethod(prefs.paymentMethods.BRAINTREE_PAYPAL.paymentMethodId).getPaymentProcessor();
    var paypalPaymentInstrument = null;
    var customerPaymentInstrument = null;
    var isSessionAccountUsed = isSessionPayPalAccountUsed(httpParameterMap.braintreePaypalNonce.stringValue);
    var fundingSource = httpParameterMap.braintreePaypalFundingSource.stringValue;

    // Creating PayPal payment processor
    Transaction.wrap(function () {
        var methodName = session.forms.billing.paymentMethod.value;

        deleteBraintreePaymentInstruments(basket);

        paypalPaymentInstrument = basket.createPaymentInstrument(methodName, getAmountPaid(basket));
        paypalPaymentInstrument.paymentTransaction.setPaymentProcessor(paymentProcessor);
    });

    // New or session PP account. Scenario for both Unauthenticated & Authenticated buyers
    if (isSessionAccountUsed) {
        Transaction.wrap(function () {
            paypalPaymentInstrument.custom.braintreeFraudRiskData = httpParameterMap.braintreePaypalRiskData.stringValue;
            paypalPaymentInstrument.custom.braintreeSaveCreditCard = httpParameterMap.braintreeSavePaypalAccount.booleanValue;
            paypalPaymentInstrument.custom.braintreePaypalEmail = httpParameterMap.braintreePaypalEmail.stringValue || basket.getCustomerEmail();
            paypalPaymentInstrument.custom.braintreePaymentMethodNonce = httpParameterMap.braintreePaypalNonce.stringValue;
            paypalPaymentInstrument.custom.payPalFundingSource = fundingSource;
        });

        // Scenarios only for authenticated buyers
    } else if (customer.authenticated) {
        // Saved PP account (PDP, Minicart, Cart scenario)
        customerPaymentInstrument = getSavedPayPalPaymentInstrumentByUUID(httpParameterMap);

        if (empty(customerPaymentInstrument.creditCardToken)) {
            return {
                error: true,
                fieldErrors: [],
                serverErrors: [
                    Resource.msg('braintree.error.PAYPAL_INVALID_PAYMENT_OPTION', 'locale', null)
                ]
            };
        }

        Transaction.wrap(function () {
            paypalPaymentInstrument.creditCardToken = customerPaymentInstrument.creditCardToken;
            paypalPaymentInstrument.custom.braintreePaypalEmail = customerPaymentInstrument.custom.braintreePaypalAccountEmail;
            paypalPaymentInstrument.custom.braintreeFraudRiskData = httpParameterMap.braintreePaypalRiskData.stringValue;
            paypalPaymentInstrument.custom.payPalFundingSource = fundingSource;
        });
    } else {
        return { success: false };
    }

    return { success: true };
}

/**
 * Authorize payment function
 * @param {string} orderNo Order Number
 * @param {Object} paymentInstrument Instrument
 * @returns {Object} success object
 */
function Authorize(orderNo, paymentInstrument) {
    var order = OrderMgr.getOrder(orderNo);

    if (paymentInstrument && paymentInstrument.getPaymentTransaction().getAmount().getValue() > 0) {
        try {
            if (prefs.paypalOrderIntent) {
                intentOrderFlow(order, paymentInstrument);
            } else {
                mainFlow(order, paymentInstrument);
            }
        } catch (error) {
            getLogger().error(error);

            var err = error.customMessage || error.message;

            return authorizeFailedFlow(order, paymentInstrument, err);
        }
    } else {
        Transaction.wrap(function () {
            order.removePaymentInstrument(paymentInstrument);
        });
    }

    return { authorized: true };
}

exports.Handle = Handle;
exports.Authorize = Authorize;
