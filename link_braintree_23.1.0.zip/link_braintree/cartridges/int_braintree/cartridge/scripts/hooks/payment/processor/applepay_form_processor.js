'use strict';

var {
    updateShippingAddress,
    updateBillingForm,
    getBillingAddressFromStringValue
 } = require('~/cartridge/scripts/hooks/payment/processor/processorHelper');

/**
 * ApplePay form processor:
 * Updating Shipping Address (only from Cart Checkout)
 * Adding paymentMethod to viewData
 *
 * @param {Object} req the request object
 * @param {Object} paymentForm - the payment form
 * @param {Object} viewFormData - object contains billing form data
 * @returns {Object} an object that has payment information
 */
function processForm(req, paymentForm, viewFormData) {
    const BasketMgr = require('dw/order/BasketMgr');
    const currentBasket = BasketMgr.getCurrentBasket();
    const viewData = viewFormData;
    const usingMultiShipping = false; // Current integration support only single shipping
    const httpParameterMap = req.httpParameterMap;

    // All needed parameters for billing address update
    const updateBillingObject = {
        data: {
            req: req,
            paymentForm: paymentForm,
            viewData: viewData
        },
        nonce: httpParameterMap.braintreeApplePayNonce.stringValue,
        billingAddress: getBillingAddressFromStringValue(httpParameterMap.braintreeApplePayBillingAddress)
    };

    req.session.privacyCache.set('usingMultiShipping', usingMultiShipping);

    viewData.paymentMethod = {
        value: paymentForm.paymentMethod.value
    };

    // Shipping handling
    if (httpParameterMap.pageFlowCart.stringValue) {
        updateShippingAddress(httpParameterMap.braintreeApplePayShippingAddress.stringValue, currentBasket.getDefaultShipment());
    }

    // Handle Billing Form
    // To be update when customer changed a billing address of session account on billing page
    updateBillingForm(updateBillingObject);

    return {
        error: false,
        viewData: viewData
    };
}

exports.processForm = processForm;
