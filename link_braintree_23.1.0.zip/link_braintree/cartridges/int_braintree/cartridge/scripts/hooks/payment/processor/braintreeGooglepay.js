'use strict';

const server = require('server');

var Transaction = require('dw/system/Transaction');
var PaymentMgr = require('dw/order/PaymentMgr');
var Resource = require('dw/web/Resource');

var prefs = require('~/cartridge/config/braintreePreferences');
var {
    deleteBraintreePaymentInstruments,
    getAmountPaid,
    handleErrorCode,
    getLogger
} = require('~/cartridge/scripts/braintree/helpers/paymentHelper');
var {
    saveGeneralTransactionData,
    createBaseSaleTransactionData,
    verifyTransactionStatus,
    getBillingAddressFromStringValue,
    createTransactionBillingAddress
} = require('~/cartridge/scripts/hooks/payment/processor/processorHelper');

var BTGraphQLSdk = require('*/cartridge/models/btGraphQLSdk');
var btGraphQLSdk = new BTGraphQLSdk();

/**
 * Perform API call to create new(sale) transaction
 * @param {dw.order.Order} order Current order
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument Used payment instrument
 * @return {Object} Response data from API call
 */
function createSaleTransactionData(order, paymentInstrument) {
    if (empty(paymentInstrument.custom.braintreePaymentMethodNonce) && empty(paymentInstrument.creditCardToken)) {
        throw new Error('paymentInstrument.custom.braintreePaymentMethodNonce or paymentInstrument.creditCardToken are empty');
    }

    const data = createBaseSaleTransactionData(order, paymentInstrument, prefs);
    // Flag to recognize Credit card/Google Pay/Apple pay transaction
    data.isCreditCard = true;
    data.deviceData = paymentInstrument.custom.braintreeFraudRiskData;
    // Sets a billing address to the transaction data
    data.options.billingAddress = createTransactionBillingAddress(
        getBillingAddressFromStringValue(paymentInstrument.custom.braintreePaymentMethodBillingAddress)
    );

    return data;
}

/**
 * Write info about failed order into payment instrument, and mark customer as Braintree customer
 * @param {dw.order.Order} orderRecord Current order
 * @param {dw.order.OrderPaymentInstrument} paymentInstrumentRecord Used payment instrument
 * @param {string} braintreeError Error text
 * @returns {Object} object which indicates error
 */
function authorizeFailedFlow(orderRecord, paymentInstrumentRecord, braintreeError) {
    Transaction.wrap(function () {
        orderRecord.custom.isBraintree = true;

        if (braintreeError) {
            paymentInstrumentRecord.custom.braintreeFailReason = braintreeError;
        }
    });

    handleErrorCode(braintreeError);

    return { error: true };
}

/**
 * It returns stringified object from billing address form.
 * @returns {string} A stringified JSON billing address.
 */
function getStringBillingAddressFormValues() {
    const billingForm = server.forms.getForm('billing');
    billingForm._getField = function (formGroupName, fieldName) {
        return billingForm[formGroupName][fieldName].htmlValue;
    };

    const billingAddress = {
        firstName: billingForm._getField('addressFields', 'firstName'),
        lastName: billingForm._getField('addressFields', 'lastName'),
        phone: billingForm._getField('contactInfoFields', 'phone'),
        countryCode: billingForm._getField('addressFields', 'country'),
        streetAddress: billingForm._getField('addressFields', 'address1'),
        extendedAddress: billingForm._getField('addressFields', 'address2'),
        locality: billingForm._getField('addressFields', 'city'),
        postalCode: billingForm._getField('addressFields', 'postalCode'),
        stateCode: billingForm.addressFields.states.stateCode.htmlValue
    };

    return JSON.stringify(billingAddress);
}

/**
 * Create Braintree payment instrument
 * @param {Object} basket Arguments of the HTTP call
 * @returns {Object} handle call result
 */
function Handle(basket) {
    var httpParameterMap = request.httpParameterMap;
    var paymentProcessor = PaymentMgr.getPaymentMethod(prefs.paymentMethods.BRAINTREE_GOOGLEPAY.paymentMethodId).getPaymentProcessor();
    var googlePayPaymentInstrument = null;
    var nonce = httpParameterMap.braintreeGooglePayNonce.stringValue;

    if (!nonce) {
        return {
            error: true,
            fieldErrors: [],
            serverErrors: [
                Resource.msg('braintree.error.CLIENT_REQUEST_ERROR', 'locale', null)
            ]
        };
    }

    // Creating GooglePay payment processor
    Transaction.wrap(function () {
        var paymentMethodName = session.forms.billing.paymentMethod.value;

        deleteBraintreePaymentInstruments(basket);

        googlePayPaymentInstrument = basket.createPaymentInstrument(paymentMethodName, getAmountPaid(basket));
        googlePayPaymentInstrument.paymentTransaction.setPaymentProcessor(paymentProcessor);
    });

    // GooglePay payment type (AndroidPayCard or PayPalAccount)
    session.privacy.googlepayPaymentType = httpParameterMap.braintreeGooglepayPaymentType.stringValue;

    Transaction.wrap(function () {
        googlePayPaymentInstrument.custom.braintreePaymentMethodNonce = nonce;
        googlePayPaymentInstrument.custom.braintreeGooglePayCardDescription = httpParameterMap.braintreeGooglePayCardDescription.stringValue || '';
        googlePayPaymentInstrument.custom.braintreeFraudRiskData = httpParameterMap.braintreeGooglePayDeviceDataInput.stringValue;

        if (httpParameterMap.braintreeGooglePayBillingAddress.empty) {
            // Case when customer using GP session account after leaving Checkout Page
            googlePayPaymentInstrument.custom.braintreePaymentMethodBillingAddress = getStringBillingAddressFormValues();
        } else {
            googlePayPaymentInstrument.custom.braintreePaymentMethodBillingAddress = httpParameterMap.braintreeGooglePayBillingAddress.stringValue;
        }
    });

    return { success: true };
}

/**
 * Authorize payment function
 * @param {string} orderNumber Order Number
 * @param {Object} paymentInstrument Payment Instrument
 * @param {Object} paymentProcessor Payment Processor
 * @returns {Object} success object
 */
function Authorize(orderNumber, paymentInstrument, paymentProcessor) {
    var OrderMgr = require('dw/order/OrderMgr');
    var order = OrderMgr.getOrder(orderNumber);

    if (paymentInstrument && paymentInstrument.getPaymentTransaction().getAmount().getValue() > 0) {
        try {
            var saleTransactionRequestData = createSaleTransactionData(order, paymentInstrument);
            var responseData = btGraphQLSdk.createTransaction(saleTransactionRequestData).transaction;
            // Throw error in case of unsuccessful status
            verifyTransactionStatus(responseData, paymentInstrument, order);

            Transaction.wrap(function () {
                if (!customer.authenticated && prefs.vaultMode) {
                    paymentInstrument.paymentTransaction.accountID = responseData.customer.id;
                }

                paymentInstrument.custom.braintreePaymentMethodBillingAddress = null;

                saveGeneralTransactionData(order, paymentInstrument, responseData, saleTransactionRequestData);
                paymentInstrument.getPaymentTransaction().setPaymentProcessor(paymentProcessor);
                // Save token for lightning order managment
                if (prefs.vaultMode && empty(paymentInstrument.creditCardToken) && !empty(responseData.paymentMethod)) {
                    paymentInstrument.creditCardToken = responseData.paymentMethod.legacyId;
                }
            });

            delete session.privacy.googlepayPaymentType;
        } catch (error) {
            getLogger().error(error);

            var err = error.customMessage || error.message;

            return authorizeFailedFlow(order, paymentInstrument, err);
        }
    } else {
        Transaction.wrap(function () {
            order.removePaymentInstrument(paymentInstrument);
        });
    }

    return { authorized: true };
}

exports.Handle = Handle;
exports.Authorize = Authorize;
