'use strict';

const addressHelper = module.superModule;

/**
 * Stores a new address for a given customer
 * @param {Object} address - New address to be saved
 * @param {Object} customer - Current customer
 * @param {string} addressId - Id of a new address to be created
 * @returns {void}
 */
addressHelper.saveAddress = function (address, customer, addressId) {
    const Transaction = require('dw/system/Transaction');
    const addressBook = customer.raw.getProfile().getAddressBook();

    Transaction.wrap(function () {
        // Fix an issue in app-storefront-base cartridge with the shipping address updating on the checkout page
        const newAddress = addressBook.createAddress(addressId) || addressBook.getAddress(addressId);
        addressHelper.updateAddressFields(newAddress, address);
    });
};

module.exports = addressHelper;
