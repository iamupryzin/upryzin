'use strict';

const Site = require('dw/system/Site');

const buttonStyles = JSON.parse(Site.current.getCustomPreferenceValue('GP_API_Button_Styles'));

module.exports = {
    GOOGLEPAY_Billing_Button_Config: buttonStyles.billing,
    GOOGLEPAY_Cart_Button_Config: buttonStyles.cart
};
