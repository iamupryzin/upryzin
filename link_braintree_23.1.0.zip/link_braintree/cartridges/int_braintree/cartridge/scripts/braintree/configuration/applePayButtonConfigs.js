'use strict';

const Site = require('dw/system/Site');

const buttonStyles = JSON.parse(Site.current.getCustomPreferenceValue('AP_API_Button_Styles'));

module.exports = {
    APPLEPAY_Billing_Button_Config: { style: buttonStyles.billing },
    APPLEPAY_Cart_Button_Config: { style: buttonStyles.cart }
};
