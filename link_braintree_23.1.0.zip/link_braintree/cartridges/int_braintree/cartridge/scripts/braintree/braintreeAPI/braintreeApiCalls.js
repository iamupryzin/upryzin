var Resource = require('dw/web/Resource');

var { getLogger } = require('~/cartridge/scripts/braintree/helpers/paymentHelper');

var braintreeApiCalls = {};

/**
 * Call API request
 *
 * @param {Object} requestData Request data
 * @returns {Object} Response data
 */
function call(requestData) {
    var createGQService = require('*/cartridge/scripts/service/braintreeGraphQLService');
    var service = null;
    var result = null;

    try {
        service = createGQService();
    } catch (error) {
        throw new Error(Resource.msg('braintree.service.noconfigurations', 'locale', null));
    }

    try {
        result = service.call(requestData);
    } catch (error) {
        getLogger().error(error);

        error.customMessage = Resource.msg('braintree.server.error.parse', 'locale', null);

        throw error;
    }

    if (!result.isOk()) {
        throw new Error(Resource.msg('braintree.server.error', 'locale', null));
    }

    return service.getResponse();
}

braintreeApiCalls.call = call;
module.exports = braintreeApiCalls;
