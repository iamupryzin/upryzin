'use strict';

const Transaction = require('dw/system/Transaction');

const prefs = require('~/cartridge/config/braintreePreferences');
const paymentHelper = require('~/cartridge/scripts/braintree/helpers/paymentHelper');
const customerHelper = require('~/cartridge/scripts/braintree/helpers/customerHelper');
const processorHelper = require('~/cartridge/scripts/hooks/payment/processor/processorHelper');
const btConstants = require('~/cartridge/config/braintreeConstants');

const BTGraphQLSdk = require('*/cartridge/models/btGraphQLSdk');
const btGraphQLSdk = new BTGraphQLSdk();

const braintreeBusinessLogic = {};

/**
 * Generate client token
 * @param {string} currencyCode currency code
 * @return {string} Client token value
 */
braintreeBusinessLogic.getClientToken = function (currencyCode) {
    if (prefs.tokenizationKey && prefs.tokenizationKey !== '') {
        return prefs.tokenizationKey;
    }

    var clientToken = null;
    var createClientTokeReq = null;

    try {
        createClientTokeReq = {
            accId: paymentHelper.getMerchantAccountID(currencyCode)
        };

        // Case when we need to generate customer specific client token
        if (customer.authenticated) {
            createClientTokeReq.btCustomerId = customerHelper.getCustomerId(customer);
        }

        clientToken = btGraphQLSdk.createClientToken(createClientTokeReq);
    } catch (error) {
        return clientToken;
    }

    return clientToken;
};

/**
 * Make API call, to get customer data if it exists in Braintree
 * @param {dw.customer.Customer} customer Customer object
 * @return {Object} Customer Data with customer ID and error flag
 */
braintreeBusinessLogic.getBraintreeCustomer = function (customer) {
    var response = {
        error: false,
        customerData: null
    };

    try {
        response.customerData = btGraphQLSdk.findCustomer({
            customerId: customerHelper.getCustomerId(customer)
        });
    } catch (error) {
        paymentHelper.getLogger().error(error);

        response.error = true;
    }

    return response;
};

/**
 * Defines whether customer is already vaulted on BT side
 * @param {dw.customer.Customer} customer Customer object
 * @return {Object} with isCustomerInVault and error flags
 */
braintreeBusinessLogic.isCustomerInVault = function (customer) {
    var braintreeCustomer = null;
    var response = {
        error: true,
        isCustomerInVault: false
    };

    braintreeCustomer = braintreeBusinessLogic.getBraintreeCustomer(customer);

    response.isCustomerInVault = !empty(braintreeCustomer.customerData);
    response.error = braintreeCustomer.error;

    return response;
};

/**
 * Create customer on Braintree side and mark current Demandware customer with isBraintree flag
 * @returns {boolean} result
 */
braintreeBusinessLogic.createCustomerOnBraintreeSide = function () {
    try {
        const profile = customer.getProfile();
        const customerId = btGraphQLSdk.createCustomer({
            firstName: profile.getFirstName(),
            lastName: profile.getLastName(),
            email: profile.getEmail(),
            company: profile.getCompanyName(),
            phone: customerHelper.getPhoneFromProfile(profile)
        });

        Transaction.wrap(function () {
            profile.custom.braintreeCustomerId = customerId;
        });
    } catch (error) {
        paymentHelper.getLogger().error(error);

        return {
            error: error.customMessage || error.message
        };
    }

    return true;
};

/**
 * Create CWPP customer on Braintree side and mark current Demandware customer with isBraintree flag
 * @argument {Object} customerInstance customer profile
 * @returns {boolean} result
 */
braintreeBusinessLogic.createCwppCustomerOnBraintreeSide = function (customerInstance) {
    try {
        var profile = customerInstance.dw.profile;

        var customerId = btGraphQLSdk.createCustomer({
            firstName: profile.getFirstName(),
            lastName: profile.getLastName(),
            email: profile.getEmail(),
            company: profile.getCompanyName(),
            phone: customerHelper.getPhoneFromProfile(profile)
        });

        Transaction.wrap(function () {
            customerInstance.dw.profile.custom.braintreeCustomerId = customerId;
        });
    } catch (error) {
        paymentHelper.getLogger().error(error);

        return {
            error: error.customMessage || error.message
        };
    }

    return true;
};

/**
 * Manually create Braintree payment method(on braintree side) for current customer
 * @param {string} nonce Payment method nonce
 * @return {Object} Response data from API call
 */
braintreeBusinessLogic.createPaymentMethodOnBraintreeSide = function (nonce) {
    var responseData = null;

    try {
        responseData = btGraphQLSdk.vaultPaymentMethod({
            customerId: customerHelper.getCustomerId(customer),
            paymentMethodNonce: nonce
        });
    } catch (error) {
        paymentHelper.getLogger().error(error);

        responseData = {
            error: error.customMessage || error.message
        };
    }

    return responseData;
};

/**
 * Vault Credit Card
 * @param {string} braintreePaymentMethodNonce BT payment method nonce
 * @return {string} vault credit card response
 */
braintreeBusinessLogic.vaultCreditCard = function (braintreePaymentMethodNonce) {
    return btGraphQLSdk.vaultCreditCard({
        customerId: customerHelper.getCustomerId(customer),
        paymentMethodNonce: braintreePaymentMethodNonce
    });
};

/**
 * Creates payment method
 * @param {string} braintreePaymentMethodNonce BT payment method nonce
 * @param {dw.order.OrderMgr} order current order
 * @return {string} payment method ID
 */
braintreeBusinessLogic.createPaymentMethod = function (braintreePaymentMethodNonce, order) {
    var customerId;

    if (customer.isRegistered()) {
        customerId = customerHelper.getCustomerId(customer);
    } else {
        var customerData = processorHelper.createGuestCustomerData(order);
        customerId = btGraphQLSdk.createCustomer(customerData);
    }

    var createPaymentMethodResponseData = btGraphQLSdk.vaultPaymentMethod({
        customerId: customerId,
        paymentMethodNonce: braintreePaymentMethodNonce
    });

    return createPaymentMethodResponseData.paymentMethod.legacyId;
};

/**
 * Deletes payment method from vault on BT side and from customer profile
 * @param {Object} paymentToDelete Payment Method details
 * @param {dw.customer.CustomerMgr} customerProfile Used for updating a customer when paypal billing agreement was canceled (webHook)
 */
braintreeBusinessLogic.deletePaymentMethod = function (paymentToDelete, customerProfile) {
    // Used for creating a graphQL request and for updating a customer
    var creditCardToken = paymentToDelete.payment.creditCardToken;

    try {
        btGraphQLSdk.deletePaymentMethodFromVault({
            creditCardToken: creditCardToken
        });

        paymentHelper.deletePaymentInstrumentFromDwCustomer(creditCardToken, customerProfile);
    } catch (error) {
        paymentHelper.getLogger().error(error);
    }
};

/**
 * Search transactions by converted ids
 * @param {Array} orders Braintree orders
 * @return {Object} Search object
 */
braintreeBusinessLogic.searchTransactionsByIds = function (orders) {
    var responseData = {};

    var convertedTransactionsIds = Object.keys(orders).map(function (transactionsId) {
        return btGraphQLSdk.legacyIdConverter(transactionsId, btConstants.LEGACY_ID_TYPE_TRANSACTION);
    }).map(function (convertedTransactionsId) {
        return convertedTransactionsId;
    });

    try {
        responseData = btGraphQLSdk.searchTransactionsByIds({
            ids: convertedTransactionsIds
        });
    } catch (error) {
        return responseData;
    }
    return responseData;
};

/**
 *'ChangePM' button flow
 * Returns data of the PayPal payment method from Braintree
 * @returns {Object} Payment method data
 */
braintreeBusinessLogic.getPaypalCustomerPmDataFromBraintree = function () {
    var braintreeCustomer = null;
    var paymentMethods = null;
    var lastUsedPaypalPmOnBraintree = null;
    var braintreeCustomerData = braintreeBusinessLogic.getBraintreeCustomer(customer);

    if (!braintreeCustomerData.error && !empty(braintreeCustomerData.customerData)) {
        braintreeCustomer = braintreeCustomerData.customerData[0].node;
        paymentMethods = braintreeCustomer.paymentMethods.edges;
        lastUsedPaypalPmOnBraintree = paymentHelper.getLastUsedPaypalPmData(paymentMethods);

        return lastUsedPaypalPmOnBraintree ? lastUsedPaypalPmOnBraintree.node : lastUsedPaypalPmOnBraintree;
    }

    return lastUsedPaypalPmOnBraintree;
};


module.exports = braintreeBusinessLogic;
