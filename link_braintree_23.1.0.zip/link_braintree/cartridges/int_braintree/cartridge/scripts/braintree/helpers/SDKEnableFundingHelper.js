'use strict';

var SDKEnableFundingHelper = {};

/**
 * Returns enableFundingArray witch not consist prohibitedMethodsList elements
 * @param {Array} enableFundingArray Array of enable-funding
 * @returns {Array} Array of filtered enable-funding
 */
SDKEnableFundingHelper.filterEnableFundingList = function (enableFundingArray) {
    var prohibitedMethodsList = [
        'venmo',
        'sepa',
        'bancontact',
        'eps',
        'giropay',
        'ideal',
        'mybank',
        'p24',
        'sofort'
    ];

    return enableFundingArray.filter(element => !prohibitedMethodsList.includes(element));
};

module.exports = SDKEnableFundingHelper;
