'use strict';

const Site = require('dw/system/Site');
const URLUtils = require('dw/web/URLUtils');
const Resource = require('dw/web/Resource');

const prefs = require('~/cartridge/config/braintreePreferences');
const urls = require('~/cartridge/config/braintreeUrls');
const sdkUrls = require('*/cartridge/config/braintreeSDK');
const paymentHelper = require('~/cartridge/scripts/braintree/helpers/paymentHelper');
const braintreeConstants = require('~/cartridge/config/braintreeConstants');
const customerHelper = require('~/cartridge/scripts/braintree/helpers/customerHelper');
const btBusinessLogic = require('~/cartridge/scripts/braintree/braintreeAPI/braintreeBusinessLogic');

const buttonConfigHelper = {};

/**
 * Returns the type of the instance(TEST/PRODUCTION)
 * @returns {string} The type of the instance
 */
function getInstanceType() {
    const dwSystem = require('dw/system/System');
    const instanceTypeNumber = dwSystem.instanceType;
    let instanceType = '';

    if (dwSystem.PRODUCTION_SYSTEM === instanceTypeNumber) {
        instanceType = braintreeConstants.PRODUCTION_SYSTEM_TYPE;
    } else {
        instanceType = braintreeConstants.DEVELOPMENT_SYSTEM_TYPE;
    }

    return instanceType;
}

/**
 * Returns Whether 'Channge payment method button' is enabled
 * @returns {boolean} Whether 'Channge payment method button' is enabled
 */
function isChangePMButtonEnabled() {
    let customerPaypalPaymentInstruments;
    let customerPaypalPmFromBraintree;

    // 'Change Payment Method Button' works only for registered users
    if (customer.registered) {
        customerPaypalPaymentInstruments = customerHelper.getCustomerPaymentInstruments(prefs.paymentMethods.BRAINTREE_PAYPAL.paymentMethodId);
        customerPaypalPmFromBraintree = btBusinessLogic.getPaypalCustomerPmDataFromBraintree();

        return prefs.changePMButtonEnabled &&
            customerPaypalPmFromBraintree !== null &&
            customerPaypalPaymentInstruments.length !== 0;
    }

    return false;
}

/**
 * Returns configuration style object for paypal button
 * @param {string} pageFlow Name of flow that called the method
 * @returns {Object} Style configuration object
 */
function getPaypalButtonStyleConfigs(pageFlow) {
    let styleConfigs;

    switch (pageFlow) {
        case braintreeConstants.PAGE_FLOW_PDP:
            styleConfigs = prefs.paypalPdpButtonConfig;
            break;
        case braintreeConstants.PAGE_FLOW_CART:
            styleConfigs = prefs.paypalCartButtonConfig;
            break;
        case braintreeConstants.PAGE_FLOW_MINICART:
            styleConfigs = prefs.paypalMiniCartButtonConfig;
            break;
        default:
            styleConfigs = prefs.paypalBillingButtonConfig;
            break;
    }

    return styleConfigs;
}

/**
 * Creates general button config object for all payment methods
 * @param {dw.order.BasketMgr} basket Basket Object
 * @param {string} clientToken Braintree clientToken
 * @returns {Object} Button config object
 */
buttonConfigHelper.createGeneralButtonConfig = function (basket, clientToken) {
    const amount = paymentHelper.getAmountPaid(basket);
    const sessionCurrency = request.session.currency.currencyCode;

    const currency = amount.valueOrNull === null ? sessionCurrency : amount.getCurrencyCode();

    return {
        clientToken: clientToken,
        messages: {
            CLIENT_REQUEST_TIMEOUT: Resource.msg('braintree.error.CLIENT_REQUEST_TIMEOUT', 'locale', null),
            CLIENT_GATEWAY_NETWORK: Resource.msg('braintree.error.CLIENT_GATEWAY_NETWORK', 'locale', null),
            CLIENT_REQUEST_ERROR: Resource.msg('braintree.error.CLIENT_REQUEST_ERROR', 'locale', null),
            CLIENT_MISSING_GATEWAY_CONFIGURATION: Resource.msg('braintree.error.CLIENT_MISSING_GATEWAY_CONFIGURATION', 'locale', null)
        },
        options: {
            amount: parseFloat(amount.getValue()),
            currency: currency
        },
        sessionPaymentMethodId: paymentHelper.getSessionPaymentMethodId(basket),
        isBuyerAuthenticated: customer.isAuthenticated(),
        getOrderInfoUrl: URLUtils.url('Braintree-GetOrderInfo').toString()
    };
};

/**
* Creates config button object for paypal
* @param {Basket} basket Basket Object
* @param {string} clientToken Braintree clientToken
* @param {string} currentFlow Name of flow that called the method
* @returns {Object} button config object
*/
buttonConfigHelper.createBraintreePayPalButtonConfig = function (basket, clientToken, currentFlow) {
    const locale = Site.getCurrent().getDefaultLocale();
    const displayName = empty(prefs.paypalDisplayName) ? '' : prefs.paypalDisplayName;
    const enableFundingList = prefs.enableFundingList;
    const disableFundingList = prefs.disableFundingList;
    const changePMButtonEnabled = isChangePMButtonEnabled();
    const vaultModeEnabled = prefs.vaultMode;
    const billingAgreementDescription = empty(prefs.paypalBillingAgreementDescription) ? '' : prefs.paypalBillingAgreementDescription;

    const paypalMessages = {
        PAYPAL_ACCOUNT_TOKENIZATION_FAILED: Resource.msg('braintree.error.PAYPAL_ACCOUNT_TOKENIZATION_FAILED', 'locale', null),
        PAYPAL_INVALID_PAYMENT_OPTION: Resource.msg('braintree.error.PAYPAL_INVALID_PAYMENT_OPTION', 'locale', null),
        PAYPAL_FLOW_FAILED: Resource.msg('braintree.error.PAYPAL_FLOW_FAILED', 'locale', null),
        PAYPAL_BROWSER_NOT_SUPPORTED: Resource.msg('braintree.error.PAYPAL_BROWSER_NOT_SUPPORTED', 'locale', null),
        PAYPAL_BILLING_ADDRESS_NOT_SUPPORTED: Resource.msg('braintree.error.PAYPAL_BILLING_ADDRESS_NOT_SUPPORTED', 'locale', null),
        CUSTOM_PAYPAL_ZERO_AMOUNT_ERROR: Resource.msg('braintree.error.CUSTOM_PAYPAL_ZERO_AMOUNT_ERROR', 'locale', null)
    };

    const paymentSpecificConfigs = {
        paymentMethodName: prefs.paymentMethods.BRAINTREE_PAYPAL.paymentMethodId,
        paypalConfig: getPaypalButtonStyleConfigs(currentFlow),
        isFraudToolsEnabled: prefs.isPaypalFraudToolsEnabled,
        paypalHandle: urls.checkoutSubmitPayment,
        redirectUrl: URLUtils.url('Checkout-Begin', 'stage', 'placeOrder').toString(),
        validateAddressesUrl: URLUtils.url('Braintree-ValidateAddresses').toString(),
        updateShippingMethodsListUrl: URLUtils.url('CheckoutShippingServices-UpdateShippingMethodsList').toString(),
        changePMButtonEnabled: changePMButtonEnabled,
        vaultModeEnabled: vaultModeEnabled
    };

    const braintreePaypalButtonConfig = buttonConfigHelper.createGeneralButtonConfig(basket, clientToken);
    let flow = braintreeConstants.PAGE_FLOW_CHECKOUT;
    let intent = prefs.paypalIntent;

    if (vaultModeEnabled) {
        flow = braintreeConstants.FLOW_VAULT;
    }

    if (prefs.paypalOrderIntent) {
        intent = braintreeConstants.INTENT_TYPE_ORDER;
        flow = braintreeConstants.PAGE_FLOW_CHECKOUT;
    }

    const paypalOptions = {
        flow: flow,
        intent: intent,
        locale: locale,
        enableShippingAddress: true,
        billingAgreementDescription: billingAgreementDescription,
        displayName: displayName
    };

    if (!empty(enableFundingList)) {
        paypalOptions.enableFundingList = enableFundingList.join(',');
    }

    if (!empty(disableFundingList)) {
        paypalOptions.disableFundingList = disableFundingList.join(',');
    }

    Object.keys(paymentSpecificConfigs).forEach(function (key) {
        braintreePaypalButtonConfig[key] = paymentSpecificConfigs[key];
    });

    // Sets PayPal related messages
    Object.keys(paypalMessages).forEach(function (key) {
        braintreePaypalButtonConfig.messages[key] = paypalMessages[key];
    });

    // Sets PayPal related options
    Object.keys(paypalOptions).forEach(function (key) {
        braintreePaypalButtonConfig.options[key] = paypalOptions[key];
    });

    if (prefs.isSettle && !prefs.paypalOrderIntent) {
        braintreePaypalButtonConfig.options.useraction = braintreeConstants.BUTTON_CONFIG_OPTIONS_USERACTION_COMMIT;
    }

    // Case for 'Change Payment Method Button' with enabled 'Vault'
    // Checkout with vault flow
    if (changePMButtonEnabled && vaultModeEnabled) {
        braintreePaypalButtonConfig.options.requestBillingAgreement = true;
        braintreePaypalButtonConfig.options.flow = braintreeConstants.FLOW_CHECKOUT;
    }

    if (currentFlow !== braintreeConstants.PAGE_FLOW_CHECKOUT) {
        braintreePaypalButtonConfig.options.style = {
            layout: braintreeConstants.BUTTON_CONFIG_OPTIONS_STYLE_LAYOUT_HORIZONTAL,
            label: braintreeConstants.BUTTON_CONFIG_PAYPAL,
            maxbuttons: 1,
            fundingicons: false,
            shape: braintreeConstants.BUTTON_CONFIG_OPTIONS_STYLE_SHAPE_RECT,
            size: braintreeConstants.BUTTON_CONFIG_OPTIONS_STYLE_SIZE_MEDIUM,
            tagline: false
        };

        paymentHelper.addDefaultShipping(basket);
    }

    return braintreePaypalButtonConfig;
};

/**
* Creates config button object for Apple Pay
* @param {Basket} basket Basket object
* @param {string} clientToken Braintree clientToken
* @param {string} currentFlow Name of flow that called the method
* @returns {Object} button config object
*/
buttonConfigHelper.createBraintreeApplePayButtonConfig = function (basket, clientToken, currentFlow) {
    const applePayButtonConfigs = require('~/cartridge/scripts/braintree/configuration/applePayButtonConfigs');

    const applePayButtonConfig = buttonConfigHelper.createGeneralButtonConfig(basket, clientToken);
    const isCartFlow = currentFlow === braintreeConstants.PAGE_FLOW_CART;
    const paymentSpecificConfigs = {
        paymentMethodName: prefs.paymentMethods.BRAINTREE_APPLEPAY.paymentMethodId,
        isFraudToolsEnabled: prefs.isPaypalFraudToolsEnabled,
        isRequiredBillingContactFields: true,
        isRequiredShippingContactFields: isCartFlow,
        applePayBtnSdk: sdkUrls.applePayBtnSdk
    };

    if (currentFlow === braintreeConstants.PAGE_FLOW_CHECKOUT) {
        paymentSpecificConfigs.applePayConfig = applePayButtonConfigs.APPLEPAY_Billing_Button_Config;
    }

    if (isCartFlow) {
        paymentSpecificConfigs.applePayConfig = applePayButtonConfigs.APPLEPAY_Cart_Button_Config;

        paymentHelper.addDefaultShipping(basket);
    }

    Object.keys(paymentSpecificConfigs).forEach(function (key) {
        applePayButtonConfig[key] = paymentSpecificConfigs[key];
    });

    applePayButtonConfig.options.displayName = prefs.applepayDisplayName;

    return applePayButtonConfig;
};

/**
* Creates config button object for Venmo
* @param {Basket} basket Basket object
* @param {string} clientToken Braintree clientToken
* @returns {Object} button config object
*/
buttonConfigHelper.createBraintreeVenmoButtonConfig = function (basket, clientToken) {
    const venmoButtonConfig = buttonConfigHelper.createGeneralButtonConfig(basket, clientToken);
    venmoButtonConfig.paymentMethodName = prefs.paymentMethods.BRAINTREE_VENMO.paymentMethodId;
    venmoButtonConfig.options.displayName = prefs.venmoDisplayName;

    const venmoMessages = {
        VENMO_ZERO_AMOUNT_ERROR: Resource.msg('braintree.error.VENMO_ZERO_AMOUNT_ERROR', 'locale', null)
    };

    Object.keys(venmoMessages).forEach(function (key) {
        venmoButtonConfig.messages[key] = venmoMessages[key];
    });

    return venmoButtonConfig;
};

/**
* Creates config button object for LPM
* @param {Basket} basket Basket object
* @param {string} clientToken Braintree clientToken
* @returns {Object} button config object
*/
buttonConfigHelper.createBraintreeLocalPaymentMethodButtonConfig = function (basket, clientToken) {
    const localPaymentMethodButtonConfig = buttonConfigHelper.createGeneralButtonConfig(basket, clientToken);
    const paymentSpecificConfigs = {
        paymentMethodName: prefs.paymentMethods.BRAINTREE_LOCAL.paymentMethodIds,
        paymentConfirmUrl: URLUtils.url('Braintree-PaymentConfirm').toString(),
        fallbackUrl: URLUtils.https('Braintree-FallbackProcess').toString()
    };

    Object.keys(paymentSpecificConfigs).forEach(function (key) {
        localPaymentMethodButtonConfig[key] = paymentSpecificConfigs[key];
    });

    localPaymentMethodButtonConfig.options.displayName = '';

    return localPaymentMethodButtonConfig;
};

/**
* Creates config button object for Google Pay
* @param {Basket} basket Basket object
* @param {string} clientToken Braintree clientToken
* @param {string} currentFlow Name of flow that called the method
* @returns {Object} button config object
*/
buttonConfigHelper.createBraintreeGooglePayButtonConfig = function (basket, clientToken, currentFlow) {
    const googlePayButtonConfigs = require('~/cartridge/scripts/braintree/configuration/googlePayButtonConfigs');

    const googlePayButtonConfig = buttonConfigHelper.createGeneralButtonConfig(basket, clientToken);

    const paymentSpecificConfigs = {
        paymentMethodName: prefs.paymentMethods.BRAINTREE_GOOGLEPAY.paymentMethodId,
        isFraudToolsEnabled: prefs.isFraudToolsEnabled,
        googleMerchantId: prefs.googleMerchantId,
        instanceType: getInstanceType()
    };

    const googlePayOptions = {
        displayName: prefs.googlepayDisplayName,
        isShippingAddressRequired: currentFlow === braintreeConstants.PAGE_FLOW_CART
    };

    Object.keys(paymentSpecificConfigs).forEach(function (key) {
        googlePayButtonConfig[key] = paymentSpecificConfigs[key];
    });

    Object.keys(googlePayOptions).forEach(function (key) {
        googlePayButtonConfig.options[key] = googlePayOptions[key];
    });

    if (currentFlow === braintreeConstants.PAGE_FLOW_CART) {
        const countries = Site.current.getAllowedLocales().toArray().reduce(function (acum, locale) {
            if (locale !== 'default' && locale.includes('_')) {
                acum.push(locale.split('_')[1]);
            }

            return acum;
        }, []);

        googlePayButtonConfig.options.countries = countries.length === 0 ? ['US'] : countries;
        googlePayButtonConfig.style = googlePayButtonConfigs.GOOGLEPAY_Cart_Button_Config;
    }

    if (currentFlow === braintreeConstants.PAGE_FLOW_CHECKOUT) {
        googlePayButtonConfig.style = googlePayButtonConfigs.GOOGLEPAY_Billing_Button_Config;
    }

    return googlePayButtonConfig;
};

/**
* Creates config button object for SRC
* @param {Basket} basket Basket object
* @param {string} clientToken Braintree clientToken
* @param {string} currentFlow Name of flow that called the method
* @returns {Object} button config object
*/
buttonConfigHelper.createBraintreeSrcButtonConfig = function (basket, clientToken, currentFlow) {
    const srcButtonConfig = buttonConfigHelper.createGeneralButtonConfig(basket, clientToken);
    const buttonSettings = currentFlow !== braintreeConstants.PAGE_FLOW_CHECKOUT ?
        prefs.SRCCartButtonConfig : prefs.SRCBillingButtonConfig;

    const srcMessages = {
        CUSTOM_SRC_ZERO_AMOUNT_ERROR: Resource.msg('braintree.error.CUSTOM_SRC_ZERO_AMOUNT_ERROR', 'locale', null)
    };

    Object.keys(srcMessages).forEach(function (key) {
        srcButtonConfig.messages[key] = srcMessages[key];
    });

    const paymentSpecificConfigs = {
        paymentMethodName: prefs.paymentMethods.BRAINTREE_SRC.paymentMethodId,
        isFraudToolsEnabled: prefs.isFraudToolsEnabled,
        SRCImageUrl: paymentHelper.createSRCImageUrl(prefs.SRCImageLink, buttonSettings),
        settings: buttonSettings
    };

    Object.keys(paymentSpecificConfigs).forEach(function (key) {
        srcButtonConfig[key] = paymentSpecificConfigs[key];
    });

    srcButtonConfig.options.isShippingAddressRequired = currentFlow === braintreeConstants.PAGE_FLOW_CART;

    if (currentFlow === braintreeConstants.PAGE_FLOW_CART) {
        srcButtonConfig.options.displayName = prefs.srcDisplayName;
    } else {
        srcButtonConfig.isNeedHideContinueButton = true;
    }

    return srcButtonConfig;
};

module.exports = buttonConfigHelper;
