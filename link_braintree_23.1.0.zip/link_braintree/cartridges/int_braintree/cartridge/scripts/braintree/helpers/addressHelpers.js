'use strict';

const braintreeConstants = require('~/cartridge/config/braintreeConstants');

/**
 * @param {Object} addressData - the address data
 * @returns {Object} - the prepared address object
 */
function prepareAddressData(addressData) {
    return {
        addressId: addressData.addressId,
        firstName: addressData.firstName,
        lastName: addressData.lastName,
        address1: addressData.line1,
        address2: addressData.line2 || '',
        city: addressData.city,
        postalCode: decodeURIComponent(addressData.postalCode),
        countryCode: addressData.countryCode,
        stateCode: addressData.stateCode,
        phone: addressData.phone.replace(/-/g, '')
    };
}

/**
 * @param {Object} braintreePayload - the payload from braintree
 * @returns {Object} - the prepared billing address object
 */
function prepareBillingAddressData(braintreePayload) {
    const billingAddress = braintreePayload.billingAddress;

    billingAddress.addressId = braintreeConstants.BILLING_ADDRESS_ID;
    billingAddress.city = billingAddress.locality;
    billingAddress.stateCode = billingAddress.region || billingAddress.state;
    billingAddress.countryCode = billingAddress.countryCodeAlpha2 || billingAddress.countryCode;

    return prepareAddressData(billingAddress);
}

/**
 * @param {Object} braintreePayload - the payload from braintree
 * @returns {Object} - the prepared shipping address object
 */
function prepareShippingAddressData(braintreePayload) {
    const shippingAddress = braintreePayload.shippingAddress;

    shippingAddress.addressId = braintreeConstants.SHIPPING_ADDRESS_ID;
    shippingAddress.phone = braintreePayload.phone;
    shippingAddress.lastName = braintreePayload.lastName;
    shippingAddress.firstName = braintreePayload.firstName;
    shippingAddress.stateCode = shippingAddress.state;

    return prepareAddressData(shippingAddress);
}

/**
 * @param {Object} form - the target of address form (billing, shipping)
 * @param {Object} data - the data for validation process
 * @returns {Object} - an object that contain the error in the form
 */
function validateAddressForm(form, data) {
    const AddressValidatorModel = require('*/cartridge/models/addressValidator');

    form.clear();
    form.copyFrom(data);
    form.country.value = data.countryCode;
    form.states.stateCode.value = data.stateCode;

    return (new AddressValidatorModel(form)).validate();
}

module.exports = {
    validateAddressForm: validateAddressForm,
    prepareBillingAddressData: prepareBillingAddressData,
    prepareShippingAddressData: prepareShippingAddressData
};
