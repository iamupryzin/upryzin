'use strict';

const Transaction = require('dw/system/Transaction');

const array = require('*/cartridge/scripts/util/array');
const prefs = require('~/cartridge/config/braintreePreferences');
const btConstants = require('~/cartridge/config/braintreeConstants');
const paymentHelper = require('~/cartridge/scripts/braintree/helpers/paymentHelper');

const customerHelper = {};

/**
 * Returns a customer payment instrument by creditCardToken
 * @param {string} token A credit card token
 * @returns {dw.customer.CustomerPaymentInstrument} A customer payment instrument
 */
customerHelper.getCustomerPaymentInstrumentByCreditCardToken = function (token) {
    return token ? customer.profile.wallet.paymentInstruments.toArray().find(function (pi) {
        return pi.creditCardToken === token;
    }) : null;
};

/**
 * Get customer payment instrument by UUID
 * @param {string} uuid UUID for PI
 * @return {dw.customer.CustomerPaymentInstrument} cutomet payment indstrument
 */
customerHelper.getCustomerPaymentInstrument = function (uuid) {
    if (!customer.authenticated) {
        return false;
    }

    var customerPaymentInstruments = customer.getProfile().getWallet().getPaymentInstruments();
    var instrument = null;

    if (uuid === null || customerPaymentInstruments === null || customerPaymentInstruments.size() < 1) {
        return false;
    }

    var instrumentsIter = customerPaymentInstruments.iterator();

    while (instrumentsIter.hasNext()) {
        instrument = instrumentsIter.next();
        // UUID can be whether uuid or email
        if (uuid.equals(instrument.UUID) ||
            uuid.equals(instrument.custom.braintreePaypalAccountEmail)) {
            return instrument;
        }
    }

    return false;
};

/**
 * Return stored PayPal payment instrument by UUID.
 * This method only used for checkout flow.
 * @param {dw.web.HttpParameterMap} httpParameterMap needed for extracting of payment instrument UUID
 * @returns {dw.customer.CustomerPaymentInstrument} or false is returned
 */
customerHelper.getSavedPayPalPaymentInstrumentByUUID = function (httpParameterMap) {
    if (!customer.authenticated) {
        return false;
    }
    var paymentMethodFromCart = httpParameterMap.paymentMethodUUID.stringValue;
    var paymentMethodFromBillingPage = httpParameterMap.braintreePaypalAccountList.stringValue;
    var paymentMethodUUID = paymentMethodFromCart || paymentMethodFromBillingPage;

    return customerHelper.getCustomerPaymentInstrument(paymentMethodUUID);
};

/**
 * Return specific payment method from customers payment methods list
 * @param {string} paymentMethodName Name of the payment method
 * @param {string} customerId Customer id
 * @return {Object} Payment method from customers payment methods list
 */
customerHelper.getCustomerPaymentInstruments = function (paymentMethodName, customerId) {
    const CustomerMgr = require('dw/customer/CustomerMgr');
    let profile = null;

    if (customerId) {
        profile = CustomerMgr.getProfile(customerId.indexOf('_') >= 0 ? customerId.split('_')[1] : customerId);
    } else {
        profile = customer.authenticated ? customer.getProfile() : null;
    }

    if (!profile) {
        return null;
    }

    return profile.getWallet().getPaymentInstruments(paymentMethodName);
};

/**
 * Get default customer PayPal payment instrument
 * @param {string} customerId Braintree customer ID or DW cusomer ID. If customer ID is null, returns payment instruments of current customer
 * @return {dw.customer.CustomerPaymentInstrument} payment instrument
 */
customerHelper.getDefaultCustomerPaypalPaymentInstrument = function (customerId) {
    var instruments = customerHelper.getCustomerPaymentInstruments(prefs.paymentMethods.BRAINTREE_PAYPAL.paymentMethodId, customerId);

    if (!instruments) {
        return null;
    }

    var iterator = instruments.iterator();
    var instrument = null;

    while (iterator.hasNext()) {
        instrument = iterator.next();
        if (instrument.custom.braintreeDefaultCard) {
            return instrument;
        }
    }

    return instruments.length > 0 && instruments[0];
};

/**
 * Get saved PayPal customer payment method instrument
 * @param {string} email PayPal account email
 * @return {dw.util.Collection} payment instruments
 */
customerHelper.getPaypalCustomerPaymentInstrumentByEmail = function (email) {
    var customerPaymentInstruments = customerHelper.getCustomerPaymentInstruments(prefs.paymentMethods.BRAINTREE_PAYPAL.paymentMethodId);

    if (empty(customerPaymentInstruments)) {
        return null;
    }

    var iterator = customerPaymentInstruments.iterator();
    var paymentInst = null;

    while (iterator.hasNext()) {
        paymentInst = iterator.next();
        if (paymentInst.custom.braintreePaypalAccountEmail === email) {
            return paymentInst;
        }
    }

    return null;
};

/**
 * Create customer ID for braintree based on the customer number
 * @param {dw.customer.Customer} customer  Registered customer object
 * @return {string} Customer ID
 */
customerHelper.createCustomerId = function (customer) {
    if (session.privacy.customerId) {
        return session.privacy.customerId;
    }

    const Site = require('dw/system/Site');

    const id = customer.profile.customerNo;
    const maxNameLength = 31;
    const allowedNameLength = maxNameLength - id.length;

    let siteName = Site.current.ID.toLowerCase();

    if (siteName.length > allowedNameLength) {
        siteName = siteName.slice(0, allowedNameLength);
    }

    siteName = siteName + '_' + id;
    session.privacy.customerId = siteName;

    return siteName;
};

/**
 * Get saved Venmo customer payment method instrument
 * @param {string} userId Venmo
 * @return {dw.util.Collection} payment instruments
 */
customerHelper.getVenmoCustomerPaymentInstrumentByUserID = function (userId) {
    var customerPaymentInstruments = customerHelper.getCustomerPaymentInstruments(prefs.paymentMethods.BRAINTREE_VENMO.paymentMethodId);

    if (customerPaymentInstruments) {
        var iterator = customerPaymentInstruments.iterator();
        var paymentInst = null;

        while (iterator.hasNext()) {
            paymentInst = iterator.next();
            if (paymentInst.custom.braintreeVenmoUserId === userId) {
                return paymentInst;
            }
        }
    }

    return null;
};

/**
 * @param  {dw.customer.Profile} profile Customer profile
 * @returns {string} Phone number
 */
customerHelper.getPhoneFromProfile = function (profile) {
    return profile.getPhoneMobile() || profile.getPhoneHome() || profile.getPhoneBusiness();
};

/**
 * Clear default property
 * applicablePI - applicable Payment Instruments
 * @param {array} applicablePI of existed payment instruments
 * @return {Object} default PI property or {}
 */
customerHelper.clearDefaultProperty = function (applicablePI) {
    if (empty(applicablePI)) {
        return {};
    }

    var defaultPI = array.find(applicablePI, function (pi) {
        return pi.custom.braintreeDefaultCard;
    });

    if (defaultPI) {
        Transaction.wrap(function () {
            defaultPI.custom.braintreeDefaultCard = false;
        });

        return defaultPI;
    }

    return {};
};

/**
 * Set braintreeDefaultCard as true for following paymentMethods:
 * -CreditCart
 * -PayPal
 * -Venmo
 * -GooglePay
 * -SRC
 *
 * @param {string} paymentMethodToken token from Braintree
 */
customerHelper.setBraintreeDefaultCard = function (paymentMethodToken) {
    var savedPaymentInstruments = customer.getProfile().getWallet().getPaymentInstruments();

    Transaction.wrap(function () {
        array.find(savedPaymentInstruments, function (payment) {
            return paymentMethodToken === payment.creditCardToken;
        }).custom.braintreeDefaultCard = true;
    });
};

/**
* Create Preferred Address for customer
* @param {Object} payerInfo payerInfo object
* @param  {string} shippingDataString stringified address data
*/
customerHelper.createPreferredAddress = function (payerInfo, shippingDataString) {
    var addressHelpers = require('*/cartridge/scripts/helpers/addressHelpers');
    var addressBook = customer.getProfile().getAddressBook();
    var shippingData = JSON.parse(shippingDataString);
    shippingData.firstName = payerInfo.firstName;
    shippingData.lastName = payerInfo.lastName;
    shippingData.phone = payerInfo.phoneNumber;
    shippingData.address1 = shippingData.line1;
    shippingData.address2 = shippingData.line2;
    shippingData.country = shippingData.countryCode;
    shippingData.states = { stateCode: shippingData.state };

    var address = addressBook.createAddress(shippingData.address1 + ' - ' + shippingData.city + ' - ' + decodeURIComponent(shippingData.postalCode));
    addressHelpers.updateAddressFields(address, shippingData);
    addressBook.setPreferredAddress(address);
};

/**
 * Defines which customer ID to use
 * @param {dw.customer.Customer} customer Customer object
 * @return {string} customer ID
 */
customerHelper.getCustomerId = function (customer) {
    return customer.profile.custom.braintreeCustomerId || customerHelper.createCustomerId(customer);
};

/**
 * Returns the matching address ID or UUID for a billing address
 * @param {dw.order.Basket} basket - line items model
 * @param {Object} customer - customer model
 * @return {string|boolean} returns matching ID or false
*/
customerHelper.getAssociatedAddress = function (basket, customer) {
    var address = basket.billingAddress;
    var matchingId;
    var anAddress;

    if (!address) {
        return false;
    }

    // First loop through all shipping addresses
    basket.shipments.toArray().forEach(function (shipment) {
        anAddress = shipment.shippingAddress;

        if (anAddress && anAddress.isEquivalentAddress(address)) {
            matchingId = shipment.UUID;
        }
    });

    // If we still haven't found a match, then loop through customer addresses to find a match
    if (!matchingId && customer && customer.addressBook && customer.addressBook.addresses) {
        customer.addressBook.addresses.toArray().forEach(function (addressBookAddress) {
            anAddress = addressBookAddress;

            if (anAddress && anAddress.isEquivalentAddress(address)) {
                matchingId = anAddress.ID;
            }
        });
    }

    return matchingId;
};

/**
 * Returns customer shipping address for 'createPayment' method of brainree SDK
 * @param {dw.customer.CustomerAddress} defaultAddress Saved customer address
 * @returns {Object} Shipping address
 */
customerHelper.getDefaultCustomerShippingAddress = function (defaultAddress) {
    return {
        line1: defaultAddress.address1,
        line2: defaultAddress.address2 || '',
        city: defaultAddress.city,
        state: defaultAddress.stateCode,
        postalCode: defaultAddress.postalCode,
        countryCode: defaultAddress.countryCode.value,
        phone: defaultAddress.phone,
        recipientName: defaultAddress.fullName
    };
};

/**
 * Returns true if Paypal basket payment instrument equal a saved paypal account
 * @returns  {boolean} true/false
 */
customerHelper.isBasketPaymentInstrEqualSavedPayPalAccount = function () {
    var customerPaypalPaymentInstruments = customerHelper.getCustomerPaymentInstruments(prefs.paymentMethods.BRAINTREE_PAYPAL.paymentMethodId);
    var currentBasket = require('dw/order/BasketMgr').currentBasket;
    var paypalBasketPaymentInstrument = currentBasket.getPaymentInstruments(
        prefs.paymentMethods.BRAINTREE_PAYPAL.paymentMethodId
    );

    if (empty(customerPaypalPaymentInstruments) || empty(paypalBasketPaymentInstrument)) {
        return false;
    }

    var iterator = customerPaypalPaymentInstruments.iterator();
    var paymentInst = null;

    while (iterator.hasNext()) {
        paymentInst = iterator.next();

        if (paymentInst.creditCardToken === paypalBasketPaymentInstrument[0].creditCardToken) {
            return true;
        }
    }

    return false;
};

/**
 * @param {string} paymentMethodName payment method name
 * @returns {Array} array of orders with status Authorized or Submitted for Settlement/Settled filtered by payment method
 */
function getAuthorizedAndPartiallyCapturedOrders(paymentMethodName) {
    return customer.orderHistory.orders.asList().toArray().filter(function (order) {
        const braintreeOrderStatus = order.custom.braintreePaymentStatus;
        const partialCaptureStatuses = [btConstants.TRANSACTION_STATUS_SUBMITTED_FOR_SETTLEMENT, btConstants.TRANSACTION_STATUS_SETTLED];

        return order.getPaymentInstruments(paymentMethodName).length && (
            (order.custom.leftToSettle && partialCaptureStatuses.includes(braintreeOrderStatus)) ||
                braintreeOrderStatus === btConstants.TRANSACTION_STATUS_AUTHORIZED
        );
    });
}

/**
* Creates data-is-remove-allowed attr for Venmo and CC/SRC buttons on the Account Page
* @param {dw.customer.CustomerPaymentInstrument} paymentInstrument payment instrument object
* @returns {boolean} 'true' if payment method remove is allowed
*/
customerHelper.isPaymentMethodRemoveAllowed = function (paymentInstrument) {
    const orders = getAuthorizedAndPartiallyCapturedOrders(paymentInstrument.paymentMethod);

    if (empty(orders)) {
        return true;
    }

    let orderPaymentInstrument;

    switch (paymentInstrument.paymentMethod) {
        case prefs.paymentMethods.BRAINTREE_VENMO.paymentMethodId:
            return !orders.some(function (order) {
                orderPaymentInstrument = paymentHelper.getBraintreePaymentInstrument(order);

                return orderPaymentInstrument.custom.braintreeVenmoUserId === paymentInstrument.custom.braintreeVenmoUserId;
            });
        case prefs.paymentMethods.BRAINTREE_CREDIT.paymentMethodId:
            return !orders.some(function (order) {
                orderPaymentInstrument = paymentHelper.getBraintreePaymentInstrument(order);

                return orderPaymentInstrument.creditCardNumberLastDigits === paymentInstrument.creditCardNumberLastDigits
                    && orderPaymentInstrument.creditCardExpirationMonth === paymentInstrument.creditCardExpirationMonth
                    && orderPaymentInstrument.creditCardExpirationYear === paymentInstrument.creditCardExpirationYear;
            });
        case prefs.paymentMethods.BRAINTREE_SRC.paymentMethodId:
            return !orders.some(function (order) {
                orderPaymentInstrument = paymentHelper.getBraintreePaymentInstrument(order);

                return orderPaymentInstrument.creditCardNumberLastDigits === paymentInstrument.creditCardNumberLastDigits
                    && orderPaymentInstrument.creditCardToken === paymentInstrument.creditCardToken;
            });
        default:
            return true;
    }
};

/**
 * Update first name and last name for shipping if second name exist
 * @param {Object} shipping req.viewData shipping
 */
customerHelper.formatCustomerName = function (shipping) {
    if (empty(shipping) || empty(shipping[0].shippingAddress)) {
        return;
    }

    var shippingAddress = shipping[0].shippingAddress;

    var firstName = shippingAddress.firstName || null;
    var secondName = shippingAddress.secondName || null;
    var lastName = shippingAddress.lastName || null;

    if (!secondName) {
        return;
    }

    var secondNameArray = secondName.split(' ');
    // if the second name contains only one word, then the second name will be added to the first name in the shipping address
    if (secondNameArray.length === 1 && firstName.split(' ').length <= 1 && lastName.split(' ').length <= 1) {
        firstName += ' ' + secondNameArray[0];
    // if the second name contains two words, then the first word will be added to the first name of the shipping address
    // and the second word will be added to the last name of the shipping address
    } else if (secondNameArray.length === 2 && firstName.split(' ').length <= 1 && lastName.split(' ').length <= 1) {
        firstName += ' ' + secondNameArray[0];
        lastName = secondNameArray[1].concat(' ', lastName);
    }

    shippingAddress.firstName = firstName;
    shippingAddress.lastName = lastName;
};

/**
 * Splits a full name into a separate first as well as a second name
 * We assume that first name is first part of full name and the rest is last name
 * @param {string} fullName A full name
 * @returns {Object} An object with first and last name
 */
customerHelper.splitFullName = function (fullName) {
    const fullNameArray = fullName.split(/\s+/);

    return {
        firstName: fullNameArray.shift(),
        lastName: fullNameArray.join(' ')
    };
};

/**
 * Preparation of necessary information that will be using in 3DSecure verify card
 * @param {dw.customer.Customer} customer customer
 * @returns {Object} customer info for credit card validation
 */
customerHelper.getCustomerInfoCreditCard = function (customer) {
    const basicHelpers = require('*/cartridge/config/basicHelpers');

    const profile = customer.profile;
    const shippingAddress = basicHelpers.getValueByKey(profile, 'addressBook.preferredAddress', {});

    return {
        email: profile.email,
        billingData: {
            firstName: basicHelpers.getValueOr(shippingAddress.firstName, profile.firstName),
            lastName: basicHelpers.getValueOr(shippingAddress.lastName, profile.lastName),
            phone: basicHelpers.getValueOr(shippingAddress.phone, profile.phoneHome),
            address1: basicHelpers.getValueOr(shippingAddress.address1, ''),
            address2: basicHelpers.getValueOr(shippingAddress.address2, ''),
            city: basicHelpers.getValueOr(shippingAddress.city, ''),
            country: basicHelpers.getValueByKey(shippingAddress, 'countryCode.value', ''),
            stateCode: basicHelpers.getValueOr(shippingAddress.stateCode, ''),
            postalCode: basicHelpers.getValueOr(shippingAddress.postalCode, '')
        },
        shippingAdditionalInfo: {
            workPhoneNumber: basicHelpers.getValueOr(shippingAddress.phone, profile.phoneHome),
            shippingGivenName: basicHelpers.getValueOr(shippingAddress.firstName, profile.firstName),
            shippingSurname: basicHelpers.getValueOr(shippingAddress.lastName, profile.lastName),
            shippingPhone: basicHelpers.getValueOr(shippingAddress.phone, profile.phoneHome),
            shippingAddress: {
                streetAddress: basicHelpers.getValueOr(shippingAddress.address1, ''),
                extendedAddress: basicHelpers.getValueOr(shippingAddress.address2, ''),
                locality: basicHelpers.getValueOr(shippingAddress.city, ''),
                region: basicHelpers.getValueOr(shippingAddress.stateCode, ''),
                postalCode: basicHelpers.getValueOr(shippingAddress.postalCode, ''),
                countryCodeAlpha2: basicHelpers.getValueByKey(shippingAddress, 'countryCode.value', '')
            }
        }
    };
};

module.exports = customerHelper;
