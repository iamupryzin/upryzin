'use strict';
/* global XML */

const xmlHelper = {};

/**
 * Parse XML into Object
 * @param {string} xmlStr XML string
 * @return {Object} Parsed object
 */
xmlHelper.parseXml = function (xmlStr) {
    const resultObj = {};
    const xmlObj = new XML(xmlStr);

    function formatNodeName(name) { // eslint-disable-line require-jsdoc
        return name.replace(/-(.)/g, function (a, b) {
            return b.toUpperCase();
        });
    }

    function parse(node, objectToParse) { // eslint-disable-line require-jsdoc
        const obj = objectToParse;
        const nodeName = formatNodeName(node.name().toString());
        const elements = node.elements();

        if (elements.length()) {
            const nodeType = node.attribute('type').toString();

            if (nodeType === 'array' || nodeType === 'collection') {
                obj[nodeName] = [];

                if (elements[0] && elements[0].hasSimpleContent() && nodeType !== 'collection') {
                    Object.keys(elements).forEach(function (elementIndex) {
                        obj[nodeName].push(elements[elementIndex].text().toString());
                    });
                } else {
                    Object.keys(elements).forEach(function (elementIndex) {
                        parse(elements[elementIndex], obj[nodeName]);
                    });
                }
            } else if (obj instanceof Array) {
                const objNew = {};

                obj.push(objNew);

                Object.keys(elements).forEach(function (elementIndex) {
                    parse(elements[elementIndex], objNew);
                });
            } else {
                obj[nodeName] = {};

                Object.keys(elements).forEach(function (elementIndex) {
                    parse(elements[elementIndex], obj[nodeName]);
                });
            }
        } else {
            obj[nodeName] = node.text().toString();
        }
    }

    parse(xmlObj, resultObj);

    return resultObj;
};

module.exports = xmlHelper;
