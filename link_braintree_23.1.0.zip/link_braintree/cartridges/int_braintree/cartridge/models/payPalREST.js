'use strict';

/**
 * SFCC API inclusions.
 */
const Site = require('dw/system/Site');
const URLUtils = require('dw/web/URLUtils');

/**
 * Custom API inclusions.
 */
const PayPalRESTService = require('~/cartridge/scripts/service/payPalREST');
const prefs = require('~/cartridge/config/braintreePreferences');

/**
 * The PayPalRESTModel function is a constructor function that creates a new PayPalRESTModel object.
 */
function PayPalRESTModel() {
    this.service = new PayPalRESTService();
}

/**
 * Returns SDK url for Connect with Paypal button on Login page
 * @param {string} oAuthReentryEndpoint redirect Url of the req.querystring
 * @returns {string} SDK Url
 */
PayPalRESTModel.prototype.getConnectWithPaypalURL = function (oAuthReentryEndpoint) {
    const locale = Site.current.defaultLocale;
    const redirectUrl = [URLUtils.abs('Braintree-HandleCWPP').toString(), '&state=', oAuthReentryEndpoint.split('=').pop()].join('');
    const clientID = this.service.configuration.credential.user;

    return [prefs.cwppButtonUrl, 'flowEntry=static&client_id=', clientID, '&locale=', locale, '&scope=openid profile email address&redirect_uri=', redirectUrl].join('');
};

/**
 * This is a function that is used to get the access token by authorization code
 * @param {string} authorizationCode authorization code
 * @returns {string} access token if responce status is OK
 */
PayPalRESTModel.prototype.getAccessTokenByAuthorizationCode = function (authorizationCode) {
    const response = this.service.call({
        requestId: 'getAccessTokenByAuthorizationCode',
        requestBody: {
            grant_type: 'authorization_code',
            code: authorizationCode
        }
    });

    return response.isOk() ? response.object.access_token : null;
};

/**
 * This is a function that is used to get the customer information by access token
 * @param {string} accessToken access token
 * @returns {Object} customer information if responce status is OK
 */
PayPalRESTModel.prototype.getCustomerInfo = function (accessToken) {
    const Resource = require('dw/web/Resource');
    const braintreeConstants = require('*/cartridge/config/braintreeConstants');

    const response = this.service.call({
        requestId: 'getCustomerInfo',
        accessToken: accessToken
    });

    const payPalCustomerInfo = response.isOk() ? response.object : null;

    if (!payPalCustomerInfo || !payPalCustomerInfo.emails || !payPalCustomerInfo.name || !payPalCustomerInfo.address) {
        return null;
    }

    const [firstName, middleName, lastName] = payPalCustomerInfo.name.trim().split(/\s+/);

    payPalCustomerInfo.firstName = firstName;
    payPalCustomerInfo.lastName = lastName || middleName;
    payPalCustomerInfo.email = payPalCustomerInfo.emails.shift().value;

    payPalCustomerInfo.addressObjectFromPayPal = {
        id: [braintreeConstants.LOGIN_PAYPAL, payPalCustomerInfo.address.postal_code].join(' - '),
        address1: payPalCustomerInfo.address.street_address,
        city: payPalCustomerInfo.address.locality,
        countryCode: payPalCustomerInfo.address.country,
        firstName: payPalCustomerInfo.firstName,
        lastName: payPalCustomerInfo.lastName,
        postalCode: payPalCustomerInfo.address.postal_code,
        stateCode: payPalCustomerInfo.address.region,
        phone: Resource.msg('braintree.account.address.phonenumber.notprovided', 'locale', null)
    };

    return payPalCustomerInfo;
};

module.exports = PayPalRESTModel;
