'use strict';

const Resource = require('dw/web/Resource');

const prefs = require('~/cartridge/config/braintreePreferences');
const obj = require('*/cartridge/scripts/query/queries');
const braintreeConstants = require('*/cartridge/config/braintreeConstants');
const braintreeApiCalls = require('~/cartridge/scripts/braintree/braintreeAPI/braintreeApiCalls');
const paymentHelper = require('~/cartridge/scripts/braintree/helpers/paymentHelper');

const BTServiceResponseHandlerModel = require('*/cartridge/models/btServiceResponseHandler');
const btServiceResponseHandler = new BTServiceResponseHandlerModel();

/**
 * Creates graphQl request data
 * @param {string} queryName query name
 * @param {Object} requestDataObj request data
 * @return {Object} prepared request data for graphQL call
 */
function createGraphQLCallRequest(queryName, requestDataObj) {
    return obj.addVariables(queryName, requestDataObj);
}

/**
 * Validates whether data object is not empty
 * @param {Object} data data object
 * @return {Object} data object or error
 */
function validateReqData(data) {
    if (empty(Object.keys(data))) {
        throw new Error(Resource.msg('braintree.error.empty.data', 'locale', null));
    }

    return data;
}

/**
 * Get Merchant account ID
 * @returns {string} Merchant ID
 */
function getMerchantAccountID() {
    const currentSite = require('dw/system/Site').current;
    const currentCurrency = paymentHelper.findCurrentSiteCurrency(currentSite.allowedCurrencies.toArray()) || currentSite.getDefaultCurrency();

    return paymentHelper.getMerchantAccountID(currentCurrency);
}

/**
 * BT graphQL sdk model
 */
function btGraphQLSdk() {}

/**
 * Converts legacy ID into graphQL ID
 * @param {string} legacyId legacy ID
 * @param {string} type type of legacy ID
 * @return {string} converted ID
 */
btGraphQLSdk.prototype.legacyIdConverter = function (legacyId, type) {
    const requestDataObj = {
        legacyId: legacyId,
        type: type
    };

    const graphQLRequestData = createGraphQLCallRequest(braintreeConstants.QUERY_NAME_LEGACY_ID_CONVERTER, requestDataObj);
    const btServiceRepsonse = braintreeApiCalls.call(graphQLRequestData);

    return btServiceResponseHandler.validateLegacyIdConverterResponse(btServiceRepsonse);
};

/**
 * Searches transactions by IDs (used for UpdatePaymentStatuses job)
 * @param {Object} data request data
 * @return {Object} response - transactions arrays
 */
btGraphQLSdk.prototype.searchTransactionsByIds = function (data) {
    const reqData = validateReqData(data);
    const requestDataObj = {
        input: {
            id: {
                in: reqData.ids
            }
        }
    };

    const graphQLRequestData = createGraphQLCallRequest(braintreeConstants.QUERY_NAME_SEARCH_TRANSACTION, requestDataObj);
    const btServiceRepsonse = braintreeApiCalls.call(graphQLRequestData);

    return btServiceResponseHandler.validateSearchTransactionsByIdsResponse(btServiceRepsonse);
};

/**
 * Creates client token
 * @param {Object} data request data
 * @return {string} client token
 */
btGraphQLSdk.prototype.createClientToken = function (data) {
    const reqData = validateReqData(data);
    const btCustomerId = data.btCustomerId;
    const requestDataObj = {
        input: {
            clientToken: {
                merchantAccountId: reqData.accId
            }
        }
    };

    if (btCustomerId) {
        requestDataObj.input.clientToken.customerId = btCustomerId;
    }

    const graphQLRequestData = createGraphQLCallRequest(braintreeConstants.QUERY_NAME_CLIENT_ID, requestDataObj);
    const btServiceRepsonse = braintreeApiCalls.call(graphQLRequestData);

    return btServiceResponseHandler.validateCreateClientTokenResponse(btServiceRepsonse);
};

/**
 * Vaults payment method
 * @param {Object} data request data
 * @return {Object} response with payment method data
 */
btGraphQLSdk.prototype.vaultPaymentMethod = function (data) {
    const reqData = validateReqData(data);
    const requestDataObj = {
        input: {
            paymentMethodId: reqData.paymentMethodNonce,
            customerId: this.legacyIdConverter(reqData.customerId, braintreeConstants.LEGACY_ID_TYPE_CUSTOMER)
        },
        authInsight: {
            merchantAccountId: getMerchantAccountID()
        }
    };

    const graphQLRequestData = createGraphQLCallRequest(braintreeConstants.QUERY_NAME_VAULT_PAYMENT_METHOD, requestDataObj);
    const btServiceRepsonse = braintreeApiCalls.call(graphQLRequestData);

    return btServiceResponseHandler.validateVaultPaymentMethodResponse(btServiceRepsonse);
};

btGraphQLSdk.prototype.vaultCreditCard = function (data) {
    const reqData = validateReqData(data);

    const requestDataObj = {
        input: {
            paymentMethodId: reqData.paymentMethodNonce,
            customerId: this.legacyIdConverter(reqData.customerId, braintreeConstants.LEGACY_ID_TYPE_CUSTOMER)
        },
        authInsight: {
            merchantAccountId: getMerchantAccountID()
        }
    };

    const graphQLRequestData = createGraphQLCallRequest(braintreeConstants.QUERY_NAME_VAULT_CREDIT_CARD, requestDataObj);
    const btServiceRepsonse = braintreeApiCalls.call(graphQLRequestData);

    return btServiceResponseHandler.validateVaultCreditCardResponse(btServiceRepsonse);
};

/**
 * Deletes payment method from vault on BT side
 * @param {Object} data request data
 * @return {Object} response
 */
btGraphQLSdk.prototype.deletePaymentMethodFromVault = function (data) {
    const reqData = validateReqData(data);
    const requestDataObj = {
        input: {
            paymentMethodId: this.legacyIdConverter(reqData.creditCardToken, braintreeConstants.LEGACY_ID_TYPE_PAYMENT_METHOD)
        }
    };

    const graphQLRequestData = createGraphQLCallRequest(braintreeConstants.QUERY_NAME_DELETE_PAYMENT_METHOD, requestDataObj);
    const btServiceRepsonse = braintreeApiCalls.call(graphQLRequestData);

    return btServiceResponseHandler.validateDeletePaymentMethodFromVaultResponse(btServiceRepsonse);
};

/**
 * Finds customer
 * @param {Object} data request data
 * @return {Object} response with customer data
 */
btGraphQLSdk.prototype.findCustomer = function (data) {
    const reqData = validateReqData(data);
    const requestDataObj = {
        input: {
            id: {
                in: [this.legacyIdConverter(reqData.customerId, braintreeConstants.LEGACY_ID_TYPE_CUSTOMER)]
            }
        }
    };

    const graphQLRequestData = createGraphQLCallRequest(braintreeConstants.QUERY_NAME_SEARCH_CUSTOMER, requestDataObj);
    const btServiceRepsonse = braintreeApiCalls.call(graphQLRequestData);

    return btServiceResponseHandler.validateFindCustomerResponse(btServiceRepsonse);
};

/**
 * Creates customer
 * @param {Object} data request data
 * @return {string} customer's ID
 */
btGraphQLSdk.prototype.createCustomer = function (data) {
    const reqData = validateReqData(data);
    const requestDataObj = {
        input: {
            customer: {
                firstName: reqData.firstName,
                lastName: reqData.lastName,
                email: reqData.email,
                company: reqData.company,
                phoneNumber: reqData.phone
            }
        }
    };

    const graphQLRequestData = createGraphQLCallRequest(braintreeConstants.QUERY_NAME_CREATE_CUSTOMER, requestDataObj);
    const btServiceRepsonse = braintreeApiCalls.call(graphQLRequestData);

    return btServiceResponseHandler.validateCreateCustomerResponse(btServiceRepsonse);
};

/**
 * Update customer data
 * @param {Object} data request data
 */
btGraphQLSdk.prototype.updateCustomer = function (data) {
    const reqData = validateReqData(data);
    const requestDataObj = {
        input: {
            customerId: reqData.customerId,
            customer: {
                firstName: reqData.firstName,
                lastName: reqData.lastName,
                phoneNumber: reqData.phoneNumber,
                email: reqData.email
            }
        }
    };

    const graphQLRequestData = createGraphQLCallRequest(braintreeConstants.QUERY_NAME_UPDATE_CUSTUMER, requestDataObj);
    braintreeApiCalls.call(graphQLRequestData);
};

/**
 * Verify a Credit Card
 * @param {Object} data request data
 * @return {Object} A verification response
 */
btGraphQLSdk.prototype.verifyCreditCard = function (data) {
    const reqData = validateReqData(data);
    const requestDataObj = {
        input: {
            paymentMethodId: this.legacyIdConverter(reqData.paymentMethodId, braintreeConstants.LEGACY_ID_TYPE_PAYMENT_METHOD),
            options: {
                tokenizedCvv: reqData.tokenizedCvv
            }
        }
    };

    const graphQLRequestData = createGraphQLCallRequest(braintreeConstants.QUERY_NAME_VERIFY_CREDIT_CARD, requestDataObj);
    const btServiceRepsonse = braintreeApiCalls.call(graphQLRequestData);

    return btServiceResponseHandler.validateVerifyCreditCardResponse(btServiceRepsonse);
};

/**
 * Creates transaction based on passed parameters
 * @param {Object} data request data
 * @return {Object} response with created transaction data
 */
btGraphQLSdk.prototype.createTransaction = function (data) {
    const reqData = validateReqData(data);
    // Define which business logic will be executed
    const queryName = paymentHelper.defineCreateTransactionQueryName(reqData);
    const requestDataObj = {
        paymentMethodId: reqData.paymentMethodNonce || this.legacyIdConverter(reqData.paymentMethodToken, braintreeConstants.LEGACY_ID_TYPE_PAYMENT_METHOD),
        transaction: {
            amount: reqData.amount,
            merchantAccountId: reqData.merchantAccountId,
            orderId: reqData.orderId,
            riskData: {
                deviceData: reqData.deviceData
            },
            tax: {},
            shipping: {},
            channel: prefs.braintreeChannel
        }
    };

    // Used in case of AutorizeCreditCard as well as ChargeCreditCard mutation
    if (reqData.options && reqData.options.billingAddress) {
        requestDataObj.options = {
            billingAddress: reqData.options.billingAddress
        };
    }

    if (!empty(reqData.customerId)) {
        requestDataObj.transaction.customerId = reqData.customerId;
    }

    if (!empty(reqData.vaultPaymentMethodAfterTransacting)) {
        requestDataObj.transaction.vaultPaymentMethodAfterTransacting = reqData.vaultPaymentMethodAfterTransacting;
    }

    if (!empty(reqData.shipping)) {
        requestDataObj.transaction.shipping.shippingAddress = reqData.shipping;
    }

    if (!empty(reqData.shippingAmount)) {
        requestDataObj.transaction.shipping.shippingAmount = reqData.shippingAmount;
    }

    if (!empty(reqData.descriptor)) {
        requestDataObj.transaction.descriptor = reqData.descriptor;
    }

    if (!empty(reqData.customFields)) {
        requestDataObj.transaction.customFields = reqData.customFields;
    }

    if (!empty(reqData.taxAmount)) {
        requestDataObj.transaction.tax.taxAmount = reqData.taxAmount;
    }

    if (!empty(reqData.discountAmount)) {
        requestDataObj.transaction.discountAmount = reqData.discountAmount;
    }

    if (!empty(reqData.lineItems)) {
        requestDataObj.transaction.lineItems = reqData.lineItems;
    }

    const graphQLRequestData = createGraphQLCallRequest(queryName, { input: requestDataObj });
    const btServiceRepsonse = braintreeApiCalls.call(graphQLRequestData);

    return btServiceResponseHandler.validateCreateTransactionResponse(btServiceRepsonse);
};

/**
 * Updates the Credit Card billing address on the Braintree side
 * @param {Object} data request data
 */
btGraphQLSdk.prototype.updateCreditCardBillingAddress = function (data) {
    const reqData = validateReqData(data);
    const billingAddress = reqData.billingAddress;
    const pmId = this.legacyIdConverter(reqData.paymentMethodId, braintreeConstants.LEGACY_ID_TYPE_PAYMENT_METHOD);
    const graphQLRequestData = createGraphQLCallRequest(
        braintreeConstants.QUERY_NAME_UPDATE_CREDIT_CARD_BILLING_ADDRESS,
        {
            input: {
                paymentMethodId: pmId,
                billingAddress: {
                    firstName: billingAddress.firstName,
                    lastName: billingAddress.lastName,
                    addressLine1: billingAddress.streetAddress,
                    extendedAddress: billingAddress.extendedAddress,
                    locality: billingAddress.locality,
                    region: billingAddress.region,
                    postalCode: billingAddress.postalCode,
                    countryCode: billingAddress.countryCodeAlpha2
                }
            }
        }
    );
    const btServiceRepsonse = braintreeApiCalls.call(graphQLRequestData);

    btServiceResponseHandler.validateUpdateCCBillingAddressResponse(btServiceRepsonse);
};

module.exports = btGraphQLSdk;
