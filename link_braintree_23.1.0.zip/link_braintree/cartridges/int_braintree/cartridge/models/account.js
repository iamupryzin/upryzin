'use strict';

const account = module.superModule;

const URLUtils = require('dw/web/URLUtils');

account.getCustomerPaymentInstruments = function (userPaymentInstruments) {
    return userPaymentInstruments.toArray().map(function (paymentInstrument) {
        let result = null;

        if (paymentInstrument.custom.braintreePaypalAccountEmail) {
            result = {
                email: paymentInstrument.custom.braintreePaypalAccountEmail,
                address: paymentInstrument.custom.braintreePaypalAccountAddresses,
                UUID: paymentInstrument.UUID,
                isDefault: paymentInstrument.custom.braintreeDefaultCard
            };
        } else if (paymentInstrument.custom.braintreeVenmoUserId) {
            result = {
                userID: paymentInstrument.custom.braintreeVenmoUserId,
                UUID: paymentInstrument.UUID,
                isDefault: paymentInstrument.custom.braintreeDefaultCard
            };
        } else {
            result = {
                creditCardHolder: paymentInstrument.creditCardHolder,
                maskedCreditCardNumber: paymentInstrument.maskedCreditCardNumber,
                creditCardType: paymentInstrument.creditCardType,
                creditCardExpirationMonth: paymentInstrument.creditCardExpirationMonth,
                creditCardExpirationYear: paymentInstrument.creditCardExpirationYear,
                creditCardExpirationYearShort: paymentInstrument.creditCardExpirationYear.toString().slice(-2),
                UUID: paymentInstrument.UUID,
                isDefault: paymentInstrument.custom.braintreeDefaultCard,
                braintreeIsCard: true,
                creditCardNumberLastDigits: paymentInstrument.creditCardNumberLastDigits,
                creationDate: paymentInstrument.creationDate,
                paymentMethod: paymentInstrument.paymentMethod
            };
            result.cardTypeImage = {
                src: URLUtils.staticURL(`/images/${paymentInstrument.creditCardType.toLowerCase().replace(/\s/g, '')}-dark.svg`),
                alt: paymentInstrument.creditCardType
            };
        }

        return result;
    });
};

module.exports = account;
