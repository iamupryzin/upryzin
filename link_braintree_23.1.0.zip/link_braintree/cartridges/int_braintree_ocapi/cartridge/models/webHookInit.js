'use strict';

const Resource = require('dw/web/Resource');
const Encoding = require('dw/crypto/Encoding');
const xmlHelper = require('~/cartridge/scripts/braintree/helpers/xmlHelper');

const paymentMethodWhHelper = require('~/cartridge/scripts/braintree/helpers/paymentMethodWhHelper');

/**
 * WebHook init model
 */
function webHookInit() {
    this.credentials = paymentMethodWhHelper.getBtServiceCredentials();
}

/**
 * Compares signatures with public key
 * @param {Array} signaturePairs Array of signature pairs
 * @returns {string} Signature string or null
 */
function matchingSignature(signaturePairs) {
    const selfe = this;
    const matchedPair = signaturePairs.find(function (signaturePair) {
        return selfe.credentials.user === signaturePair[0];
    });

    /** return signature;*/
    return matchedPair ? matchedPair[1] : null;
}

/**
 * Parse payload into object
 * @param {string} payload Payment method webHook payload
 * @returns {Object} Notification object
 */
webHookInit.prototype.parsePayload = function (payload) {
    const illegalPattern = /^A-Za-z0-9+=\/\n]/;

    if (!payload) {
        throw Resource.msg('braintree.ocapi.paymentMethod.webhook.payload.not.exist', 'locale', 'null');
    }

    if (illegalPattern.test(payload)) {
        throw Resource.msg('braintree.ocapi.paymentMethod.webhook.payload.contains.illegal.characters', 'locale', 'null');
    }

    // Creates xml string from payload of characters encoded in base-64
    const xmlPayload = Encoding.fromBase64(payload).toString();

    return xmlHelper.parseXml(xmlPayload);
};

/**
 * Validates signature
 * @param {string} signatureString Signature
 * @param {string} payload Payload
 * @return {boolean} "true" if payload match the signature
 */
webHookInit.prototype.validateSignature = function (signatureString, payload) {
    if (!signatureString) {
        throw Resource.msg('braintree.ocapi.paymentMethod.webhook.signature.not.exist', 'locale', 'null');
    }

    const signaturePairs = signatureString.split('&').filter(function (pair) {
        return pair.indexOf('|') !== -1;
    }).map(function (pair) {
        return pair.split('|');
    });
    const signature = matchingSignature.call(this, signaturePairs);
    const self = this;

    if (!signature) {
        throw Resource.msg('braintree.ocapi.paymentMethod.webhook.signature.nomatch.public.key', 'locale', 'null');
    }

    const matches = [payload, payload + '\n'].some(function (data) {
        return paymentMethodWhHelper.signatureWithPayloadComparizon(signature, paymentMethodWhHelper.getSha1HexDigestValue(self.credentials.password, data));
    });

    if (!matches) {
        throw Resource.msg('braintree.ocapi.paymentMethod.webhook.signature.doesnot.match.payload', 'locale', 'null');
    }

    return matches;
};

module.exports = webHookInit;
