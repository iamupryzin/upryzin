'use strict';

const WebHookInitModel = require('~/cartridge/models/webHookInit');
const braintreeBusinessLogic = require('~/cartridge/scripts/braintree/braintreeAPI/braintreeBusinessLogic');
const prefs = require('~/cartridge/config/braintreePreferences');
const paymentHelper = require('~/cartridge/scripts/braintree/helpers/paymentHelper');

const CustomerMgr = require('dw/customer/CustomerMgr');
const Resource = require('dw/web/Resource');

/**
 * paymentMethodWhMgr model
 */
function paymentMethodWhMgr() {
    WebHookInitModel.apply(this, arguments);
}

paymentMethodWhMgr.prototype = Object.create(WebHookInitModel.prototype);

/**
 * Deletes revoked payment method from Storefront and Braintree account when a customer canceled their PayPal billing agreement.
 * @param {Object} paypalAccount Customer paypal account
 */
paymentMethodWhMgr.prototype.deleteRevokedPaymentMethod = function (paypalAccount) {
    const customerId = paypalAccount.customerId;

    let customerProfile = CustomerMgr.queryProfile('custom.braintreeCustomerId = {0}', customerId);

    // Handles cases when customer was created by legacy API
    if (!customerProfile) {
        const customerNumber = customerId.substring(customerId.indexOf('_') + 1);

        customerProfile = CustomerMgr.queryProfile('customerNo = {0}', customerNumber);
    }

    // Handle cases when merchant removed storefront customer from business manager and buyer revoked billing agreement from its account
    if (!customerProfile) {
        throw new Error(Resource.msg('braintree.ocapi.server.error.custom', 'locale', null));
    }

    const isPayPalAccountIsDefaultPayment = customerProfile.wallet.paymentInstruments.toArray().find(function (paymentInstrument) {
        return paymentInstrument.creditCardToken === paypalAccount.token && paymentInstrument.custom.braintreeDefaultCard !== null;
    });

    // Deletes revoked payment method from braintree account
    braintreeBusinessLogic.deletePaymentMethod(paypalAccount.token);

    // Deletes revoked payment method from storefront customer
    paymentHelper.deletePaymentInstrumentFromDwCustomer(paypalAccount.token, customerProfile);

    // Sets new default PayPal card
    if (isPayPalAccountIsDefaultPayment) {
        paymentHelper.setAndReturnNewDefaultCard(prefs.paymentMethods.BRAINTREE_PAYPAL.paymentMethodId, customerProfile);
    }
};

module.exports = paymentMethodWhMgr;
