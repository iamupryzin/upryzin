'use strict';

const server = require('server');

/**
 * A payment instrument that was previously enabled has been revoked by the customer.
 * Currently this webhook will only be sent when a customer cancels their PayPal billing agreement
 */
server.post('PaymentMethodHook',
    function (req, res, next) {
        const paymentHelper = require('~/cartridge/scripts/braintree/helpers/paymentHelper');
        const PaymentMethodWhMgr = require('~/cartridge/models/paymentMethodWhMgr');
        const braintreeConstants = require('~/cartridge/scripts/util/braintreeConstants');
        const Resource = require('dw/web/Resource');

        const body = request.httpParameterMap;
        const btPayload = body.bt_payload.value;
        const paymentMethodWhMgr = new PaymentMethodWhMgr();

        let parsedPayload;

        try {
            // Validates signature. In case if signature is not valid an error will be thrown
            paymentMethodWhMgr.validateSignature(body.bt_signature.value, btPayload);

            // Parse payload and return a notification object. In case if payload is not valid an error will be thrown
            parsedPayload = paymentMethodWhMgr.parsePayload(btPayload);

            if (parsedPayload.notification.kind === braintreeConstants.TYPE_PAYMENT_METHOD_REVOKED_BY_CUSTOMER) {
                // Deletes revoked payment method when a customer canceled their PayPal billing agreement
                paymentMethodWhMgr.deleteRevokedPaymentMethod(parsedPayload.notification.subject.paypalAccount);
            } else {
                paymentHelper.getLogger().error(
                    Resource.msg('braintree.ocapi.paymentMethod.webhook.notification.type.doesnot.match', 'locale', 'null')
                );
            }
        } catch (err) {
            res.json({
                success: false,
                error: err
            });

            paymentHelper.getLogger().error(err);

            return next();
        }

        res.json({
            success: true
        });

        return next();
    });

module.exports = server.exports();
