'use strict';

const currentSite = require('dw/system/Site').getCurrent();
const cacheBraintreePreferences = require('dw/system/CacheMgr').getCache('braintreePreferences');
const LocalServiceRegistry = require('dw/svc/LocalServiceRegistry');

const serviceName = 'int_braintree.http.graphql.payment.Braintree';

const btLoggingMode = 'all';
const btFraudToolsEnabled = true;
const btPaypalFraudToolsEnabled = true;
const btCreditCardDescriptorPhone = '';
const btCreditCardDescriptorName = '';
const btCreditCardDescriptorUrl = '';
const btPaypalDescriptor = '';

const SDKEnableFundingHelper = require('../scripts/braintree/helpers/SDKEnableFundingHelper');
const SRCButtonConfig = require('../scripts/braintree/configuration/SRCButtonConfig');
const paypalButtonConfigs = require('~/cartridge/scripts/braintree/configuration/paypalButtonConfigs');

/**
 * Gets from credentials and returns tokenization key
 *
 * @returns {string} with tokenization key
 */
const getTokenizationKey = function () {
    const braintreeService = LocalServiceRegistry.createService(serviceName, {});

    return braintreeService.configuration.credential.custom.BRAINTREE_Tokenization_Key;
};

/**
 *  Returns all custom site preferences
 *
 * @returns {Object} statis preferences
 */
const getCustomSitePreferencies = function () {
    return {
        merchantAccountIDs: currentSite.getCustomPreferenceValue('BRAINTREE_Merchant_Account_IDs'),
        vaultMode: currentSite.getCustomPreferenceValue('BRAINTREE_Vault_Mode'),
        isSettle: currentSite.getCustomPreferenceValue('BRAINTREE_SETTLE'),
        isL2L3: currentSite.getCustomPreferenceValue('BRAINTREE_L2_L3'),
        customFields: currentSite.getCustomPreferenceValue('BRAINTREE_Custom_Fields'),

        is3DSecureEnabled: currentSite.getCustomPreferenceValue('BRAINTREE_3DSecure_Enabled').getValue() === 'enabled',
        is3DSecureSkipClientValidationResult: currentSite.getCustomPreferenceValue('BRAINTREE_3DSecure_Skip_Client_Validation_Result').getValue() === 'enabled',

        paypalDisplayName: currentSite.getCustomPreferenceValue('BRAINTREE_PAYPAL_Display_Name'),
        paypalOrderIntent: currentSite.getCustomPreferenceValue('BRAINTREE_PAYPAL_Is_Order_Intent'),
        paypalBillingAgreementDescription: currentSite.getCustomPreferenceValue('BRAINTREE_PAYPAL_Billing_Agreement_Description'),
        paypalButtonLocation: currentSite.getCustomPreferenceValue('BRAINTREE_PAYPAL_Button_Location').getValue(),
        changePMButtonEnabled: currentSite.getCustomPreferenceValue('BRAINTREE_PAYPAL_ChangePaymentMethodButton_Enabled'),
        enableFundingList: SDKEnableFundingHelper.filterEnableFundingList(currentSite.getCustomPreferenceValue('BRAINTREE_PAYPAL_Enable_Funding_List')),
        disableFundingList: currentSite.getCustomPreferenceValue('BRAINTREE_PAYPAL_Disable_Funding_List'),

        applepayDisplayName: currentSite.getCustomPreferenceValue('BRAINTREE_APPLEPAY_Display_Name'),
        applepayVisibilityOnCart: currentSite.getCustomPreferenceValue('BRAINTREE_APPLEPAY_Visibility_Button_On_Cart'),

        venmoDisplayName: currentSite.getCustomPreferenceValue('BRAINTREE_VENMO_Display_Name'),

        googlepayDisplayName: currentSite.getCustomPreferenceValue('BRAINTREE_GOOGLEPAY_Display_Name'),
        googlepayVisibilityOnCart: currentSite.getCustomPreferenceValue('BRAINTREE_GOOGLEPAY_Visibility_Button_On_Cart'),
        googleMerchantId: currentSite.getCustomPreferenceValue('BRAINTREE_GOOGLEPAY_Google_Merchant_Id'),

        srcDisplayName: currentSite.getCustomPreferenceValue('BRAINTREE_SRC_Display_Name'),
        srcVisibilityOnCart: currentSite.getCustomPreferenceValue('BRAINTREE_SRC_Visibility_Button_On_Cart')
    };
};

const getPreference = function () {
    const cacheResult = cacheBraintreePreferences.get('btPreference');

    if (cacheResult) {
        return cacheResult;
    }

    const prefs = getCustomSitePreferencies();

    // Hardcoded preferences:
    prefs.loggingMode = btLoggingMode;
    prefs.isFraudToolsEnabled = btFraudToolsEnabled;
    prefs.isPaypalFraudToolsEnabled = btPaypalFraudToolsEnabled;
    prefs.creditCardDescriptorPhone = btCreditCardDescriptorPhone;
    prefs.creditCardDescriptorName = btCreditCardDescriptorName;
    prefs.creditCardDescriptorUrl = btCreditCardDescriptorUrl;
    prefs.paypalDescriptorName = btPaypalDescriptor;

    prefs.paypalIntent = prefs.isSettle ? 'capture' : 'authorize';
    prefs.paypalBillingAgreementDescription = empty(prefs.paypalBillingAgreementDescription) ? '' : prefs.paypalBillingAgreementDescription.slice(0, 249);

    // PayPal Configs preferences:
    prefs.tokenizationKey = getTokenizationKey();
    prefs.paypalCartButtonConfig = paypalButtonConfigs.PAYPAL_Cart_Button_Config;
    prefs.paypalBillingButtonConfig = paypalButtonConfigs.PAYPAL_Billing_Button_Config;
    prefs.paypalMiniCartButtonConfig = paypalButtonConfigs.PAYPAL_MiniCart_Button_Config;
    prefs.paypalPdpButtonConfig = paypalButtonConfigs.PAYPAL_PDP_Button_Config;
    prefs.SRCBillingButtonConfig = SRCButtonConfig.SRC_Billing_Button_Config;
    prefs.SRCCartButtonConfig = SRCButtonConfig.SRC_Cart_Button_Config;
    prefs.SRCAccountButtonConfig = SRCButtonConfig.SRC_Account_Button_Config;

    if (prefs.paypalCartButtonConfig === null) {
        prefs.paypalCartButtonConfig = {};
    }

    if (prefs.paypalBillingButtonConfig === null) {
        prefs.paypalBillingButtonConfig = {};
    }
    if (prefs.paypalMiniCartButtonConfig === null) {
        prefs.paypalMiniCartButtonConfig = {};
    }
    if (prefs.paypalPdpButtonConfig === null) {
        prefs.paypalPdpButtonConfig = {};
    }

    prefs.SRCImageLink = 'https://sandbox.secure.checkout.visa.com/wallet-services-web/xo/button.png';
    prefs.SRCAccountButtonConfig = SRCButtonConfig.SRC_Account_Button_Config;

    prefs.paymentMethods = require('~/cartridge/scripts/braintree/helpers/paymentHelper').getActivePaymentMethods();

    prefs.braintreeChannel = 'SFCC_BT_SFRA_23_1_0';

    cacheBraintreePreferences.put('btPreference', prefs);
    return prefs;
};

module.exports = getPreference();
