'use strict';

module.exports = {
    // flows
    FLOW_CHECKOUT: 'checkout',
    FLOW_VAULT: 'vault',
    // Pages flows
    PAGE_FLOW_BILLING: 'billing',
    PAGE_FLOW_PDP: 'pdp',
    PAGE_FLOW_MINICART: 'minicart',
    PAGE_FLOW_CART: 'cart',
    PAGE_FLOW_ACCOUNT: 'account',
    // intents
    INTENT_TYPE_ORDER: 'order',
    // PayPal button configs
    BUTTON_CONFIG_OPTIONS_STYLE_LAYOUT_HORIZONTAL: 'horizontal',
    BUTTON_CONFIG_OPTIONS_STYLE_SHAPE_RECT: 'rect',
    BUTTON_CONFIG_OPTIONS_STYLE_SIZE_MEDIUM: 'medium',
    BUTTON_CONFIG_OPTIONS_STYLE_SIZE_SMALL: 'small',
    BUTTON_CONFIG_PAYPAL: 'paypal',
    // Payment processor IDs
    PAYMENT_PROCCESSOR_ID_BRAINTREE_CREDIT: 'BRAINTREE_CREDIT',
    PAYMENT_PROCCESSOR_ID_BRAINTREE_PAYPAL: 'BRAINTREE_PAYPAL',
    PAYMENT_PROCCESSOR_ID_BRAINTREE_APPLEPAY: 'BRAINTREE_APPLEPAY',
    PAYMENT_PROCCESSOR_ID_BRAINTREE_VENMO: 'BRAINTREE_VENMO',
    PAYMENT_PROCCESSOR_ID_BRAINTREE_SRC: 'BRAINTREE_SRC',
    PAYMENT_PROCCESSOR_ID_BRAINTREE_LOCAL: 'BRAINTREE_LOCAL',
    PAYMENT_PROCCESSOR_ID_BRAINTREE_GOOGLEPAY: 'BRAINTREE_GOOGLEPAY',
    // Payment method IDs
    PAYMENT_METHOD_ID_PAYPAL: 'PayPal',
    PAYMENT_METHOD_ID_GOOGLEPAY: 'GooglePay',
    PAYMENT_METHOD_ID_APPLEPAY: 'ApplePay',
    PAYMENT_METHOD_ID_VENMO: 'Venmo',
    PAYMENT_METHOD_ID_CREDIT_CARD: 'CREDIT_CARD',
    PAYMENT_METHOD_ID_SRC: 'SRC',
    // GraphQl call query names
    QUERY_NAME_LEGACY_ID_CONVERTER: 'legacyIdConverter',
    QUERY_NAME_SEARCH_TRANSACTION: 'searchTransaction',
    QUERY_NAME_CLIENT_ID: 'clientId',
    QUERY_NAME_VAULT_PAYMENT_METHOD: 'vaultPaymentMethod',
    QUERY_NAME_DELETE_PAYMENT_METHOD: 'deletePaymentMethodFromVault',
    QUERY_NAME_SEARCH_CUSTOMER: 'searchCustomer',
    QUERY_NAME_CREATE_CUSTOMER: 'createCustomer',
    QUERY_NAME_SALE: 'sale',
    QUERY_NAME_AUTHORIZATION: 'authorization',
    QUERY_NAME_PAYPAL_SALE: 'chargePaypal',
    QUERY_NAME_PAYPAL_AUTHORIZATION: 'authorizePaypal',
    // Legacy ID types for graphQL calls
    LEGACY_ID_TYPE_CUSTOMER: 'CUSTOMER',
    LEGACY_ID_TYPE_PAYMENT_METHOD: 'PAYMENT_METHOD',
    LEGACY_ID_TYPE_TRANSACTION: 'TRANSACTION',
    // Card types
    CREDIT_CARD_TYPE_VISA: 'visa',
    GOOGLEPAY_TYPE_ANDROID_PAY_CARD: 'AndroidPayCard',
    // Transaction statuses
    TRANSACTION_STATUS_SETTLING: 'SETTLING',
    TRANSACTION_STATUS_SUBMITTED_FOR_SETTLEMENT: 'SUBMITTED_FOR_SETTLEMENT',
    TRANSACTION_STATUS_AUTHORIZED: 'AUTHORIZED',
    TRANSACTION_STATUS_SETTLED: 'SETTLED',
    TRANSACTION_STATUS_SETTLEMENT_PENDING: 'SETTLEMENT_PENDING',
    // BT webHooks notification types
    TYPE_PAYMENT_METHOD_REVOKED_BY_CUSTOMER: 'payment_method_revoked_by_customer',
    // etc.
    TRANSACTION_VAULT_ON_SUCCESS: 'ON_SUCCESSFUL_TRANSACTION',
    LINE_ITEMS_KIND: 'DEBIT',
    // 'Payment method details' types from Braintree
    PAYPAL_ACCOUNT_DETAILS_TYPE: 'PayPalAccountDetails',
    // Instance types
    DEVELOPMENT_SYSTEM_TYPE: 'TEST',
    PRODUCTION_SYSTEM_TYPE: 'PRODUCTION',
    // OCAPI Error types
    CUSTOM_ERROR_TYPE: 'customError',
    BRAINTREE_ERROR_TYPE: 'BraintreeError',
    // The custom Ocapi 'flashes' types
    CUSTOMER_EMAIL_REQUIRED_FLASH_TYPE: 'CustomerEmailRequired',
    // The custom Ocapi 'flashes' paths
    CUSTOMER_EMAIL_REQUIRED_FLASH_PATH: '$.customer_info.email',
    // Auth request typed
    AUTH_REQUEST_TYPE_GUEST: 'guest',
    // Patterns
    // eslint-disable-next-line
    EMAIL_PATTERN: /^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i
};
