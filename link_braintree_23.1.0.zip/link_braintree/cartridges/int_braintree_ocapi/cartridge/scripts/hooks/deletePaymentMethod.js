'use strict';

var Status = require('dw/system/Status');
var Resource = require('dw/web/Resource');
var Logger = require('dw/system/Logger');

var braintreeConstants = require('~/cartridge/scripts/util/braintreeConstants');
var btBusinessLogic = require('~/cartridge/scripts/braintree/braintreeAPI/braintreeBusinessLogic');

/**
 * The hook that performs the removal of a payment instrument on the Braintree side
 * @param {Object} customer the object which represents the current customer
 * @param {string} UUID the string which represents the current payment instrument
 * @returns {Object} returns an error object if there are no payment instruments in customer' wallet or an incorrect UUID is used
**/
function beforeDELETE(customer, UUID) {
    try {
        const paymentInstruments = customer.getProfile().getWallet().getPaymentInstruments();

        if (paymentInstruments.empty) {
            throw Resource.msg('no.payment.instrument.to.delete', 'error', null);
        }

        const paymentInstrumentsArray = paymentInstruments.toArray();
        const currentPaymentInstrument = paymentInstrumentsArray.filter(paymentInstrument => paymentInstrument.UUID === UUID);

        if (empty(currentPaymentInstrument)) {
            throw Resource.msg('no.payment.instrument.with.current.UUID', 'error', null);
        }
        // Delete Payment Method from Braintree && Customer Payment Instruments
        btBusinessLogic.deletePaymentMethod(currentPaymentInstrument[0].creditCardToken);
    } catch (error) {
        Logger.error(error);
        return new Status(Status.ERROR, braintreeConstants.CUSTOM_ERROR_TYPE, error);
    }
}

exports.beforeDELETE = beforeDELETE;
