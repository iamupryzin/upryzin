'use strict';

const Status = require('dw/system/Status');
const Logger = require('dw/system/Logger');

const braintreeConstants = require('~/cartridge/scripts/util/braintreeConstants');
const btBusinessLogic = require('~/cartridge/scripts/braintree/braintreeAPI/braintreeBusinessLogic');

// Hook dw.ocapi.shop.customer.afterPOST functionality

/**
 * The hook which checks the current customer already exists in the wallet
 * @param {Object} customer the object which represents the current customer
 * @returns {Object} returns an error object if the same customer already exists
**/
function afterPOST(customer) {
    const btResponse = btBusinessLogic.createCustomerOnBraintreeSide(customer);

    if (btResponse.error) {
        Logger.error(btResponse.error);

        return new Status(Status.ERROR, braintreeConstants.CUSTOM_ERROR_TYPE, btResponse.error);
    }
}

// Hook dw.ocapi.shop.customer.beforePOST functionality

/**
 * The hook which checks the current customer already exists
 * @param {Object} registration the object which represents the current customer registration info
 * @returns {Object} returns an error object if the validation fails
**/
function beforePOST(registration) {
    try {
        const customerHelper = require('~/cartridge/scripts/braintree/helpers/customerHelper');

        customerHelper.areCustomerRegistrationRequiredFieldsFilled(registration);
    } catch (error) {
        Logger.error(error.message);

        return new Status(Status.ERROR, braintreeConstants.CUSTOM_ERROR_TYPE, error.message);
    }
}

exports.afterPOST = afterPOST;
exports.beforePOST = beforePOST;
