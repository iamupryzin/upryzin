'use strict';

/**
 * The function is called before payment instrument adding to a basket
 * The hook validates all required values for adding Braintree payment instrument to the basket
 * @param {dw.order.Basket} basket A current basket
 * @param {BasketPaymentInstrumentRequest} paymentInstrument Document representing a basket payment instrument request.
 * @returns {Status} new Status. Depends of hook execution OK/ERROR
 */
function beforePOST(basket, paymentInstrument) {
    const Resource = require('dw/web/Resource');

    const createBasketPaymentInstrumentHelper = require('~/cartridge/scripts/braintree/helpers/createBasketPaymentInstrumentHelper');
    const hooksHelper = require('~/cartridge/scripts/braintree/helpers/hooksHelper');
    const braintreeConstants = require('~/cartridge/scripts/util/braintreeConstants');

    const piErrorObject = {
        message: Resource.msg('braintree.ocapi.error.paymentinstrument.amount', 'locale', null)
    };

    try {
        if (paymentInstrument.amount === null || paymentInstrument.amount.get() === 0) {
            throw piErrorObject;
        }

        const customer = basket.customer;

        switch (paymentInstrument.paymentMethodId) {
            case braintreeConstants.PAYMENT_METHOD_ID_PAYPAL:
                createBasketPaymentInstrumentHelper.validatePayPalRequest(paymentInstrument, customer);
                break;
            case braintreeConstants.PAYMENT_METHOD_ID_GOOGLEPAY:
                createBasketPaymentInstrumentHelper.validateGooglePayRequest(paymentInstrument);
                break;
            case braintreeConstants.PAYMENT_METHOD_ID_APPLEPAY:
                createBasketPaymentInstrumentHelper.validateApplePayRequest(paymentInstrument);
                break;
            case braintreeConstants.PAYMENT_METHOD_ID_CREDIT_CARD:
                createBasketPaymentInstrumentHelper.validateCreditCardRequest(paymentInstrument, customer);
                break;
            case braintreeConstants.PAYMENT_METHOD_ID_SRC:
                createBasketPaymentInstrumentHelper.validateSrcRequest(paymentInstrument, customer);
                break;
            case braintreeConstants.PAYMENT_METHOD_ID_VENMO:
                createBasketPaymentInstrumentHelper.validateVenmoRequest(paymentInstrument, customer);
                break;
            // LPM
            default:
                createBasketPaymentInstrumentHelper.validateLpmRequest(paymentInstrument);
                break;
        }
    } catch (error) {
        return hooksHelper.createErrorStatus(error.message);
    }
}

exports.beforePOST = beforePOST;
