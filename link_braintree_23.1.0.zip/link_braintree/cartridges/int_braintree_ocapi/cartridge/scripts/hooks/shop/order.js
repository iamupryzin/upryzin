'use strict';

const Status = require('dw/system/Status');
const Order = require('dw/order/Order');
const OrderMgr = require('dw/order/OrderMgr');

const braintreeConstants = require('~/cartridge/scripts/util/braintreeConstants');

/**
 * Handles the failed order flow
 * @param {Object} error An error object
 * @param {dw.order.Order} order The order object
 * @returns {dw.system.Status} An error status for ocapi hook
 */
function handleFailedOrderFlow(error, order) {
    const paymentHelper = require('~/cartridge/scripts/braintree/helpers/paymentHelper');

    const message = error.errorMsg || error.message;
    const code = error.errorCode || braintreeConstants.CUSTOM_ERROR_TYPE;

    paymentHelper.getLogger().error(message);

    OrderMgr.failOrder(order, true);

    return new Status(Status.ERROR, code, message);
}

/**
 * handles the payment authorization for each payment instrument
 * @param {dw.order.Order} order The order object
 */
function handlePayments(order) {
    let braintreeProcessor;

    order.paymentInstruments.toArray().forEach(function (paymentInstrument) {
        switch (paymentInstrument.paymentMethod) {
            case braintreeConstants.PAYMENT_METHOD_ID_PAYPAL:
                braintreeProcessor = require('~/cartridge/scripts/braintree/payment/processor/braintreePayPal');
                break;
            case braintreeConstants.PAYMENT_METHOD_ID_GOOGLEPAY:
                braintreeProcessor = require('~/cartridge/scripts/braintree/payment/processor/braintreeGooglePay');
                break;
            case braintreeConstants.PAYMENT_METHOD_ID_APPLEPAY:
                braintreeProcessor = require('~/cartridge/scripts/braintree/payment/processor/braintreeApplePay');
                break;
            case braintreeConstants.PAYMENT_METHOD_ID_VENMO:
                braintreeProcessor = require('~/cartridge/scripts/braintree/payment/processor/braintreeVenmo');
                break;
            case braintreeConstants.PAYMENT_METHOD_ID_CREDIT_CARD:
                braintreeProcessor = require('~/cartridge/scripts/braintree/payment/processor/braintreeCredit');
                break;
            case braintreeConstants.PAYMENT_METHOD_ID_SRC:
                braintreeProcessor = require('~/cartridge/scripts/braintree/payment/processor/braintreeSrc');
                break;
            // LPM
            default:
                braintreeProcessor = require('~/cartridge/scripts/braintree/payment/processor/braintreeLpm');
                break;
        }

        // Handles the payment authorization for current payment method on the Braintree side
        braintreeProcessor.authorize(
            order,
            paymentInstrument
        );
    });
}

/**
 * The function is called after an order was created from the basket
 * The Hook authorize transaction on the Braintree side
 * @param {dw.order.Order} order A Current order
 * @returns {Status} new Status. Depends of hook execution OK/ERROR
 */
function afterPOST(order) {
    try {
        // Handles the payment authorization for each payment instrument on the Braintree side
        handlePayments(order);

        // Attempts to place the order
        const placeOrderStatus = OrderMgr.placeOrder(order);

        if (placeOrderStatus === Status.ERROR) {
            throw new Error();
        }

        order.setConfirmationStatus(Order.CONFIRMATION_STATUS_CONFIRMED);
        order.setExportStatus(Order.EXPORT_STATUS_READY);
    } catch (error) {
        return handleFailedOrderFlow(error, order);
    }
}

exports.afterPOST = afterPOST;
