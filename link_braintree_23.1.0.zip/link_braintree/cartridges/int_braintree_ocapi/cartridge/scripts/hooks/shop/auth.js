'use strict';

const hooksHelper = require('~/cartridge/scripts/braintree/helpers/hooksHelper');
const braintreeConstants = require('~/cartridge/scripts/util/braintreeConstants');

// Hook dw.ocapi.shop.auth.modifyPOSTResponse functionality

/**
 * Returns a specific account page config object
 * @returns {Object} A specific account page config object
 */
function getAccountPageConfigs() {
    const prefs = require('~/cartridge/config/braintreePreferences');
    const accountButtonConfigHelper = require('~/cartridge/scripts/braintree/helpers/accountButtonConfigHelper');

    return {
        paypal: {
            isPaypalVaultAllowed: prefs.vaultMode && !prefs.paypalOrderIntent,
            paypalAccountButtonConfig: accountButtonConfigHelper.createPaypalAccountButtonConfig()
        },
        venmo: {
            venmoAccountButtonConfig: accountButtonConfigHelper.createAccountVenmoButtonConfig()
        },
        hostedFieldsConfig: hooksHelper.createHostedFieldsConfig(prefs),
        accountSrcButtonConfig: accountButtonConfigHelper.createAccountSrcButtonConfig(),
        isCreditCardSavingAllowed: prefs.paymentMethods.BRAINTREE_CREDIT && prefs.paymentMethods.BRAINTREE_CREDIT.isActive && prefs.vaultMode && !prefs.is3DSecureEnabled,
        isSrcSavingAllowed: prefs.paymentMethods.BRAINTREE_SRC && prefs.paymentMethods.BRAINTREE_SRC.isActive && prefs.vaultMode
    };
}

/**
 * Returns a specific pdp page config object
 * @param {dw.customer.Customer} customer The auth customer
 * @param {Object} queryStringObject An object represent a query strings from request
 * @returns {Object} An object
 */
function getPdpPageConfigs(customer, queryStringObject) {
    const buttonConfigHelper = require('~/cartridge/scripts/braintree/helpers/buttonConfigHelper');
    const config = {
        paypalButtonConfig: buttonConfigHelper.createBraintreePayPalButtonConfig(null, queryStringObject.currentFlow, customer)
    };

    // The price value of current product on the Pdp page
    const price = hooksHelper.getPdpProductPrice(queryStringObject.productId);
    const salesPrice = price.sales;

    // Updates an amount value of PayPal options
    if (salesPrice) {
        config.paypalButtonConfig.options.amount = parseFloat(salesPrice.decimalPrice);
    }

    config.paypalButtonConfig.options.currency = queryStringObject.currencyCode;

    return config;
}

/**
 * Returns a general page config object
 * @param {Object} queryStringObject An object represent a query strings from request
 * @param {dw.customer.Customer} customer The auth customer
 * @returns {Object} A button config object
 */
function getBraintreeButtonsConfigForCurrentPage(queryStringObject, customer) {
    const btBusinessLogic = require('~/cartridge/scripts/braintree/braintreeAPI/braintreeBusinessLogic');

    let buttonConfigObject = {
        clientToken: btBusinessLogic.getClientToken(customer, queryStringObject.currencyCode)
    };

    if (queryStringObject.pageId === braintreeConstants.PAGE_FLOW_ACCOUNT) {
        buttonConfigObject = Object.assign(buttonConfigObject, getAccountPageConfigs());
    // Pdp page
    } else {
        buttonConfigObject = Object.assign(buttonConfigObject, getPdpPageConfigs(
            customer,
            queryStringObject
        ));
    }

    return buttonConfigObject;
}

/**
 * Modify post response by adding a 'BraintreePmButtonConfig' custom value to the customer
 * @param {dw.customer.Customer} customer The auth customer
 * @param {CustomerDocument} customerResponse Document representing a customer
 * @param {dw.value.EnumValue} authRequestType Auth request type enum
 */
function modifyPOSTResponse(customer, customerResponse, authRequestType) {
    const queryStringObject = hooksHelper.createObjectFromQueryString(request.httpQueryString.split('&'));
    const pageId = queryStringObject.pageId;
    // The following two variables define whether modifying of Post response is allowed
    const isGuestOnAccountPage = pageId === braintreeConstants.PAGE_FLOW_ACCOUNT && authRequestType.displayValue === braintreeConstants.AUTH_REQUEST_TYPE_GUEST;
    const isPageFlowAllowed = pageId === braintreeConstants.PAGE_FLOW_ACCOUNT || pageId === braintreeConstants.PAGE_FLOW_PDP;

    // Does not initiate a braintree buttons config in case whether user is unregistered on the 'account' page
    // or the current page is not 'account' or 'pdp'
    if (!isGuestOnAccountPage && isPageFlowAllowed) {
        try {
            customerResponse.c_braintreePmButtonsConfig = getBraintreeButtonsConfigForCurrentPage(queryStringObject, customer);
        } catch (error) {
            const paymentHelper = require('~/cartridge/scripts/braintree/helpers/paymentHelper');

            const errorMsg = error.errorMsg || error.message;
            const errCode = error.errorCode || braintreeConstants.CUSTOM_ERROR_TYPE;

            customerResponse.c_braintreePmButtonsConfig = {
                isObjectSetCorrectly: false,
                failedReason: {
                    message: errorMsg,
                    code: errCode
                }
            };

            paymentHelper.getLogger().error(errorMsg);
        }
    }
}

// Hook dw.ocapi.shop.auth.beforePOST functionality

/**
 * The function is called before the customer has been authenticated
 * Validates a 'pageId', 'currencyCode', 'productId' query strings of request
 * @returns {Status} new Status. Depends of hook execution OK/ERROR
 */
function beforePOST() {
    const Resource = require('dw/web/Resource');
    const validationHelper = require('~/cartridge/scripts/braintree/helpers/validationHelper');

    const queryStringObject = hooksHelper.createObjectFromQueryString();
    const pageId = queryStringObject.pageId;
    const isProductPageUsed = pageId === braintreeConstants.PAGE_FLOW_PDP;

    try {
        // Validates a 'pageId' query string
        if (!validationHelper.validateRequestStringValue(pageId)) {
            throw Resource.msg('braintree.ocapi.error.pageid.querystring.invalid', 'locale', null);
        }

        // Validates a 'currencyCode' query string
        if (isProductPageUsed || pageId === braintreeConstants.PAGE_FLOW_ACCOUNT) {
            validationHelper.validateRequestCurrencyCode(queryStringObject.currencyCode);
        }

        // Validates a 'productId' query string on the 'Pdp' page
        if (isProductPageUsed) {
            validationHelper.validateProductFromRequest(queryStringObject.productId);
        }
    } catch (error) {
        return hooksHelper.createErrorStatus(error);
    }
}

exports.beforePOST = beforePOST;
exports.modifyPOSTResponse = modifyPOSTResponse;
