'use strict';

const Status = require('dw/system/Status');
const Resource = require('dw/web/Resource');
const Logger = require('dw/system/Logger');

const braintreeConstants = require('~/cartridge/scripts/util/braintreeConstants');
const btBusinessLogic = require('~/cartridge/scripts/braintree/braintreeAPI/braintreeBusinessLogic');

const processorHelper = require('~/cartridge/scripts/braintree/payment/processor/processorHelper');

// Hook dw.ocapi.shop.customer.payment_instrument.beforeDELETE functionality

/**
 * The hook that performs the removal of a payment instrument on the Braintree side
 * @param {Object} customer the object which represents the current customer
 * @param {string} UUID the string which represents the current payment instrument
 * @returns {Object} returns an error object if there are no payment instruments in customer' wallet or an incorrect UUID is used
**/
function beforeDELETE(customer, UUID) {
    try {
        const paymentInstruments = customer.getProfile().getWallet().getPaymentInstruments();

        if (paymentInstruments.empty) {
            throw Resource.msg('no.payment.instrument.to.delete', 'error', null);
        }

        const paymentInstrumentsArray = paymentInstruments.toArray();
        const currentPaymentInstrument = paymentInstrumentsArray.filter(function (paymentInstrument) {
            return paymentInstrument.UUID === UUID;
        });

        if (empty(currentPaymentInstrument)) {
            throw Resource.msg('no.payment.instrument.with.current.UUID', 'error', null);
        }
        // Delete Payment Method from Braintree && Customer Payment Instruments
        btBusinessLogic.deletePaymentMethod(currentPaymentInstrument[0].creditCardToken);

        return new Status(Status.OK);
    } catch (error) {
        Logger.error(error);

        return new Status(Status.ERROR, braintreeConstants.CUSTOM_ERROR_TYPE, error);
    }
}

// Hook dw.ocapi.shop.customer.payment_instrument.afterPOST functionality

/**
 * The hook that performs the adding of a payment instrument on the Braintree side
 * @param {Object} customer the object which represents the current customer
 * @param {Object} paymentInstrument the object which represents the current payment instrument
 * @returns {Status} new Status. Depends of hook execution OK/ERROR
**/
function afterPOST(customer, paymentInstrument) {
    // In paymentInstrument object should be provided a special Payment Method Nonce we get from BT side -
    // for more information about Payment Method Nonces look here - https://developer.paypal.com/braintree/docs/guides/payment-method-nonces
    try {
        const braintreePaymentInstrumentCustomProperties = {
            braintreePaymentMethodNonce: paymentInstrument.c_braintreePaymentMethodNonce,
            braintreePaymentMethodAccount: paymentInstrument.c_braintreePaymentMethodAccount,
            braintreeDefaultCard: paymentInstrument.c_braintreeDefaultCard ? paymentInstrument.c_braintreeDefaultCard : null,
            braintreePaypalAccountAddresses: paymentInstrument.c_braintreePaypalAccountAddresses ? paymentInstrument.c_braintreePaypalAccountAddresses : null
        };

        const createPaymentMethodResponseData = btBusinessLogic.createPaymentMethodOnBraintreeSide(paymentInstrument.c_braintreePaymentMethodNonce);

        if (createPaymentMethodResponseData.error) {
            throw createPaymentMethodResponseData.error;
        }

        processorHelper.savePaymentInstrument(createPaymentMethodResponseData.paymentMethod, customer, braintreePaymentInstrumentCustomProperties);

        return new Status(Status.OK);
    } catch (error) {
        Logger.error(error);

        return new Status(Status.ERROR, braintreeConstants.CUSTOM_ERROR_TYPE, error);
    }
}

// dw.ocapi.shop.customer.payment_instrument.beforePOST functionality

/**
 * The hook which checks the payment instrument to see if it already exists in the wallet
 * @param {Object} customer the object which represents the current customer
 * @param {Object} paymentInstrument the object which represents the current payment instrument
 * @returns {Object} returns an error object if the same payment instrument already exists in the wallet
**/
function beforePOST(customer, paymentInstrument) {
    const CUSTOM_ERROR_TYPE = braintreeConstants.CUSTOM_ERROR_TYPE;
    const STATUS_ERROR = Status.ERROR;

    try {
        const paymentHelper = require('~/cartridge/scripts/braintree/helpers/paymentHelper');

        if (!paymentHelper.areRequiredFieldsFilled(paymentInstrument)) {
            const RequiredFieldsAreNotProvidedErrMsg = Resource.msg('required.fields.are.not.filled', 'error', null);

            Logger.error(RequiredFieldsAreNotProvidedErrMsg);

            return new Status(STATUS_ERROR, CUSTOM_ERROR_TYPE, RequiredFieldsAreNotProvidedErrMsg);
        }

        const instruments = customer.getProfile().getWallet().getPaymentInstruments();

        if (paymentHelper.isSavedPaymentMethod(instruments, paymentInstrument)) {
            const piAlreadyExistErrMsg = Resource.msg('payment.instrument.already.exist', 'error', null);

            Logger.error(piAlreadyExistErrMsg);

            return new Status(STATUS_ERROR, CUSTOM_ERROR_TYPE, piAlreadyExistErrMsg);
        }
    } catch (error) {
        Logger.error(error.message);

        return new Status(STATUS_ERROR, CUSTOM_ERROR_TYPE, error.message);
    }
}

exports.beforeDELETE = beforeDELETE;
exports.afterPOST = afterPOST;
exports.beforePOST = beforePOST;
