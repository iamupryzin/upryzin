'use strict';

const hooksHelper = require('~/cartridge/scripts/braintree/helpers/hooksHelper');
const braintreeConstants = require('~/cartridge/scripts/util/braintreeConstants');

// Hook dw.ocapi.shop.basket.afterPOST functionality

/**
 * Sets a default site shipping method to the default basket shipment
 * @param {dw.order.Basket} basket The current basket
 */
function setDefaultShippingMethod(basket) {
    const ShippingMgr = require('dw/order/ShippingMgr');

    basket.shipments[0].setShippingMethod(ShippingMgr.getDefaultShippingMethod());
}

/**
 * The function is called after the basket was created.
 * @param {dw.order.Basket} basket The current basket
 */
function afterPOST(basket) {
    setDefaultShippingMethod(basket);
}

// Hook dw.ocapi.shop.basket.modifyGETResponse functionality

/**
 * Returns a general  page config object
 * @param {Object} queryStringObject An object represent a query strings from request
 * @param {dw.order.Basket} basket The current basket
 * @returns {Object} A button config object
 */
function getBraintreeButtonsConfigForCurrentPage(queryStringObject, basket) {
    const addProductToBasketHelper = require('~/cartridge/scripts/braintree/helpers/addProductToBasketHelper');
    const btBusinessLogic = require('~/cartridge/scripts/braintree/braintreeAPI/braintreeBusinessLogic');

    const pageId = queryStringObject.pageId;

    let buttonConfigObject = {
        clientToken: btBusinessLogic.getClientToken(basket.customer, basket.currencyCode)
    };

    switch (pageId) {
        case braintreeConstants.PAGE_FLOW_CART:
            buttonConfigObject = Object.assign(buttonConfigObject, addProductToBasketHelper.getCartPageConfigs(basket, pageId));
            break;
        case braintreeConstants.PAGE_FLOW_MINICART:
            buttonConfigObject = Object.assign(buttonConfigObject, addProductToBasketHelper.getMiniCartPageConfigs(basket, pageId));
            break;
        case braintreeConstants.PAGE_FLOW_BILLING:
            buttonConfigObject = Object.assign(buttonConfigObject, addProductToBasketHelper.getCheckoutPageConfigs(basket, pageId));
            break;
        default:
            break;
    }

    // Indicates a correctly installed buttons configuration object
    buttonConfigObject.isObjectSetCorrectly = true;

    return buttonConfigObject;
}

/**
 * Modify post response by adding a 'BraintreePmButtonConfig' custom value to the basket response object
 * @param {dw.order.Basket} basket The target basket
 * @param {BasketDocument} basketResponse Basket response object
 */
function modifyGETResponse(basket, basketResponse) {
    const allowedPagesIdsArray = [
        braintreeConstants.PAGE_FLOW_CART,
        braintreeConstants.PAGE_FLOW_MINICART,
        braintreeConstants.PAGE_FLOW_BILLING
    ];
    const queryStringObject = hooksHelper.createObjectFromQueryString();
    const isModifyPostResponseAllowed = allowedPagesIdsArray.some(function (pageId) {
        return pageId === queryStringObject.pageId;
    });

    if (isModifyPostResponseAllowed) {
        try {
            basketResponse.c_braintreePmButtonsConfig = getBraintreeButtonsConfigForCurrentPage(queryStringObject, basket);
        } catch (error) {
            const paymentHelper = require('~/cartridge/scripts/braintree/helpers/paymentHelper');

            const errorMsg = error.errorMsg || error.message;
            const errCode = error.errorCode || braintreeConstants.CUSTOM_ERROR_TYPE;

            basketResponse.c_braintreePmButtonsConfig = {
                isObjectSetCorrectly: false,
                failedReason: {
                    message: errorMsg,
                    code: errCode
                }
            };

            paymentHelper.getLogger().error(errorMsg);
        }
    }
}

// Hook dw.ocapi.shop.basket.beforeGET functionality

/**
 * The function is called before the basket response had returned
 * Validates a pageId query string from request
 * @returns {Status} new Status. Depends of hook execution OK/ERROR
 */
function beforeGET() {
    const Resource = require('dw/web/Resource');
    const validationHelper = require('~/cartridge/scripts/braintree/helpers/validationHelper');

    // Validates a 'pageId' query string
    if (!validationHelper.validateRequestStringValue(hooksHelper.createObjectFromQueryString().pageId)) {
        return hooksHelper.createErrorStatus(
            Resource.msg('braintree.ocapi.error.addproducttocart.pageid.querystring.invalid', 'locale', null)
        );
    }
}

// Hook dw.ocapi.shop.basket.validateBasket functionality

/**
 * Validates whether a customer email exist in current basket, and add a flash in case if no
 * @param {BasketDocument} basketResponse The basket response to be validated
 */
function validateBasket(basketResponse) {
    const Resource = require('dw/web/Resource');
    // Initiates a custom 'CustomerEmailRequired' type to the flashes list
    if (!basketResponse.customerInfo.email) {
        basketResponse.addFlash({
            type: braintreeConstants.CUSTOMER_EMAIL_REQUIRED_FLASH_TYPE,
            message: Resource.msg('braintree.ocapi.flash.customeremailrequired.message', 'locale', null),
            path: braintreeConstants.CUSTOMER_EMAIL_REQUIRED_FLASH_PATH
        });
    }
}

exports.afterPOST = afterPOST;
exports.modifyGETResponse = modifyGETResponse;
exports.beforeGET = beforeGET;
exports.validateBasket = validateBasket;
