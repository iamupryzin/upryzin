'use strict';

/**
 * The function is called before setting of customer information for the basket
 * The hook validates an email address that is required for creating order with Braintree payment instrument
 * @param {dw.order.Basket} basket A current basket
 * @param {CustomerInfo} customerInfo Document representing information used to identify a customer
 * @returns {Status} new Status. Depends of hook execution OK/ERROR
 */
function beforePUT(basket, customerInfo) {
    const Resource = require('dw/web/Resource');

    const hooksHelper = require('~/cartridge/scripts/braintree/helpers/hooksHelper');
    const braintreeConstants = require('~/cartridge/scripts/util/braintreeConstants');

    const email = customerInfo.email;
    const EMAIL_PATTERN = braintreeConstants.EMAIL_PATTERN;

    let errorMessage;

    if (!email) {
        errorMessage = Resource.msg('braintree.ocapi.error.email.address.isrequired', 'locale', null);
    } else if (!EMAIL_PATTERN.test(email)) {
        errorMessage = Resource.msg('braintree.ocapi.error.email.address.not.valid', 'locale', null);
    }

    if (errorMessage) {
        return hooksHelper.createErrorStatus(errorMessage);
    }
}

exports.beforePUT = beforePUT;
