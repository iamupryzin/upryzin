'use strict';
/* global XML */

const xmlHelper = {};

/**
 * Parse XML into Object
 * @param {string} xmlStr XML string
 * @return {Object} Parsed object
 */
xmlHelper.parseXml = function (xmlStr) {
    const resultObj = {};

    const xmlObj = new XML(xmlStr);

    function formatNodeName(name) { // eslint-disable-line require-jsdoc
        const nameParts = name.split('-');

        for (let i = 1; i < nameParts.length; i++) {
            nameParts[i] = nameParts[i].charAt(0).toUpperCase() + nameParts[i].slice(1);
        }

        return nameParts.join('');
    }

    function parse(node, objectToParse) { // eslint-disable-line require-jsdoc
        const obj = objectToParse;
        const nodeName = formatNodeName(node.name().toString());

        const elements = node.elements();

        if (elements.length()) {
            const nodeType = node.attribute('type').toString();

            if (nodeType === 'array' || nodeType === 'collection') {
                obj[nodeName] = [];
                if (elements[0] && elements[0].hasSimpleContent() && nodeType !== 'collection') {
                    Object.values(elements).forEach(function (element) {
                        obj[nodeName].push(element.text().toString());
                    });
                } else {
                    Object.values(elements).forEach(function (element) {
                        parse(element, obj[nodeName]);
                    });
                }
            } else if (obj instanceof Array) {
                const objNew = {};

                obj.push(objNew);
                Object.values(elements).forEach(function (element) {
                    parse(element, objNew);
                });
            } else {
                obj[nodeName] = {};
                Object.values(elements).forEach(function (element) {
                    parse(element, obj[nodeName]);
                });
            }
        } else {
            obj[nodeName] = node.text().toString();
        }
    }

    parse(xmlObj, resultObj);
    return resultObj;
};

module.exports = xmlHelper;
