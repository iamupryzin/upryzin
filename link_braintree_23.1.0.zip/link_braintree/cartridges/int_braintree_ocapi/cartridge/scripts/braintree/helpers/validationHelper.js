'use strict';

const Resource = require('dw/web/Resource');

const validationHelper = {};

/**
 * Validates whether this value belongs to the string data type
 * @param {string} value we are checking
 * @returns {boolean} returns true if the current value belongs to the string data type
**/
validationHelper.validateRequestStringValue = function (value) {
    return value !== null && typeof value === 'string' && value.length !== 0;
};

/**
 * Validates whether this value belongs to the number data type
 * @param {number} value we are checking
 * @returns {boolean} returns true if the current value belongs to the number data type
**/
validationHelper.validateRequestNumberValue = function (value) {
    return value !== null && typeof value === 'number';
};

/**
 * Validates whether this value belongs to the boolean data type
 * @param {boolean} value we are checking
 * @returns {boolean} returns true if the current value belongs to the boolean data type
**/
validationHelper.validateRequestBooleanValue = function (value) {
    return value !== null && typeof value === 'boolean';
};

/**
 * Validates an orderAddress document from Ocapi call
 * @param {OrderAddress} address Document representing an order address.
 * @returns {boolean} true/false
 */
validationHelper.validateOrderAddress = function (address) {
    return validationHelper.validateRequestStringValue(address.firstName) &&
        validationHelper.validateRequestStringValue(address.lastName) &&
        validationHelper.validateRequestStringValue(address.address1) &&
        validationHelper.validateRequestStringValue(address.city) &&
        validationHelper.validateRequestStringValue(address.countryCode) &&
        validationHelper.validateRequestStringValue(address.phone) &&
        validationHelper.validateRequestStringValue(address.postalCode) &&
        validationHelper.validateRequestStringValue(address.stateCode);
};

/**
 * Validates a currency code value
 * @param {string} currencyCode A currency code
 */
validationHelper.validateRequestCurrencyCode = function (currencyCode) {
    const currentSite = require('dw/system/Site').current;

    if (!validationHelper.validateRequestStringValue(currencyCode)) {
        throw Resource.msg('braintree.ocapi.error.currencyCode.querystring.invalid', 'locale', null);
    }

    const isCurrencyAllowed = currentSite.allowedCurrencies.toArray().some(function (allowedCurrency) {
        return allowedCurrency === currencyCode;
    });

    if (!isCurrencyAllowed) {
        throw Resource.msgf('braintree.ocapi.error.currencyCode.notallowed', 'locale', null, currencyCode);
    }
};

/**
 * Validates a product item from request
 * @param {string} productId The product id
 */
validationHelper.validateProductFromRequest = function (productId) {
    if (!validationHelper.validateRequestStringValue(productId)) {
        throw Resource.msg('braintree.ocapi.error.productid.value.invalid', 'locale', null);
    }

    const ProductMgr = require('dw/catalog/ProductMgr');
    const product = ProductMgr.getProduct(productId);

    if (!product) {
        throw Resource.msgf('braintree.ocapi.error.product.notexist', 'locale', null, productId);
    }
};

module.exports = validationHelper;
