'use strict';

const validationHelper = require('~/cartridge/scripts/braintree/helpers/validationHelper');
const customerHelper = require('~/cartridge/scripts/braintree/helpers/customerHelper');

const paymentInstrumentValidationHelper = {};

/**
 * Validates braintreePaymentMethodAccount
 * @param {Object} customerResponse the object which represents the current customerResponse
 * @returns {boolean} returns true if the current customerResponse contains correct braintreePaymentMethodAccount property
**/
paymentInstrumentValidationHelper.validateBraintreePaymentMethodAccount = function (customerResponse) {
    const braintreePaymentMethodAccount = customerResponse.c_braintreePaymentMethodAccount || null;

    return validationHelper.validateRequestStringValue(braintreePaymentMethodAccount);
};

/**
 * Validates braintreePaymentMethodNonce
 * @param {Object} customerResponse the object which represents the current customerResponse
 * @returns {boolean} returns true if the current customerResponse contains correct braintreePaymentMethodNonce property
**/
paymentInstrumentValidationHelper.validateBraintreePaymentMethodNonce = function (customerResponse) {
    const braintreePaymentMethodNonce = customerResponse.c_braintreePaymentMethodNonce || null;

    return validationHelper.validateRequestStringValue(braintreePaymentMethodNonce);
};

/**
 * Validates braintreePayPalEmail
 * @param {BasketPaymentInstrumentRequest} paymentInstrument Document representing a basket payment instrument request
 * @returns {boolean} returns true if the current basketResponse contains correct braintreePayPalEmail property
**/
paymentInstrumentValidationHelper.validateBraintreePayPalEmail = function (paymentInstrument) {
    const braintreeConstants = require('~/cartridge/scripts/util/braintreeConstants');
    const braintreePayPalEmail = paymentInstrument.c_braintreePaypalEmail || null;

    return validationHelper.validateRequestStringValue(braintreePayPalEmail) && braintreeConstants.EMAIL_PATTERN.test(braintreePayPalEmail);
};

/**
 * Validates braintreeFraudRiskData
 * @param {BasketPaymentInstrumentRequest} paymentInstrument Document representing a basket payment instrument request
 * @returns {boolean} returns true if the current basketResponse contains correct braintreeFraudRiskData property
**/
paymentInstrumentValidationHelper.validateBraintreeFraudRiskData = function (paymentInstrument) {
    const braintreeFraudRiskData = paymentInstrument.c_braintreeFraudRiskData || null;

    return validationHelper.validateRequestStringValue(braintreeFraudRiskData);
};

/**
 * Validates payPalFundingSource
 * @param {BasketPaymentInstrumentRequest} paymentInstrument Document representing a basket payment instrument request
 * @returns {boolean} returns true if the current basketResponse contains correct payPalFundingSource property
**/
paymentInstrumentValidationHelper.validatePayPalFundingSource = function (paymentInstrument) {
    const payPalFundingSource = paymentInstrument.c_payPalFundingSource || null;

    return validationHelper.validateRequestStringValue(payPalFundingSource);
};

/**
 * Validates creditToken
 * @param {BasketPaymentInstrumentRequest} paymentInstrument Document representing a basket payment instrument request
 * @param {dw.customer.Customer} customer A customer object
 * @returns {boolean} returns true if the current basketResponse.paymentCard contains correct creditToken property
**/
paymentInstrumentValidationHelper.validateCreditToken = function (paymentInstrument, customer) {
    const creditToken = paymentInstrument.paymentCard.creditCardToken || null;

    if (validationHelper.validateRequestStringValue(creditToken)) {
        const customerPaymentInstruments = customerHelper.getCustomerPaymentInstruments(paymentInstrument.paymentMethodId, customer);

        // Checks if exist a payment instrument with current 'CreditCardToken'
        return customerPaymentInstruments.toArray().some(function (pi) {
            return pi.creditCardToken === creditToken;
        });
    }

    return false;
};

/**
 * Validates braintreeSaveCreditCard
 * @param {BasketPaymentInstrumentRequest} paymentInstrument Document representing a basket payment instrument request
 * @returns {boolean} returns true if the current basketResponse contains correct braintreeSaveCreditCard property
**/
paymentInstrumentValidationHelper.validateBraintreeSaveCreditCard = function (paymentInstrument) {
    const braintreeSaveCreditCard = paymentInstrument.c_braintreeSaveCreditCard;

    return validationHelper.validateRequestBooleanValue(braintreeSaveCreditCard);
};

/**
 * Validates braintreePaymentMethodNonce
 * @param {BasketPaymentInstrumentRequest} paymentInstrument Document representing a basket payment instrument request
 * @returns {boolean} returns true if the current basketResponse contains correct braintreePaymentMethodNonce property
**/
paymentInstrumentValidationHelper.validateBraintreePaymentMethodNonce = function (paymentInstrument) {
    const braintreePaymentMethodNonce = paymentInstrument.c_braintreePaymentMethodNonce || null;

    return validationHelper.validateRequestStringValue(braintreePaymentMethodNonce);
};

/**
 * Validates googlePayDescription
 * @param {BasketPaymentInstrumentRequest} paymentInstrument Document representing a basket payment instrument request
 * @returns {boolean} returns true if the current basketResponse contains correct googlePayDescription property
**/
paymentInstrumentValidationHelper.validateGooglePayDescription = function (paymentInstrument) {
    const googlePayDescription = paymentInstrument.c_braintreeGooglePayCardDescription;

    return validationHelper.validateRequestStringValue(googlePayDescription);
};

/**
 * Validates BraintreeGooglePayPaymentType
 * @param {BasketPaymentInstrumentRequest} paymentInstrument Document representing a basket payment instrument request
 * @returns {boolean} returns true if the current basketResponse contains correct BraintreeGooglePayPaymentType property
**/
paymentInstrumentValidationHelper.validateBraintreeGooglepayPaymentType = function (paymentInstrument) {
    const braintreeGooglepayPaymentType = paymentInstrument.c_braintreeGooglepayPaymentType;

    return validationHelper.validateRequestStringValue(braintreeGooglepayPaymentType);
};

/**
 * Validates creditCardType
 * @param {BasketPaymentInstrumentRequest} paymentInstrument Document representing a basket payment instrument request
 * @returns {boolean} returns true if the current basketResponse.paymentCard contains correct creditCardType property
**/
paymentInstrumentValidationHelper.validateCreditCardType = function (paymentInstrument) {
    const creditCardType = paymentInstrument.paymentCard.cardType || null;

    return validationHelper.validateRequestStringValue(creditCardType);
};

/**
 * Validates creditCardNumber
 * @param {BasketPaymentInstrumentRequest} paymentInstrument Document representing a basket payment instrument request
 * @returns {boolean} returns true if the current basketResponse.paymentCard contains correct creditCardNumber property
**/
paymentInstrumentValidationHelper.validateCreditCardNumber = function (paymentInstrument) {
    const creditCardNumber = paymentInstrument.paymentCard.number || null;

    return validationHelper.validateRequestStringValue(creditCardNumber);
};

/**
 * Validates creditCardHolder
 * @param {BasketPaymentInstrumentRequest} paymentInstrument Document representing a basket payment instrument request
 * @returns {boolean} returns true if the current basketResponse.paymentCard contains correct creditCardHolder property
**/
paymentInstrumentValidationHelper.validateCreditCardHolder = function (paymentInstrument) {
    const creditCardHolder = paymentInstrument.paymentCard.holder || null;

    return validationHelper.validateRequestStringValue(creditCardHolder);
};

/**
 * Validates creditCardExpirationMonth
 * @param {BasketPaymentInstrumentRequest} paymentInstrument Document representing a basket payment instrument request
 * @returns {boolean} returns true if the current basketResponse.paymentCard contains correct creditCardExpirationMonth property
**/
paymentInstrumentValidationHelper.validateCreditCardExpirationMonth = function (paymentInstrument) {
    const creditCardExpirationMonth = paymentInstrument.paymentCard.expirationMonth || null;

    return validationHelper.validateRequestNumberValue(creditCardExpirationMonth);
};

/**
 * Validates creditCardExpirationYear
 * @param {BasketPaymentInstrumentRequest} paymentInstrument Document representing a basket payment instrument request
 * @returns {boolean} returns true if the current basketResponse.paymentCard contains correct creditCardExpirationYear property
**/
paymentInstrumentValidationHelper.validateCreditCardExpirationYear = function (paymentInstrument) {
    const creditCardExpirationYear = paymentInstrument.paymentCard.expirationYear || null;

    return validationHelper.validateRequestNumberValue(creditCardExpirationYear);
};

/**
 * Validates braintreeSrcCardDescription
 * @param {BasketPaymentInstrumentRequest} paymentInstrument Document representing a basket payment instrument request
 * @returns {boolean} returns true if the current basketResponse contains correct braintreeSrcCardDescription property
**/
paymentInstrumentValidationHelper.validateBraintreeSrcCardDescription = function (paymentInstrument) {
    const braintreeSrcCardDescription = paymentInstrument.c_braintreeSrcCardDescription || null;

    return validationHelper.validateRequestStringValue(braintreeSrcCardDescription);
};

module.exports = paymentInstrumentValidationHelper;
