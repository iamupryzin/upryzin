'use strict';

const hooksHelper = {};

/**
 * Returns an object from request query strings
 * @returns {Object} An object
 */
hooksHelper.createObjectFromQueryString = function () {
    const resultObj = {};

    if (request.httpQueryString !== null) {
        request.httpQueryString.split('&').forEach(function (queryParam) {
            const queryParamArray = queryParam.split('=');

            resultObj[queryParamArray[0]] = queryParamArray[1];
        });
    }

    return resultObj;
};

/**
* Creates config for hosted fields
* @param {Object} prefs A braintree preferences object
* @returns {Object} configuration object
*/
hooksHelper.createHostedFieldsConfig = function (prefs) {
    const Resource = require('dw/web/Resource');

    return {
        paymentMethodName: prefs.paymentMethods.BRAINTREE_CREDIT.paymentMethodId,
        is3dSecureEnabled: prefs.is3DSecureEnabled,
        isFraudToolsEnabled: prefs.isFraudToolsEnabled,
        isSkip3dSecureLiabilityResult: prefs.is3DSecureSkipClientValidationResult,
        messages: {
            validation: Resource.msg('braintree.ocapi.creditcard.error.validation', 'locale', null),
            secure3DFailed: Resource.msg('braintree.ocapi.creditcard.error.secure3DFailed', 'locale', null),
            HOSTED_FIELDS_FIELDS_EMPTY: Resource.msg('braintree.ocapi.creditcard.error.HOSTED_FIELDS_FIELDS_EMPTY', 'locale', null),
            HOSTED_FIELDS_FIELDS_INVALID: Resource.msg('braintree.ocapi.creditcard.error.HOSTED_FIELDS_FIELDS_INVALID', 'locale', null),
            HOSTED_FIELDS_FAILED_TOKENIZATION: Resource.msg('braintree.ocapi.creditcard.error.HOSTED_FIELDS_FAILED_TOKENIZATION', 'locale', null),
            HOSTED_FIELDS_TOKENIZATION_NETWORK_ERROR: Resource.msg('braintree.ocapi.creditcard.error.HOSTED_FIELDS_TOKENIZATION_NETWORK_ERROR', 'locale', null),
            CLIENT_REQUEST_TIMEOUT: Resource.msg('braintree.ocapi.error.CLIENT_REQUEST_TIMEOUT', 'locale', null),
            CLIENT_GATEWAY_NETWORK: Resource.msg('braintree.ocapi.error.CLIENT_GATEWAY_NETWORK', 'locale', null),
            CLIENT_REQUEST_ERROR: Resource.msg('braintree.ocapi.error.CLIENT_REQUEST_ERROR', 'locale', null),
            CLIENT_MISSING_GATEWAY_CONFIGURATION: Resource.msg('braintree.ocapi.error.CLIENT_MISSING_GATEWAY_CONFIGURATION', 'locale', null)
        },
        amount: 1,
        customMessages: {
            CARD_ALREADY_EXIST_ERROR_MESSAGE: Resource.msg('braintree.ocapi.account.error.existentCard', 'locale', null)
        }
    };
};

/**
 * Returns product's price object
 * @param {string} productId The product id
 * @return {TieredPrice|RangePrice|DefaultPrice} - The product's price
 */
hooksHelper.getPdpProductPrice = function (productId) {
    const ProductMgr = require('dw/catalog/ProductMgr');
    const PromotionMgr = require('dw/campaign/PromotionMgr');

    const priceHelper = require('~/cartridge/scripts/braintree/helpers/priceHelper');
    const product = ProductMgr.getProduct(productId);
    const promotions = PromotionMgr.activeCustomerPromotions.getProductPromotions(product);
    const optionModel = product.optionModel;

    return priceHelper.getProductPrice(product, false, promotions, optionModel);
};

/**
 * Creates a status object for failed OCAPI flow
 * @param {Object|string} error An error
 * @returns {Status} new Status - ERROR
 */
hooksHelper.createErrorStatus = function (error) {
    const Status = require('dw/system/Status');

    const paymentHelper = require('~/cartridge/scripts/braintree/helpers/paymentHelper');
    const braintreeConstants = require('~/cartridge/scripts/util/braintreeConstants');

    const message = error.errorMsg || error;
    const code = error.errorCode || braintreeConstants.CUSTOM_ERROR_TYPE;

    paymentHelper.getLogger().error(message);

    return new Status(Status.ERROR, code, message);
};

module.exports = hooksHelper;
