'use strict';

const Site = require('dw/system/Site');
const Resource = require('dw/web/Resource');

const prefs = require('~/cartridge/config/braintreePreferences');
const paymentHelper = require('~/cartridge/scripts/braintree/helpers/paymentHelper');

const braintreeConstants = require('~/cartridge/scripts/util/braintreeConstants');

// Generall error messages for all buttons
const errorMessages = {
    CLIENT_REQUEST_TIMEOUT: Resource.msg('braintree.ocapi.error.CLIENT_REQUEST_TIMEOUT', 'locale', null),
    CLIENT_GATEWAY_NETWORK: Resource.msg('braintree.ocapi.error.CLIENT_GATEWAY_NETWORK', 'locale', null),
    CLIENT_REQUEST_ERROR: Resource.msg('braintree.ocapi.error.CLIENT_REQUEST_ERROR', 'locale', null),
    CLIENT_MISSING_GATEWAY_CONFIGURATION: Resource.msg('braintree.ocapi.error.CLIENT_MISSING_GATEWAY_CONFIGURATION', 'locale', null)
};

const buttonConfigHelper = {};

/**
 * Returns the type of the instance(TEST/PRODUCTION)
 * @returns {string} The type of the instance
 */
function getInstanceType() {
    const dwSystem = require('dw/system/System');
    const systemInstanceType = dwSystem.getInstanceType();

    let instanceType = '';

    if (systemInstanceType === dwSystem.PRODUCTION_SYSTEM) {
        instanceType = braintreeConstants.PRODUCTION_SYSTEM_TYPE;
    } else {
        instanceType = braintreeConstants.DEVELOPMENT_SYSTEM_TYPE;
    }

    return instanceType;
}

/**
 * Returns configuration style object for paypal button
 * @param {string} pageFlow Name of flow that called the method
 * @returns {Object} Style configuration object
 */
function getPaypalButtonStyleConfigs(pageFlow) {
    let styleConfigs;

    switch (pageFlow) {
        case braintreeConstants.PAGE_FLOW_PDP:
            styleConfigs = prefs.paypalPdpButtonConfig;
            break;
        case braintreeConstants.PAGE_FLOW_CART:
            styleConfigs = prefs.paypalCartButtonConfig;
            break;
        case braintreeConstants.PAGE_FLOW_MINICART:
            styleConfigs = prefs.paypalMiniCartButtonConfig;
            break;
        default:
            styleConfigs = prefs.paypalBillingButtonConfig;
            break;
    }

    return styleConfigs;
}

/**
 * Returns general 'pdp' button config object for all payment methods
 * @param {dw.customer.Customer} customer Customer object
 * @returns {Object} Button config object
 */
function getGeneralPdpConfig(customer) {
    return {
        messages: errorMessages,
        isBuyerAuthenticated: customer.isAuthenticated(),
        options: {
            amount: 0
        }
    };
}

/**
 * Creates general button config object for all payment methods
 * @param {Basket} basket Basket object
 * @returns {Object} Button config object
 */
buttonConfigHelper.createGeneralButtonConfig = function (basket) {
    const amount = paymentHelper.getAmountPaid(basket);

    return {
        messages: errorMessages,
        options: {
            amount: parseFloat(amount.getValue()),
            currency: amount.valueOrNull === null ? request.session.currency.currencyCode : amount.getCurrencyCode()
        },
        isBuyerAuthenticated: basket.customer.isAuthenticated()
    };
};

/**
* Creates config button object for paypal
* @param {dw.order.Basket} basket Basket Object
* @param {string} currentFlow Name of flow that called the method
* @param {dw.customer.Customer} customer The auth customer
* @returns {Object} button config object
*/
buttonConfigHelper.createBraintreePayPalButtonConfig = function (basket, currentFlow, customer) {
    const enableFundingList = prefs.enableFundingList;
    const disableFundingList = prefs.disableFundingList;
    const vaultModeEnabled = prefs.vaultMode;
    const paypalMessages = {
        PAYPAL_ACCOUNT_TOKENIZATION_FAILED: Resource.msg('braintree.ocapi.error.PAYPAL_ACCOUNT_TOKENIZATION_FAILED', 'locale', null),
        PAYPAL_INVALID_PAYMENT_OPTION: Resource.msg('braintree.ocapi.error.PAYPAL_INVALID_PAYMENT_OPTION', 'locale', null),
        PAYPAL_FLOW_FAILED: Resource.msg('braintree.ocapi.error.PAYPAL_FLOW_FAILED', 'locale', null),
        PAYPAL_BROWSER_NOT_SUPPORTED: Resource.msg('braintree.ocapi.error.PAYPAL_BROWSER_NOT_SUPPORTED', 'locale', null),
        PAYPAL_BILLING_ADDRESS_NOT_SUPPORTED: Resource.msg('braintree.ocapi.error.PAYPAL_BILLING_ADDRESS_NOT_SUPPORTED', 'locale', null),
        CUSTOM_PAYPAL_ZERO_AMOUNT_ERROR: Resource.msg('braintree.ocapi.error.CUSTOM_PAYPAL_ZERO_AMOUNT_ERROR', 'locale', null)
    };
    const paymentSpecificConfigs = {
        paymentMethodName: prefs.paymentMethods.BRAINTREE_PAYPAL.paymentMethodId,
        paypalConfig: getPaypalButtonStyleConfigs(currentFlow),
        isFraudToolsEnabled: prefs.isPaypalFraudToolsEnabled,
        vaultModeEnabled: vaultModeEnabled
    };
    const braintreePaypalButtonConfig = customer ? getGeneralPdpConfig(customer) :
        buttonConfigHelper.createGeneralButtonConfig(basket);

    let flow = braintreeConstants.FLOW_CHECKOUT;
    let intent = prefs.paypalIntent;

    if (vaultModeEnabled) {
        flow = braintreeConstants.FLOW_VAULT;
    }

    if (prefs.paypalOrderIntent) {
        intent = braintreeConstants.INTENT_TYPE_ORDER;
        flow = braintreeConstants.FLOW_CHECKOUT;
    }

    const paypalOptions = {
        flow: flow,
        intent: intent,
        locale: Site.getCurrent().getDefaultLocale(),
        enableShippingAddress: true,
        billingAgreementDescription: empty(prefs.paypalBillingAgreementDescription) ? '' : prefs.paypalBillingAgreementDescription,
        displayName: empty(prefs.paypalDisplayName) ? '' : prefs.paypalDisplayName
    };

    if (!empty(enableFundingList)) {
        paypalOptions.enableFundingList = enableFundingList.join(',');
    }

    if (!empty(disableFundingList)) {
        paypalOptions.disableFundingList = disableFundingList.join(',');
    }

    Object.keys(paymentSpecificConfigs).forEach(function (key) {
        braintreePaypalButtonConfig[key] = paymentSpecificConfigs[key];
    });

    // Sets PayPal related messages
    Object.keys(paypalMessages).forEach(function (key) {
        braintreePaypalButtonConfig.messages[key] = paypalMessages[key];
    });

    // Sets PayPal related options
    Object.keys(paypalOptions).forEach(function (key) {
        braintreePaypalButtonConfig.options[key] = paypalOptions[key];
    });

    if (prefs.isSettle && !prefs.paypalOrderIntent) {
        braintreePaypalButtonConfig.options.useraction = braintreeConstants.BUTTON_CONFIG_OPTIONS_USERACTION_COMMIT;
    }

    if (currentFlow !== braintreeConstants.PAGE_FLOW_BILLING) {
        braintreePaypalButtonConfig.options.style = {
            layout: braintreeConstants.BUTTON_CONFIG_OPTIONS_STYLE_LAYOUT_HORIZONTAL,
            label: braintreeConstants.BUTTON_CONFIG_PAYPAL,
            maxbuttons: 1,
            fundingicons: false,
            shape: braintreeConstants.BUTTON_CONFIG_OPTIONS_STYLE_SHAPE_RECT,
            size: braintreeConstants.BUTTON_CONFIG_OPTIONS_STYLE_SIZE_MEDIUM,
            tagline: false
        };
    }

    return braintreePaypalButtonConfig;
};

/**
* Creates config button object for Apple Pay
* @param {Basket} basket Basket object
* @param {string} currentFlow Name of flow that called the method
* @returns {Object} button config object
*/
buttonConfigHelper.createBraintreeApplePayButtonConfig = function (basket, currentFlow) {
    const applePayButtonConfig = buttonConfigHelper.createGeneralButtonConfig(basket);
    const paymentSpecificConfigs = {
        paymentMethodName: prefs.paymentMethods.BRAINTREE_APPLEPAY.paymentMethodId,
        isFraudToolsEnabled: prefs.isPaypalFraudToolsEnabled,
        isRequiredBillingContactFields: true,
        isRequiredShippingContactFields: currentFlow === braintreeConstants.PAGE_FLOW_CART
    };

    Object.keys(paymentSpecificConfigs).forEach(function (key) {
        applePayButtonConfig[key] = paymentSpecificConfigs[key];
    });

    applePayButtonConfig.options.displayName = prefs.applepayDisplayName;

    return applePayButtonConfig;
};

/**
* Creates config button object for Venmo
* @param {Basket} basket Basket object
* @returns {Object} button config object
*/
buttonConfigHelper.createBraintreeVenmoButtonConfig = function (basket) {
    const venmoButtonConfig = buttonConfigHelper.createGeneralButtonConfig(basket);

    venmoButtonConfig.paymentMethodName = prefs.paymentMethods.BRAINTREE_VENMO.paymentMethodId;
    venmoButtonConfig.options.displayName = prefs.venmoDisplayName;

    const venmoMessages = {
        VENMO_ZERO_AMOUNT_ERROR: Resource.msg('braintree.ocapi.error.VENMO_ZERO_AMOUNT_ERROR', 'locale', null)
    };

    Object.keys(venmoMessages).forEach(function (key) {
        venmoButtonConfig.messages[key] = venmoMessages[key];
    });

    return venmoButtonConfig;
};

/**
* Creates config button object for LPM
* @param {Basket} basket Basket object
* @returns {Object} button config object
*/
buttonConfigHelper.createBraintreeLocalPaymentMethodButtonConfig = function (basket) {
    const localPaymentMethodButtonConfig = buttonConfigHelper.createGeneralButtonConfig(basket);
    const paymentSpecificConfigs = {
        paymentMethodName: prefs.paymentMethods.BRAINTREE_LOCAL.paymentMethodIds
    };

    Object.keys(paymentSpecificConfigs).forEach(function (key) {
        localPaymentMethodButtonConfig[key] = paymentSpecificConfigs[key];
    });

    localPaymentMethodButtonConfig.options.displayName = '';

    return localPaymentMethodButtonConfig;
};

/**
* Creates config button object for Google Pay
* @param {Basket} basket Basket object
* @param {string} currentFlow Name of flow that called the method
* @returns {Object} button config object
*/
buttonConfigHelper.createBraintreeGooglePayButtonConfig = function (basket, currentFlow) {
    const googlepayButtonConfig = buttonConfigHelper.createGeneralButtonConfig(basket);
    const paymentSpecificConfigs = {
        paymentMethodName: prefs.paymentMethods.BRAINTREE_GOOGLEPAY.paymentMethodId,
        isFraudToolsEnabled: prefs.isFraudToolsEnabled,
        googleMerchantId: prefs.googleMerchantId,
        instanceType: getInstanceType()
    };
    const googlePayOptions = {
        displayName: prefs.googlepayDisplayName,
        isShippingAddressRequired: currentFlow === braintreeConstants.PAGE_FLOW_CART
    };

    Object.keys(paymentSpecificConfigs).forEach(function (key) {
        googlepayButtonConfig[key] = paymentSpecificConfigs[key];
    });

    Object.keys(googlePayOptions).forEach(function (key) {
        googlepayButtonConfig.options[key] = googlePayOptions[key];
    });

    return googlepayButtonConfig;
};

/**
* Creates config button object for SRC
* @param {Basket} basket Basket object
* @param {string} currentFlow Name of flow that called the method
* @returns {Object} button config object
*/
buttonConfigHelper.createBraintreeSrcButtonConfig = function (basket, currentFlow) {
    const srcButtonConfig = buttonConfigHelper.createGeneralButtonConfig(basket);
    const buttonSettings = currentFlow !== braintreeConstants.PAGE_FLOW_BILLING ?
        prefs.SRCCartButtonConfig : prefs.SRCBillingButtonConfig;
    const srcMessages = {
        CUSTOM_SRC_ZERO_AMOUNT_ERROR: Resource.msg('braintree.ocapi.error.CUSTOM_SRC_ZERO_AMOUNT_ERROR', 'locale', null)
    };

    Object.keys(srcMessages).forEach(function (key) {
        srcButtonConfig.messages[key] = srcMessages[key];
    });

    const paymentSpecificConfigs = {
        paymentMethodName: prefs.paymentMethods.BRAINTREE_SRC.paymentMethodId,
        isFraudToolsEnabled: prefs.isFraudToolsEnabled,
        SRCImageUrl: paymentHelper.createSRCImageUrl(prefs.SRCImageLink, buttonSettings),
        settings: buttonSettings
    };

    Object.keys(paymentSpecificConfigs).forEach(function (key) {
        srcButtonConfig[key] = paymentSpecificConfigs[key];
    });

    srcButtonConfig.options.isShippingAddressRequired = currentFlow === braintreeConstants.PAGE_FLOW_CART;

    if (currentFlow === braintreeConstants.PAGE_FLOW_CART) {
        srcButtonConfig.options.displayName = prefs.srcDisplayName;
    }

    return srcButtonConfig;
};

module.exports = buttonConfigHelper;
