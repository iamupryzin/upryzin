'use strict';

const Transaction = require('dw/system/Transaction');
const Logger = require('dw/system/Logger');
const Resource = require('dw/web/Resource');
const Money = require('dw/value/Money');
const PaymentMgr = require('dw/order/PaymentMgr');
const StringUtils = require('dw/util/StringUtils');

const braintreeConstants = require('~/cartridge/scripts/util/braintreeConstants');
const paymentInstrumentValidationHelper = require('~/cartridge/scripts/braintree/helpers/paymentInstrumentValidationHelper');

const paymentHelper = {};


const allowedProcessorsIds = [
    braintreeConstants.PAYMENT_PROCCESSOR_ID_BRAINTREE_CREDIT,
    braintreeConstants.PAYMENT_PROCCESSOR_ID_BRAINTREE_PAYPAL,
    braintreeConstants.PAYMENT_PROCCESSOR_ID_BRAINTREE_APPLEPAY,
    braintreeConstants.PAYMENT_PROCCESSOR_ID_BRAINTREE_VENMO,
    braintreeConstants.PAYMENT_PROCCESSOR_ID_BRAINTREE_SRC,
    braintreeConstants.PAYMENT_PROCCESSOR_ID_BRAINTREE_LOCAL,
    braintreeConstants.PAYMENT_PROCCESSOR_ID_BRAINTREE_GOOGLEPAY
];

/**
 * Search in array for an object with passed key/value in properties
 * @param {Array} array with objects
 * @param {Object} properties object with key/value based on which search in array will be performed
 * @returns {Object} return found object or null
 */
function getObjectAndIndexFromArrayByProp(array, properties) {
    let object = null;
    let flag = true;

    array.forEach(function (element) {
        let elementFound = true;

        Object.keys(properties).forEach(function (prop) {
            if (element[prop] !== properties[prop]) {
                elementFound = false;
            }
        });

        if (elementFound && flag) {
            object = element;
            flag = false;
        }
    });

    return object;
}

/**
 * Returns array without duplicating of credit cards
 * @param {Arrya} arrToFilter array which will be filtered
 * @param {Arrya} allowedProcessorIds array with credit card processors
 * @param {Function} callbackOnDuplicate callback which will be executed on duplicate was found
 * @returns {Array} returns array without duplicates
 */
function getArrayWithoutRepitableCards(arrToFilter, allowedProcessorIds, callbackOnDuplicate) {
    const filteredArray = [];

    arrToFilter.forEach(function (paymentInstrument) {
        if (allowedProcessorIds.indexOf(paymentInstrument.paymentMethod) !== -1) {
            const creditCardIdentifiers = {
                creditCardType: paymentInstrument.creditCardType,
                creditCardNumberLastDigits: paymentInstrument.creditCardNumberLastDigits
            };
            const instrumentFromFilteredArray = getObjectAndIndexFromArrayByProp(filteredArray, creditCardIdentifiers);

            if (instrumentFromFilteredArray) {
                if (callbackOnDuplicate) {
                    callbackOnDuplicate(paymentInstrument, instrumentFromFilteredArray);
                }
            } else {
                filteredArray.push(paymentInstrument);
            }
        }
    });

    return filteredArray;
}

/**
 * Return an object with merchant accounts from the BRAINTREE_Merchant_Account_IDs site pref
 * @param {Object} merchantAccountIDs Set of strings value of the BRAINTREE_Merchant_Account_IDs site pref
 * @returns {Object} An Object contains merchant accounts
 */
function createMerchantAccountsObject(merchantAccountIDs) {
    let fieldArr;

    return Object.keys(merchantAccountIDs).reduce(function (acum, curr) {
        fieldArr = merchantAccountIDs[curr].split(':');
        acum[fieldArr[0].toUpperCase()] = fieldArr[1];

        return acum;
    }, {});
}

/**
 * Creates or get logger
 *
 * @returns {Object} Object with logger for API operation
 */
paymentHelper.getLogger = function () {
    const prefs = require('~/cartridge/config/braintreePreferences');
    const errorMode = prefs.loggingMode !== 'none' && prefs.loggingMode;
    const logger = Logger.getLogger('Braintree', 'Braintree_General');

    return {
        error: function (msg) {
            if (errorMode) {
                logger.error(msg);
            }
        },
        info: function (msg) {
            if (errorMode && errorMode !== 'errors') {
                logger.info(msg);
            }
        },
        warn: function (msg) {
            if (errorMode && errorMode !== 'errors') {
                logger.warn(msg);
            }
        }
    };
};

/** Defines query name for transaction creating graphQL call
 * @param {Object} data data object with parameters
 * @returns {string} sale/authorization or in case of PayPal transaction: chargePaypal/authorizePaypal
 */
paymentHelper.defineCreateTransactionQueryName = function (data) {
    if (data.isPaypal) {
        return data.options.submitForSettlement ? braintreeConstants.QUERY_NAME_PAYPAL_SALE : braintreeConstants.QUERY_NAME_PAYPAL_AUTHORIZATION;
    }

    return data.options.submitForSettlement ? braintreeConstants.QUERY_NAME_SALE : braintreeConstants.QUERY_NAME_AUTHORIZATION;
};

/**
 * Function go through array with payment instruments and return array without duplicated Credit Cards on Checkout
 * @param {Array} arrToFilter array of payment instruments which will be filtered
 * @returns {Array} filtered array (array without duplicated credit cards)
 */
paymentHelper.getArrayWithoutRepitableCardsOnCheckout = function (arrToFilter) {
    const sortedByCreationDateArray = arrToFilter.slice().sort(function (firstEl, secondEl) {
        return firstEl.creationDate.getTime() - secondEl.creationDate.getTime();
    });
    const activePaymentMethods = paymentHelper.getActivePaymentMethods();
    const creditCardProcessorsIds = [
        activePaymentMethods.BRAINTREE_CREDIT.paymentMethodId,
        activePaymentMethods.BRAINTREE_SRC.paymentMethodId
    ];

    // Filtered array
    return getArrayWithoutRepitableCards(
        sortedByCreationDateArray,
        creditCardProcessorsIds,
        function (duplicatePaymentInstrument, filteredPaymentInstrument) {
            if (duplicatePaymentInstrument.custom.braintreeDefaultCard) {
                duplicatePaymentInstrument.custom.braintreeDefaultCard = false;
                filteredPaymentInstrument.custom.braintreeDefaultCard = true;
            }
        }
    );
};

/**
 * Calculate amount of gift certificates in the order
 * @param {dw.order.Order} order Order object
 * @return {dw.value.Money} Certificates total
 */
paymentHelper.calculateAppliedGiftCertificatesAmount = function (order) {
    let paymentInstrument = null;
    let amount = new Money(0, order.getCurrencyCode());

    const paymentInstruments = order.getGiftCertificatePaymentInstruments();
    const iterator = paymentInstruments.iterator();

    while (iterator.hasNext()) {
        paymentInstrument = iterator.next();
        amount = amount.add(paymentInstrument.getPaymentTransaction().getAmount());
    }

    return amount;
};

/**
 * Calculate order amount
 * @param {dw.order.Order} order Order object
 * @return {dw.value.Money} New Amount value
 */
paymentHelper.getAmountPaid = function (order) {
    const appliedGiftCertificatesAmount = paymentHelper.calculateAppliedGiftCertificatesAmount(order);

    // Returns an amount
    return order.getTotalGrossPrice().subtract(appliedGiftCertificatesAmount);
};

/**
 * Create shipping address data for request
 * @param {dw.order.OrderAddress} address Address data from order
 * @return {Object} transformed data object
 */
paymentHelper.createShippingAddressData = function (address) {
    return {
        company: address.getCompanyName(),
        countryCode: address.getCountryCode().getValue().toUpperCase(),
        countryName: address.getCountryCode().getDisplayValue(),
        firstName: address.getFirstName(),
        lastName: address.getLastName(),
        locality: address.getCity(),
        postalCode: decodeURIComponent(address.getPostalCode()),
        region: address.getStateCode(),
        streetAddress: address.getAddress1(),
        extendedAddress: address.getAddress2()
    };
};

/**
 * Gets the order discount amount by subtracting the basket's total including the discount from
 * the basket's total excluding the order discount.
 *
 * @param {dw.order.LineItemCtnr} lineItemContainer - Current users's basket
 * @returns {string} string that contains the value order discount
 */
paymentHelper.getOrderLevelDiscountTotal = function (lineItemContainer) {
    return lineItemContainer.getAdjustedMerchandizeTotalPrice(false).subtract(lineItemContainer.getAdjustedMerchandizeTotalPrice(true)).getDecimalValue().toString();
};

/**
 * Gets required Level3 line items
 *
 * @param {dw.order.Order} order Current users's order object
 * @returns {Object} an object with required fields
 */
paymentHelper.getLineItems = function (order) {
    let productsData = [];
    let gcData = [];

    const productLineItems = order.productLineItems;
    const gcLineItems = order.giftCertificateLineItems;

    if (!empty(productLineItems)) {
        productsData = productLineItems.toArray().map(function (value) {
            return {
                name: value.getProductName().substring(0, 30),
                kind: braintreeConstants.LINE_ITEMS_KIND,
                quantity: value.getQuantityValue(),
                unitAmount: value.getProduct().getPriceModel().getPrice().toNumberString(),
                unitOfMeasure: value.getProduct().custom.unitOfMeasure || '',
                totalAmount: value.getPrice().toNumberString(),
                taxAmount: value.getTax().toNumberString(),
                discountAmount: value.getPrice().subtract(value.getProratedPrice()).getDecimalValue().toString(),
                productCode: value.getProduct().getUPC(),
                commodityCode: value.getProduct().custom.commodityCode || ''
            };
        });
    }
    if (!empty(gcLineItems)) {
        gcData = gcLineItems.toArray().map(function (value) {
            return {
                name: ('Gift - ' + value.recipientEmail).substring(0, 30),
                kind: braintreeConstants.LINE_ITEMS_KIND,
                quantity: 1,
                unitAmount: value.getPrice().toNumberString(),
                unitOfMeasure: '',
                totalAmount: value.getPrice().toNumberString(),
                taxAmount: value.getTax().toNumberString(),
                discountAmount: '',
                productCode: '',
                commodityCode: ''
            };
        });
    }

    return productsData.concat(gcData);
};

/**
 * Returns Active Payment Methods
 *
 * Setting isActive to true
 * Saves paymentMethodId to refs.paymentMethods
 *
 * @returns {Object} an object with active payment Methods
 */
paymentHelper.getActivePaymentMethods = function () {
    const activePaymentMethods = require('dw/order/PaymentMgr').getActivePaymentMethods();
    const paymentMethods = {
        BRAINTREE_CREDIT: {},
        BRAINTREE_PAYPAL: {},
        BRAINTREE_APPLEPAY: {},
        BRAINTREE_VENMO: {},
        BRAINTREE_LOCAL: {},
        BRAINTREE_GOOGLEPAY: {},
        BRAINTREE_SRC: {}
    };

    Array
        .filter(activePaymentMethods, function (paymentMethod) {
            return paymentMethod.paymentProcessor && allowedProcessorsIds.indexOf(paymentMethod.paymentProcessor.ID) !== -1;
        })
        .forEach(function (paymentMethod) {
            const processorId = paymentMethod.paymentProcessor.ID;

            if (processorId === braintreeConstants.PAYMENT_PROCCESSOR_ID_BRAINTREE_LOCAL) {
                if (!paymentMethods[processorId].isActive) {
                    paymentMethods[processorId] = {
                        isActive: true,
                        paymentMethodIds: [paymentMethod.ID]
                    };
                } else {
                    paymentMethods[processorId].paymentMethodIds.push(paymentMethod.ID);
                }
            } else {
                paymentMethods[processorId] = {
                    isActive: true,
                    paymentMethodId: paymentMethod.ID
                };
            }
        });

    return paymentMethods;
};

/**
 * Saves error text to session based on error code or status
 * @param {string} errorStatus status of transaction which should be handled as error case
 */
paymentHelper.handleErrorCode = function (errorStatus) {
    const declinedPaymentErrorMessage = Resource.msg('braintree.error.2000', 'locale', 'null');

    if (session.privacy.braintreeErrorCode) {
        const firstLetter = session.privacy.braintreeErrorCode.charAt(0);

        if (firstLetter === '2') {
            session.privacy.braintreeErrorMsg = declinedPaymentErrorMessage;
        } else if (firstLetter === '3') {
            session.privacy.braintreeErrorMsg = Resource.msg('braintree.error.3000', 'locale', 'null');
        } else if (session.privacy.braintreeErrorCode === '91564') {
            session.privacy.braintreeErrorMsg = Resource.msg('braintree.error.91564', 'locale', 'null');
        }

        session.privacy.braintreeErrorCode = null;
    }

    if (errorStatus) {
        const unsuccessfulStatuses = ['PROCESSOR_DECLINED', 'GATEWAY_REJECTED', 'FAILED'];

        if (unsuccessfulStatuses.indexOf(errorStatus) !== -1) {
            session.privacy.braintreeErrorMsg = declinedPaymentErrorMessage;
        }
    }
};

/**
 * Returns Applicable Credit Card Payment Instruments
 * Allowed Credit Card Processors Ids:
 *  -BRAINTREE_CREDIT
 *  -BRAINTREE_GOOGLEPAY
 *  -BRAINTREE_SRC
 *
 ** Use allowedCreditCardProcessorsIds to add more Credit Card Processors
 * @returns {Array} array of applicable Credit Card Payment Instruments of current site
 */
paymentHelper.getApplicableCreditCardPaymentInstruments = function () {
    if (!customer.authenticated) {
        return [];
    }

    const customerWalletPaymentInstruments = customer.getProfile().getWallet().getPaymentInstruments();
    const activePaymentMethods = paymentHelper.getActivePaymentMethods();
    const allowedCreditCardProcessorsIds = [
        activePaymentMethods.BRAINTREE_CREDIT.paymentMethodId,
        activePaymentMethods.BRAINTREE_SRC.paymentMethodId
    ];

    let customerCardPaymentInstruments = Array
        .filter(customerWalletPaymentInstruments, function (paymentInstrument) {
            return allowedCreditCardProcessorsIds.indexOf(paymentInstrument.paymentMethod) !== -1;
        });

    // Filter card payment instruments for duplicates
    customerCardPaymentInstruments = paymentHelper.getArrayWithoutRepitableCardsOnCheckout(customerCardPaymentInstruments);

    return customerCardPaymentInstruments;
};

/**
 * Indicates whether a new payment account used
 * @param {dw.order.PaymentInstrument} paymentInstrument An order payment instrument
 * @returns {boolean} true/false
 */
paymentHelper.isNewAccountUsed = function (paymentInstrument) {
    return paymentInstrument.c_braintreePaymentMethodNonce !== null;
};

/**
 * Verifies if transaction status refers to successful
 * @param {Object} responseTransaction transaction response
 * @param {Object} paymentInstrument Payment instrument
 * @param {Object} order current order
 */
paymentHelper.verifyTransactionStatus = function (responseTransaction, paymentInstrument, order) {
    const successfulStatuses = [
        braintreeConstants.TRANSACTION_STATUS_AUTHORIZED,
        braintreeConstants.TRANSACTION_STATUS_SETTLED,
        braintreeConstants.TRANSACTION_STATUS_SETTLEMENT_PENDING,
        braintreeConstants.TRANSACTION_STATUS_SETTLING,
        braintreeConstants.TRANSACTION_STATUS_SUBMITTED_FOR_SETTLEMENT
    ];
    const transaction = responseTransaction.transaction || responseTransaction;
    const legacyId = transaction.legacyId;
    const transactionStatus = transaction.status;

    if (successfulStatuses.indexOf(transactionStatus) === -1) {
        if (legacyId) {
            const paymentTransaction = paymentInstrument.getPaymentTransaction();

            paymentTransaction.setTransactionID(legacyId);

            order.custom.braintreePaymentStatus = transactionStatus;
        }

        throw new Error(transactionStatus);
    }
};

/**
 * Returns a prepared custom fields string
 * @param {dw.order.Order} order Order
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument Order payment instrument
 * @return {string} custom fields string
 */
paymentHelper.getCustomFields = function (order, paymentInstrument) {
    const prefs = require('~/cartridge/config/braintreePreferences');
    const HookMgr = require('dw/system/HookMgr');
    const paymentProcessorId = paymentInstrument.getPaymentTransaction().getPaymentProcessor().ID;
    const prefsCustomFields = prefs.customFields;
    const hookMethodName = paymentProcessorId.split('_')[1].toLowerCase();
    const cfObject = {};

    let resultStr = '';
    // Use in forEach below
    let prefsCustomFiledArray;

    Object.keys(prefsCustomFields).forEach(function (fName) {
        prefsCustomFiledArray = prefsCustomFields[fName].split(':');

        cfObject[prefsCustomFiledArray[0]] = prefsCustomFiledArray[1];
    });

    if (HookMgr.hasHook('braintree.customFields')) {
        const cfs = HookMgr.callHook('braintree.customFields', hookMethodName, { order: order, paymentInstrument: paymentInstrument });

        Object.keys(cfs).forEach(function (field) {
            cfObject[field] = cfs[field];
        });
    }

    Object.keys(cfObject).forEach(function (field2) {
        resultStr += StringUtils.format('<{0}>{1}</{0}>', field2, cfObject[field2]);
    });

    return resultStr;
};

/**
 * Return merchant id for passed currency code
 * @param {string} currencyCode - Currency Code
 * @return {string} Merchant ID
 */
paymentHelper.getMerchantAccountID = function (currencyCode) {
    const prefs = require('~/cartridge/config/braintreePreferences');
    const merchantAccounts = createMerchantAccountsObject(prefs.merchantAccountIDs);
    const code = currencyCode.toUpperCase();
    const marchantAccountError = {
        message: Resource.msg('braintree.ocapi.error.merchant.acccoundid.isincorrect', 'locale', null)
    };

    const merchantAccountID = merchantAccounts[code];

    if (!merchantAccountID) {
        throw marchantAccountError;
    }

    return merchantAccountID.replace(/\s/g, '');
};

/** Returns a three-letter abbreviation for this Locale's country, or an empty string if no country has been specified for the Locale
 *
 * @param {string} localeId locale id
 * @return {string} a three-letter abbreviation for this lLocale's country, or an empty string
 */
paymentHelper.getISO3Country = function (localeId) {
    return require('dw/util/Locale').getLocale(localeId).getISO3Country();
};

/**
 * Returns true if payment method is already saved to the customer's wallet
 * @param {Collection} savedPaymentInstruments List of payer's payment methods from DW
 * @param {PaymentInstrument} currentPaymentInstrument PaymentInstrument Object which represent current payment instrument
 * @returns {boolean} true if payment method is already saved to the customer's wallet
 */
paymentHelper.isSavedPaymentMethod = function (savedPaymentInstruments, currentPaymentInstrument) {
    if (savedPaymentInstruments.empty) {
        return false;
    }

    const PAYMENT_METHOD_ID_PAYPAL = braintreeConstants.PAYMENT_METHOD_ID_PAYPAL;
    const PAYMENT_METHOD_ID_VENMO = braintreeConstants.PAYMENT_METHOD_ID_VENMO;
    const PAYMENT_METHOD_ID_CREDIT_CARD = braintreeConstants.PAYMENT_METHOD_ID_CREDIT_CARD;
    const PAYMENT_METHOD_ID_SRC = braintreeConstants.PAYMENT_METHOD_ID_SRC;
    const currentPaymentMethodId = currentPaymentInstrument.paymentMethodId;

    return savedPaymentInstruments.toArray().some(function (pi) {
        const piPaymentMethodId = pi.paymentMethod;
        const isPiEmailEqual = pi.custom.braintreePaymentMethodAccount === currentPaymentInstrument.c_braintreePaymentMethodAccount;
        const isPayPalExist = currentPaymentMethodId === PAYMENT_METHOD_ID_PAYPAL && piPaymentMethodId === PAYMENT_METHOD_ID_PAYPAL && isPiEmailEqual;
        const isVenmoExist = currentPaymentMethodId === PAYMENT_METHOD_ID_VENMO && piPaymentMethodId === PAYMENT_METHOD_ID_VENMO && isPiEmailEqual;
        // SRC or Credit Card
        const isCreditCardExist = (currentPaymentMethodId === PAYMENT_METHOD_ID_CREDIT_CARD || currentPaymentMethodId === PAYMENT_METHOD_ID_SRC) &&
        pi.creditCardExpirationMonth === currentPaymentInstrument.paymentCard.expirationMonth &&
        pi.creditCardExpirationYear === currentPaymentInstrument.paymentCard.expirationYear &&
        pi.creditCardNumberLastDigits === currentPaymentInstrument.paymentCard.number.substr(currentPaymentInstrument.paymentCard.number.length - 4);

        return isPayPalExist || isVenmoExist || isCreditCardExist;
    });
};


/**
 * Returns true if current payment method includes required fields
 * @param {PaymentInstrument} currentPaymentInstrument PaymentInstrument Object which represent current payment instrument
 * @returns {boolean} true if current payment method includes required fields
 */
paymentHelper.areRequiredFieldsFilled = function (currentPaymentInstrument) {
    if (currentPaymentInstrument && currentPaymentInstrument.paymentMethodId) {
        if (currentPaymentInstrument.paymentMethodId === 'PayPal' || currentPaymentInstrument.paymentMethodId === 'Venmo') {
            return paymentInstrumentValidationHelper.validateBraintreePaymentMethodAccount(currentPaymentInstrument) &&
            paymentInstrumentValidationHelper.validateBraintreePaymentMethodNonce(currentPaymentInstrument);
        } else if (currentPaymentInstrument.paymentMethodId === 'CREDIT_CARD' || currentPaymentInstrument.paymentMethodId === 'SRC') {
            return paymentInstrumentValidationHelper.validateCreditCardExpirationMonth(currentPaymentInstrument) &&
                paymentInstrumentValidationHelper.validateCreditCardExpirationYear(currentPaymentInstrument) &&
                paymentInstrumentValidationHelper.validateCreditCardNumber(currentPaymentInstrument) &&
                paymentInstrumentValidationHelper.validateBraintreePaymentMethodNonce(currentPaymentInstrument);
        }
    }

    return false;
};

/**
 * Function go through array with payment instruments and return array without duplicated Credit Cards on Account
 * @param {Array} arrToFilter array which will be filtered
 * @returns {Array} filtered array (array without duplicated credit cards)
 */
paymentHelper.getArrayWithoutRepitableCardsOnAccount = function (arrToFilter) {
    const sortedByCreationDateArray = arrToFilter.slice().sort(function (firstEl, secondEl) {
        return firstEl.creationDate.getTime() <= secondEl.creationDate.getTime();
    });
    const activePaymentMethods = paymentHelper.getActivePaymentMethods();
    const creditCardProcessorsIds = [
        activePaymentMethods.BRAINTREE_CREDIT.paymentMethodId,
        activePaymentMethods.BRAINTREE_SRC.paymentMethodId
    ];

    return getArrayWithoutRepitableCards(
        sortedByCreationDateArray,
        creditCardProcessorsIds
    );
};

/** Return string of Secure Remote Commerce url and add params to base url
 * @param {string} baseUrl base url of Secure Remote Commerce image
 * @param {Object} params object of url params
 * @returns {string} string of Secure Remote Commerce image url
 */
paymentHelper.createSRCImageUrl = function (baseUrl, params) {
    if (empty(params)) {
        return baseUrl;
    }

    const queryString = Object.keys(params).map(function (key) {
        return StringUtils.format('{0}={1}', key, params[key]);
    }).join('&');

    return StringUtils.format('{0}?{1}', baseUrl, queryString);
};

/**
 * Check if PayPal button is enabled
 * @param {string} targetPage prefs value
 * @return {boolean} disabled or enabled
 */
paymentHelper.isPaypalButtonEnabled = function (targetPage) {
    const prefs = require('~/cartridge/config/braintreePreferences');
    const displayPages = prefs.paypalButtonLocation.toLowerCase();

    if (displayPages === 'none' || !targetPage) {
        return false;
    }

    return displayPages.indexOf(targetPage) !== -1;
};

/**
 * Returns Applicable Local Payment Methods
 *
 * All parameters are optional, and if not specified, the respective restriction won't be validated.
 * For example, if a method is restricted by billing country, but no country code is specified,
 * this method will be returned, unless it is filtered out by customer group or payment amount.
 *
 * @param {Object} parameters - paymentMethodIds, applicablePaymentMethods
 * @returns {Array} array of applicable payment methods ID's of current site
 */
paymentHelper.getApplicableLocalPaymentMethods = function (parameters) {
    const applicablePM = parameters.applicablePaymentMethods
        .map(function (paymentMethod) {
            return paymentMethod.ID;
        });

    return parameters.paymentMethodIds.filter(function (paymentMethod) {
        return applicablePM.indexOf(paymentMethod) !== -1;
    });
};

/**
 * Returns the applicable payment methods for current basket
 * @param {dw.order.Basket} basket The current basket
 * @param {string} countryCode A current country code
 * @returns {Object} An object with applicable payment methods
 */
paymentHelper.getApplicablePaymentMethods = function (basket, countryCode) {
    const paymentMethods = PaymentMgr.getApplicablePaymentMethods(
        basket.customer,
        countryCode,
        basket.totalGrossPrice.value
    );

    return paymentMethods.toArray().map(function (method) {
        return {
            ID: method.ID,
            name: method.name
        };
    });
};

/**
 * Sets and returns new default card
 * @param {string} paymentMethodId Payment Method ID
 * @param {dw.customer.Profile} customerProfile Customer Profile. Use when a billing agreement was revoked
 * @returns {CustomerPaymentInstrument} New default account
 */
paymentHelper.setAndReturnNewDefaultCard = function (paymentMethodId, customerProfile) {
    const braintreePrefs = require('~/cartridge/config/braintreePreferences');
    const profile = customer.profile || customerProfile;
    /**
        * Allowed Credit Card Processors IDs:
        *  -BRAINTREE_CREDIT
        *  -BRAINTREE_SRC
    */
    const allowedCardProcessorsIds = [
        require('dw/order/PaymentInstrument').METHOD_CREDIT_CARD,
        braintreePrefs.paymentMethods.BRAINTREE_GOOGLEPAY.paymentMethodId,
        braintreePrefs.paymentMethods.BRAINTREE_SRC.paymentMethodId
    ];
    const newDefaultAccount = allowedCardProcessorsIds.indexOf(paymentMethodId) !== -1 ?
        paymentHelper.getApplicableCreditCardPaymentInstruments() :
        profile.getWallet().getPaymentInstruments(paymentMethodId);

    if (!empty(newDefaultAccount)) {
        Transaction.wrap(function () {
            newDefaultAccount[0].custom.braintreeDefaultCard = true;
        });
    }

    return newDefaultAccount;
};

/**
 * Deletes payment method from customer's payment instrument (wallet)
 * @param {string} creditCardToken token of payment method which must be removed
 * @param {dw.customer.Profile} customerProfile Customer profile. Used when billing agreement was revoked
 */
paymentHelper.deletePaymentInstrumentFromDwCustomer = function (creditCardToken, customerProfile) {
    const profile = customer.profile || customerProfile;
    const customerPaymentInstruments = profile.wallet.getPaymentInstruments();

    if (empty(customerPaymentInstruments)) {
        return;
    }

    try {
        Transaction.wrap(function () {
            profile.getWallet().removePaymentInstrument(customerPaymentInstruments.toArray().find(function (paymentInst) {
                return creditCardToken === paymentInst.creditCardToken;
            }));
        });
    } catch (error) {
        throw new Error(error);
    }
};

/**
 * Get Braintree payment instrument from array of payment instruments
 * @param {dw.order.LineItemCtnr} lineItemContainer Order object
 * @return {dw.order.OrderPaymentInstrument} Braintree Payment Instrument
 */
paymentHelper.getBraintreePaymentInstrument = function (lineItemContainer) {
    const paymentInstruments = lineItemContainer.getPaymentInstruments();

    return paymentInstruments.toArray().find(function (paymentInstrument) {
        return allowedProcessorsIds.indexOf(paymentInstrument.getPaymentTransaction().getPaymentProcessor().ID !== -1);
    });
};

module.exports = paymentHelper;
