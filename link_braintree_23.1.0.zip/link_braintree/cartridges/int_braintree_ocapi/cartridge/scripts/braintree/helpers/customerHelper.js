'use strict';

const Site = require('dw/system/Site');
const Resource = require('dw/web/Resource');

const validationHelper = require('~/cartridge/scripts/braintree/helpers/validationHelper');
// An error object that is thrown in case when request is not completely correct
const dataErrorObject = {
    valid: false,
    message: Resource.msg('required.fields.are.not.filled', 'error', null)
};

const customerHelper = {};

/**
 * Create customer ID for braintree based on the customer number
 * @param {dw.customer.Customer} customer  Registered customer object
 * @return {string} Customer ID
 */
customerHelper.createCustomerId = function (customer) {
    if (session.privacy.customerId) {
        return session.privacy.customerId;
    }

    const id = customer.getProfile().getCustomerNo();
    const allowNameLength = 31 - id.length;

    let siteName = Site.getCurrent().getID().toLowerCase();

    if (siteName.length > allowNameLength) {
        siteName = siteName.slice(0, allowNameLength);
    }

    siteName = siteName.concat('_', id);
    session.privacy.customerId = siteName;

    return siteName;
};

/**
 * Defines which customer ID to use
 * @param {dw.customer.Customer} customer Customer object
 * @return {string} customer ID
 */
customerHelper.getCustomerId = function (customer) {
    return customer.profile.custom.braintreeCustomerId || customerHelper.createCustomerId(customer);
};

/**
 * Return specific payment method from customers payment methods list
 * @param {string} paymentMethodName Name of the payment method
 * @param {dw.customer.Customer} customer A customer object
 * @return {Object} Payment method from customers payment methods list
 */
customerHelper.getCustomerPaymentInstruments = function (paymentMethodName, customer) {
    const customerProfile = customer.profile;

    if (!customerProfile) {
        return null;
    }

    return customerProfile.getWallet().getPaymentInstruments(paymentMethodName);
};

/**
 * Get saved PayPal customer payment method instrument
 * @param {dw.customer.Customer} customer A customer object
 * @param {string} email PayPal account email
 * @return {dw.util.Collection} payment instruments
 */
customerHelper.getPaypalCustomerPaymentInstrumentByEmail = function (customer, email) {
    const prefs = require('~/cartridge/config/braintreePreferences');
    const customerPaymentInstruments = customerHelper.getCustomerPaymentInstruments(prefs.paymentMethods.BRAINTREE_PAYPAL.paymentMethodId, customer);

    if (empty(customerPaymentInstruments)) {
        return null;
    }

    const iterator = customerPaymentInstruments.iterator();

    let paymentInst = null;

    while (iterator.hasNext()) {
        paymentInst = iterator.next();
        if (paymentInst.custom.braintreePaymentMethodAccount === email) {
            return paymentInst;
        }
    }

    return null;
};

/**
 * Get saved Venmo customer payment method instrument
 * @param {string} userId Venmo
 * @param {dw.customer.Customer} customer A customer object
 * @return {dw.util.Collection} payment instruments
 */
customerHelper.getVenmoCustomerPaymentInstrument = function (userId, customer) {
    const prefs = require('~/cartridge/config/braintreePreferences');
    const customerPaymentInstruments = customerHelper.getCustomerPaymentInstruments(prefs.paymentMethods.BRAINTREE_VENMO.paymentMethodId, customer);

    if (customerPaymentInstruments) {
        const iterator = customerPaymentInstruments.iterator();

        let paymentInst = null;

        while (iterator.hasNext()) {
            paymentInst = iterator.next();
            if (paymentInst.custom.braintreeVenmoUserId === userId) {
                return paymentInst;
            }
        }
    }

    return null;
};

/**
 * Clear default property
 * applicablePI - applicable Payment Instruments
 * @param {array} applicablePI of existed payment instruments
 * @return {Object} default PI property or {}
 */
customerHelper.clearDefaultProperty = function (applicablePI) {
    const custometPaymentInstruments = applicablePI instanceof Array ? applicablePI : applicablePI.toArray();

    if (empty(applicablePI)) {
        return {};
    }

    const defaultPI = custometPaymentInstruments.find(function (pi) {
        return pi.custom.braintreeDefaultCard;
    });

    if (defaultPI) {
        defaultPI.custom.braintreeDefaultCard = false;

        return defaultPI;
    }

    return {};
};

/**
 * Set braintreeDefaultCard as true for following paymentMethods:
 * -CreditCart
 * -PayPal
 * -Venmo
 * -GooglePay
 * -SRC
 * Sets a Braintree default card
 * @param {dw.customer.Customer} customer A customer object
 * @param {string} paymentMethodToken token from Braintree
 */
customerHelper.setBraintreeDefaultCard = function (customer, paymentMethodToken) {
    const savedPaymentInstruments = customer.getProfile().getWallet().getPaymentInstruments();

    savedPaymentInstruments.toArray().find(function (payment) {
        return paymentMethodToken === payment.creditCardToken;
    }).custom.braintreeDefaultCard = true;
};

/**
 * Returns customer shipping address for 'createPayment' method of brainree SDK
 * @param {dw.customer.CustomerAddress} defaultAddress Saved customer address
 * @returns {Object} Shipping address
 */
customerHelper.getDefaultCustomerShippingAddress = function (defaultAddress) {
    return {
        line1: defaultAddress.address1,
        line2: defaultAddress.address2 || '',
        city: defaultAddress.city,
        state: defaultAddress.stateCode,
        postalCode: defaultAddress.postalCode,
        countryCode: defaultAddress.countryCode.value,
        phone: defaultAddress.phone,
        recipientName: defaultAddress.fullName
    };
};

/**
 * Get default customer PayPal payment instrument
 * @param {dw.customer.Customer} customer A customer object
 * @return {dw.customer.CustomerPaymentInstrument} payment instrument
 */
customerHelper.getDefaultCustomerPaypalPaymentInstrument = function (customer) {
    const prefs = require('~/cartridge/config/braintreePreferences');
    const instruments = customerHelper.getCustomerPaymentInstruments(prefs.paymentMethods.BRAINTREE_PAYPAL.paymentMethodId, customer);

    if (!instruments) {
        return null;
    }

    const iterator = instruments.iterator();

    let instrument = null;

    while (iterator.hasNext()) {
        instrument = iterator.next();
        if (instrument.custom.braintreeDefaultCard) {
            return instrument;
        }
    }

    return instruments.length > 0 && instruments[0];
};

/**
 * Returns true if current customer registration object includes required fields
 * @param {Object} registration registration Object which represent current customer registration info
**/
customerHelper.areCustomerRegistrationRequiredFieldsFilled = function (registration) {
    if (empty(registration) ||
        !validationHelper.validateRequestStringValue(registration.customer.firstName) ||
        !validationHelper.validateRequestStringValue(registration.customer.lastName) ||
        !validationHelper.validateRequestStringValue(registration.customer.login) ||
        !validationHelper.validateRequestStringValue(registration.customer.email) ||
        !validationHelper.validateRequestStringValue(registration.customer.phoneHome) ||
        !validationHelper.validateRequestStringValue(registration.password)
    ) {
        throw dataErrorObject;
    }
};

module.exports = customerHelper;
