'use strict';

const paymentHelper = require('~/cartridge/scripts/braintree/helpers/paymentHelper');
const customerHelper = require('~/cartridge/scripts/braintree/helpers/customerHelper');
const buttonConfigHelper = require('~/cartridge/scripts/braintree/helpers/buttonConfigHelper');

const addProductToBasketHelper = {};

/**
 * Returns an object with Paypal related configs
 * @param {dw.order.Basket} basket The current Basket
 * @param {string} currentFlow The current page flow
 * @returns {Object} An object
 */
function processPayPalConfigs(basket, currentFlow) {
    const prefs = require('~/cartridge/config/braintreePreferences');

    const config = {
        payPalButtonConfig: null,
        dafaultPaypalShippingAddress: null
    };

    if (prefs.paymentMethods.BRAINTREE_PAYPAL.isActive && paymentHelper.isPaypalButtonEnabled(currentFlow)) {
        config.payPalButtonConfig = buttonConfigHelper.createBraintreePayPalButtonConfig(basket, currentFlow);

        const defaultPayPalPI = customerHelper.getDefaultCustomerPaypalPaymentInstrument(basket.customer);

        if (defaultPayPalPI) {
            const defaultPaypalAddress = basket.customer.getAddressBook().getPreferredAddress();

            if (!empty(defaultPaypalAddress)) {
                config.dafaultPaypalShippingAddress = customerHelper.getDefaultCustomerShippingAddress(defaultPaypalAddress);
            }
        }
    }

    return config;
}

/**
 * Returns braintree buttons config object for 'Mini cart' page
 * @param {dw.order.Basket} basket The current Basket
 * @param {string} currentFlow The current page flow
 * @returns {Object} An object
 */
addProductToBasketHelper.getMiniCartPageConfigs = function (basket, currentFlow) {
    return processPayPalConfigs(basket, currentFlow);
};

/**
 * Returns braintree buttons config object for 'Checkout' page
 * @param {dw.order.Basket} basket The current Basket
 * @param {string} currentFlow The current page flow
 * @returns {Object} An object
 */
addProductToBasketHelper.getCheckoutPageConfigs = function (basket, currentFlow) {
    const Locale = require('dw/util/Locale');
    const hooksHelper = require('~/cartridge/scripts/braintree/helpers/hooksHelper');
    const prefs = require('~/cartridge/config/braintreePreferences');

    const config = {
        payPalButtonConfig: null,
        venmoButtonConfig: null,
        applePayButtonConfig: null,
        hostedFieldsConfig: null,
        isActiveLpmPaymentOptions: null,
        isSettle: null,
        lpmButtonConfig: null,
        lpmPaymentOptions: null,
        googlepayButtonConfig: null,
        srcButtonConfig: null
    };

    if (prefs.paymentMethods.BRAINTREE_PAYPAL.isActive) {
        config.payPalButtonConfig = buttonConfigHelper.createBraintreePayPalButtonConfig(basket, currentFlow);
    }

    if (prefs.paymentMethods.BRAINTREE_VENMO.isActive) {
        config.venmoButtonConfig = buttonConfigHelper.createBraintreeVenmoButtonConfig(basket, currentFlow);
    }

    if (prefs.paymentMethods.BRAINTREE_APPLEPAY.isActive) {
        config.applePayButtonConfig = buttonConfigHelper.createBraintreeApplePayButtonConfig(basket, currentFlow);
    }

    if (prefs.paymentMethods.BRAINTREE_CREDIT.isActive) {
        config.hostedFieldsConfig = hooksHelper.createHostedFieldsConfig(prefs);
    }

    if (prefs.paymentMethods.BRAINTREE_LOCAL.isActive) {
        const countryCode = Locale.getLocale(request.locale).country;

        config.isActiveLpmPaymentOptions = prefs.paymentMethods.BRAINTREE_LOCAL.isActive;
        config.isSettle = prefs.isSettle;
        config.lpmButtonConfig = buttonConfigHelper.createBraintreeLocalPaymentMethodButtonConfig(basket, currentFlow);
        config.lpmPaymentOptions = paymentHelper.getApplicableLocalPaymentMethods({
            applicablePaymentMethods: paymentHelper.getApplicablePaymentMethods(basket, countryCode),
            paymentMethodIds: prefs.paymentMethods.BRAINTREE_LOCAL.paymentMethodIds
        });
    }

    if (prefs.paymentMethods.BRAINTREE_GOOGLEPAY.isActive) {
        config.googlepayButtonConfig = buttonConfigHelper.createBraintreeGooglePayButtonConfig(basket, currentFlow);
    }

    if (prefs.paymentMethods.BRAINTREE_SRC.isActive) {
        config.srcButtonConfig = buttonConfigHelper.createBraintreeSrcButtonConfig(basket, currentFlow);
    }

    return config;
};


/**
 * Returns braintree buttons config object for 'Cart' page
 * @param {dw.order.Basket} basket The current Basket
 * @param {string} currentFlow The current page flow
 * @returns {Object} An object
 */
addProductToBasketHelper.getCartPageConfigs = function (basket, currentFlow) {
    const prefs = require('~/cartridge/config/braintreePreferences');

    const config = {
        applePayButtonConfig: null,
        googlepayButtonConfig: null,
        srcButtonConfig: null
    };
    const paypalConfig = processPayPalConfigs(basket, currentFlow);

    if (prefs.paymentMethods.BRAINTREE_APPLEPAY.isActive && prefs.applepayVisibilityOnCart) {
        config.applePayButtonConfig = buttonConfigHelper.createBraintreeApplePayButtonConfig(basket, currentFlow);
    }

    if (prefs.paymentMethods.BRAINTREE_GOOGLEPAY.isActive && prefs.googlepayVisibilityOnCart) {
        config.googlepayButtonConfig = buttonConfigHelper.createBraintreeGooglePayButtonConfig(basket, currentFlow);
    }

    if (prefs.paymentMethods.BRAINTREE_SRC.isActive && prefs.srcVisibilityOnCart) {
        config.srcButtonConfig = buttonConfigHelper.createBraintreeSrcButtonConfig(basket, currentFlow);
    }

    return Object.assign(config, paypalConfig);
};

module.exports = addProductToBasketHelper;
