'use strict';

const Resource = require('dw/web/Resource');

const paymentHelper = require('*/cartridge/scripts/braintree/helpers/paymentHelper');
const paymentInstrumentValidationHelper = require('*/cartridge/scripts/braintree/helpers/paymentInstrumentValidationHelper');

// An error object that is thrown in case of an invalid 'CreditCardToken' value
const creditTokenErrorObject = {
    message: Resource.msg('braintree.ocapi.error.paymentinstrument.creditcardtoken.notvalid', 'locale', null)
};

// An error object that is thrown in case when request is not completely correct
const dataErrorObject = {
    valid: false,
    message: Resource.msg('braintree.ocapi.error.DATA_REQUEST_ERROR', 'locale', null)
};

// An error object that is thrown in case of an invalid 'braintreePaymentMethodNonce' value
const clientRequestErrorObject = {
    valid: false,
    message: Resource.msg('braintree.ocapi.error.CLIENT_REQUEST_ERROR', 'locale', null)
};

const createBasketPaymentInstrumentHelper = {};

/**
 * Validate Payment Nonce
 * @param {BasketPaymentInstrumentRequest} paymentInstrument Document representing a basket payment instrument request
 */
const validateNonce = function (paymentInstrument) {
    // Validates a Braintree payment method nonce
    if (!paymentInstrumentValidationHelper.validateBraintreePaymentMethodNonce(paymentInstrument)) {
        throw clientRequestErrorObject;
    }
};

/**
 * Validate Fraud Risk Data
 * @param {BasketPaymentInstrumentRequest} paymentInstrument Document representing a basket payment instrument request
 */
const validateFraudRiskData = function (paymentInstrument) {
    // Validates request data for a Braintree
    if (!paymentInstrumentValidationHelper.validateBraintreeFraudRiskData(paymentInstrument)) {
        throw dataErrorObject;
    }
};

/**
 * Validates a PayPal request
 * @param {BasketPaymentInstrumentRequest} paymentInstrument Document representing a basket payment instrument request
 */
createBasketPaymentInstrumentHelper.validatePayPalRequest = function (paymentInstrument) {
    const isCreditCardTokenProvided = paymentInstrument.paymentCard && paymentInstrument.paymentCard.creditCardToken;

    // Throws an error if 'creditCardToken' and 'braintreePaymentMethodNonce' are not provided
    if (!isCreditCardTokenProvided && !paymentInstrument.c_braintreePaymentMethodNonce) {
        throw clientRequestErrorObject;
    }

    // The general request data for the saved and new PayPal accounts
    const isBraintreePayPalEmailValid = paymentInstrumentValidationHelper.validateBraintreePayPalEmail(paymentInstrument);
    const isBraintreeFraudRiskDataValid = paymentInstrumentValidationHelper.validateBraintreeFraudRiskData(paymentInstrument);
    const isPayPalFundingSourceValid = paymentInstrumentValidationHelper.validatePayPalFundingSource(paymentInstrument);
    const isBraintreePaymentMethodNonceValid = paymentInstrumentValidationHelper.validateBraintreePaymentMethodNonce(paymentInstrument);
    const isBraintreeSaveCreditCardValid = paymentInstrumentValidationHelper.validateBraintreeSaveCreditCard(paymentInstrument);

    // Saved PayPal account validation
    if (!paymentHelper.isNewAccountUsed(paymentInstrument)) {
        if (!paymentInstrumentValidationHelper.validateCreditToken(paymentInstrument, customer)) {
            throw creditTokenErrorObject;
        }

        if (!isBraintreePayPalEmailValid || !isBraintreeFraudRiskDataValid || !isPayPalFundingSourceValid) {
            throw dataErrorObject;
        }
    // New PayPal account validation
    } else if (!isBraintreePaymentMethodNonceValid || !isBraintreeSaveCreditCardValid ||
        !isBraintreePayPalEmailValid || !isBraintreeFraudRiskDataValid || !isPayPalFundingSourceValid) {
        throw dataErrorObject;
    }
};

/**
 * Validates a Google pay request
 * @param {BasketPaymentInstrumentRequest} paymentInstrument Document representing a basket payment instrument request
 */
createBasketPaymentInstrumentHelper.validateGooglePayRequest = function (paymentInstrument) {
    validateNonce(paymentInstrument);

    const isBraintreeGooglepayPaymentTypeValid = paymentInstrumentValidationHelper.validateBraintreeGooglepayPaymentType(paymentInstrument);
    const isGooglePayDescriptionValid = paymentInstrumentValidationHelper.validateGooglePayDescription(paymentInstrument);
    const isBraintreeFraudRiskDataValid = paymentInstrumentValidationHelper.validateBraintreeFraudRiskData(paymentInstrument);

    // Validates the request data for a Braintree Google Pay
    if (!isBraintreeGooglepayPaymentTypeValid || !isGooglePayDescriptionValid || !isBraintreeFraudRiskDataValid) {
        throw dataErrorObject;
    }
};

/**
 * Validates an Apple pay request
 * @param {BasketPaymentInstrumentRequest} paymentInstrument Document representing a basket payment instrument request
 */
createBasketPaymentInstrumentHelper.validateApplePayRequest = function (paymentInstrument) {
    validateNonce(paymentInstrument);
    validateFraudRiskData(paymentInstrument);
};

/**
 * Validates a Credit Card request
 * @param {BasketPaymentInstrumentRequest} paymentInstrument Document representing a basket payment instrument request
 * @param {dw.customer.Customer} customer A customer object
 */
createBasketPaymentInstrumentHelper.validateCreditCardRequest = function (paymentInstrument, customer) {
    const isCreditCardTokenProvided = paymentInstrument.paymentCard && paymentInstrument.paymentCard.creditCardToken;
    // Throws an error if 'creditCardToken' and 'braintreePaymentMethod nonce' are not provided
    if (!isCreditCardTokenProvided && !paymentInstrument.c_braintreePaymentMethodNonce) {
        throw clientRequestErrorObject;
    }

    // The general request data for the saved and new Credit card accounts
    const isBraintreeFraudRiskDataValid = paymentInstrumentValidationHelper.validateBraintreeFraudRiskData(paymentInstrument);
    const isCreditCardNumberValid = paymentInstrumentValidationHelper.validateCreditCardNumber(paymentInstrument);
    const isCreditCardTypeValid = paymentInstrumentValidationHelper.validateCreditCardType(paymentInstrument);
    const isCreditCardHolderValid = paymentInstrumentValidationHelper.validateCreditCardHolder(paymentInstrument);
    const isCreditCardExpirationMonthValid = paymentInstrumentValidationHelper.validateCreditCardExpirationMonth(paymentInstrument);
    const isCreditCardExpirationYearValid = paymentInstrumentValidationHelper.validateCreditCardExpirationYear(paymentInstrument);
    const isBraintreePaymentMethodNonceValid = paymentInstrumentValidationHelper.validateBraintreePaymentMethodNonce(paymentInstrument);
    const isBraintreeSaveCreditCardValid = paymentInstrumentValidationHelper.validateBraintreeSaveCreditCard(paymentInstrument);

    // Saved Credit card account validation
    if (!paymentHelper.isNewAccountUsed(paymentInstrument)) {
        if (!paymentInstrumentValidationHelper.validateCreditToken(paymentInstrument, customer)) {
            throw creditTokenErrorObject;
        }

        if (!isBraintreeFraudRiskDataValid || !isCreditCardNumberValid) {
            throw dataErrorObject;
        }
    // New Credit card account validation
    } else if (!isCreditCardTypeValid || !isCreditCardNumberValid || !isCreditCardHolderValid ||
        !isCreditCardExpirationMonthValid || !isCreditCardExpirationYearValid || !isBraintreePaymentMethodNonceValid ||
        !isBraintreeSaveCreditCardValid || !isBraintreeFraudRiskDataValid) {
        throw dataErrorObject;
    }
};

/**
 * Validates a SRC request
 * @param {BasketPaymentInstrumentRequest} paymentInstrument Document representing a basket payment instrument request
 * @param {dw.customer.Customer} customer A customer object
 */
createBasketPaymentInstrumentHelper.validateSrcRequest = function (paymentInstrument, customer) {
    createBasketPaymentInstrumentHelper.validateCreditCardRequest(paymentInstrument, customer);

    if (!paymentInstrumentValidationHelper.validateBraintreeSrcCardDescription(paymentInstrument)) {
        throw dataErrorObject;
    }
};

/**
 * Validates a Venmo request
 * @param {BasketPaymentInstrumentRequest} paymentInstrument Document representing a basket payment instrument request
 */
createBasketPaymentInstrumentHelper.validateVenmoRequest = function (paymentInstrument) {
    const isCreditCardTokenProvided = paymentInstrument.paymentCard && paymentInstrument.paymentCard.creditCardToken;
    // Throws an error if 'creditCardToken' and 'braintreePaymentMethod nonce' are not provided
    if (!isCreditCardTokenProvided && !paymentInstrument.c_braintreePaymentMethodNonce) {
        throw clientRequestErrorObject;
    }

    const isBraintreePaymentMethodNonceValid = paymentInstrumentValidationHelper.validateBraintreePaymentMethodNonce(paymentInstrument);
    const isBraintreeFraudRiskDataValid = paymentInstrumentValidationHelper.validateBraintreeFraudRiskData(paymentInstrument);
    const isBraintreeSaveCreditCardValid = paymentInstrumentValidationHelper.validateBraintreeSaveCreditCard(paymentInstrument);

    // New venmo account
    if (paymentHelper.isNewAccountUsed(paymentInstrument)) {
        if (!isBraintreePaymentMethodNonceValid || !isBraintreeFraudRiskDataValid || !isBraintreeSaveCreditCardValid) {
            throw dataErrorObject;
        }
    // Saved venmo account
    } else if (!paymentInstrumentValidationHelper.validateCreditToken(paymentInstrument, customer)) {
        throw creditTokenErrorObject;
    }
};

/**
 * Validates a Lpm request
 * @param {BasketPaymentInstrumentRequest} paymentInstrument Document representing a basket payment instrument request
 */
createBasketPaymentInstrumentHelper.validateLpmRequest = function (paymentInstrument) {
    validateNonce(paymentInstrument);
    validateFraudRiskData(paymentInstrument);
};

module.exports = createBasketPaymentInstrumentHelper;
