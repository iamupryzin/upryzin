'use strict';

const Resource = require('dw/web/Resource');

const prefs = require('~/cartridge/config/braintreePreferences');
const paymentHelper = require('~/cartridge/scripts/braintree/helpers/paymentHelper');
const braintreeConstants = require('~/cartridge/scripts/util/braintreeConstants');

const accountButtonConfigHelper = {};

/**
 * Creates general button config object for all payment methods
 * @param {string} paymentMethodName Payment Method name
 * @returns {Object} Button config object
 */
accountButtonConfigHelper.createGeneralButtonConfig = function (paymentMethodName) {
    const buttonConfig = {
        paymentMethodName: paymentMethodName,
        messages: {
            CLIENT_REQUEST_TIMEOUT: Resource.msg('braintree.ocapi.error.CLIENT_REQUEST_TIMEOUT', 'locale', null),
            CLIENT_GATEWAY_NETWORK: Resource.msg('braintree.ocapi.error.CLIENT_GATEWAY_NETWORK', 'locale', null),
            CLIENT_REQUEST_ERROR: Resource.msg('braintree.ocapi.error.CLIENT_REQUEST_ERROR', 'locale', null),
            CLIENT_MISSING_GATEWAY_CONFIGURATION: Resource.msg('braintree.ocapi.error.CLIENT_MISSING_GATEWAY_CONFIGURATION', 'locale', null)
        }
    };

    if (paymentMethodName === prefs.paymentMethods.BRAINTREE_GOOGLEPAY.paymentMethodId ||
        paymentMethodName === prefs.paymentMethods.BRAINTREE_SRC.paymentMethodId
    ) {
        buttonConfig.options = {
            amount: '0.00',
            isAccount: true
        };
    }

    return buttonConfig;
};

/**
* Creates config for PayPal button on the Account Page
* @returns {Object} configuration object
*/
accountButtonConfigHelper.createPaypalAccountButtonConfig = function () {
    const config = accountButtonConfigHelper.createGeneralButtonConfig(prefs.paymentMethods.BRAINTREE_PAYPAL.paymentMethodId);
    const paypalMessages = {
        PAYPAL_ACCOUNT_TOKENIZATION_FAILED: Resource.msg('braintree.ocapi.error.PAYPAL_ACCOUNT_TOKENIZATION_FAILED', 'locale', null),
        PAYPAL_INVALID_PAYMENT_OPTION: Resource.msg('braintree.ocapi.error.PAYPAL_INVALID_PAYMENT_OPTION', 'locale', null),
        PAYPAL_FLOW_FAILED: Resource.msg('braintree.ocapi.error.PAYPAL_FLOW_FAILED', 'locale', null),
        PAYPAL_BROWSER_NOT_SUPPORTED: Resource.msg('braintree.ocapi.error.PAYPAL_BROWSER_NOT_SUPPORTED', 'locale', null),
        PAYPAL_BILLING_ADDRESS_NOT_SUPPORTED: Resource.msg('braintree.ocapi.error.PAYPAL_BILLING_ADDRESS_NOT_SUPPORTED', 'locale', null)
    };

    // Sets PayPal related messages
    Object.keys(paypalMessages).forEach(function (key) {
        config.messages[key] = paypalMessages[key];
    });

    config.options = {
        flow: braintreeConstants.FLOW_VAULT,
        enableShippingAddress: true,
        displayName: empty(prefs.paypalDisplayName) ? '' : prefs.paypalDisplayName,
        billingAgreementDescription: empty(prefs.paypalBillingAgreementDescription) ? '' : prefs.paypalBillingAgreementDescription
    };
    config.paypalConfig = {
        fundingSource: braintreeConstants.BUTTON_CONFIG_PAYPAL,
        style: {
            layout: braintreeConstants.BUTTON_CONFIG_OPTIONS_STYLE_LAYOUT_HORIZONTAL,
            label: braintreeConstants.BUTTON_CONFIG_PAYPAL,
            maxbuttons: 1,
            fundingicons: false,
            shape: braintreeConstants.BUTTON_CONFIG_OPTIONS_STYLE_SHAPE_RECT,
            size: braintreeConstants.BUTTON_CONFIG_OPTIONS_STYLE_SIZE_SMALL,
            tagline: false
        }
    };

    return config;
};

/**
 * Creates config for SRC button on the Account Page
 * @returns {Object} configuration object
 */
accountButtonConfigHelper.createAccountSrcButtonConfig = function () {
    const config = accountButtonConfigHelper.createGeneralButtonConfig(prefs.paymentMethods.BRAINTREE_SRC.paymentMethodId);
    const srcOptions = {
        displayName: prefs.srcDisplayName,
        isShippingAddressRequired: false
    };
    const paymentSpecificConfigs = {
        SRCImageUrl: paymentHelper.createSRCImageUrl(prefs.SRCImageLink, prefs.SRCAccountButtonConfig.style),
        settings: prefs.SRCAccountButtonConfig
    };

    const srcMessages = {
        CARD_ALREADY_EXIST_ERROR_MESSAGE: Resource.msg('braintree.ocapi.account.error.existentCard', 'locale', null)
    };

    Object.keys(srcOptions).forEach(function (key) {
        config.options[key] = srcOptions[key];
    });

    Object.keys(paymentSpecificConfigs).forEach(function (key) {
        config[key] = paymentSpecificConfigs[key];
    });

    Object.keys(srcMessages).forEach(function (key) {
        config.messages[key] = srcMessages[key];
    });

    return config;
};

/**
* Creates config for Venmo button on the Account Page
* @returns {Object} configuration object
*/
accountButtonConfigHelper.createAccountVenmoButtonConfig = function () {
    const config = accountButtonConfigHelper.createGeneralButtonConfig(prefs.paymentMethods.BRAINTREE_VENMO.paymentMethodId);
    const venmoMessages = {
        VENMO_ACCOUNT_TOKENIZATION_FAILED: Resource.msg('braintree.ocapi.error.VENMO_ACCOUNT_TOKENIZATION_FAILED', 'locale', null),
        VENMO_BROWSER_NOT_SUPPORTED: Resource.msg('braintree.ocapi.error.VENMO_BROWSER_NOT_SUPPORTED', 'locale', null)
    };
    config.venmoAccountPage = true;
    config.options = {
        flow: braintreeConstants.FLOW_VAULT,
        displayName: prefs.venmoDisplayName || ''
    };

    Object.keys(venmoMessages).forEach(function (key) {
        config.messages[key] = venmoMessages[key];
    });

    return config;
};

module.exports = accountButtonConfigHelper;
