'use strict';

const Bytes = require('dw/util/Bytes');
const Encoding = require('dw/crypto/Encoding');
const WeakMessageDigest = require('dw/crypto/WeakMessageDigest');
const WeakMac = require('dw/crypto/WeakMac');

const paymentMethodWhHelper = {};

/**
 * Computes the hash value of sha1 Algorithm for the passed secret key
 * @param {string} key Private key
 * @returns {Bytes} Bytes
 */
function getSha1HashValue(key) {
    const privateKeyToBytes = new Bytes(key);
    const weakMessageDigest = new WeakMessageDigest(WeakMessageDigest.DIGEST_SHA_1);

    return weakMessageDigest.digestBytes(privateKeyToBytes);
}

/**
 * Computes the hash value for the passed payload using the passed secret key.
 * @param {string} key Private Key
 * @param {Object} data Payload
 * @returns {string} Hex string
 */
function getHmacSha1HashValue(key, data) {
    const payloadToBytes = new Bytes(data);
    const weekMac = new WeakMac(WeakMac.HMAC_SHA_1);

    return weekMac.digest(payloadToBytes, getSha1HashValue(key));
}

/**
 * Creates array of bytes
 * @param {string} string String to unpack
 * @returns {Array} Array of bytes
 */
function getBytesFromString(string) {
    const bytes = [];

    for (let index = 0; index < string.length; index++) {
        bytes.push(string.charCodeAt(index));
    }

    return bytes;
}

/**
 * Creates zip array
 * @param {Array} arrays Arrays of bytes
 * @returns {Array} Array
 */
function getZipArray(arrays) {
    const longestLength = arrays.reduce(function (prev, current) {
        return prev > current.length ? prev : current.length;
    }, 0);
    const zipArray = [];

    let currentIndex = 0;
    let nextArray = [];

    while (currentIndex < longestLength) {
        arrays.forEach(function (array) {
            nextArray.push([array[currentIndex]]);
        });

        zipArray.push(nextArray);
        nextArray = [];

        currentIndex++;
    }

    return zipArray;
}

/**
 * Gets graphQL service credentials
 * @returns {dw.svc.ServiceCredential} Service credentials
 */
paymentMethodWhHelper.getBtServiceCredentials = function () {
    const createGraphQlService = require('*/cartridge/scripts/service/braintreeGraphQLService');
    const service = createGraphQlService();

    return service.configuration.credential;
};

/**
 * Compare signature with payload
 * @param {string} signature Signatare
 * @param {string} payload Payload
 * @returns {boolean} Boolean
 */
paymentMethodWhHelper.signatureWithPayloadComparizon = function (signature, payload) {
    if (signature == null || payload == null) {
        return false;
    }

    const signatureInBytes = getBytesFromString(signature);
    const payloadInBytes = getBytesFromString(payload);

    let result = 0;

    for (const [signatureInByte, payloadInByte] of getZipArray([signatureInBytes, payloadInBytes])) {
        result |= signatureInByte ^ payloadInByte;
    }

    return result === 0;
};

/**
 * Computes sha1 hex digest for payload using the passed secret key
 * @param {string} key Private Key
 * @param {string} data Payload
 * @returns {Bytes} Bytes
 */
paymentMethodWhHelper.getSha1HexDigestValue = function (key, data) {
    const hmacSha1HashValue = getHmacSha1HashValue(key, data);

    return Encoding.toHex(hmacSha1HashValue);
};

module.exports = paymentMethodWhHelper;
