'use strict';

const Money = require('dw/value/Money');

const priceHelper = {};

/**
 * Return root price book for a given price book
 * @param {dw.catalog.PriceBook} priceBook - Provided price book
 * @returns {dw.catalog.PriceBook} root price book
 */
function getRootPriceBook(priceBook) {
    let rootPriceBook = priceBook;

    while (rootPriceBook.parentPriceBook) {
        rootPriceBook = rootPriceBook.parentPriceBook;
    }

    return rootPriceBook;
}

/**
 * Get a product's promotional price
 *
 * @param {dw.catalog.Product} product - Product under evaluation
 * @param {dw.util.Collection.<dw.campaign.Promotion>} promotions - Promotions that apply to this
 *     product
 * @param {dw.catalog.ProductOptionModel} currentOptionModel - The product's option model
 * @return {dw.value.Money} - Promotional price
 */
function getPromotionPrice(product, promotions, currentOptionModel) {
    const PROMOTION_CLASS_PRODUCT = require('dw/campaign/Promotion').PROMOTION_CLASS_PRODUCT;
    const promotion = promotions.toArray().find(function (promo) {
        return promo.promotionClass && promo.promotionClass.equals(PROMOTION_CLASS_PRODUCT);
    });

    let price = Money.NOT_AVAILABLE;

    if (promotion) {
        price = currentOptionModel
            ? promotion.getPromotionalPrice(product, currentOptionModel)
            : promotion.getPromotionalPrice(product, product.optionModel);
    }

    return price;
}

/**
 * Get list price for a product
 *
 * @param {dw.catalog.ProductPriceModel} priceModel - Product price model
 * @return {dw.value.Money} - List price
 */
function getListPrice(priceModel) {
    if (priceModel.price.valueOrNull === null && priceModel.minPrice) {
        return priceModel.minPrice;
    }

    const priceBook = getRootPriceBook(priceModel.priceInfo.priceBook);
    const priceBookPrice = priceModel.getPriceBookPrice(priceBook.ID);

    if (priceBookPrice.available) {
        return priceBookPrice;
    }

    return priceModel.price.available ? priceModel.price : priceModel.minPrice;
}

/**
 * Get range price for a product
 *
 * @param {dw.catalog.Product|dw.catalog.productSearchHit} currentProduct - API object for a current product
 * @param {dw.catalog.ProductPriceModel} priceModel - Product price model
 * @return {RangePrice} - The product's price
 */
function getRangePrice(currentProduct, priceModel) {
    const RangePrice = require('~/cartridge/models/price/range');

    let rangePrice;

    if ((currentProduct.master || currentProduct.variationGroup) && priceModel.priceRange) {
        rangePrice = new RangePrice(priceModel.minPrice, priceModel.maxPrice);
    }

    return rangePrice;
}

/**
 * Retrieves Price instance
 *
 * @param {dw.catalog.Product|dw.catalog.productSearchHit} product - API object for a product
 * @param {boolean} useSimplePrice - Flag as to whether a simple price should be used, used for
 *     product tiles and cart line items.
 * @param {dw.util.Collection<dw.campaign.Promotion>} promotions - Promotions that apply to this
 *                                                                 product
 * @param {dw.catalog.ProductOptionModel} currentOptionModel - The product's option model
 * @return {TieredPrice|RangePrice|DefaultPrice} - The product's price
 */
priceHelper.getProductPrice = function (product, useSimplePrice, promotions, currentOptionModel) {
    const DefaultPrice = require('~/cartridge/models/price/default');
    const TieredPrice = require('~/cartridge/models/price/tiered');
    let priceModel = currentOptionModel
        ? product.getPriceModel(currentOptionModel)
        : product.getPriceModel();
    const priceTable = priceModel.getPriceTable();

    let salesPrice;
    let listPrice;
    let promotionPrice = Money.NOT_AVAILABLE;
    let currentProduct = product;

    // TIERED
    if (priceTable.quantities.length > 1) {
        return new TieredPrice(priceTable, useSimplePrice);
    }

    // RANGE
    const rangePrice = getRangePrice(currentProduct, priceModel);

    if (rangePrice && rangePrice.min.sales.value !== rangePrice.max.sales.value) {
        return rangePrice;
    }

    // DEFAULT
    if ((currentProduct.master || currentProduct.variationGroup) && currentProduct.variationModel.variants.length > 0) {
        currentProduct = currentProduct.variationModel.variants[0];
        priceModel = currentProduct.priceModel;
    }

    promotionPrice = getPromotionPrice(currentProduct, promotions, currentOptionModel);
    listPrice = getListPrice(priceModel);
    salesPrice = priceModel.price;

    if (promotionPrice && promotionPrice.available && salesPrice.compareTo(promotionPrice)) {
        salesPrice = promotionPrice;
    }

    if (salesPrice && listPrice && salesPrice.value === listPrice.value) {
        listPrice = null;
    }

    if (salesPrice.valueOrNull === null && (listPrice && listPrice.valueOrNull !== null)) {
        salesPrice = listPrice;
        listPrice = {};
    }
    return new DefaultPrice(salesPrice, listPrice);
};

module.exports = priceHelper;
