'use strict';

const prefs = require('~/cartridge/config/braintreePreferences');
const btBusinessLogic = require('~/cartridge/scripts/braintree/braintreeAPI/braintreeBusinessLogic');

const processorHelper = require('~/cartridge/scripts/braintree/payment/processor/processorHelper');
const customerHelper = require('~/cartridge/scripts/braintree/helpers/customerHelper');

const BTGraphQLSdk = require('*/cartridge/models/btGraphQLSdk');
const btGraphQLSdk = new BTGraphQLSdk();

/**
 * Perform API call to create new(sale) transaction
 * @param {dw.order.Order} order Current order
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument Used payment instrument
 * @return {Object} Response data from API call
 */
function createSaleTransactionData(order, paymentInstrument) {
    const data = processorHelper.createBaseSaleTransactionData(order, paymentInstrument, prefs);

    data.descriptor = { name: prefs.paypalDescriptorName || '' };
    // Flag to recognize PayPal transaction
    data.isPaypal = true;

    if (prefs.isPaypalFraudToolsEnabled) {
        data.deviceData = paymentInstrument.custom.braintreeFraudRiskData;
    }

    return data;
}

/**
 * Save result of the success sale transaction
 * @param {dw.order.Order} order Current order
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument Current payment instrument
 * @param {Object} response Response data from API call
 */
function saveTransactionData(order, paymentInstrument, response) {
    const paypalTransactionData = response.transaction;
    const paypalPaymentMethodData = paypalTransactionData.paymentMethod || response.billingAgreementWithPurchasePaymentMethod;

    // Save token for lightning order managment
    if (!empty(paypalPaymentMethodData) && empty(paymentInstrument.creditCardToken)) {
        paymentInstrument.creditCardToken = paypalPaymentMethodData.legacyId;
    }

    processorHelper.saveGeneralTransactionData(order, paymentInstrument, paypalTransactionData);
}

/**
 * Create billing address for PayPal account
 * @param {dw.order.Order} order Current order
 * @return {Object} Object with billing address
 */
function createPaypalBillingAddress(order) {
    const billingAddress = order.getBillingAddress();

    return {
        firstName: billingAddress.getFirstName(),
        lastName: billingAddress.getLastName(),
        countryCodeAlpha2: billingAddress.getCountryCode().value,
        locality: billingAddress.getCity(),
        streetAddress: billingAddress.getAddress1(),
        extendedAddress: billingAddress.getAddress2(),
        postalCode: decodeURIComponent(billingAddress.getPostalCode()),
        region: billingAddress.getStateCode(),
        phone: billingAddress.getPhone()
    };
}

/**
* Update stored PayPal account billing address
* @param {Object} createPaymentMethodResponseData payment method response data
* @param  {string} accountAddresses Braintree paypal account addresses
* @param {dw.customer.Customer} customer A customer object
*/
function updatePaypalAccountBillingAddress(createPaymentMethodResponseData, accountAddresses, customer) {
    const paypalEmail = createPaymentMethodResponseData.details ? createPaymentMethodResponseData.details.email :
        createPaymentMethodResponseData.transaction.paymentMethodSnapshot.payer.email;
    const customerPayPalPaymentInstruments = customer.getProfile().getWallet().getPaymentInstruments(prefs.paymentMethods.BRAINTREE_PAYPAL.paymentMethodId).toArray();

    // Find current buyer's PayPal account and update its billing address
    customerPayPalPaymentInstruments.forEach(function (payPalPaymentInstrument) {
        if (payPalPaymentInstrument.custom.braintreePaymentMethodAccount === paypalEmail) {
            payPalPaymentInstrument.custom.braintreePaypalAccountAddresses = accountAddresses;
        }
    });
}

/**
 * Perform API call to create new(sale) transaction
 * @param {dw.order.Order} order Current order
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument Used payment instrument
 */
function mainFlow(order, paymentInstrument) {
    const saleTransactionRequestData = createSaleTransactionData(order, paymentInstrument);
    const paypalData = btGraphQLSdk.createTransaction(saleTransactionRequestData);
    const paypalTransactionData = paypalData.transaction;
    const paypalPaymentMethodData = paypalTransactionData.paymentMethod || paypalData.billingAgreementWithPurchasePaymentMethod;

    // Throw error in case of unsuccessful status
    processorHelper.verifyTransactionStatus(paypalTransactionData, paymentInstrument, order);
    saveTransactionData(order, paymentInstrument, paypalData);

    if (order.customer.authenticated && prefs.vaultMode) {
        const customerPaymentInstrument = customerHelper.getPaypalCustomerPaymentInstrumentByEmail(
            order.customer, paypalTransactionData.paymentMethodSnapshot.payer.email
        );

        if (paymentInstrument.custom.braintreeSaveCreditCard) {
            const payPalBillingAddress = JSON.stringify(createPaypalBillingAddress(order));

            // Case when buyer procceed with new PayPal account
            if (!customerPaymentInstrument) {
                const token = paypalPaymentMethodData.legacyId;

                processorHelper.savePaypalAccount(paypalData, payPalBillingAddress, token, order.customer);
                customerHelper.clearDefaultProperty(
                    customerHelper.getCustomerPaymentInstruments(prefs.paymentMethods.BRAINTREE_PAYPAL.paymentMethodId, order.customer)
                );
                customerHelper.setBraintreeDefaultCard(order.customer, token);
            } else {
                // Case when buyer go with new PayPal account with the same email as already stored
                updatePaypalAccountBillingAddress(paypalData, payPalBillingAddress, order.customer);
            }
        }
    }

    paymentInstrument.custom.braintreeSaveCreditCard = null;
}

/**
 * Perform API call to create new(sale) transaction
 * @param {dw.order.Order} order Current order
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument Used payment instrument
 */
function intentOrderFlow(order, paymentInstrument) {
    const paymentMethodToken = paymentInstrument.creditCardToken ||
        btBusinessLogic.createPaymentMethod(paymentInstrument.custom.braintreePaymentMethodNonce, order);

    paymentInstrument.custom.braintreeFraudRiskData = null;
    order.custom.isBraintree = true;
    order.custom.isBraintreeIntentOrder = true;

    // Save token for lightning order managment
    if (!paymentInstrument.creditCardToken) {
        paymentInstrument.creditCardToken = paymentMethodToken;
    }
}

/**
 * Authorize payment function
 * @param {dw.order.Order} order A Current order
 * @param {Object} paymentInstrument Payment Instrument
 */
function authorize(order, paymentInstrument) {
    try {
        if (prefs.paypalOrderIntent) {
            intentOrderFlow(order, paymentInstrument);
        } else {
            mainFlow(order, paymentInstrument);
        }
    } catch (error) { // NOSONAR
        throw error;
    }
}

exports.authorize = authorize;
