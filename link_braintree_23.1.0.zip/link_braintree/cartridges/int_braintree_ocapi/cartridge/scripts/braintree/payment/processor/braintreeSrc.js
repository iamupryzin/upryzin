/* eslint-disable require-jsdoc */
'use strict';

const processorHelper = require('~/cartridge/scripts/braintree/payment/processor/processorHelper');
const customerHelper = require('~/cartridge/scripts/braintree/helpers/customerHelper');

const prefs = require('~/cartridge/config/braintreePreferences');

const BTGraphQLSdk = require('*/cartridge/models/btGraphQLSdk');
const btGraphQLSdk = new BTGraphQLSdk();

/**
 * Perform API call to create new(sale) transaction
 * @param {dw.order.Order} order Current order
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument Used payment instrument
 * @return {Object} Response data from API call
 */
function createSaleTransactionData(order, paymentInstrument) {
    if (empty(paymentInstrument.custom.braintreePaymentMethodNonce) && empty(paymentInstrument.creditCardToken)) {
        throw new Error('paymentInstrument.custom.braintreePaymentMethodNonce or paymentInstrument.creditCardToken are empty');
    }

    const data = processorHelper.createBaseSaleTransactionData(order, paymentInstrument, prefs);

    data.deviceData = paymentInstrument.custom.braintreeFraudRiskData;

    return data;
}

/**
 * Authorize payment function
 * @param {dw.order.Order} order A Current order
 * @param {Object} paymentInstrument Instrument
 * @returns {Object} success object
 */
function authorize(order, paymentInstrument) {
    try {
        const saleTransactionRequestData = createSaleTransactionData(order, paymentInstrument);
        const responseData = btGraphQLSdk.createTransaction(saleTransactionRequestData).transaction;
        const paymentTokenData = responseData.paymentMethod;
        // Throw error in case of unsuccessful status
        processorHelper.verifyTransactionStatus(responseData, paymentInstrument, order);

        if (order.customer.authenticated && prefs.vaultMode && paymentInstrument.custom.braintreeSaveCreditCard) {
            processorHelper.saveCreditCardAccount(responseData, paymentInstrument.paymentMethod, order.customer);
            customerHelper.setBraintreeDefaultCard(order.customer, paymentTokenData.legacyId);
        }

        processorHelper.saveGeneralTransactionData(order, paymentInstrument, responseData);
        // Save token for lightning order managment
        if (prefs.vaultMode && empty(paymentInstrument.creditCardToken) && !empty(paymentTokenData)) {
            paymentInstrument.creditCardToken = paymentTokenData.legacyId;
        }

        paymentInstrument.custom.braintreeSaveCreditCard = null;

        return { error: false };
    } catch (error) { // NOSONAR
        throw error;
    }
}

exports.authorize = authorize;
