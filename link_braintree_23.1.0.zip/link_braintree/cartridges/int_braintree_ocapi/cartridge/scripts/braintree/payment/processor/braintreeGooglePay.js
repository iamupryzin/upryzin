'use strict';

const prefs = require('~/cartridge/config/braintreePreferences');
const processorHelper = require('~/cartridge/scripts/braintree/payment/processor/processorHelper');

const BTGraphQLSdk = require('*/cartridge/models/btGraphQLSdk');
const btGraphQLSdk = new BTGraphQLSdk();

/**
 * Perform API call to create new(sale) transaction
 * @param {dw.order.Order} order Current order
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument Used payment instrument
 * @return {Object} Response data from API call
 */
function createSaleTransactionData(order, paymentInstrument) {
    const data = processorHelper.createBaseSaleTransactionData(order, paymentInstrument, prefs);

    data.deviceData = paymentInstrument.custom.braintreeFraudRiskData;

    return data;
}

/**
 * Authorize payment function
 * @param {dw.order.Order} order A Current order
 * @param {Object} paymentInstrument Payment Instrument
 */
function authorize(order, paymentInstrument) {
    try {
        const saleTransactionRequestData = createSaleTransactionData(order, paymentInstrument);
        const responseData = btGraphQLSdk.createTransaction(saleTransactionRequestData).transaction;
        // Throw error in case of unsuccessful status
        processorHelper.verifyTransactionStatus(responseData, paymentInstrument, order);
        processorHelper.saveGeneralTransactionData(order, paymentInstrument, responseData);

        // Save token for lightning order managment
        if (prefs.vaultMode && empty(paymentInstrument.creditCardToken) && !empty(responseData.paymentMethod)) {
            paymentInstrument.creditCardToken = responseData.paymentMethod.legacyId;
        }

        delete session.privacy.googlepayPaymentType;
    } catch (error) { // NOSONAR
        throw error;
    }
}

exports.authorize = authorize;
