'use strict';
/* global dw request empty session */

const PaymentMgr = require('dw/order/PaymentMgr');

const customerHelper = require('~/cartridge/scripts/braintree/helpers/customerHelper');
const processorHelper = require('~/cartridge/scripts/braintree/payment/processor/processorHelper');


const prefs = require('~/cartridge/config/braintreePreferences');

const BTGraphQLSdk = require('*/cartridge/models/btGraphQLSdk');
const btGraphQLSdk = new BTGraphQLSdk();

/**
 * Perform API call to create new(sale) transaction
 * @param {dw.order.Order} order Current order
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument Used payment instrument
 * @return {Object} Response data from API call
 */
function createSaleTransactionData(order, paymentInstrument) {
    const data = processorHelper.createBaseSaleTransactionData(order, paymentInstrument, prefs);

    data.descriptor = { name: prefs.BRAINTREE_VENMO_Descriptor_Name || '' };
    data.deviceData = paymentInstrument.custom.braintreeFraudRiskData;

    return data;
}

/**
 * Save result of the success sale transaction
 * @param {dw.order.Order} order Current order
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument Current payment instrument
 * @param {Object} saleTransactionResponseData Response data from API call
 */
function saveTransactionData(order, paymentInstrument, saleTransactionResponseData) {
    const paymentProcessor = PaymentMgr.getPaymentMethod(prefs.paymentMethods.BRAINTREE_VENMO.paymentMethodId).getPaymentProcessor();

    processorHelper.saveGeneralTransactionData(order, paymentInstrument, saleTransactionResponseData);
    paymentInstrument.getPaymentTransaction().setPaymentProcessor(paymentProcessor);
    // Save token for lightning order managment
    if (!empty(saleTransactionResponseData.paymentMethod) && empty(paymentInstrument.creditCardToken)) {
        paymentInstrument.creditCardToken = saleTransactionResponseData.paymentMethod.legacyId;
    }
}

/**
 * Authorize payment function
 * @param {dw.order.Order} order A Current order
 * @param {Object} paymentInstrument Instrument
 */
function authorize(order, paymentInstrument) {
    try {
        const saleTransactionRequestData = createSaleTransactionData(order, paymentInstrument);
        const responseData = btGraphQLSdk.createTransaction(saleTransactionRequestData).transaction;
        // throw error in case of unsuccessful status
        processorHelper.verifyTransactionStatus(responseData, paymentInstrument, order);
        saveTransactionData(order, paymentInstrument, responseData);

        const existCustomerPaymentInstrument = customerHelper.getVenmoCustomerPaymentInstrument(responseData.paymentMethodSnapshot.venmoUserId, order.customer);

        if (order.customer.authenticated && paymentInstrument.custom.braintreeSaveCreditCard && !existCustomerPaymentInstrument) {
            processorHelper.saveVenmoAccount(responseData, order.customer);
            customerHelper.clearDefaultProperty(
                customerHelper.getCustomerPaymentInstruments(prefs.paymentMethods.BRAINTREE_VENMO.paymentMethodId, order.customer)
            );
            customerHelper.setBraintreeDefaultCard(
                order.customer,
                responseData.paymentMethod.legacyId
            );

            paymentInstrument.custom.braintreeSaveCreditCard = null;
            paymentInstrument.custom.braintreeDefaultCard = null;
        }
    } catch (error) { // NOSONAR
        throw error;
    }
}

exports.authorize = authorize;
