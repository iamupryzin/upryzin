'use strict';

const braintreeConstants = require('~/cartridge/scripts/util/braintreeConstants');

const customerHelper = require('~/cartridge/scripts/braintree/helpers/customerHelper');
const paymentHelper = require('~/cartridge/scripts/braintree/helpers/paymentHelper');

/**
 * Create customer data for API call
 * @param {dw.order.Order} order Order object
 * @return {Object} Customer data for request
 */
function createGuestCustomerData(order) {
    const billingAddress = order.getBillingAddress();
    const shippingAddress = order.getDefaultShipment().getShippingAddress();

    return {
        id: null,
        firstName: billingAddress.getFirstName(),
        lastName: billingAddress.getLastName(),
        email: order.getCustomerEmail(),
        phone: billingAddress.getPhone() || shippingAddress.getPhone(),
        company: '',
        fax: ''
    };
}

/**
 * Save General Transaction Data
 * @param  {dw.order.Order} order Order
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument Order payment instrument
 * @param  {Object} responseTransaction - response transaction
 */
function saveGeneralTransactionData(order, paymentInstrument, responseTransaction) {
    const Money = require('dw/value/Money');
    const PT = require('dw/order/PaymentTransaction');

    const prefs = require('~/cartridge/config/braintreePreferences');
    const paymentTransaction = paymentInstrument.getPaymentTransaction();
    const transaction = responseTransaction.transaction || responseTransaction;
    const transactionStatus = transaction.status;

    paymentTransaction.setTransactionID(transaction.legacyId);
    paymentTransaction.setAmount(new Money(transaction.amount.value, order.getCurrencyCode()));

    order.custom.isBraintree = true;
    order.custom.braintreePaymentStatus = transactionStatus;

    paymentInstrument.custom.braintreePaymentMethodNonce = null;

    if (!prefs.isSettle && transactionStatus === braintreeConstants.TRANSACTION_STATUS_AUTHORIZED) {
        paymentTransaction.setType(PT.TYPE_AUTH);
    } else if (prefs.isSettle &&
        (transactionStatus === braintreeConstants.TRANSACTION_STATUS_SETTLING ||
            transactionStatus === braintreeConstants.TRANSACTION_STATUS_SUBMITTED_FOR_SETTLEMENT)) {
        paymentTransaction.setType(PT.TYPE_CAPTURE);
    }
}

/**
 * Create Base Sale Transaction Data
 * @param  {dw.order.Order} order Order
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument Order payment instrument
 * @param {Object} prefsData preferencies data settings
 * @returns {Object} data fields
 */
function createBaseSaleTransactionData(order, paymentInstrument, prefsData) {
    const customer = order.getCustomer();
    const isCustomerAuthentificated = customer.isAuthenticated();
    const creditCardToken = paymentInstrument.creditCardToken;
    const newPaymentMethodNonce = paymentInstrument.custom.braintreePaymentMethodNonce;
    const isVaultingAllowed = prefsData.vaultMode;

    const data = {
        orderId: order.getOrderNo(),
        amount: paymentHelper.getAmountPaid(order).getValue(),
        currencyCode: order.getCurrencyCode(),
        customFields: paymentHelper.getCustomFields(order, paymentInstrument),
        options: {
            submitForSettlement: prefsData.isSettle
        },
        merchantAccountId: paymentHelper.getMerchantAccountID(order.getCurrencyCode())
    };

    // Case when customer is auth and used stored payment method
    // Nonce is taken from vault namager
    if (isCustomerAuthentificated && creditCardToken) {
        data.customerId = null;
        data.paymentMethodToken = creditCardToken;
    // Case when customer is auth and new payment method is used
    } else if (isCustomerAuthentificated && newPaymentMethodNonce) {
        data.customerId = customerHelper.getCustomerId(customer);
        data.paymentMethodNonce = newPaymentMethodNonce;
        // Add partial capturing functionality for BM (vaultPaymentMethodAfterTransacting property is need for token creation)
        if (isVaultingAllowed) {
            data.vaultPaymentMethodAfterTransacting = {
                when: braintreeConstants.TRANSACTION_VAULT_ON_SUCCESS
            };
        }
    // Case when customer is guest
    } else {
        data.customerId = null;
        data.paymentMethodNonce = paymentInstrument.custom.braintreePaymentMethodNonce;
        // Add partial capturing functionality for BM (vaultPaymentMethodAfterTransacting property is need for token creation)
        if (isVaultingAllowed) {
            data.vaultPaymentMethodAfterTransacting = {
                when: braintreeConstants.TRANSACTION_VAULT_ON_SUCCESS
            };
        }
    }

    const orderShippingAddress = order.getDefaultShipment().getShippingAddress();
    const shipping = paymentHelper.createShippingAddressData(orderShippingAddress);
    const orderLocale = order.getCustomerLocaleID();
    const orderCountry = orderLocale.split('_')[1];
    const orderCountryToLowCase = orderCountry ? orderCountry.toLowerCase() : null;
    const customerShippingAddressCountry = shipping.countryCode.toLowerCase();

    if (orderCountryToLowCase === customerShippingAddressCountry) {
        shipping.countryCode = paymentHelper.getISO3Country(order.getCustomerLocaleID());
    }

    data.shipping = shipping;

    if (prefsData.isL2L3) {
        data.taxAmount = order.getTotalTax().toNumberString();

        if (paymentInstrument.paymentMethod === braintreeConstants.PAYMENT_METHOD_ID_PAYPAL) {
            /** Rounding issues due to discounts, removed from scope due to bug on PayPal / BT end.
                * No ETA on bug fix and not in roadmap.
                *
                * data.shippingAmount = order.getShippingTotalPrice().value;
                * data.discountAmount = paymentHelper.getOrderLevelDiscountTotal(order);
                * data.lineItems = paymentHelper.getLineItems(order.productLineItems);
            */
        } else {
            data.shippingAmount = order.getShippingTotalPrice().toNumberString();
            data.discountAmount = paymentHelper.getOrderLevelDiscountTotal(order);
            data.lineItems = paymentHelper.getLineItems(order);
        }
    }

    return data;
}

/**
 * Verifies if transaction status refers to successful
 * @param {Object} responseTransaction transaction response
 * @param {Object} paymentInstrument Payment instrument
 * @param {Object} order current order
 */
function verifyTransactionStatus(responseTransaction, paymentInstrument, order) {
    const successfulStatuses = [
        braintreeConstants.TRANSACTION_STATUS_AUTHORIZED,
        braintreeConstants.TRANSACTION_STATUS_SETTLED,
        braintreeConstants.TRANSACTION_STATUS_SETTLEMENT_PENDING,
        braintreeConstants.TRANSACTION_STATUS_SETTLING,
        braintreeConstants.TRANSACTION_STATUS_SUBMITTED_FOR_SETTLEMENT
    ];
    const transaction = responseTransaction.transaction || responseTransaction;
    const legacyId = transaction.legacyId;
    const transactionStatus = transaction.status;

    if (successfulStatuses.indexOf(transactionStatus) === -1) {
        if (legacyId) {
            const paymentTransaction = paymentInstrument.getPaymentTransaction();

            paymentTransaction.setTransactionID(legacyId);
            order.custom.braintreePaymentStatus = transactionStatus;
        }

        throw new Error(transactionStatus);
    }
}

/**
* Saves PayPal account
* @param {Object} createPaymentMethodResponseData payment method response data
* @param {string} accountAddresses Braintree paypal account addresses
* @param {string} paypalToken token - is passed from PP processor in case of checkout from PDP/minicart/cart
* @param {dw.customer.Customer} customer The current customer
* @returns {Object} Object with token
*/
function savePaypalAccount(createPaymentMethodResponseData, accountAddresses, paypalToken, customer) {
    const prefs = require('~/cartridge/config/braintreePreferences');
    // token passed from processor || token taken from response in case of saving on account page
    const token = paypalToken || createPaymentMethodResponseData.legacyId;
    const paypalEmail = createPaymentMethodResponseData.details ? createPaymentMethodResponseData.details.email :
        createPaymentMethodResponseData.transaction.paymentMethodSnapshot.payer.email;

    const customerPaymentInstrument = customer.getProfile().getWallet().createPaymentInstrument(
        prefs.paymentMethods.BRAINTREE_PAYPAL.paymentMethodId
    );

    customerPaymentInstrument.setCreditCardType(braintreeConstants.CREDIT_CARD_TYPE_VISA); // hack for MFRA account.js line 99 (paymentInstrument.creditCardType.toLowerCase())
    customerPaymentInstrument.creditCardToken = token;
    customerPaymentInstrument.custom.braintreePaymentMethodAccount = paypalEmail;
    customerPaymentInstrument.custom.braintreePaypalAccountAddresses = accountAddresses;

    return {
        token: token
    };
}

/**
* Saves Venmo account
* @param {Object} createPaymentMethodResponseData payment method response data
* @param {dw.customer.Customer} customer The current customer
* @returns {Object} Object with token
*/
function saveVenmoAccount(createPaymentMethodResponseData, customer) {
    const prefs = require('~/cartridge/config/braintreePreferences');
    const paymentMethodResponseData = createPaymentMethodResponseData.paymentMethodSnapshot || createPaymentMethodResponseData.paymentMethod.details;
    const paymentMethodData = createPaymentMethodResponseData.paymentMethod;
    const customerPaymentInstrument = customer.getProfile().getWallet().createPaymentInstrument(prefs.paymentMethods.BRAINTREE_VENMO.paymentMethodId);

    customerPaymentInstrument.setCreditCardType(braintreeConstants.CREDIT_CARD_TYPE_VISA); // hack for MFRA account.js line 99 (paymentInstrument.creditCardType.toLowerCase())
    customerPaymentInstrument.creditCardToken = paymentMethodData.legacyId;
    customerPaymentInstrument.custom.braintreeVenmoUserId = paymentMethodResponseData.venmoUserId;

    return {
        token: paymentMethodData.legacyId
    };
}

/**
* @param {Object} createPaymentMethodResponseData Payment method response data from Braintree response
* @returns {Object} Card name
 */
function createOwnerName(createPaymentMethodResponseData) {
    const StringUtils = require('dw/util/StringUtils');
    const { firstName, lastName } = createPaymentMethodResponseData.customer;

    return StringUtils.format('{0} {1}', (firstName || ''), (lastName || ''));
}

/**
* Saves parameters of the credit card or Src
* @param {Object} createPaymentMethodResponseData Payment method response data from Braintree response
* @param {string} paymentMethodId Payment method id
* @param {dw.customer.Customer} customer The current customer
* @param {string} creditOwner Credit card owner
* @returns {Object} Object with token
*/
function saveCreditCardAccount(createPaymentMethodResponseData, paymentMethodId, customer, creditOwner) {
    const paymentMethodData = createPaymentMethodResponseData.paymentMethod;
    const response = createPaymentMethodResponseData.paymentMethodSnapshot || paymentMethodData.details;
    const customerWallet = customer.getProfile().getWallet();
    // modify card type to appropriate format
    const type = response.brandCode.toLowerCase();
    const firstTypeSymbol = type.charAt(0);
    const cardType = type.replace(/_/g, ' ').replace(firstTypeSymbol, (firstTypeSymbol).toUpperCase());

    const card = {
        expirationMonth: response.expirationMonth,
        expirationYear: response.expirationYear,
        number: Date.now().toString().substr(0, 11) + response.last4,
        type: cardType,
        paymentMethodToken: paymentMethodData.legacyId,
        owner: creditOwner || createOwnerName(paymentMethodData)
    };

    customerHelper.clearDefaultProperty(paymentHelper.getApplicableCreditCardPaymentInstruments());

    const customerPaymentInstrument = customerWallet.createPaymentInstrument(paymentMethodId);
    customerPaymentInstrument.setCreditCardHolder(card.owner);
    customerPaymentInstrument.setCreditCardNumber(card.number);
    customerPaymentInstrument.setCreditCardExpirationMonth(parseInt(card.expirationMonth, 10));
    customerPaymentInstrument.setCreditCardExpirationYear(parseInt(card.expirationYear, 10));
    customerPaymentInstrument.setCreditCardType(card.type);
    customerPaymentInstrument.creditCardToken = card.paymentMethodToken;
    customerPaymentInstrument.custom.braintreeDefaultCard = true;
    const customerPaymentInstrumentObject = customerPaymentInstrument;

    return {
        customerPaymentInstrument: customerPaymentInstrumentObject,
        error: false
    };
}

/**
* Saves PayPal account
* @param {Object} createPaymentMethodResponseData payment method response data
* @param  {Object} customer current customer object
* @param  {Object} paymentInstrumentCustom - object which contains custom properties we get from a payment instrument
**/
function savePaymentInstrument(createPaymentMethodResponseData, customer, paymentInstrumentCustom) {
    // token passed from processor || token taken from response in case of saving on account page
    const token = createPaymentMethodResponseData.legacyId;

    const instruments = customer.getProfile().getWallet().getPaymentInstruments();
    const iterator = instruments.iterator();

    let currentInstrument = null;
    let instrument = null;

    while (iterator.hasNext()) {
        instrument = iterator.next();

        if (instrument.custom.braintreePaymentMethodNonce === paymentInstrumentCustom.braintreePaymentMethodNonce) {
            currentInstrument = instrument;
            break;
        }
    }

    currentInstrument.creditCardToken = token;
}

module.exports = {
    createGuestCustomerData: createGuestCustomerData,
    saveGeneralTransactionData: saveGeneralTransactionData,
    createBaseSaleTransactionData: createBaseSaleTransactionData,
    verifyTransactionStatus: verifyTransactionStatus,
    savePaypalAccount: savePaypalAccount,
    saveVenmoAccount: saveVenmoAccount,
    saveCreditCardAccount: saveCreditCardAccount,
    savePaymentInstrument: savePaymentInstrument
};
