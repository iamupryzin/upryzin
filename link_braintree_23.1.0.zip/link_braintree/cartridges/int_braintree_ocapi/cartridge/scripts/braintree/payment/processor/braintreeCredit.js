'use strict';

const prefs = require('~/cartridge/config/braintreePreferences');
const paymentHelper = require('~/cartridge/scripts/braintree/helpers/paymentHelper');
const processorHelper = require('~/cartridge/scripts/braintree/payment/processor/processorHelper');
const customerHelper = require('~/cartridge/scripts/braintree/helpers/customerHelper');

const BTGraphQLSdk = require('*/cartridge/models/btGraphQLSdk');
const btGraphQLSdk = new BTGraphQLSdk();

/**
 * Perform API call to create new(sale) transaction
 * @param  {dw.order.Order} order Current order
 * @param  {dw.order.OrderPaymentInstrument} paymentInstrument Used payment instrument
 * @returns {Object} Response data from API call
 */
function createSaleTransactionData(order, paymentInstrument) {
    const data = processorHelper.createBaseSaleTransactionData(order, paymentInstrument, prefs);

    data.descriptor = {
        name: prefs.creditCardDescriptorName || '',
        phone: prefs.creditCardDescriptorPhone || '',
        url: prefs.creditCardDescriptorUrl || ''
    };

    if (prefs.isFraudToolsEnabled) {
        data.deviceData = paymentInstrument.custom.braintreeFraudRiskData;
    }

    return data;
}

/**
 * Save result of the success sale transaction
 * @param {dw.order.Order} orderRecord Current order
 * @param {dw.order.OrderPaymentInstrument} paymentInstrumentRecord Current payment instrument
 * @param {Object} responseTransaction Response data from API call
 */
function saveTransactionData(orderRecord, paymentInstrumentRecord, responseTransaction) {
    const threeDSecureInfo = responseTransaction.paymentMethodSnapshot.threeDSecure;

    // Save token for lightning order managment
    if (!empty(responseTransaction.paymentMethod) && empty(paymentInstrumentRecord.creditCardToken)) {
        paymentInstrumentRecord.creditCardToken = responseTransaction.paymentMethod.legacyId;
    }

    processorHelper.saveGeneralTransactionData(orderRecord, paymentInstrumentRecord, responseTransaction);

    paymentInstrumentRecord.custom.braintree3dSecureStatus = threeDSecureInfo.authenticationStatus || null;
}

/**
 * Authorize payment function
 * @param {dw.order.Order} order A Current order
 * @param {Object} paymentInstrument Payment Instrument
 */
function authorize(order, paymentInstrument) {
    try {
        const saleTransactionRequestData = createSaleTransactionData(order, paymentInstrument);
        const responseData = btGraphQLSdk.createTransaction(saleTransactionRequestData).transaction;
        // throw error in case of unsuccessful status
        processorHelper.verifyTransactionStatus(responseData, paymentInstrument, order);
        saveTransactionData(order, paymentInstrument, responseData);

        if (paymentInstrument.custom.braintreeSaveCreditCard) {
            processorHelper.saveCreditCardAccount(
                responseData,
                paymentInstrument.paymentMethod,
                order.customer,
                paymentInstrument.creditCardHolder
            );
            customerHelper.clearDefaultProperty(paymentHelper.getApplicableCreditCardPaymentInstruments());
            customerHelper.setBraintreeDefaultCard(order.customer, responseData.paymentMethod.legacyId);

            paymentInstrument.custom.braintreeSaveCreditCard = null;
        }
    } catch (error) { // NOSONAR
        throw error;
    }
}

exports.authorize = authorize;
