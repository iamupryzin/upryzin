'use strict';

const prefs = require('~/cartridge/config/braintreePreferences');

const processorHelper = require('~/cartridge/scripts/braintree/payment/processor/processorHelper');

const braintreeConstants = require('~/cartridge/scripts/util/braintreeConstants');

const BTGraphQLSdk = require('*/cartridge/models/btGraphQLSdk');
const btGraphQLSdk = new BTGraphQLSdk();

/**
 * Perform API call to create new(sale) transaction
 * @param {dw.order.Order} order Current order
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument Used payment instrument
 * @return {Object} Response data from API call
 */
function createSaleTransactionData(order, paymentInstrument) {
    const data = processorHelper.createBaseSaleTransactionData(order, paymentInstrument, prefs);

    data.options.submitForSettlement = true;
    data.deviceData = paymentInstrument.custom.braintreeFraudRiskData;

    return data;
}

/**
 * Save result of the success sale transaction
 * @param {dw.order.Order} order Current order
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument Current payment instrument
 * @param {Object} responseTransaction Response data from API call
 */
function saveTransactionData(order, paymentInstrument, responseTransaction) {
    const PT = require('dw/order/PaymentTransaction');
    const paymentTransaction = paymentInstrument.getPaymentTransaction();
    const transactionStatus = responseTransaction.transaction.status;

    if (transactionStatus === braintreeConstants.TRANSACTION_STATUS_SETTLING ||
        transactionStatus === braintreeConstants.TRANSACTION_STATUS_SUBMITTED_FOR_SETTLEMENT) {
        paymentTransaction.setType(PT.TYPE_CAPTURE);
    }

    processorHelper.saveGeneralTransactionData(order, paymentInstrument, responseTransaction);
}

/**
 * Authorize payment function
 * @param {dw.order.Order} order A Current order
 * @param {Object} paymentInstrument Payment Instrument
 */
function authorize(order, paymentInstrument) {
    const saleTransactionRequestData = createSaleTransactionData(order, paymentInstrument);
    const responseTransaction = btGraphQLSdk.createTransaction(saleTransactionRequestData);

    // throw error in case of unsuccessful status
    processorHelper.verifyTransactionStatus(responseTransaction, paymentInstrument, order);
    saveTransactionData(order, paymentInstrument, responseTransaction);
}

exports.authorize = authorize;
