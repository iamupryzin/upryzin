'use strict';

/**
 * It's job, which synchronize transaction statuses on Braintree side with related orders transactions
 */

const Status = require('dw/system/Status');
const Transaction = require('dw/system/Transaction');
const Order = require('dw/order/Order');

/**
 * Update payment status of Braintree orders
 * @param {Array} orders orders Braintree orders
 * @param {Object} PaymentHelper PaymentHelper object
 */
function updateOrders(orders) {
    const btBusinessLogic = require('~/cartridge/scripts/braintree/braintreeAPI/braintreeBusinessLogic');

    const transactions = btBusinessLogic.searchTransactionsByIds(orders);

    let order;

    if (!transactions.error) {
        Transaction.wrap(function () {
            transactions.forEach(function (transaction) {
                order = orders[transaction.node.legacyId];

                if (order) {
                    order.custom.braintreePaymentStatus = transaction.node.status;
                }
            });
        });
    }
}

function execute() { // eslint-disable-line require-jsdoc
    const paymentHelper = require('~/cartridge/scripts/braintree/helpers/paymentHelper');
    const searchQuery = 'custom.isBraintree = {0} AND status != {1} AND custom.braintreePaymentStatus != {2} AND custom.braintreePaymentStatus != {3}';
    const orders = require('dw/object/SystemObjectMgr').querySystemObjects('Order', searchQuery, 'orderNo desc', true, Order.ORDER_STATUS_FAILED, 'voided', 'settled');

    const partSize = 30;

    let ordersPart = {};
    let orderIndex = 1;
    let order;
    let transactionId;

    while (orders.hasNext()) {
        order = orders.next();
        transactionId = paymentHelper.getBraintreePaymentInstrument(order).getPaymentTransaction().getTransactionID();

        if (orderIndex % partSize === 0) {
            ordersPart[transactionId] = order;
            updateOrders(ordersPart);
            ordersPart = {};
        } else {
            ordersPart[transactionId] = order;
        }

        orderIndex++;
    }

    updateOrders(ordersPart);

    return new Status(Status.OK);
}

exports.execute = execute;
