'use strict';

const paymentHelper = require('~/cartridge/scripts/braintree/helpers/paymentHelper');
const customerHelper = require('~/cartridge/scripts/braintree/helpers/customerHelper');
const processorHelper = require('~/cartridge/scripts/braintree/payment/processor/processorHelper');
const btConstants = require('~/cartridge/scripts/util/braintreeConstants');

const BTGraphQLSdk = require('~/cartridge/models/btGraphQLSdk');
const btGraphQLSdk = new BTGraphQLSdk();

const braintreeBusinessLogic = {};

/**
 * Generate client token
 * @param {dw.customer.Customer} customer A customer object
 * @param {string} currencyCode currency code
 * @return {string} Client token value
 */
braintreeBusinessLogic.getClientToken = function (customer, currencyCode) {
    const prefs = require('~/cartridge/config/braintreePreferences');

    if (prefs.tokenizationKey && prefs.tokenizationKey !== '') {
        return prefs.tokenizationKey;
    }

    let clientToken = null;
    let createClientTokeReq = null;

    try {
        createClientTokeReq = {
            accId: paymentHelper.getMerchantAccountID(currencyCode)
        };

        // Case when we need to generate customer specific client token
        if (customer.authenticated) {
            createClientTokeReq.btCustomerId = customerHelper.getCustomerId(customer);
        }

        clientToken = btGraphQLSdk.createClientToken(createClientTokeReq);
    } catch (error) {
        paymentHelper.getLogger().error(error.message);

        throw error;
    }

    return clientToken;
};

/**
 * Make API call, to get customer data if it exists in Braintree
 * @param {dw.customer.Customer} customer Customer object
 * @return {Object} Customer Data with customer ID and error flag
 */
braintreeBusinessLogic.getBraintreeCustomer = function (customer) {
    const response = {
        error: false,
        customerData: null
    };

    try {
        response.customerData = btGraphQLSdk.findCustomer({
            customerId: customerHelper.getCustomerId(customer)
        });
    } catch (error) {
        paymentHelper.getLogger().error(error);

        response.error = true;
    }

    return response;
};

/**
 * Manually create Braintree payment method(on braintree side) for current customer
 * @param {string} nonce Payment method nonce
 * @return {Object} Response data from API call
 */
braintreeBusinessLogic.createPaymentMethodOnBraintreeSide = function (nonce) {
    let responseData = null;

    try {
        responseData = btGraphQLSdk.vaultPaymentMethod({
            customerId: customerHelper.getCustomerId(customer),
            paymentMethodNonce: nonce
        });
    } catch (error) {
        paymentHelper.getLogger().error(error);

        responseData = {
            error: error.customMessage || error.message
        };
    }

    return responseData;
};

/**
 * Creates payment method
 * @param {string} braintreePaymentMethodNonce BT payment method nonce
 * @param {dw.order.OrderMgr} order current order
 * @return {string} payment method ID
 */
braintreeBusinessLogic.createPaymentMethod = function (braintreePaymentMethodNonce, order) {
    let customerId;

    if (customer.isRegistered()) {
        customerId = customerHelper.getCustomerId(customer);
    } else {
        const customerData = processorHelper.createGuestCustomerData(order);

        customerId = btGraphQLSdk.createCustomer(customerData);
    }

    const createPaymentMethodResponseData = btGraphQLSdk.vaultPaymentMethod({
        customerId: customerId,
        paymentMethodNonce: braintreePaymentMethodNonce
    });

    return createPaymentMethodResponseData.paymentMethod.legacyId;
};

/**
 * Deletes payment method from vault on BT side and from customer profile
 * @param {Object} creditCardToken Payment Method details
 */
braintreeBusinessLogic.deletePaymentMethod = function (creditCardToken) {
    // Used for creating a graphQL request and for updating a customer
    try {
        btGraphQLSdk.deletePaymentMethodFromVault({
            creditCardToken: creditCardToken
        });
    } catch (error) {
        paymentHelper.getLogger().error(error);
    }
};

/**
 * Create customer on Braintree side
 * @param {Object} customer current customer profile
 * @returns {boolean} result
 */
braintreeBusinessLogic.createCustomerOnBraintreeSide = function (customer) {
    try {
        const profile = customer.getProfile();

        profile.custom.braintreeCustomerId = btGraphQLSdk.createCustomer({
            firstName: profile.firstName,
            lastName: profile.lastName,
            email: profile.email,
            phone: profile.phoneHome
        });
    } catch (error) {
        paymentHelper.getLogger().error(error);

        return {
            error: error.customMessage || error.message
        };
    }

    return true;
};

/**
 * Search transactions by converted ids
 * @param {Array} orders Braintree orders
 * @return {Object} Search object
 */
braintreeBusinessLogic.searchTransactionsByIds = function (orders) {
    let responseData = {};

    const convertedTransactionsIds = Object.keys(orders).map(function (transactionsId) {
        return btGraphQLSdk.legacyIdConverter(transactionsId, btConstants.LEGACY_ID_TYPE_TRANSACTION);
    }).map(function (convertedTransactionsId) {
        return convertedTransactionsId;
    });

    try {
        responseData = btGraphQLSdk.searchTransactionsByIds({
            ids: convertedTransactionsIds
        });
    } catch (error) {
        return responseData;
    }
    return responseData;
};

module.exports = braintreeBusinessLogic;
