'use strict';

/* global dw request response empty */

const Site = require('dw/system/Site');
const Transaction = require('dw/system/Transaction');

/**
 * @namespace GooglePayConfig
 */

/**
 * Renders configuration template with required configurations and parameters
 */
function start() {
    const PaymentMgr = require('dw/order/PaymentMgr');
    const googlePaySDK = 'https://pay.google.com/gp/p/js/pay.js';

    const isPaymentMethodEnabled = PaymentMgr.getPaymentMethod('GooglePay');

    const buttonStyles = Site.current.getCustomPreferenceValue('GP_API_Button_Styles') || '';
    const cartButtonEnabled = Site.current.getCustomPreferenceValue('BRAINTREE_GOOGLEPAY_Visibility_Button_On_Cart');

    require('dw/template/ISML').renderTemplate('button/googlepay/configuration', {
        googlePaySDK: googlePaySDK,
        buttonStyles: buttonStyles,
        pdpButtonEnabled: false,
        minicartButtonEnabled: false,
        cartButtonEnabled: cartButtonEnabled,
        isPaymentMethodEnabled: isPaymentMethodEnabled
    });
}

/**
 * Save Button configuration to Custom Preference value: GP_API_Button_Styles
 */
function saveButton() {
    response.setContentType('application/json');

    try {
        const params = request.httpParameterMap;
        const data = JSON.parse(Site.current.getCustomPreferenceValue('GP_API_Button_Styles')) || {};

        const buttonStyle = {
            buttonType: params.buttonType.value,
            buttonSizeMode: params.buttonSizeMode.value
        };

        data[params.location.value] = buttonStyle;

        Transaction.wrap(function () {
            Site.current.setCustomPreferenceValue('GP_API_Button_Styles', JSON.stringify(data));
        });

        response.setStatus(200);
        response.writer.print(JSON.stringify({
            options: buttonStyle,
            redirectUrl: require('dw/web/URLUtils').https(
                'Configuration-Start',
                'tab', 'google-pay',
                'location', params.location.value
            ).toString()
        }));
    } catch (error) {
        response.setStatus(500);
        response.writer.print(error.message);
    }
}

start.public = true;
saveButton.public = true;

exports.Start = start;
exports.SaveButton = saveButton;
