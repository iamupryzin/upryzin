'use strict';

/* global dw request response empty */

const Site = require('dw/system/Site');
const Transaction = require('dw/system/Transaction');

/**
 * @namespace ApplePayConfig
 */

/**
 * Renders configuration template with required configurations and parameters
 */
function start() {
    const PaymentMgr = require('dw/order/PaymentMgr');
    const isPaymentMethodEnabled = PaymentMgr.getPaymentMethod('ApplePay');

    const buttonStyles = Site.current.getCustomPreferenceValue('DROPIN_AP_API_Button_Styles') || '';
    const cartButtonEnabled = Site.current.getCustomPreferenceValue('BRAINTREE_APPLEPAY_Visibility_Button_On_Cart');

    require('dw/template/ISML').renderTemplate('button/applepay/configuration', {
        buttonStyles: buttonStyles,
        cartButtonEnabled: cartButtonEnabled,
        isPaymentMethodEnabled: isPaymentMethodEnabled,
        applePayButtonSdk: 'https://applepay.cdn-apple.com/jsapi/v1/apple-pay-sdk.js'
    });
}

/**
 * Save Button configuration to Custom Preference value: DROPIN_AP_API_Button_Styles
 */
function saveButton() {
    response.setContentType('application/json');

    try {
        const AP_API_BUTTON_STYLES = 'DROPIN_AP_API_Button_Styles';
        const params = request.httpParameterMap;
        const data = JSON.parse(Site.current.getCustomPreferenceValue(AP_API_BUTTON_STYLES)) || {};

        const buttonStyle = {
            buttonStyle: params.buttonStyle.value
        };

        data[params.location.value] = buttonStyle;

        Transaction.wrap(function () {
            Site.current.setCustomPreferenceValue(AP_API_BUTTON_STYLES, JSON.stringify(data));
        });

        response.setStatus(200);
        response.writer.print(JSON.stringify({
            options: buttonStyle,
            redirectUrl: require('dw/web/URLUtils').https(
                'Configuration-Start',
                'tab', 'apple-pay',
                'location', params.location.value
            ).toString()
        }));
    } catch (error) {
        response.setStatus(500);
        response.writer.print(error.message);
    }
}

start.public = true;
saveButton.public = true;

exports.Start = start;
exports.SaveButton = saveButton;
