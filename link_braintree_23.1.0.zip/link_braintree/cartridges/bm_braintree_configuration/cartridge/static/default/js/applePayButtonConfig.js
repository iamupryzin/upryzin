'use strict';
((win, doc, $) => {
    const $alert = doc.getElementById('ap-alert');
    const $loader = doc.getElementById('ap-loader');
    const $location = doc.getElementById('ap-location');
    const $buttonStyle = doc.getElementById('ap-button-style');

    const $form = doc.getElementById('apple-pay-config-form');
    const $container = doc.getElementById('apple-pay-container');

    const showAlertMessage = (message) => {
        $alert.textContent = message;
        $alert.classList.remove('d-none');

        setTimeout(() => {
            $alert.textContent = '';
            $alert.classList.add('d-none');
        }, 5000);
    };

    const updateButtonStyleOptionByLocation = (location) => {
        const data = JSON.parse($form.getAttribute('data-button-styles'))[location];

        $buttonStyle.value = data.buttonStyle;
    };

    const rebuildApplePayButton = () => {
        const $applePayBtn = document.getElementById('apple-pay-btn');

        // Builds an Apple pay button by parameters
        $applePayBtn.setAttribute('buttonstyle', $buttonStyle.value);
    };

    const handleLocation = () => {
        updateButtonStyleOptionByLocation($location.value);

        rebuildApplePayButton();
    };


    const handleSubmitForm = (event) => {
        event.preventDefault();

        $loader.classList.remove('d-none');

        $.post(event.currentTarget.action, event.currentTarget.serialize())
            .done((reponse) => {
                win.location.href = reponse.redirectUrl;
            })
            .fail((error) => {
                showAlertMessage(error.responseText);
            })
            .always(() => {
                $loader.classList.add('d-none');
            });
    };

    const applePayInit = () => {
        if ($container) {
            const params = new URLSearchParams(win.location.search);
            const location = params.get('tab') === 'apple-pay' && params.has('location') ? params.get('location') : 'billing';

            $location.value = location;

            updateButtonStyleOptionByLocation(location);

            rebuildApplePayButton();

            $location.addEventListener('change', handleLocation);
            $buttonStyle.addEventListener('change', rebuildApplePayButton);

            $form.addEventListener('submit', handleSubmitForm);
        }
    };

    doc.addEventListener('DOMContentLoaded', applePayInit);
})(window, document, window.jQuery);
