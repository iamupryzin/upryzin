/**
 * Variables
 */
const $colorButton = document.querySelector('#color_button');
const $shapeButton = document.querySelector('#shape_button');
const $size = document.querySelector('#size');
const $label = document.querySelector('#label');
const $locationButton = document.querySelector('#location_button');
const $smartbuttonConfigForm = document.getElementById('smartbutton-config-form');
const paypalCartButtonSelector = '.paypal-cart-button';

/**
 * Appends Alerts message
 *
 * Avaible alerts types:
 * primary,  secondary, success, danger, warning, info, alert, dark
 * @param {Object} alert Alerts and type messages
 */
function showSmartButtonAlertMessage(alert) {
    const alertDiv = document.querySelector('#smart-button-alert-message');
    alertDiv.innerHTML = `<h5>${alert.message}</h5>`;
    alertDiv.className = `alert alert-${alert.type} show`;
    window.scrollTo(0, 0);
}

/**
 * Fades Alerts message
 */
function fadeSmartButtonAlertMessage() {
    const alertDiv = document.querySelector('#smart-button-alert-message');
    alertDiv.innerHTML = '';
    alertDiv.className = 'alert alert-success fade';
}

/**
 * Return style configurations for Pay Pal smart button
 * Available values:
 * color: (string) gold, blue, silver, black, white,
 * shape: (string) pill, rect
 * label: (string) paypal, pay, checkout
 * size: (string) small, medium, large, responsive
 *
 * @param {Object} object with height, color, shape, label, tagline configs
 * @returns {Object} button styles
*/
function getSmartButtonStyleConfigs() {
    return {
        color: $colorButton.value,
        shape: $shapeButton.value,
        layout: 'horizontal',
        label: $label.value,
        size: $size.value
    };
}

/**
 * Update html option's with saved Pay Pal smart button  values from custom pref PP_API_Smart_Button_Styles
 *
 * @param {Object} savedSmartStyles object with color, shape, label, size, location configs
*/
function updateValuesWithStyleConfigs(savedSmartStyles) {
    $colorButton.value = savedSmartStyles.color;
    $shapeButton.value = savedSmartStyles.shape;
    $label.value = savedSmartStyles.label;
    $size.value = savedSmartStyles.size;
    $locationButton.value = savedSmartStyles.location;
}

/**
 * Render PayPal Buttons
 *
 * @param {Object} styleConfiguration button style config
 * @returns {void}
 */
function paypalButtonsRender(styleConfiguration) {
    // eslint-disable-next-line new-cap
    window.paypal.Buttons({
        onInit: (_, actions) => {
            return actions.disable();
        },
        createOrder: () => { },
        onApprove: () => { },
        onCancel: () => { },
        onError: () => { },
        style: styleConfiguration
    }).render(paypalCartButtonSelector);
}

document.addEventListener('DOMContentLoaded', function () {
    let pageType = 'billing';
    const params = (new URLSearchParams(window.location.search));

    if (params.has('savedButtonStyle')) {
        pageType = params.get('savedButtonStyle');
        window.history.replaceState(null, null, window.location.pathname);
    }

    const smartButtonConfig = JSON.parse($smartbuttonConfigForm.getAttribute('data-smart-styles'))[pageType];
    const smartButtonSpecificConfigs = {
        color: smartButtonConfig.color,
        shape: smartButtonConfig.shape,
        size: smartButtonConfig.size,
        layout: 'horizontal',
        label: smartButtonConfig.label,
        location: pageType
    };

    updateValuesWithStyleConfigs(smartButtonSpecificConfigs);
    paypalButtonsRender(smartButtonSpecificConfigs);
});

/**
 * Re-render buttons with a new styles
 * @returns {void}
 */
function updatePayPalButtonRender() {
    document.querySelector(paypalCartButtonSelector).innerHTML = '';
    fadeSmartButtonAlertMessage();
    paypalButtonsRender(getSmartButtonStyleConfigs());
}

$colorButton.addEventListener('change', updatePayPalButtonRender);

$size.addEventListener('change', updatePayPalButtonRender);

$label.addEventListener('change', updatePayPalButtonRender);

$shapeButton.addEventListener('change', updatePayPalButtonRender);

$locationButton.addEventListener('change', () => {
    document.querySelector(paypalCartButtonSelector).innerHTML = '';
    fadeSmartButtonAlertMessage();

    const savedSmartStyles = JSON.parse($smartbuttonConfigForm.getAttribute('data-smart-styles'));
    const locationButton = $locationButton.value;
    const currentSavedSmartStyles = savedSmartStyles[locationButton];

    const smartStyles = {
        color: currentSavedSmartStyles.color,
        shape: currentSavedSmartStyles.shape,
        size: currentSavedSmartStyles.size,
        layout: 'horizontal',
        label: currentSavedSmartStyles.label,
        location: locationButton
    };

    updateValuesWithStyleConfigs(smartStyles);

    // eslint-disable-next-line new-cap
    window.paypal.Buttons({
        onInit: (_, actions) => {
            return actions.disable();
        },
        createOrder: () => { },
        onApprove: () => { },
        onCancel: () => { },
        onError: () => { },
        style: smartStyles
    }).render(paypalCartButtonSelector).then(function () {
        window.scrollTo(0, 0);
    });
});

$smartbuttonConfigForm.addEventListener('submit', (e) => {
    e.preventDefault();

    // eslint-disable-next-line no-undef
    jQuery.post(e.currentTarget.action, e.currentTarget.serialize())
        .done(function (data) {
            location.href = data.redirectUrl;
        })
        .fail(function (err) {
            showSmartButtonAlertMessage({
                message: err.responseText,
                type: 'danger'
            });
        });

    return false;
});
