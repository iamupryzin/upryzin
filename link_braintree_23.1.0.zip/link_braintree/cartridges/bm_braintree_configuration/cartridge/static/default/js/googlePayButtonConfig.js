'use strict';

((win, doc, $, google) => {
    let paymentsClient = null;

    const buttonOptions = {
        buttonColor: 'black',
        buttonType: 'buy',
        buttonSizeMode: 'static',
        onClick: () => {}
    };

    const $alert = doc.getElementById('gp-alert');
    const $loader = doc.getElementById('gp-loader');
    const $location = doc.getElementById('gp-location');

    const $form = doc.getElementById('google-pay-config-form');
    const $container = doc.getElementById('google-pay-container');

    const $buttonType = doc.getElementById('gp-button-type');
    const $buttonSizeMode = doc.getElementById('gp-button-size-mode');

    const getGooglePaymentsClient = () => {
        if (paymentsClient === null) {
            paymentsClient = new google.payments.api.PaymentsClient({ environment: 'TEST' });
        }

        return paymentsClient;
    };

    const updateButtonStyle = (key, value) => {
        $container.innerHTML = '';

        if (key !== undefined) {
            buttonOptions[key] = value;
        }

        const button = getGooglePaymentsClient().createButton(buttonOptions);

        $container.appendChild(button);
    };

    const showAlertMessage = (message) => {
        $alert.textContent = message;
        $alert.classList.remove('d-none');

        setTimeout(() => {
            $alert.textContent = '';
            $alert.classList.add('d-none');
        }, 5000);
    };

    const handleSizeMode = () => {
        updateButtonStyle('buttonSizeMode', $buttonSizeMode.value);
    };

    const handleType = () => updateButtonStyle('buttonType', $buttonType.value);

    const updateButtonOptionsByLocation = (locationKey) => {
        const data = JSON.parse($form.getAttribute('data-button-styles'))[locationKey];

        buttonOptions.buttonType = data.buttonType;
        buttonOptions.buttonSizeMode = data.buttonSizeMode;

        $buttonType.value = data.buttonType;
        $buttonSizeMode.value = data.buttonSizeMode;

        updateButtonStyle();
    };

    const handleLocation = () => {
        updateButtonOptionsByLocation($location.value);
    };

    const handleSubmitForm = (event) => {
        event.preventDefault();

        $loader.classList.remove('d-none');

        $.post(event.currentTarget.action, event.currentTarget.serialize())
            .done((reponse) => {
                win.location.href = reponse.redirectUrl;
            })
            .fail((error) => {
                showAlertMessage(error.responseText);
            })
            .always(() => {
                $loader.classList.add('d-none');
            });
    };

    const googlePayInit = () => {
        if ($container) {
            const params = new URLSearchParams(win.location.search);
            const location = params.get('tab') === 'google-pay' && params.has('location') ? params.get('location') : 'billing';

            $location.value = location;

            updateButtonOptionsByLocation(location);

            $buttonType.addEventListener('change', handleType);

            $buttonSizeMode.addEventListener('change', handleSizeMode);

            $form.addEventListener('submit', handleSubmitForm);
            $location.addEventListener('change', handleLocation);
        }
    };

    doc.addEventListener('DOMContentLoaded', googlePayInit);
})(window, document, window.jQuery, window.google);
