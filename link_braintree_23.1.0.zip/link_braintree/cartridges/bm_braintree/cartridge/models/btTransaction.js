'use strict';

const Money = require('dw/value/Money');

const bmBraintreeHelper = require('*/cartridge/scripts/braintree/bmBraintreeHelper');
const btConstants = require('*/cartridge/config/braintreeConstants');
const BTTransactionMgrModel = require('*/cartridge/models/btTransactionMgr');
const btTransactionMgr = new BTTransactionMgrModel();

/**
 * BT Transaction Model
 * @param {dw.order.orderMgr} order current order
 * @param {Object} transactionObject transaction data
 */
function TransactionModel(order, transactionObject) {
    try {
        const self = this;
        const currency = transactionObject.amount.currencyCode;
        const transactionAmount = new Money(parseFloat(transactionObject.amount.value), currency);

        const initialOrderTransactionId = btTransactionMgr.getInitialOrderTransactionId(order);
        const transactions = btTransactionMgr.getDetailedTransactionsList(order, initialOrderTransactionId);
        const paymentInstrument = bmBraintreeHelper.getBraintreePaymentInstrument(order);
        const paymentTransaction = paymentInstrument.getPaymentTransaction();

        const isEmptyRefunds = empty(transactionObject.refunds);
        const refundTransactions = isEmptyRefunds ? [] : btTransactionMgr.getRefundTransactionsDetails(transactionObject.refunds);
        const refundedAmount = isEmptyRefunds ? new Money(0, currency) : btTransactionMgr.calculateTransactionsAmountValue(refundTransactions, currency);

        const initialOrderTransactionAmount = btTransactionMgr.getInitialOrderTransactionAmount(initialOrderTransactionId, transactions, currency);
        const settledAmount = btTransactionMgr.calculateTransactionsAmountValue(transactions, currency);
        const transactionsRefundedAmount = btTransactionMgr.calculateTotalRefund(transactions, currency);
        const leftToSettle = btTransactionMgr.calculateLeftAmount(initialOrderTransactionAmount, settledAmount).add(transactionsRefundedAmount);
        const leftToRefund = btTransactionMgr.calculateLeftAmount(transactionAmount, refundedAmount);

        const isFullCaptured = leftToSettle.getValue() === 0;
        const isInitialOrderTransactionIdEqualToCurrentTransactionId = initialOrderTransactionId === transactionObject.legacyId;
        const isAbleToCapture = !isFullCaptured && isInitialOrderTransactionIdEqualToCurrentTransactionId;
        // if payment token exists (paymentMethod.legacyId) partial settlement for non-PayPal payment methods is available
        const isPaymentTokenExist = !empty(transactionObject.paymentMethod) && transactionObject.paymentMethod.legacyId;

        Object.keys(transactionObject).forEach(function (property) {
            self[property] = transactionObject[property];
        });

        const braintreeRequest = paymentTransaction.custom.braintreeRequest ? JSON.parse(paymentTransaction.custom.braintreeRequest) : null;
        const braintreeResponse = paymentTransaction.custom.braintreeResponse ? JSON.parse(paymentTransaction.custom.braintreeResponse) : null;

        const whiteSpace = 8;

        // amount related
        this.currency = currency;
        this.initialOrderTransactionAmount = initialOrderTransactionAmount;
        this.settledAmount = settledAmount;
        this.transactionsRefundedAmount = transactionsRefundedAmount;
        this.leftToSettle = leftToSettle;
        this.refundedAmount = refundedAmount;
        this.leftToRefund = leftToRefund;
        this.braintreeRequest = empty(braintreeRequest) ? '' : JSON.stringify(braintreeRequest, null, whiteSpace);
        this.braintreeResponse = empty(braintreeResponse) ? '' : JSON.stringify(braintreeResponse, null, whiteSpace);

        // transaction history
        this.transactionHistoryList = btTransactionMgr.getTransactionHistoryList(transactions);

        // flags
        // isDataUpdateRequired - flag for void action
        this.isDataUpdateRequired = isInitialOrderTransactionIdEqualToCurrentTransactionId;
        this.isAbleToCapture = isAbleToCapture;
        this.isAbleToCaptureByNewTransaction = isAbleToCapture && isPaymentTokenExist;
        this.isAbleToRefund = refundedAmount !== transactionAmount;
        // isPaypal flag - to identify PayPal transaction to determine possible actions for such transaction
        this.isPaypal = !empty(order.getPaymentInstruments(btConstants.PAYMENT_METHOD_ID_PAYPAL));
        this.paymentMethodName = btTransactionMgr.getPaymentMethodName(order);
    } catch (error) {
        bmBraintreeHelper.getLogger().error(error);

        throw error;
    }
}

module.exports = TransactionModel;
