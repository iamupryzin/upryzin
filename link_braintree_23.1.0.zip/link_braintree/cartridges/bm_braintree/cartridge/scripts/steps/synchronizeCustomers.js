/**
 * Step Type that gets the customer's backup file compares it with current SFCC users and in a case, if the customer does not exist already,
 * sends the request to Braintree to remove this customer. Finally, creates a report with all actions made with customers.
 *
 * @module bm_braintree/cartridge/scripts/steps/synchronizeCustomers.js
 *
 * @parameters {CustomerBackupPath} - this parameter is responsible for the path and name of the file from the customer's backup info will be taken
 * @parameters {FileReportPath} - this parameter is responsible for the path and name of the file in which the report will be stored
 */

'use strict';

/* global dw module */

const File = require('dw/io/File');
const Status = require('dw/system/Status');
const Calendar = require('dw/util/Calendar');
const FileWriter = require('dw/io/FileWriter');
const FileReader = require('dw/io/FileReader');
const StringUtils = require('dw/util/StringUtils');
const CustomerMgr = require('dw/customer/CustomerMgr');
const CSVStreamWriter = require('dw/io/CSVStreamWriter');
const CSVStreamReader = require('dw/io/CSVStreamReader');

/**
 * Get logger instance
 * @param {Object} error Error message
 */
const createErrorLog = function (error) {
    const Logger = require('dw/system/Logger');

    const jobLogger = Logger.getLogger('Braintree', 'Braintree_Job_SynchronizeCustomers');

    if (empty(error)) {
        jobLogger.debug('Empty log entry');
    } else {
        jobLogger.error(error.stack ? (error.message + error.stack) : error);
    }
};

/**
 * Deleting the customer from Braintree
 * @param {string} braintreeCustomerId Braintree customer ID
 * @returns {Object} Braintree delete customer response object
 */
function removeCustomerOnBraintreeSide(braintreeCustomerId) {
    const BTGraphQLSdkModel = require('~/cartridge/models/btGraphQLSdk');
    const btGraphQLSdk = new BTGraphQLSdkModel();

    try {
        return btGraphQLSdk.deleteCustomer({
            customerId: braintreeCustomerId
        });
    } catch (error) {
        createErrorLog(error);

        return error.customMessage || error.message;
    }
}

let profiles;
let fileReader;
let fileWriter;
let csvStreamReader;
let csvStreamWriter;
let fileCustomersBackupPath;
let customersBackupFile;

/**
 * Before step function
 * @param {dw.util.HashMap} parameters that are available as scriptable objects for each exposed module function and for the dw.job.JobStepExecution object.
 * @param {dw.job.JobStepExecution} _stepExecution object allows read-only access to information about the current step execution and job execution
 * @returns {Status} in a case when customersBackupFile doesn't exist yet
 */
const beforeStep = function (parameters, _stepExecution) { // eslint-disable-line no-unused-vars
    const dateTime = StringUtils.formatCalendar(new Calendar(), 'yyyy-MM-dd\'T\'hh-mm-ss');
    const fileReportPath = parameters.get('FileReportPath').replace('{DateTime}', dateTime);

    fileCustomersBackupPath = parameters.get('CustomerBackupPath');

    customersBackupFile = File(fileCustomersBackupPath); // eslint-disable-line new-cap

    if (!customersBackupFile.file) {
        return new Status(Status.OK);
    }

    fileReader = new FileReader(customersBackupFile);
    csvStreamReader = new CSVStreamReader(fileReader, ',', '/', 1);
    profiles = csvStreamReader;

    const directoryPath = fileReportPath.match(/.+\//).shift();
    const reportDirectoryPath = File(directoryPath); // eslint-disable-line new-cap

    if (!reportDirectoryPath.exists()) {
        reportDirectoryPath.mkdir();
    }

    const csvFile = new File(fileReportPath);

    fileWriter = new FileWriter(csvFile);
    csvStreamWriter = new CSVStreamWriter(fileWriter);

    csvStreamWriter.writeNext([
        'email',
        'braintreeCustomerId',
        'sfccProfileExist',
        'braintreeCustomerDeleteResult'
    ]);
};

/**
 * Read function
 * @param {dw.util.HashMap} _parameters that are available as scriptable objects for each exposed module function and for the dw.job.JobStepExecution object.
 * @param {dw.job.JobStepExecution} _stepExecution object allows read-only access to information about the current step execution and job execution
 * @returns {Object} Returns the next element from the Iterator.
 */
const read = function (_parameters, _stepExecution) { // eslint-disable-line no-unused-vars
    return profiles && profiles.readNext();
};

/**
 * Process function
 * @param {Object} profile receives the item returned by the read function (current profile, external profile and orders)
 * @param {dw.util.HashMap} _parameters that are available as scriptable objects for each exposed module function and for the dw.job.JobStepExecution object.
 * @param {dw.job.JobStepExecution} _stepExecution object allows read-only access to information about the current step execution and job execution
 * @returns {Object} number of merged items
 */
const process = function (profile, _parameters, _stepExecution) { // eslint-disable-line no-unused-vars
    const braintreeCustomerId = profile[1];
    const sfccProfileExist = !!CustomerMgr.searchProfile('custom.braintreeCustomerId = {0}', braintreeCustomerId);
    const resultMessage = sfccProfileExist ? 'No deletion was performed' : removeCustomerOnBraintreeSide(braintreeCustomerId);

    return {
        email: profile[0],
        braintreeCustomerId: braintreeCustomerId,
        sfccProfileExist: sfccProfileExist,
        braintreeCustomerDeleteResult: resultMessage
    };
};

/**
 * Write function
 * @param {dw.util.List} lines a list of items
 * @param {dw.util.HashMap} _parameters that are available as scriptable objects for each exposed module function and for the dw.job.JobStepExecution object.
 * @param {dw.job.JobStepExecution} _stepExecution object allows read-only access to information about the current step execution and job execution
 */
const write = function (lines, _parameters, _stepExecution) { // eslint-disable-line no-unused-vars
    lines.toArray().forEach(function (line) {
        csvStreamWriter.writeNext([
            line.email,
            line.braintreeCustomerId,
            line.sfccProfileExist,
            line.braintreeCustomerDeleteResult
        ]);
    });
};

/**
 * After step function
 * @param {boolean} success step status
 * @param {dw.util.HashMap} _parameters that are available as scriptable objects for each exposed module function and for the dw.job.JobStepExecution object.
 * @param {dw.job.JobStepExecution} _stepExecution object allows read-only access to information about the current step execution and job execution
 */
const afterStep = function (success, _parameters, _stepExecution) { // eslint-disable-line no-unused-vars
    csvStreamWriter && csvStreamWriter.close(); // eslint-disable-line no-unused-expressions
    csvStreamReader && csvStreamReader.close(); // eslint-disable-line no-unused-expressions
    fileWriter && fileWriter.close(); // eslint-disable-line no-unused-expressions
    fileReader && fileReader.close(); // eslint-disable-line no-unused-expressions

    if (success && customersBackupFile.file) {
        const dateTime = StringUtils.formatCalendar(new Calendar(), 'yyyy-MM-dd\'T\'hh-mm-ss');
        const customersBackupZip = [fileCustomersBackupPath.split('.csv')[0], '-', dateTime, '.zip'].join('');
        customersBackupFile.zip(File(customersBackupZip)); // eslint-disable-line new-cap
    }
};

module.exports = {
    beforeStep: beforeStep,
    read: read,
    process: process,
    write: write,
    afterStep: afterStep
};
