/**
 * Job Step Type that creates the Braintree customers backup, which exists on the SFCC side.
 *
 * @module bm_braintree/cartridge/scripts/steps/createCustomersBackup.js
 *
 * @parameters {CustomerBackupPath} - this parameter is responsible for the path and name of the file in which this information will be stored
 */

'use strict';

/* global dw module */
const File = require('dw/io/File');
const FileWriter = require('dw/io/FileWriter');
const CustomerMgr = require('dw/customer/CustomerMgr');
const CSVStreamWriter = require('dw/io/CSVStreamWriter');

let profiles;
let fileWriter;
let csvStreamWriter;

/**
 * Before step function
 * @param {dw.util.HashMap} parameters that are available as scriptable objects for each exposed module function and for the dw.job.JobStepExecution object.
 * @param {dw.job.JobStepExecution} _stepExecution object allows read-only access to information about the current step execution and job execution
 */
const beforeStep = function (parameters, _stepExecution) { // eslint-disable-line no-unused-vars
    const fileCustomerBackupPath = parameters.get('CustomerBackupPath');
    const directoryPath = fileCustomerBackupPath.match(/.+\//).shift();
    const backupDirectoryPath = new File(directoryPath);

    if (!backupDirectoryPath.exists()) {
        backupDirectoryPath.mkdirs();
    }

    profiles = CustomerMgr.searchProfiles('custom.braintreeCustomerId != NULL', 'customerNo ASC');

    const csvFile = new File(fileCustomerBackupPath);

    if (!csvFile.isFile()) {
        csvFile.createNewFile();
    }

    fileWriter = new FileWriter(csvFile);
    csvStreamWriter = new CSVStreamWriter(fileWriter);
    csvStreamWriter.writeNext([
        'Customer Email',
        'Customer Braintree ID'
    ]);
};

/**
 * Total count function
 * @param {dw.util.HashMap} _parameters that are available as scriptable objects for each exposed module function and for the dw.job.JobStepExecution object.
 * @param {dw.job.JobStepExecution} _stepExecution object allows read-only access to information about the current step execution and job execution
 * @returns {number} Returns the total number of items that are available.
 */
const getTotalCount = function (_parameters, _stepExecution) { // eslint-disable-line no-unused-vars
    return profiles.getCount();
};

/**
 * Read function
 * @param {dw.util.HashMap} _parameters that are available as scriptable objects for each exposed module function and for the dw.job.JobStepExecution object.
 * @param {dw.job.JobStepExecution} _stepExecution object allows read-only access to information about the current step execution and job execution
 * @returns {Object} Returns the next element from the Iterator.
 */
const read = function (_parameters, _stepExecution) { // eslint-disable-line no-unused-vars
    return profiles.hasNext() ? profiles.next() : undefined;
};

/**
 * Process function
 * @param {Object} profile receives the item returned by the read function (current profile, external profile and orders)
 * @param {dw.util.HashMap} _parameters that are available as scriptable objects for each exposed module function and for the dw.job.JobStepExecution object.
 * @param {dw.job.JobStepExecution} _stepExecution object allows read-only access to information about the current step execution and job execution
 * @returns {Object} number of merged items
 */
const process = function (profile, _parameters, _stepExecution) { // eslint-disable-line no-unused-vars
    return {
        email: profile.email,
        id: profile.custom.braintreeCustomerId
    };
};

/**
 * Write function
 * @param {dw.util.List} lines a list of items
 * @param {dw.util.HashMap} _parameters that are available as scriptable objects for each exposed module function and for the dw.job.JobStepExecution object.
 * @param {dw.job.JobStepExecution} _stepExecution object allows read-only access to information about the current step execution and job execution
 */
const write = function (lines, _parameters, _stepExecution) { // eslint-disable-line no-unused-vars
    lines.toArray().forEach(function (line) {
        csvStreamWriter.writeNext([
            line.email,
            line.id
        ]);
    });
};

/**
 * After step function
 * @param {boolean} _success step status
 * @param {dw.util.HashMap} _parameters that are available as scriptable objects for each exposed module function and for the dw.job.JobStepExecution object.
 * @param {dw.job.JobStepExecution} _stepExecution object allows read-only access to information about the current step execution and job execution
 */
const afterStep = function (_success, _parameters, _stepExecution) { // eslint-disable-line no-unused-vars
    csvStreamWriter.close();
    fileWriter.close();
};

module.exports = {
    beforeStep: beforeStep,
    getTotalCount: getTotalCount,
    read: read,
    process: process,
    write: write,
    afterStep: afterStep
};
