'use strict';

const system = require('dw/system');
const PaymentMgr = require('dw/order/PaymentMgr');

const BraintreeHelper = {};
const prefs = require('~/cartridge/config/bmBraintreePreferences');
const btConstants = require('~/cartridge/config/braintreeConstants');
const coreHelpers = require('~/cartridge/scripts/helpers/coreHelpers');

/**
 * Creates or get logger
 *
 * @returns {Object} Object with logger for API operation
 */
BraintreeHelper.getLogger = function () {
    const errorMode = prefs.loggingMode === 'none' ? false : prefs.loggingMode;
    const logger = system.Logger.getLogger('Braintree', 'Braintree_General');

    return {
        error: function (msg) {
            if (errorMode) {
                logger.error(msg);
            }
        },
        info: function (msg) {
            if (errorMode && errorMode !== 'errors') {
                logger.info(msg);
            }
        },
        warn: function (msg) {
            if (errorMode && errorMode !== 'errors') {
                logger.warn(msg);
            }
        }
    };
};

/**
 * Remove underscore and capitalize first letter in payment status
 * @param {string} paymentStatus payment status
 * @return {string} Formatted payment status
 */
BraintreeHelper.parseStatus = function (paymentStatus) {
    let result = null;

    try {
        const status = paymentStatus.toLowerCase();
        const firstLetter = status.charAt(0);
        result = status.replace(/_/g, ' ').replace(firstLetter, firstLetter.toUpperCase());
    } catch (error) {
        BraintreeHelper.getLogger().error(error);
    }

    return result;
};

/**
 * Get braintree payment instrument from array of payment instruments
 * @param {dw.order.LineItemCtnr} lineItemContainer Order object
 * @return {dw.order.OrderPaymentInstrument} Braintree Payment Instrument
 */
BraintreeHelper.getBraintreePaymentInstrument = function (lineItemContainer) {
    let paymentInstrument = null;
    let braintreePaymentInstrument = null;

    const paymentInstruments = lineItemContainer.getPaymentInstruments();
    const iterator = paymentInstruments.iterator();
    const paymentProcessors = [
        btConstants.PROCESSOR_NAME_BT_CREDIT,
        btConstants.PROCESSOR_NAME_BT_PAYPAL,
        btConstants.PROCESSOR_NAME_BT_APPLEPAY,
        btConstants.PROCESSOR_NAME_BT_VENMO,
        btConstants.PROCESSOR_NAME_BT_LOCAL,
        btConstants.PROCESSOR_NAME_BT_GOOGLEPAY,
        btConstants.PROCESSOR_NAME_BT_SRC
    ];

    while (iterator.hasNext()) {
        paymentInstrument = iterator.next();

        const paymentProcessorId = PaymentMgr.getPaymentMethod(paymentInstrument.getPaymentMethod()).getPaymentProcessor().getID();

        if (paymentProcessors.indexOf(paymentProcessorId) !== -1) {
            braintreePaymentInstrument = paymentInstrument;

            break;
        }
    }

    return braintreePaymentInstrument;
};

/**
 * Returns Applicable Active Payment Methods
 * @returns {Object} an object with active payment Methods
 */
BraintreeHelper.getApplicablePaymentMethods = function () {
    let paymentInstrument = null;

    const braintreePaymentInstruments = [];
    const activePaymentMethods = PaymentMgr.getActivePaymentMethods();
    const iterator = activePaymentMethods.iterator();
    const paymentProcessors = [
        btConstants.PROCESSOR_NAME_BT_CREDIT,
        btConstants.PROCESSOR_NAME_BT_PAYPAL,
        btConstants.PROCESSOR_NAME_BT_APPLEPAY,
        btConstants.PROCESSOR_NAME_BT_VENMO,
        btConstants.PROCESSOR_NAME_BT_LOCAL,
        btConstants.PROCESSOR_NAME_BT_GOOGLEPAY,
        btConstants.PROCESSOR_NAME_BT_SRC
    ];

    while (iterator.hasNext()) {
        paymentInstrument = iterator.next();

        const paymentProcessorId = paymentInstrument.paymentProcessor ? paymentInstrument.paymentProcessor.ID : '';

        if (paymentProcessors.indexOf(paymentProcessorId) !== -1) {
            braintreePaymentInstruments.push(paymentInstrument);
        }
    }

    return braintreePaymentInstruments;
};

/**
 * Returns Transaction Statistics of payment statuses
 * @returns {Array} an array with the number of orders for each payment status
 */
BraintreeHelper.getPaymentStatusTransactionStatistics = function () {
    let orders;
    const statuses = [];

    const Resource = require('dw/web/Resource');
    const SystemObjectMgr = require('dw/object/SystemObjectMgr');

    const TRANSACTION_STATUSES = btConstants.TRANSACTION_STATUSES;
    const FAILED_STATUSES = btConstants.TRANSACTION_FAILED_STATUSES;

    // to search for orders for which the value of the field is not set
    FAILED_STATUSES.push(null);
    TRANSACTION_STATUSES.push(null);

    TRANSACTION_STATUSES.forEach(function (paymentStatus) {
        orders = SystemObjectMgr.querySystemObjects('Order', 'custom.isBraintree = {0} AND custom.braintreePaymentStatus = {1}', 'orderNo desc', true, paymentStatus);

        const label = paymentStatus ? BraintreeHelper.parseStatus(paymentStatus) : 'N/A';
        const plural = coreHelpers.pluralize(orders.count, Resource.msg('transaction.word', 'braintreebm', null));

        statuses.push({
            label: label,
            count: orders.count,
            value: paymentStatus,
            title: [label, plural].join(' '),
            color: FAILED_STATUSES.includes(paymentStatus) ? 'failure' : 'success'
        });
    });

    orders = null;

    const successfulStatuses = coreHelpers.sortByProperty(
        coreHelpers.filterByProperty(statuses, 'color', 'success'),
        'value'
    );

    const failedStatuses = coreHelpers.sortByProperty(
        coreHelpers.filterByProperty(statuses, 'color', 'failure'),
        'value'
    );

    return successfulStatuses.concat(failedStatuses);
};

/**
 * Returns boolean value whether search query inputs are empty or not
 * @param {string} transactionId transaction Id
 * @param {string} paymentMethod payment Method
 * @param {string} orderNo order No
 * @param {string} paymentStatus payment status
 * @returns {boolean} value
 */
BraintreeHelper.isSearchQueryEmpty = function (transactionId, paymentMethod, orderNo, paymentStatus) {
    return empty(transactionId.value) && empty(paymentMethod.stringValue) && empty(orderNo.stringValue) && empty(paymentStatus.stringValue);
};

/**
 * Gets search type based on submitted search query
 * @param {string} transactionId transaction Id
 * @param {string} paymentMethod payment Method
 * @param {string} paymentStatus payment Status
 * @returns {string} search type
 */
BraintreeHelper.getSearchType = function (transactionId, paymentMethod, paymentStatus) {
    let searchType = btConstants.SEARCH_BY_ORDER_NUMBER;
    const isSearchByTransactionId = transactionId.submitted;
    const isSearchByPaymentMethod = paymentMethod.submitted && !empty(paymentMethod.stringValue);
    const isSearchByPaymentStatus = paymentStatus.submitted && !empty(paymentStatus.stringValue);

    if (isSearchByTransactionId) {
        searchType = btConstants.SEARCH_BY_TRANSACTION_ID;
    } else if (isSearchByPaymentMethod) {
        searchType = btConstants.SEARCH_BY_PAYMENT_METHOD;
    } else if (isSearchByPaymentStatus) {
        searchType = btConstants.SEARCH_BY_PAYMENT_STATUS;
    }

    return searchType;
};

/**
 * Format date string in to the M/dd/yy h:mm format
 * @param {string} isoString date string
 * @return {Date} Date object
 */
BraintreeHelper.convertToDate = function (isoString) {
    const date = isoString.replace('000000Z', '000Z');

    return new Date(date);
};

/**
 * Updates transaction and updatePartialList values for the action 'submit settlement'
 * @param {Object} params data object with values for paymentTransaction, amount, amountValue, reqData, isPaypalPaymentMethod and btTransactionActionsModel
 * @returns {Object} data object with values for transaction and updatePartialList
 */
BraintreeHelper.submitForSettlement = function (params) {
    const paymentTransactionAmount = params.paymentTransaction.getAmount();
    // if transaction is fully (not partially) submitted for settlement
    const isFullSettlementSubmitted = empty(params.amount) || (paymentTransactionAmount.subtract(params.amountValue) <= 0);
    // Indicates whether the amount was settled before the current transaction
    const isAmountSettled = params.reqData.leftToSettle !== paymentTransactionAmount.value.toString();
    // Indicates whether use submitForSettlement API
    const isSubmitForSettlement = (isFullSettlementSubmitted && !isAmountSettled) || !params.isPaypalPaymentMethod;

    if (isSubmitForSettlement) {
        return {
            transaction: params.btTransactionActionsModel.submitForSettlement(params.reqData),
            updatePartialList: false
        };
    }

    return {
        transaction: params.btTransactionActionsModel.submitPartialSettlement(params.reqData),
        updatePartialList: true
    };
};

module.exports = BraintreeHelper;
