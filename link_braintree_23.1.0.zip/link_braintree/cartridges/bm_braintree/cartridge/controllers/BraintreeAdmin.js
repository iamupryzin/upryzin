'use strict';

const Money = require('dw/value/Money');
const Resource = require('dw/web/Resource');
const OrderMgr = require('dw/order/OrderMgr');

const braintreeHelper = require('~/cartridge/scripts/braintree/bmBraintreeHelper');
const btConstants = require('*/cartridge/config/braintreeConstants');
const { render, renderJson, renderError } = require('*/cartridge/scripts/braintree/responseHelper');

const BTTransactionMgrModel = require('*/cartridge/models/btTransactionMgr');
const BTTransactionModel = require('*/cartridge/models/btTransaction');
const BTOrdersPagingModel = require('*/cartridge/models/btOrdersPaging');
const BTTransactionActionsModel = require('*/cartridge/models/btTransactionActions');
const BTOrderMgrModel = require('*/cartridge/models/btOrderMgr');

const hm = request.httpParameterMap;

/**
 *  Gets orders list. Can be filtered by order ID or transaction ID
 */
function orders() {
    let ordersList = null;
    let searchType = null;
    let pagingModel = null;
    let searchByPaymentMethodOrStatusFlag = false;
    const btOrderMgrModel = new BTOrderMgrModel();
    const btOrdersPagingModel = new BTOrdersPagingModel();
    const isSearchQueryEmpty = braintreeHelper.isSearchQueryEmpty(hm.transactionId, hm.paymentMethod, hm.orderNo, hm.paymentStatus);

    // if search query inputs are empty get full orders list
    if (isSearchQueryEmpty) {
        ordersList = btOrderMgrModel.getAllOrders();
    } else {
        // define search type based on submitted search query
        searchType = braintreeHelper.getSearchType(hm.transactionId, hm.paymentMethod, hm.paymentStatus);

        switch (searchType) {
            case btConstants.SEARCH_BY_TRANSACTION_ID:
                ordersList = btOrderMgrModel.getOrdersByTransactionId(hm.transactionId.value);

                break;
            case btConstants.SEARCH_BY_ORDER_NUMBER:
                ordersList = btOrderMgrModel.getOrdersByOrderNo(hm.orderNo.stringValue);

                break;
            case btConstants.SEARCH_BY_PAYMENT_METHOD:
                ordersList = btOrderMgrModel.getOrdersByPaymentMethod(hm.paymentMethod.stringValue);
                searchByPaymentMethodOrStatusFlag = true;

                break;
            case btConstants.SEARCH_BY_PAYMENT_STATUS:
                ordersList = btOrderMgrModel.getOrdersByPaymentStatus(hm.paymentStatus.stringValue);
                searchByPaymentMethodOrStatusFlag = true;

                break;
            default:
                break;
        }
    }

    // if requested order/s exist create dw.web.PagingModel and set its size, paging
    if (!empty(ordersList)) {
        pagingModel = btOrdersPagingModel.createPagingModel(ordersList, searchByPaymentMethodOrStatusFlag);
        btOrdersPagingModel.setPagingModelSize(pagingModel, hm.page, hm.pagesize);
    }

    // set what payment methods are enabled and we can make search by payment method from it's list
    const braintreePaymentInstruments = braintreeHelper.getApplicablePaymentMethods();
    const braintreeTransactionStatistics = braintreeHelper.getPaymentStatusTransactionStatistics();
    const braintreePaymentStatuses = braintreeTransactionStatistics.map(function (paymentStatus) {
        return { value: paymentStatus.value, label: paymentStatus.label, count: paymentStatus.count };
    }).sort(function (prevPaymentStatus, nextPaymentStatus) {
        return prevPaymentStatus.value > nextPaymentStatus.value ? 1 : -1;
    });

    render('braintreebm/transactions/orderslist', {
        PagingModel: pagingModel,
        braintreePaymentStatuses: braintreePaymentStatuses,
        braintreePaymentInstruments: braintreePaymentInstruments,
        braintreeTransactionStatistics: braintreeTransactionStatistics
    });
}

/**
 * Get transaction details
 * @return {*} in case of error render error
 */
function orderTransaction() {
    let btTransactionModel = null;
    const order = OrderMgr.getOrder(hm.orderNo.stringValue, hm.orderToken.stringValue);
    const transactionDetailErrorMessage = Resource.msg('transaction.detail.error', 'braintreebm', null);

    try {
        if (!order) {
            return renderError(null);
        }

        const braintreePaymentInstrument = braintreeHelper.getBraintreePaymentInstrument(order);
        const transactionId = empty(hm.transactionId.stringValue) ? braintreePaymentInstrument.getPaymentTransaction().getTransactionID() : hm.transactionId.stringValue;

        if (!transactionId) {
            return renderError(Resource.msg('transaction.detail.error.transactionid', 'braintreebm', null));
        }

        const btTransactionMgrModel = new BTTransactionMgrModel();
        const transaction = btTransactionMgrModel.findTransaction(hm.transactionType.stringValue, transactionId);

        if (!transaction) {
            return renderError(transactionDetailErrorMessage);
        }

        // update order payment status based on initial transaction status
        const btOrderMgrModel = new BTOrderMgrModel();
        btOrderMgrModel.updateBtPaymentStatusOfOrder(order, transaction.status, transactionId);

        // extend transaction object with required data such as refundedAmount, settledAmount, flags, etc.
        btTransactionModel = new BTTransactionModel(order, transaction);
    } catch (error) {
        // if error message is intended for user we display it, otherwise show standard error msg
        return renderError(error.isBusinessLogic ? error.message : transactionDetailErrorMessage);
    }

    return render('braintreebm/transactions/ordertransaction', {
        Order: order,
        Transaction: btTransactionModel
    });
}

/**
 * Do actions like Settle, Refund and etc.
 * @return {*} in case of error render error
 */
function action() {
    const Transaction = require('dw/system/Transaction');

    let transaction = null;
    let order = null;
    let paymentInstrument = null;
    let paymentTransaction = null;
    let initialOrderPaymentStatus = null;
    let amountValue = null;
    let isPaypalPaymentMethod = null;

    const method = hm.get('method').getStringValue();
    const amount = hm.get('amount').getDoubleValue();
    const orderNo = hm.get('orderNo').getStringValue();
    const orderToken = hm.get('orderToken').getStringValue();
    let updatePartialList = hm.get('updatePartialList').getBooleanValue() || false;

    // orderNo is not available in case of ACTION_NEW_TRANSACTION_FROM_VAULT
    if (orderNo && orderToken) {
        order = OrderMgr.getOrder(orderNo, orderToken);
        paymentInstrument = braintreeHelper.getBraintreePaymentInstrument(order);
        paymentTransaction = paymentInstrument.getPaymentTransaction();
        initialOrderPaymentStatus = order.custom.braintreePaymentStatus || '';
        amountValue = amount && new Money(amount, paymentTransaction.getAmount().getCurrencyCode());
        isPaypalPaymentMethod = paymentInstrument.paymentMethod === btConstants.PAYMENT_METHOD_ID_PAYPAL;
    }

    const btTransactionActionsModel = new BTTransactionActionsModel();
    const btOrderMgrModel = new BTOrderMgrModel();

    const reqData = {};

    hm.parameterNames.toArray().forEach(function (name) {
        reqData[name] = hm.get(name).getStringValue();
    });

    try {
        switch (method) {
            case btConstants.ACTION_SUBMIT_FOR_SETTLEMENT: {
                const actionSubmitForSettlement = braintreeHelper.submitForSettlement({
                    paymentTransaction: paymentTransaction,
                    amount: amount,
                    amountValue: amountValue,
                    reqData: reqData,
                    isPaypalPaymentMethod: isPaypalPaymentMethod,
                    btTransactionActionsModel: btTransactionActionsModel
                });

                transaction = actionSubmitForSettlement.transaction;
                updatePartialList = actionSubmitForSettlement.updatePartialList;

                break;
            }
            case btConstants.ACTION_REFUND:
                transaction = btTransactionActionsModel.refund(reqData);

                break;
            case btConstants.ACTION_VOID:
                transaction = btTransactionActionsModel.void(reqData);

                btOrderMgrModel.updateBraintreePaymentStatus(order, transaction.status);

                break;
            case btConstants.ACTION_VOID_WITHOUT_UPDATE:
                transaction = btTransactionActionsModel.voidWithoutUpdate(reqData);

                break;

            case btConstants.ACTION_SUBMIT_FOR_PARTIAL_SETTLEMENT_FOR_NON_PP_TRANSACTION:
                // simulating partial capture transaction for non PayPal transactions by adding isSubmitForSettlement flag
                if (paymentInstrument && !isPaypalPaymentMethod) {
                    reqData.isSubmitForSettlement = true;
                }

                transaction = btTransactionActionsModel.newTransactionFromVault(reqData);

                break;

            case btConstants.ACTION_NEW_TRANSACTION_FROM_VAULT:
                transaction = btTransactionActionsModel.newTransactionFromVault(reqData);

                break;
            case btConstants.ACTION_CREATE_INTENT_ORDER_TRANSACTION:
                reqData.isSubmitForSettlement = JSON.parse(reqData.isSubmitForSettlement);
                transaction = btTransactionActionsModel.newTransactionFromVault(reqData);

                btOrderMgrModel.updateIntentOrderData(order, paymentTransaction, transaction);

                break;
            default:
                break;
        }
    } catch (error) {
        // if error message is intended for user we display it, otherwise show standard error msg
        return renderJson('Error', error.isBusinessLogic ? error.message : Resource.msg('transaction.detail.error', 'braintreebm', null));
    }

    if (updatePartialList) {
        btOrderMgrModel.updatePartialTransactionsList(order, transaction.legacyId);
    }
    // used to detect whether the removal of a payment method is allowed
    const btTransactionModel = new BTTransactionModel(order, transaction);

    Transaction.wrap(function () {
        order.custom.leftToSettle = btTransactionModel.leftToSettle.value;
    });

    if (order && initialOrderPaymentStatus !== order.custom.braintreePaymentStatus) {
        return renderJson('Success', null, {
            orderNo: orderNo,
            paymentStatus: braintreeHelper.parseStatus(order.custom.braintreePaymentStatus)
        });
    }
    return renderJson('Success');
}

/**
 * Return template for AJAX call
 */
function merchantView() {
    render(hm.template.stringValue, {
        httpParameterMap: hm
    });
}

/*
* Web exposed methods
*/

orders.public = true;
orderTransaction.public = true;
action.public = true;
merchantView.public = true;

exports.Orders = orders;
exports.OrderTransaction = orderTransaction;
exports.Action = action;
exports.MerchantView = merchantView;
