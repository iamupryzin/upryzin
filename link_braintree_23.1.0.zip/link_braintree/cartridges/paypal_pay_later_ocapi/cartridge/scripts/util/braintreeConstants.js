module.exports = {
    // Pages flows
    PAGE_FLOW_CHECKOUT: 'checkout',
    PAGE_FLOW_PDP: 'pdp',
    PAGE_FLOW_MINICART: 'minicart',
    PAGE_FLOW_CART: 'cart',
    PAGE_FLOW_ACCOUNT: 'account',
    // OCAPI Error types
    CUSTOM_ERROR_TYPE: 'customError'
};
