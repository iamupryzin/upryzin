'use strict';

const Resource = require('dw/web/Resource');

const { getLogger } = require('~/cartridge/scripts/braintree/helpers/paymentHelper');

const braintreeApiCalls = {};

/**
 * Call API request
 *
 * @param {Object} requestData Request data
 * @returns {Object} Response data
 */
function call(requestData) {
    const createGQService = require('~/cartridge/scripts/service/braintreeGraphQLService');
    let service = null;
    let result = null;

    try {
        service = createGQService();
    } catch (error) {
        throw new Error(Resource.msg('braintree.service.noconfigurations', 'locale', null));
    }

    try {
        result = service.call(requestData);
    } catch (error) {
        getLogger().error(error);
        error.customMessage = Resource.msg('braintree.server.error.parse', 'locale', null);

        throw error;
    }

    if (!result.isOk()) {
        throw new Error(Resource.msg('braintree.server.error', 'locale', null));
    }

    return service.getResponse();
}

braintreeApiCalls.call = call;
module.exports = braintreeApiCalls;
