'use strict';

const Logger = require('dw/system/Logger');
const Status = require('dw/system/Status');
const currentSite = require('dw/system/Site').getCurrent();

const braintreeConstants = require('~/cartridge/scripts/util/braintreeConstants');

/**
 * If the credit message is available and the vault mode is enabled, then return the banner configs
 * @param {dw.order.Basket} basket The current Basket
 * @param {string} pageId - The page ID of the page you're on
 * @returns {Object} with additional banner configs
 */
function getCartMinicartBannerConfigs(basket, pageId) {
    const creditMessageAvailable = currentSite.getCustomPreferenceValue('PP_Show_On_Cart');
    const { vaultMode } = require('*/cartridge/config/braintreePreferences');
    const { cartMessageConfig } = require('~/cartridge/config/creditMessageConfig');
    const { isPaypalButtonEnabled } = require('*/cartridge/scripts/braintree/helpers/paymentHelper');

    if (vaultMode && creditMessageAvailable) {
        const configs = {
            bannerConfig: cartMessageConfig,
            creditMessageAvailable: creditMessageAvailable,
            paypalAmount: basket.totalGrossPrice.value
        };

        if (pageId === braintreeConstants.PAGE_FLOW_CART) {
            configs.isCartButtonEnabled = isPaypalButtonEnabled(pageId);
        }

        if (pageId === braintreeConstants.PAGE_FLOW_MINICART) {
            configs.isMinicartButtonEnabled = isPaypalButtonEnabled(pageId);
        }

        return configs;
    }
    return null;
}

/**
 * The function modify get response by adding custom attributes
 * Used in the follwing resource: /baskets
 * @param {dw.order.Basket} basket The current basket
 * @param {basketResponse} basketResponse Document representing a basket.
 * @returns {Status} new Status. Depends of hook execution OK/ERROR
 */
function modifyGETResponse(basket, basketResponse) {
    try {
        const { createObjectFromQueryString } = require('*/cartridge/scripts/braintree/helpers/hooksHelper');

        const httpQueryStringArray = request.httpQueryString.split('&');
        const queryStringObject = createObjectFromQueryString(httpQueryStringArray);
        const pageId = queryStringObject.pageId;

        if (pageId === braintreeConstants.PAGE_FLOW_CART || pageId === braintreeConstants.PAGE_FLOW_MINICART) {
            // Add credit banners configuration
            basketResponse.c_paypalBannersConfig = getCartMinicartBannerConfigs(basket, pageId);
        }

        return new Status(Status.OK);
    } catch (error) {
        Logger.error(error);
        return new Status(Status.ERROR, braintreeConstants.CUSTOM_ERROR_TYPE, error);
    }
}

exports.modifyGETResponse = modifyGETResponse;
