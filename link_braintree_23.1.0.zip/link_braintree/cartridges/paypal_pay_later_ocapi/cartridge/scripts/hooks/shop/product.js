'use strict';

const Logger = require('dw/system/Logger');
const Status = require('dw/system/Status');
const currentSite = require('dw/system/Site').getCurrent();

const braintreeConstants = require('*/cartridge/scripts/util/braintreeConstants');

/**
 * If the credit message is available, and the PayPal button is enabled, then return the banner config
 * @returns {Object} with three properties:
 * bannerConfig: productDetailMessageConfig,
 * creditMessageAvailable: creditMessageAvailable,
 * isPDPButtonEnabled: isPaypalButtonEnabled(braintreeConstants.PAGE_FLOW_PDP)
 */
function getPdpBannerConfigs() {
    const { productDetailMessageConfig } = require('~/cartridge/config/creditMessageConfig');
    const { isPaypalButtonEnabled } = require('*/cartridge/scripts/braintree/helpers/paymentHelper');
    const creditMessageAvailable = currentSite.getCustomPreferenceValue('PP_Show_On_PDP');
    const { vaultMode } = require('*/cartridge/config/braintreePreferences');

    if (vaultMode && creditMessageAvailable) {
        return {
            bannerConfig: productDetailMessageConfig,
            creditMessageAvailable: creditMessageAvailable,
            isPDPButtonEnabled: isPaypalButtonEnabled(braintreeConstants.PAGE_FLOW_PDP)
        };
    }
    return null;
}

/**
 * The hook that performs the adding of additional PayPal credit financial info when we search products
 * @param {dw.catalog.Product} _ object which represents chosen product
 * @param {Object} documentResponse object which represents the response document we are modifying
 * @returns {Status} status of hook execution
**/
function modifyGETResponse(_, documentResponse) {
    try {
        documentResponse.c_paypalProductBannersConfig = getPdpBannerConfigs();
        return new Status(Status.OK);
    } catch (error) {
        Logger.error(error);
        return new Status(Status.ERROR, braintreeConstants.CUSTOM_ERROR_TYPE, error);
    }
}

exports.modifyGETResponse = modifyGETResponse;
