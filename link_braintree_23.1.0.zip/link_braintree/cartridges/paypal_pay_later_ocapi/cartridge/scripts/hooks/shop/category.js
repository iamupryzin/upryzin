'use strict';

const Status = require('dw/system/Status');
const Logger = require('dw/system/Logger');
const currentSite = require('dw/system/Site').getCurrent();

const btBusinessLogic = require('*/cartridge/scripts/braintree/braintreeAPI/braintreeBusinessLogic');
const braintreeConstants = require('*/cartridge/scripts/util/braintreeConstants');

/**
 * Returns a specific pdp page config object
 * @returns {Object} An object
 */
function getPlpBannerConfigs() {
    const creditMessageAvailable = currentSite.getCustomPreferenceValue('PP_Show_On_Category');
    const { vaultMode } = require('*/cartridge/config/braintreePreferences');

    if (vaultMode && creditMessageAvailable) {
        const { categoryMessageConfig } = require('~/cartridge/config/creditMessageConfig');
        const basket = require('dw/order/BasketMgr').getCurrentBasket();
        const clientToken = btBusinessLogic.getClientToken(customer, currentSite.getDefaultCurrency());

        return {
            bannerConfig: categoryMessageConfig,
            clientToken: clientToken,
            paypalAmount: (basket && basket.totalGrossPrice.value) || 0,
            creditMessageAvailable: creditMessageAvailable
        };
    }
    return null;
}

/**
 * The hook that performs the adding of additional PayPal credit financial info when we search products
 * @param {dw.catalog.Category} _ object which represents chosen product category
 * @param {Object} documentResponse object which represents the response document we are modifying
 * @returns {Status} status of hook execution
**/
function modifyGETResponse(_, documentResponse) {
    try {
        documentResponse.c_paypalCategoryBannersConfig = getPlpBannerConfigs();
        return new Status(Status.OK);
    } catch (error) {
        Logger.error(error);
        return new Status(Status.ERROR, braintreeConstants.CUSTOM_ERROR_TYPE, error);
    }
}

exports.modifyGETResponse = modifyGETResponse;
