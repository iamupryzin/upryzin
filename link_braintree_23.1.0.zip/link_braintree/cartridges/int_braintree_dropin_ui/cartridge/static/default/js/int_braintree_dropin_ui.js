'use strict';

var button = document.querySelector('#dropin-request-payment-method-button');
var token = document.querySelector('#dropin-container').getAttribute('data-client-token');

// eslint-disable-next-line no-undef
braintree.dropin.create({
    authorization: token,
    container: '#dropin-container',
    paypal: {
        flow: 'checkout',
        amount: '10.00',
        currency: 'USD'
    },
    venmo: true
}, function (createErr, instance) {
    button.addEventListener('click', function () {
        instance.requestPaymentMethod(function (requestPaymentMethodErr, payload) {
            console.log(requestPaymentMethodErr, payload);
        });
    });
});
