'use strict';

var dropinSdk = require('../dropinsdk/dropinSdk');

/**
 * A DropinAccount constructor
 * @param {Object} errorHandlingModelInstance A error handling model instance
 * @param {DOMElement} $addCardButton An add card button
 * @param {DOMElement} $dropinContainer A Drop-in container
 * @param {Object} paymentMethodsConfigurations A payment configurations object
 * @param {DOMElement} $closeAlertButton A close alert button
 * @param {Object} errorHandlingDuplicateCClModelInstance A error handling model instance
 */
function DropinAccountModel(
    errorHandlingModelInstance,
    $addCardButton,
    $dropinContainer,
    paymentMethodsConfigurations,
    $closeAlertButton,
    errorHandlingDuplicateCClModelInstance
) {
    this.$addCardButton = $addCardButton;
    this.$closeAlertButton = $closeAlertButton;
    this.$dropinContainer = $dropinContainer;
    this.dropinSdk = dropinSdk;
    this.dropinConfigs = paymentMethodsConfigurations.dropinConfigs;
    this.errorHandlingModelInstance = errorHandlingModelInstance;
    this.errorHandlingDuplicateCClModelInstance = errorHandlingDuplicateCClModelInstance;
}

/**
 * Returns a PayPal configs object
 * @returns {Object} A PayPal configs object
 */
DropinAccountModel.prototype.getPayPalConfigs = function () {
    return {
        flow: 'vault'
    };
};

/**
 * Initiates a Drop-in on account Page
 * @returns {Promise} A promise
 */
DropinAccountModel.prototype.initDropIn = function () {
    var dropinAccountInstance = this;

    // Clears a '__paypal_storage__' item from the local storage in order to avoid paypal sdk conflicts
    // Can happens when PayPal style configuration in bm was used
    window.localStorage.removeItem('__paypal_storage__');

    return this.dropinSdk.initDropinOnAccountPage(this)
        .then(function (dropinInstance) {
            // Inits onChangeActive view event listener
            dropinAccountInstance.dropinSdk.onChangeActiveView(dropinInstance, dropinAccountInstance);

            dropinAccountInstance.$addCardButton.addEventListener('click', function () {
                dropinAccountInstance.errorHandlingModelInstance.hideError();
                dropinAccountInstance.dropinSdk.requestPaymentMethod(
                    dropinInstance,
                    dropinAccountInstance.dropinConfigs
                )
                    .then(function (payload) {
                        dropinAccountInstance.dropinSdk.checkIfDuplicateCCSubmitted(dropinInstance, payload);
                    });
            });

            dropinAccountInstance.$closeAlertButton.addEventListener('click', function () {
                dropinAccountInstance.errorHandlingDuplicateCClModelInstance.hideError();
            });
        })
        .catch(function (error) {
            dropinAccountInstance.errorHandlingModelInstance.showErrorByObject(error);
        });
};

module.exports = DropinAccountModel;
