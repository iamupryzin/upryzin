'use strict';

const ErrorHandlingBaseModel = require('./errorHandlingBaseModel');

/**
 * Error Handling Duplicate credit card model constructor
 * @param {Object} errorMessages object with error messages
 */
function ErrorHandlingDuplicateCCModel() {
    ErrorHandlingBaseModel.call(this);

    this.$errorContainer = document.querySelector('.js-dropin-alert-container');
    this.$errorContainerMsg = document.querySelector('.js-dropin-alert-container-msg-txt');
}

/**
 * ES5 inheritance
 */
ErrorHandlingDuplicateCCModel.prototype = Object.create(ErrorHandlingBaseModel.prototype);

// See corresponding method inside "ErrorHandlingBaseModel" model

ErrorHandlingDuplicateCCModel.prototype.createErrorNotification = function (errorMessage) {
    this.$errorContainer.classList.remove('hide');
    this.$errorContainerMsg.innerText = errorMessage;
};

ErrorHandlingDuplicateCCModel.prototype.showDefaultErrorMessage = function () {
    const parsedDatasetBraintree = JSON.parse(document.getElementById('dropin-container').dataset.braintree);
    const failOnDuplicateCreditCardErrorMessage = parsedDatasetBraintree.dropinCustomConfigs.errorMessages.failOnDuplicateCreditCardErrorMessage;

    this.createErrorNotification(failOnDuplicateCreditCardErrorMessage);
};

// See corresponding method inside "ErrorHandlingBaseModel" model
ErrorHandlingDuplicateCCModel.prototype.hideError = function () {
    this.$errorContainer.classList.add('hide');
};

module.exports = ErrorHandlingDuplicateCCModel;
