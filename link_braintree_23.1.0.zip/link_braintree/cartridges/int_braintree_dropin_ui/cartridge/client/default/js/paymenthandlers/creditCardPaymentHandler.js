'use strict';

const dropInHelper = require('../helpers/dropInHelper');

/**
 * Fills all Credit card payment fields that is necessary for process payment on the server side
 * @param {tokenizePayload} payload A Credit card tokenizePayload
 */
function fillCreditCardPaymentFields(payload) {
    var payloadDetails = payload.details;
    var $creditCardFieldsCardNumber = document.querySelector('input[name=dwfrm_billing_creditCardFields_cardNumber]');

    document.querySelector('#braintreeCardType').value = dropInHelper.convertCreditCardType(payloadDetails.cardType);
    document.querySelector('#braintreeCardMaskNumber').value = '************' + payloadDetails.lastFour;
    document.querySelector('#braintreeCardExpirationMonth').value = payloadDetails.expirationMonth;
    document.querySelector('#braintreeCardExpirationYear').value = payloadDetails.expirationYear.substr(2);
    document.querySelector('#braintreeCardHolder').value = payloadDetails.cardholderName;

    if ($creditCardFieldsCardNumber) {
        $creditCardFieldsCardNumber.value = '************' + payloadDetails.lastFour;
    }

    document.querySelector('input[name=braintreePaymentMethodNonce]').value = payload.nonce;
    document.querySelector('input[name=braintreeDeviceData]').value = payload.deviceData;
}

/**
 * Process a Credit card tokenizePayload in order to handle an order on the server side
 * @param {tokenizePayload} payload A Credit card tokenizePayload
 */
function checkoutPaymentProcessing(payload) {
    fillCreditCardPaymentFields(payload);
}

module.exports = {
    checkoutPaymentProcessing
};
