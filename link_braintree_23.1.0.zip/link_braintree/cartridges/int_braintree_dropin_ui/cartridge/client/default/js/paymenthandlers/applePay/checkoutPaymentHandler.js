'use strict';

var billingFormHelper = require('../../helpers/billingFormHelper');

/**
 * Fills all Apple pay payment fields that is necessary for process payment on the server side
 * @param {tokenizePayload} payload An Apple pay tokenizePayload
 */
function fillApplePayPaymentFields(payload) {
    var googlePayDetails = payload.details;
    document.querySelector('#braintreeApplePayNonce').value = payload.nonce;

    document.querySelector('#braintreeApplePayDeviceData').value = payload.deviceData;
    document.querySelector('#braintreeGooglepayPaymentType').value = googlePayDetails.cardType;
}

/**
 * Process an Apple pay tokenizePayload from the Checkout page
 * @param {tokenizePayload} payload An Apple pay tokenizePayload
 */
function paymentProcessing(payload) {
    var paymentData = payload.details.rawPaymentData;
    var applePayBillingAddress = paymentData.billingContact;
    var apDetails = {
        firstName: applePayBillingAddress.givenName,
        lastName: applePayBillingAddress.familyName,
        phone: paymentData.shippingContact.phoneNumber
    };
    var storeFrontBillingData = billingFormHelper.mapBraintreeWithDwBillingAddress(
        billingFormHelper.getSuitableApplePayBillingAddress(applePayBillingAddress),
        apDetails
    );

    fillApplePayPaymentFields(payload);
    billingFormHelper.updateBillingFormValues(storeFrontBillingData);
}

module.exports = {
    paymentProcessing
};
