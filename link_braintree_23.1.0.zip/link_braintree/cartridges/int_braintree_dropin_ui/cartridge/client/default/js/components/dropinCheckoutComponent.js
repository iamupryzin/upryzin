'use strict';

const DropinBaseModel = require('../models/dropinBaseModel');
const ErrorHandlingCheckoutModel = require('../errorhandler/errorHandlingCheckoutModel');
const ErrorHandlingDuplicateCCModel = require('../errorhandler/errorHandlingDuplicateCCModel');

// Helpers
const dropInHelper = require('../helpers/dropInHelper');
const loaderInstance = require('../helpers/loaderHelper');

/**
 * Initiates all necessary drop-in components
 */
function init() {
    // Variables needed for creation of "DropinBaseModel" instance
    const $submitPaymentButton = document.querySelector('.js_dropin-checkout-submit-btn');
    const $addCardButton = document.querySelector('.js_dropin-addCard-btn');
    const $closeAlertButton = document.querySelector('.js-dropin-alert-container-close-btn');
    const $dropinContainer = document.getElementById('dropin-container');
    const $totalAmountElement = document.querySelector('.grand-total-sum');
    const dropinLoader = loaderInstance(document.querySelector('.js_braintreeDropinLoader'));
    const paymentMethodsConfigurations = dropInHelper.getBraintreeConfigs($dropinContainer);
    const dropinConfigs = paymentMethodsConfigurations.dropinConfigs;
    const errorHandlingCheckoutModelInstance = new ErrorHandlingCheckoutModel(dropinConfigs.errorMessages);
    const errorHandlingDuplicateCClModelInstance = new ErrorHandlingDuplicateCCModel(dropinConfigs.errorMessages);
    const DropInModelInstance = new DropinBaseModel(
        dropinLoader,
        $totalAmountElement,
        errorHandlingCheckoutModelInstance,
        $submitPaymentButton,
        $addCardButton,
        $dropinContainer,
        paymentMethodsConfigurations,
        errorHandlingDuplicateCClModelInstance,
        $closeAlertButton
    );

    if (!dropinConfigs.isApplePayEnabledInDropIn || !window.ApplePaySession) {
        DropInModelInstance.initDropIn();
    } else {
        // Inits applePayInstance in order fill drop in component with Apple pay
        DropInModelInstance.createApplePayInstance()
            .then(function (apInstance) {
                DropInModelInstance.initApplePayInstance(apInstance);

                return DropInModelInstance.initDropIn();
            })
            .catch(function (error) {
                errorHandlingCheckoutModelInstance.showErrorByObject(error);
            });
    }
}

module.exports = {
    init
};
