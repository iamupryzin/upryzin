'use strict';

// Helpers
var dropinPaymentMethodHelper = require('./dropInPaymentMethodsHelper');
var dropinHelper = require('./dropInHelper');

/**
 * Gets a valid payment method type for the Drop-in
 * @param {string} pmType A payment method type
 * @returns {string} A valid payment method type for the Drop-in
 */
function getValidDropInPmType(pmType) {
    var type = '';

    switch (pmType) {
        case 'PayPalAccount':
            type = 'paypal';
            break;
        case 'CreditCard':
            type = 'card';
            break;
        default:
    }

    return type;
}

/**
 * Handles all necessary functions of billing checkout page
 * @param {Object} activePaymentMethod The active payment method object
 * @param {DOMElement} $dropinContainer A dropin container
 */
function handleBillingCheckoutFunctionality(activePaymentMethod, $dropinContainer) {
    var activePmType = activePaymentMethod ? getValidDropInPmType(activePaymentMethod.type) : '';
    // Whether show or hide the billing address info message on billing page
    dropinPaymentMethodHelper.handleBillingAddressInfoAlert(activePmType);

    // Sets active payment method type in data attribute
    $dropinContainer.setAttribute('data-active-dropin-payment-method-type', activePmType);

    if (activePmType !== '') {
        // Sets active class to the appropriate payment method tab
        dropinPaymentMethodHelper.handleDropInActivePaymentMethodTab({
            newViewId: activePmType,
            previousViewId: ''
        });
        dropinPaymentMethodHelper.handleBillingAddressFunctiinality(activePmType);
    } else {
        // Hides 'Place order' button in case no saved payment methods
        dropinHelper.continueButtonToggle(false);
    }
}

/**
 * Return payment method name in lovercase
 * @param {string} paymentMethodName Payment method name
 * @returns {string} Paymnet method name
 */
function getPaymentMethodToLowerCase(paymentMethodName) {
    var paymentMethod = paymentMethodName.split('_');
    if (paymentMethod.length === 1) {
        return paymentMethodName;
    }
    paymentMethod.forEach(function (element, index) {
        paymentMethod[index] = element.charAt(0) + element.slice(1).toLocaleLowerCase();
    });
    return paymentMethod[1] ?
        `${paymentMethod[0]} ${paymentMethod[1]}` :
        paymentMethod[0];
}

/**
 * Updates checkout view
 * @param {Object} e Event object
 * @param {Object} data Data object
 */
function updateCheckoutView(e, data) {
    var $paymentSummary = document.querySelector('.summary-details .braintree-payment-details');
    var htmlToAppend = '';
    var order = data.order;
    var payment = order.billing.payment;

    if (payment && payment.selectedPaymentInstruments
        && payment.selectedPaymentInstruments.length > 0) {
        var selectedPaymentInstrument = payment.selectedPaymentInstruments[0];
        var paymnetMethodId = selectedPaymentInstrument.paymentMethod;

        htmlToAppend += `<div>${getPaymentMethodToLowerCase(paymnetMethodId)}</div>`;
        if (selectedPaymentInstrument.maskedCreditCardNumber) {
            htmlToAppend += `<div>${selectedPaymentInstrument.maskedCreditCardNumber}</div>`;
        }
        if (paymnetMethodId === 'PayPal') {
            htmlToAppend += `<div>${selectedPaymentInstrument.braintreePaypalEmail}</div>`;
        }
        if (paymnetMethodId === 'Venmo') {
            htmlToAppend += `<div>${selectedPaymentInstrument.braintreeVenmoUserId}</div>`;
        }
        if (selectedPaymentInstrument.type) {
            htmlToAppend += `<div>${selectedPaymentInstrument.type}</div>`;
        }
        htmlToAppend += `<div>${order.priceTotal.charAt(0)}${selectedPaymentInstrument.amount}</div>`;
    }

    if ($paymentSummary) {
        $paymentSummary.innerHTML = htmlToAppend;
    }
}

    /**
 * Method override default SFRA payment-details filling behavior.
 * Method fill payment-details block with the right payment methdo data (like name, account, etc.)
 */
function fillPaymentSummaryContainer() {
    var $summaryDetails = document.querySelector('.summary-details .payment-details');

    if ($summaryDetails) {
        $summaryDetails.classList.add('braintree-payment-details');
        $summaryDetails.classList.remove('payment-details');

        $('body').on('checkout:updateCheckoutView', updateCheckoutView);
    }
}

module.exports = {
    handleBillingCheckoutFunctionality,
    fillPaymentSummaryContainer,
    getValidDropInPmType
};
