'use strict';

var payPalCartPageHelper = require('../../helpers/payPalCartPageHelper');
var requestHelper = require('../../helpers/requestHelper');

var isPayPalBillingAddressExist;

/**
 * Process a PayPal tokenizePayload on the Cart page
 * @param {tokenizePayload} payload A PayPal tokenize payload
 * @param {Object} dropinInstance A dropin model instance
 */
function paymentProcessing(payload, dropinInstance) {
    var payloadDetails = payload.details;
    var $cartPayPalWrapper = document.querySelector('.braintree-dropin-cart-paypal-wrap');
    var $csrfToken = document.querySelector('.braintree-dropin-cart-paypal-wrap #csrf_token');
    var paypalCheckoutFormFields = JSON.parse($cartPayPalWrapper.getAttribute('data-paypal-checkout-form-fields'));
    var billingAddressData;
    var billingFormData;
    var shippingAddressData;
    isPayPalBillingAddressExist = Boolean(payloadDetails.billingAddress);

    if (isPayPalBillingAddressExist) {
        billingAddressData = payPalCartPageHelper.createBillingAddressData(payloadDetails);

        // Create form data only with billing address
        billingFormData = payPalCartPageHelper.createPayPalBillingAddressFormData(paypalCheckoutFormFields, billingAddressData);

        // Create a shipping address object, stringify it and store in FormData as an input
        payPalCartPageHelper.appendBillingAddressAsStringToFormData(billingFormData, billingAddressData);
    } else {
        billingFormData = new FormData();
    }

    // Indicates whether show or hide a billing address on the order confirmation page
    billingFormData.append('braintreeDropinIsPayPalBillingAddressExist', isPayPalBillingAddressExist);

    payPalCartPageHelper.appendCsrfTokenToFormData(billingFormData, $csrfToken);

    payPalCartPageHelper.appendFraudDataToFormData(billingFormData, payload.deviceData);

    if (payloadDetails.shippingAddress) {
        shippingAddressData = payPalCartPageHelper.createShippingAddressData(payloadDetails);

        payPalCartPageHelper.appendShippingDataAsStringToFormData(billingFormData, shippingAddressData);
    }

    payPalCartPageHelper.appendEmailAsStringToFormData(billingFormData, payloadDetails.email);

    payPalCartPageHelper.appendBtPaymentFieldsToFormData(billingFormData, payload);

    // Submit customer form with email (CheckoutServices-SubmitCustomer)
    // as we skip step "login via guest/registered user" while express checkout
    // email is set only in case of guest checkout and if email is not already set
    requestHelper.submitCustomerForm(payloadDetails.email);

    requestHelper.updateShippingMethodsList(
        dropinInstance.payPalConfigurations.updateShippingMethodsListUrl,
        payPalCartPageHelper.prepareShippingAddressFormData(payloadDetails)
    );

    requestHelper.submitPaymentDataToServerPromise(
        billingFormData,
        dropinInstance
    );
}

module.exports = {
    paymentProcessing
};
