'use strict';

/**
 * Fills all Venmo payment fields that is necessary for process payment on the server side
 * @param {tokenizePayload} payload A Venmo tokenizePayload
 */
function fillVenmoPaymentFields(payload) {
    document.querySelector('input[name=braintreeVenmoNonce]').value = payload.nonce;
    document.querySelector('input[name=braintreeVenmoUserId]').value = payload.details.username;
}

/**
 * Process a Venmo tokenizePayload in order to handle an order on the server side
 * @param {tokenizePayload} payload A Venmo tokenizePayload
 */
function checkoutPaymentProcessing(payload) {
    fillVenmoPaymentFields(payload);
}

module.exports = {
    checkoutPaymentProcessing
};
