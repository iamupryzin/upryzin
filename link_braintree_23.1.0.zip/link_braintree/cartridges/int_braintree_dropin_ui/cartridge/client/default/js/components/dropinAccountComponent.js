'use strict';

const DropinAccountModel = require('../models/dropinAccountModel');
const ErrorHandlingBaseModel = require('../errorhandler/errorHandlingBaseModel');
const ErrorHandlingDuplicateCCModel = require('../errorhandler/errorHandlingDuplicateCCModel');

// Helpers
const dropinHelper = require('../helpers/dropInHelper');
const dropinAccountHelper = require('../helpers/dropinAccountHelper');

/**
 * Initiates all necessary drop-in components
 */
function init() {
    // Variables needed for creation of "DropinAccountModel" instance
    const $dropinContainer = document.getElementById('dropin-container');
    const $addCardButton = document.querySelector('.js_dropin-addCard-btn');
    const $closeAlertButton = document.querySelector('.js-dropin-alert-container-close-btn');
    const paymentMethodsConfigurations = dropinHelper.getBraintreeConfigs($dropinContainer);
    const dropinConfigs = paymentMethodsConfigurations.dropinConfigs;
    const errorHandlingBaseModelInstance = new ErrorHandlingBaseModel(dropinConfigs.errorMessages);
    const errorHandlingDuplicateCClModelInstance = new ErrorHandlingDuplicateCCModel(dropinConfigs.errorMessages);
    const DropInAccountModelInstance = new DropinAccountModel(
        errorHandlingBaseModelInstance,
        $addCardButton,
        $dropinContainer,
        paymentMethodsConfigurations,
        $closeAlertButton,
        errorHandlingDuplicateCClModelInstance
    );

    DropInAccountModelInstance.initDropIn()
        .then(function () {
            dropinAccountHelper.handlePaymentOptionsInDropin(paymentMethodsConfigurations);
            dropinAccountHelper.removeMethodsLabelFromDropin();
            dropinAccountHelper.createDropinMainLabel(dropinConfigs);
            dropinAccountHelper.modifyDropinLabels(dropinConfigs);
            dropinAccountHelper.removeBraintreeMethodCheckContainers();
        })
        .catch(function (error) {
            errorHandlingBaseModelInstance.showErrorByObject(error);
        });
}

module.exports = {
    init
};
