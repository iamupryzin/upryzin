'use strict';

/**
 * A DropinGooglePay constructor
 * @param {Object} paymentMethodsConfigurations A Google pay configurations object
 */
function DropinGooglePayModel(
    paymentMethodsConfigurations
) {
    this.googlePayConfiguration = paymentMethodsConfigurations.googlepayButtonConfig;
}

/**
 * Gets a Google pay configuration object for Drop-in
 * @param {string} amount A total amount
 * @returns {Objectt} A Google pay configuration object for Drop-in
 */
DropinGooglePayModel.prototype.getGooglePayConfigs = function (amount) {
    var paymentDataRequest = {
        googlePayVersion: 2,
        transactionInfo: {
            totalPriceStatus: 'FINAL',
            totalPrice: amount,
            currencyCode: this.googlePayConfiguration.options.currency
        },
        allowedPaymentMethods: [{
            type: 'CARD',
            parameters: {
                billingAddressRequired: true,
                billingAddressParameters: {
                    format: 'FULL',
                    phoneNumberRequired: true
                }
            }
        }],
        shippingAddressRequired: true,
        shippingAddressParameters: {
            phoneNumberRequired: true
        },
        emailRequired: true

    };
    var googleMerchantId = this.googlePayConfiguration.googleMerchantId;

    if (googleMerchantId !== null) {
        paymentDataRequest.merchantId = googleMerchantId;
    }

    return paymentDataRequest;
};

module.exports = DropinGooglePayModel;
