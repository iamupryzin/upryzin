'use strict';

/**
 * Removes a Google pay session payment data
 */
function removeGooglePaySessionPaymentData() {
    document.querySelector('#braintreeGooglePayNonce').value = '';
    document.querySelector('#braintreeGooglePayCardDescription').value = '';
    document.querySelector('#braintreeGooglepayPaymentType').value = '';
}

/**
 * Removes an Apple pay session payment data
 */
function removeApplePaySessionPaymentData() {
    document.querySelector('#braintreeApplePayNonce').value = '';
    document.querySelector('#braintreeApplePayDeviceData').value = '';
    document.querySelector('#braintreeGooglepayPaymentType').value = '';
}

/**
 * Removes a Venmo session payment data
 */
function removeVenmoSessionPaymentData() {
    document.querySelector('input[name=braintreeVenmoNonce]').value = '';
    document.querySelector('input[name=braintreeVenmoUserId]').value = '';
}

/**
 * Removes a payPal session payment data
 */
function removePayPalSessionPaymentData() {
    document.querySelector('input[name=braintreePaypalNonce]').value = '';
    document.querySelector('input[name=braintreePaypalEmail]').value = '';
    document.querySelector('input[name=braintreePaypalRiskData]').value = '';
    document.querySelector('input[name=braintreeDropinIsPayPalBillingAddressExist]').value = '';
}

/**
 * Removes a Credit card session payment data
 */
function removeCreditCardSessionPaymentData() {
    var $creditCardFieldsCardNumber = document.querySelector('input[name=dwfrm_billing_creditCardFields_cardNumber]');

    document.querySelector('#braintreeCardType').value = '';
    document.querySelector('#braintreeCardMaskNumber').value = '';
    document.querySelector('#braintreeCardExpirationMonth').value = '';
    document.querySelector('#braintreeCardExpirationYear').value = '';
    document.querySelector('#braintreeCardHolder').value = '';

    if ($creditCardFieldsCardNumber) {
        $creditCardFieldsCardNumber.value = '';
    }

    document.querySelector('input[name=braintreePaymentMethodNonce]').value = '';
    document.querySelector('input[name=braintreeDeviceData]').value = '';
}

/**
 * Handles the process of removing a session payment data
 * @param {string} pmId A payment method id
 */
function removeSessionPaymentData(pmId) {
    switch (pmId) {
        case 'PayPal':
            removePayPalSessionPaymentData();
            break;
        case 'CREDIT_CARD':
            removeCreditCardSessionPaymentData();
            break;
        case 'Venmo':
            removeVenmoSessionPaymentData();
            break;
        case 'ApplePay':
            removeApplePaySessionPaymentData();
            break;
        case 'GooglePay':
            removeGooglePaySessionPaymentData();
            break;
        default:
            break;
    }
}

/**
 * Gets Nonce depending on payment method name
 *
 * @param {string} paymentMethodName - payment method name
 * @returns {boolean} nonce exist
 */
function isNonceExist(paymentMethodName) {
    // Payment method name
    var pmName = paymentMethodName;
    var $nonceInput;

    // Сhange 'CREDIT_CARD' to 'CreditCard' in order to get braintreewCreditCardNonce input
    if (paymentMethodName === 'CREDIT_CARD') {
        pmName = 'CreditCard';
    }

    $nonceInput = document.querySelector(`#braintree${pmName}Nonce`);

    if (!$nonceInput) {
        return false;
    }

    return $nonceInput.value !== '';
}

/**
 * This method is called to remove active session account
 * @returns {function} Function call
 */
function removeActiveSessionPayment() {
    const activePaymentMethods = [];
    var $paymentOptions = document.querySelector('.js-dropin-paymentOptions').children;
    var paymentOptionsInArray = Array.prototype.slice.call($paymentOptions);

    paymentOptionsInArray.forEach(function ($el) {
        activePaymentMethods.push($el.dataset.methodId);
    });

    var activePM = activePaymentMethods.find(function (el) {
        return isNonceExist(el);
    });

    if (activePM) {
        return removeSessionPaymentData(activePM);
    }
}

module.exports = {
    removeActiveSessionPayment
};
