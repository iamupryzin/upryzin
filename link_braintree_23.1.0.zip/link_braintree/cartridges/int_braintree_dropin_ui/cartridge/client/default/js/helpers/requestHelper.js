'use strict';

var dropInHelper = require('../helpers/dropInHelper');

/**
 * Get basket data
 * @param {string} url Braintree-GetOrderInfo url
 * @returns {Object} object with basket data from DW
 */
function getBasketData(url) {
    return $.ajax({
        url: url,
        method: 'GET',
        async: false
    }).responseJSON;
}

/**
 * Callback function to handle the successful response
 *
 * @callback doneCallback
 * @param {object} response successful request response
 */

/**
 * Callback function to handle a failed request
 *
 * @callback failCallback
 * @param {object} error failed request response
 */

/**
 * Update Shipping Methods List
 * @param {string} updateShippingUrl Update Shipping Methods List Url
 * @param {FormData} shippingAddressFormData Shipping form data
 * @param {doneCallback} doneCallback callback function to handle the successful response
 * @param {failCallback} failCallback callback function to handle a failed request
 * @returns {Promise} Promise with response result
 */
function updateShippingMethodsList(updateShippingUrl, shippingAddressFormData, doneCallback, failCallback) {
    return $.ajax({
        type: 'POST',
        url: updateShippingUrl,
        data: shippingAddressFormData,
        contentType: false,
        processData: false
    })
    .done(function (response) {
        if (doneCallback && typeof doneCallback === 'function') {
            doneCallback(response);
        }
    })
    .fail(function (error) {
        if (failCallback && typeof failCallback === 'function') {
            failCallback(error);
        }
    });
}

/**
 * Submit payment (billing) data to the server
 * @param {FromData} billingFormData Billing Form Data
 * @param {Object} dropinInstance A dropin model instance
 * @returns {Promise} Promise with response result
 */
function submitPaymentDataToServerPromise(billingFormData, dropinInstance) {
    var payPalConfigurations = dropinInstance.payPalConfigurations;

    return $.ajax({
        type: 'POST',
        url: payPalConfigurations.paypalHandle,
        data: billingFormData,
        contentType: false,
        processData: false
    })
    .done(function (data) {
        if (data.error) {
            var errorMessage = '';

            if (data.fieldErrors.length) {
                data.fieldErrors.forEach(function (error, index) {
                    var keys = Object.keys(error);
                    if (keys.length) {
                        errorMessage += `${keys[index].replace('dwfrm_billing_', '').replace('_', ' ')} ${data.fieldErrors[index][keys[index]]}. `;
                    }
                });
                dropinInstance.errorHandlingModelInstance.showErrorByMessage(errorMessage);
            }

            if (data.serverErrors.length) {
                data.serverErrors.forEach(function (error) {
                    errorMessage += `${error}. `;
                });
                dropinInstance.errorHandlingModelInstance.showErrorByMessage(errorMessage);
            }

            // Usually in case of any errors "cartError" will be "true"
            if (data.cartError) {
                window.location.href = data.redirectUrl;
            }

            dropinInstance.loader.hide();
        } else {
            sessionStorage.setItem('pageState', 'cart');
            window.location.href = payPalConfigurations.redirectUrl;
            dropinInstance.loader.hide();
        }
    })
    .fail(function (err) {
        dropinInstance.loader.hide();

        if (err && err.redirectUrl) {
            window.location.href = err.redirectUrl;
        }
    });
}

/**
 * Submits customer form with email to CheckoutServices-SubmitCustomer endpoint
 * Call is triggered only in case if email in basket is empty (guest first checkout from cart)
 * @param {string} email email from payment method's response
 * @returns {Ajax} ajax call to CheckoutServices-SubmitCustomer endpoint
 */
function submitCustomerForm(email) {
    var $dropinWrapper = document.querySelector('.braintree-dropin-cart-wrap') ||
        document.querySelector('.braintree-dropin-cart-paypal-wrap');

    var isCustomerEmailEmpty = JSON.parse($dropinWrapper.getAttribute('data-is-customer-email-empty'));
    // Could be "true" only in case if email in basket is empty (first guest checkout from cart)
    if (isCustomerEmailEmpty) {
        const submitCustomerUrl = window.braintreeUrls.submitCustomerUrl;
        var customerFormData = dropInHelper.createCustomerFormData(email);

        return $.ajax({
            type: 'POST',
            url: submitCustomerUrl,
            data: customerFormData,
            contentType: false,
            processData: false
        });
    }
}

/**
 * Add product to the Cart
 * @returns {Object} Response data from DW
 */
function addProductToCart() {
    var $bundleItem = $('.bundle-item');

    /**
     * @param {JQuery} $productContainer  product container element
     * @returns {string} Product options
     */
    function getOptions($productContainer) {
        var options = $productContainer
            .find('.product-option')
            .map(function () {
                var $elOption = $(this).find('.options-select');
                var urlValue = $elOption.val();
                var selectedValueId = $elOption.find(`option[value="${urlValue}"]`)
                    .data('value-id');
                return {
                    optionId: $(this).data('option-id'),
                    selectedValueId: selectedValueId
                };
            }).toArray();

        return JSON.stringify(options);
    }

    var pid = $('.product-detail:not(.bundle-item)').data('pid');
    var $btn = $('.braintree_pdp_button');
    var $productContainer = $btn.closest('.product-detail');

    var form = {
        pid: pid,
        quantity: $('.quantity-select').val()
    };

    if (!$bundleItem.length) {
        form.options = getOptions($productContainer);
    } else {
        var items = $bundleItem.map(function () {
            return {
                pid: $(this).find('.product-id').text(),
                quantity: parseInt($(this).find('label.quantity').data('quantity'), 10)
            };
        });
        form.childProducts = JSON.stringify(items.toArray());
    }

    var response = $.ajax({
        url: $('.add-to-cart-url').val(),
        method: 'POST',
        async: false,
        data: form
    }).responseJSON;
    response.pid = pid;
    return response;
}

/**
 * Submit duplicate credit card data to the server
 * @param {string} url Page url
 * @param {Object} data Credit card data
 * @returns {Promise} Promise with response result
 */
function submitDuplicateCreditCardDataToServerPromise(url, data) {
    return fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: btoa(JSON.stringify(data))
    });
}

module.exports = {
    getBasketData,
    submitPaymentDataToServerPromise,
    submitCustomerForm,
    addProductToCart,
    updateShippingMethodsList,
    submitDuplicateCreditCardDataToServerPromise
};
