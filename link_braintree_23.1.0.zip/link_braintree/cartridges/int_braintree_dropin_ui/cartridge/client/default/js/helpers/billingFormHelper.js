'use strict';

var dropInHelper = require('../helpers/dropInHelper');

// Containers
var $addressSummaryBlock = document.querySelector('.js_dropin_address_summary');
var $orderSummaryBillingInfo = document.querySelector('.js_dropin_order_summary_billinginfo');
var $billingAddressBlock = document.querySelector('.billing-address-block .billing-address');
var $showDetailsButton = document.querySelector('.address-selector-block .btn-show-details');
var $addNewButton = document.querySelector('.address-selector-block .btn-add-new');

/**
 * Update Checkout Billing form values
 *
 * @param {Object} billingData - fields data values
 */
function updateBillingFormValues(billingData) {
    var $billingFormFields = document.querySelectorAll('.billing-address select, .billing-address input, .contact-info-block input');

    $billingFormFields.forEach(function (el) {
        if (billingData[el.name]) {
            el.value = billingData[el.name];
        }
    });
}

/**
 * Fill DW billing form with Billing address from Bt
 * @param {Object} braintreeAddress billing address from Bt
 * @param {Object} btDetails details from bt
 * @returns {Object} object with billing form fields and it's values
 */
function mapBraintreeWithDwBillingAddress(braintreeAddress, btDetails) {
    var $btPaymentMethodWrapper = document.querySelector('.braintree-billing-payment-wrap');
    var dwBillingFormFieldNames = JSON.parse($btPaymentMethodWrapper.getAttribute('data-billing-form-fields-names'));

    dwBillingFormFieldNames.dwfrm_billing_addressFields_firstName = btDetails.firstName;
    dwBillingFormFieldNames.dwfrm_billing_addressFields_lastName = btDetails.lastName;
    dwBillingFormFieldNames.dwfrm_billing_addressFields_address1 = braintreeAddress.line1;
    dwBillingFormFieldNames.dwfrm_billing_addressFields_address2 = braintreeAddress.line2;
    dwBillingFormFieldNames.dwfrm_billing_addressFields_city = braintreeAddress.city;
    dwBillingFormFieldNames.dwfrm_billing_addressFields_postalCode = braintreeAddress.postalCode;
    dwBillingFormFieldNames.dwfrm_billing_addressFields_states_stateCode = braintreeAddress.state;
    dwBillingFormFieldNames.dwfrm_billing_addressFields_country = braintreeAddress.countryCode;
    dwBillingFormFieldNames.dwfrm_billing_contactInfoFields_phone = btDetails.phone;

    return dwBillingFormFieldNames;
}

/**
 * Copy PayPal billing address to DW billing form
 * @param {Object} braintreeBillingAddress billing address from Bt
 * @param {Object} btDetails details from bt
 */
function copyPayPalBillingAddressToDw(braintreeBillingAddress, btDetails) {
    var $braintreePaypalBillingAddressInput = document.querySelector('input[name=braintreePaypalBillingAddress]');
    var paypalBillingData = mapBraintreeWithDwBillingAddress(braintreeBillingAddress, btDetails);

    // Store billing address inside hidden input in order to send it to the server and
    // proccess with billing address server logic (the logic - billing address can't be overrided by
    // buyer. Only paypal billing address should be used)
    $braintreePaypalBillingAddressInput.value = JSON.stringify(paypalBillingData);
    updateBillingFormValues(paypalBillingData);
}

/**
 * Gets a state code by a country code
 * @param {string} countryState A country code
 * @returns {string} A State code
 */
function getStateCode(countryState) {
    var $billingState = document.getElementById('billingState');
    var arrayOfOptions = Array.apply(null, $billingState.options);
    var $stateCodeOption = arrayOfOptions.find(function (option) {
        return option.label === countryState;
    });

    return $stateCodeOption ? $stateCodeOption.id : '';
}

/**
 * Gets a suitable billing address for updating of demandware billing address
 * @param {Object} apBillingAddress An Apple pay billing address
 * @returns {Object} A billing address object
 */
function getSuitableApplePayBillingAddress(apBillingAddress) {
    return {
        line1: apBillingAddress.addressLines[0],
        line2: apBillingAddress.addressLines[1],
        city: apBillingAddress.locality,
        postalCode: apBillingAddress.postalCode,
        state: getStateCode(apBillingAddress.administrativeArea),
        countryCode: apBillingAddress.countryCode
    };
}

/**
 * Gets a suitable billing address for updating of demandware billing address
 * @param {Object} gpBillingAddress A Google pay billing address
 * @returns {Object} A billing address object
 */
function getSuitableGoogllePayBillingAddress(gpBillingAddress) {
    return {
        line1: gpBillingAddress.address1,
        line2: gpBillingAddress.address2,
        city: gpBillingAddress.locality,
        postalCode: gpBillingAddress.postalCode,
        state: getStateCode(gpBillingAddress.administrativeArea),
        countryCode: gpBillingAddress.countryCode
    };
}

/**
 * Shows a billing summary message on order confirmation page intead of a billing address
 */
function showBillingSummaryMessage() {
    dropInHelper.hideHtmlElement($addressSummaryBlock);
    dropInHelper.showHtmlElement($orderSummaryBillingInfo);
}

/**
 * Hides a billing summmary message on order confirmation page and show a billing address
 */
function hideBillingSummaryMessage() {
    dropInHelper.hideHtmlElement($orderSummaryBillingInfo);
    dropInHelper.showHtmlElement($addressSummaryBlock);
}

/**
 * Handles whether show a billing address or a billing summary message on order confirmation page
 * @param {boolean} isPayPalBillingAddressExist Whether a Paypal tolenizePayload contains a billing address or not
 */
function handleSummaryBillingAddress(isPayPalBillingAddressExist) {
    if (isPayPalBillingAddressExist) {
        hideBillingSummaryMessage();
    } else {
        showBillingSummaryMessage();
    }
}

/**
 * Disable a billing address list on checkout page
 */
function disableBillingAddressList() {
    document.getElementById('billingAddressSelector').setAttribute('disabled', 'disabled');
}

/**
 * Enable a billing address list on checkout page
 */
function enableBillingAddressList() {
    document.getElementById('billingAddressSelector').removeAttribute('disabled');
}

/**
 * Hides the billing address manipulation buttons (Update, Add new) on checkout.billing page
 */
function hideBillingAddressManipulationButtons() {
    dropInHelper.hideHtmlElement($showDetailsButton);
    dropInHelper.hideHtmlElement($addNewButton);
}

/**
 * Hides the billing address manipulation buttons(Update, Add new) on checkout.billing page
 */
function showBillingAddressManipulationButtons() {
    dropInHelper.showHtmlElement($showDetailsButton);
    dropInHelper.showHtmlElement($addNewButton);
}

/**
 * Hides biiling address form on billing page for appropriate tabs.
 * Case when customer cliked 'Updated address' or 'Add New' button and flipped through the payment method tabs
 */
function hideBillingAddressForm() {
    dropInHelper.hideHtmlElement($billingAddressBlock);
}

/**
 * Shows biiling address form on billing page for appropriate tabs.
 * Case when customer cliked 'Updated address' or 'Add New' button and flipped through the payment method tabs
 */
function showBillingAddressForm() {
    dropInHelper.showHtmlElement($billingAddressBlock);
}

/**
 * Disabled billing address functionality on billing page
 */
function disableBillingAddressFunctionality() {
    disableBillingAddressList();
    hideBillingAddressManipulationButtons();
    hideBillingAddressForm();
}

/**
 * Enabled billing address functionality on billing page
 */
function enableBillingAddressFunctionality() {
    showBillingAddressManipulationButtons();
    enableBillingAddressList();
    showBillingAddressForm();
}

/**
 * Gets Billing Address Form Values
 *
 * @returns {Object} with Billing Address
 */
function getBillingAddressFormValues() {
    return {
        firstName: document.getElementById('billingFirstName').value,
        lastName: document.getElementById('billingLastName').value,
        phone: document.getElementById('phoneNumber').value,
        address1: document.getElementById('billingAddressOne').value,
        address2: document.getElementById('billingAddressTwo').value,
        city: document.getElementById('billingAddressCity').value,
        stateCode: document.getElementById('billingState').value,
        postalCode: document.getElementById('billingZipCode').value,
        country: document.getElementById('billingCountry').value
    };
}

module.exports = {
    copyPayPalBillingAddressToDw,
    mapBraintreeWithDwBillingAddress,
    getSuitableApplePayBillingAddress,
    getSuitableGoogllePayBillingAddress,
    updateBillingFormValues,
    disableBillingAddressFunctionality,
    enableBillingAddressFunctionality,
    handleSummaryBillingAddress,
    hideBillingSummaryMessage,
    getBillingAddressFormValues
};
