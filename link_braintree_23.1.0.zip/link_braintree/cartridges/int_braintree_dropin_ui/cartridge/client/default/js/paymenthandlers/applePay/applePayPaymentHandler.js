'use strict';

var checkoutPaymentHandler = require('../applePay/checkoutPaymentHandler');
var cartPaymentHandler = require('../applePay/cartPaymentHandler');

var applePayCartPageHelper = require('../../helpers/applePayCartPageHelper');

/**
 * Process an Apple pay tokenizePayload in order to handle an order on the server side
 * @param {tokenizePayload} dropinResponse An Apple pay tokenizePayload
 * @param {string} pageFlow A current page flow
 * @param {Object} dropinModelInstance A dropin model instance
 */
function paymentProcessing(dropinResponse, pageFlow, dropinModelInstance) {
    if (pageFlow === 'checkout') {
        checkoutPaymentHandler.paymentProcessing(dropinResponse);
    } else {
        dropinModelInstance.loader.show();

        var tokenizePayload = applePayCartPageHelper.getTokenizedPaymentData(dropinResponse);

        cartPaymentHandler.paymentProcessing(tokenizePayload, dropinModelInstance);
    }
}

module.exports = {
    paymentProcessing
};
