'use strict';

const requestHelper = require('../helpers/requestHelper');

/**
 * Updates an Drop-in amount for PayPal and PayPal Credit
 * @param {dropinInstance} dropinInstance A Dropin Instance
 * @param {Object} dropinModelInstance A instance of dropin model
 * @param {number} amount The total amount of basket
 */
function updateDropinPayPalAmount(dropinInstance, dropinModelInstance, amount) {
    var amountString = 'amount';

    dropinModelInstance.dropinSdk.updateConfiguration(dropinInstance, {
        property: 'paypal',
        key: amountString,
        value: amount
    });

    dropinModelInstance.dropinSdk.updateConfiguration(dropinInstance, {
        property: 'paypalCredit',
        key: amountString,
        value: amount
    });
}

/**
 * Updates an Drop-in amount for Google Pay
 * @param {dropinInstance} dropinInstance A Dropin Instance
 * @param {Object} dropinModelInstance A instance of dropin model
 * @param {number} amount The total amount of basket
 */
function updateDropinGooglePayAmount(dropinInstance, dropinModelInstance, amount) {
    dropinModelInstance.dropinSdk.updateConfiguration(dropinInstance, {
        property: 'googlePay',
        key: 'transactionInfo',
        value: {
            totalPriceStatus: 'FINAL',
            totalPrice: String(amount),
            currencyCode: dropinModelInstance.googlePayConfiguration.options.currency
        }
    });
}

/**
 * Updates an Drop-in amount for Apple Pay
 * @param {dropinInstance} dropinInstance A Dropin Instance
 * @param {Object} dropinModelInstance A instance of dropin model
 * @param {number} amount The total amount of basket
 */
function updateDropinApplePayAmount(dropinInstance, dropinModelInstance, amount) {
    var applePayPaymentRequest = dropinModelInstance.paymentRequest;
    applePayPaymentRequest.total.amount = String(amount);

    dropinModelInstance.dropinSdk.updateConfiguration(dropinInstance, {
        property: 'applePay',
        key: 'paymentRequest',
        value: applePayPaymentRequest
    });
}

/**
 * Updates a total amount option in Drop-in
 * @param {dropinInstance} dropinInstance A Dropin Instance
 * @param {Object} dropinModelInstance A instance of dropin model
 */
function updateDropinTotalAmount(dropinInstance, dropinModelInstance) {
    var basketData = requestHelper.getBasketData(dropinModelInstance.basketDataUrl);
    var basketAmount = basketData.amount;
    var dropinConfigs = dropinModelInstance.dropinConfigs;
    var $dropinContainer = dropinModelInstance.$dropinContainer;
    var initialAmount = Number($dropinContainer.getAttribute('data-amount'));
    var isAmountChanged = initialAmount !== basketAmount;

    // Updates an amount for PayPal
    if (dropinConfigs.isPayPalEnabledInDropIn && isAmountChanged) {
        updateDropinPayPalAmount(dropinInstance, dropinModelInstance, basketAmount);
    }

    // Updates an amount for Apple Pay
    if (dropinConfigs.pageFlow !== 'minicart' && dropinConfigs.isApplePayEnabledInDropIn && window.ApplePaySession && isAmountChanged) {
        updateDropinApplePayAmount(dropinInstance, dropinModelInstance, basketAmount);
    }

    // Updates an amount for Google Pay
    if (dropinConfigs.pageFlow !== 'minicart' && dropinConfigs.isGooglePayEnabledInDropIn && isAmountChanged) {
        updateDropinGooglePayAmount(dropinInstance, dropinModelInstance, basketAmount);
    }

    $dropinContainer.setAttribute('data-amount', basketAmount);
}

/**
 * Initiates a total amount element observer
 * @param {dropinInstance} dropinInstance A Dropin Instance
 * @param {Object} dropinModelInstance A instance of dropin model
 */
function initTotalAmountElementObserver(dropinInstance, dropinModelInstance) {
    var config = { attributes: true, childList: true, subtree: true };

    var observer = new MutationObserver(() => {
        updateDropinTotalAmount(dropinInstance, dropinModelInstance);
    });

    observer.observe(dropinModelInstance.$totalAmountElement, config);
}

module.exports = {
    initTotalAmountElementObserver
};
