'use strict';

var dropInHelper = require('../helpers/dropInHelper');
var billingFormHelper = require('../helpers/billingFormHelper');
var requestHelper = require('./requestHelper');
var payPalCartPageHelper = require('./payPalCartPageHelper');

// Containers
var $paypalContent = document.querySelector('.js_dropin_paypalContent');
var $creditCardContent = document.querySelector('.js-creditcard-content');
var $googlePayContent = document.querySelector('.js_dropin_googlepayContent');
var $venmoContent = document.querySelector('.js_dropin_venmoContent');
var $applePayContent = document.querySelector('.js_dropin_applepayContent');

// Indicates the payment methods that take billing address from braintree
var takeBillingFromBraintreeList = ['paypal', 'googlePay', 'applePay'];
// All possible payment methods in drop-in
var possiblePaymentMethods = {
    paypal: 'paypal',
    card: 'card',
    googlePay: 'googlePay',
    venmo: 'venmo',
    applePay: 'applePay'
};

/**
 * Gets a valid payment method id by payment method string
 * @param {string} string A payment method string
 * @returns {string} A payment method id
 */
function getPaymentMethodIdByPaymentMethodString(string) {
    var paymentMethodId;

    switch (string) {
        case 'Paying with PayPal':
            paymentMethodId = possiblePaymentMethods.paypal;
            break;
        case 'Paying with Google Pay':
            paymentMethodId = possiblePaymentMethods.googlePay;
            break;
        case 'Paying with Venmo':
            paymentMethodId = possiblePaymentMethods.venmo;
            break;
        case 'Paying with Apple Pay':
            paymentMethodId = possiblePaymentMethods.applePay;
            break;
        default:
            paymentMethodId = possiblePaymentMethods.card;
            break;
    }

    return paymentMethodId;
}

/**
 * Gets a valid view ids object
 * A sample of keys: newViewId: 'card', previousViewID: 'venmo'
 * @param {Object} event An object with a newViewId and a previousViewId from OnChangeActiveView event
 * @returns {Object} An object with a newViewId and a previousViewId
 */
function getCurrentViewIdsObject(event) {
    var viewIdMethods = 'methods';
    var $dropInContainer = document.getElementById('dropin-container');
    var currentDropinPaymentMethodString = document.querySelector('.braintree-heading').innerHTML;
    var newViewId = event.newViewId === viewIdMethods ?
        getPaymentMethodIdByPaymentMethodString(currentDropinPaymentMethodString) :
        event.newViewId;
    var previousViewId = event.previousViewId === viewIdMethods ?
        $dropInContainer.getAttribute('data-active-dropin-payment-method-type') :
        event.previousViewId;

    // Leads 'paypal' and 'paypalCredit' to one view type
    if (newViewId === 'paypalCredit') {
        newViewId = possiblePaymentMethods.paypal;
    }

    if (previousViewId === 'paypalCredit') {
        previousViewId = possiblePaymentMethods.paypal;
    }

    return {
        previousViewId: previousViewId,
        newViewId: newViewId
    };
}

/**
 * Handles Add card button that use for Credit card in Drop-in
 * @param {string} viewId A new view id (card, venmo)
 */
function handleAddCardButton(viewId) {
    var $addCardButton = document.querySelector('.js_dropin-addCard-btn');

    if (viewId === 'card') {
        dropInHelper.showHtmlElement($addCardButton);
    } else {
        dropInHelper.hideHtmlElement($addCardButton);
    }
}

/**
 * Handles the buttons that interacts with Drop-in
 * @param {string} viewId A new view id (card, venmo...)
 */
function handleDropInBillingCheckoutButtons(viewId) {
    var isToggleContinueButton = viewId === 'methods';

    dropInHelper.continueButtonToggle(isToggleContinueButton);
    handleAddCardButton(viewId);
}

/**
 * Sets an active 'class' to the payment method that currently use in Drop-in
 * @param {string} paymentMethodId A payment method id
 */
function addDropInActivePaymentMethod(paymentMethodId) {
    switch (paymentMethodId) {
        case possiblePaymentMethods.paypal:
            if ($paypalContent) {
                $paypalContent.classList.add('active');
            }
            break;
        case possiblePaymentMethods.card:
            if ($creditCardContent) {
                $creditCardContent.classList.add('active');
            }
            break;
        case possiblePaymentMethods.googlePay:
            if ($googlePayContent) {
                $googlePayContent.classList.add('active');
            }
            break;
        case possiblePaymentMethods.venmo:
            if ($venmoContent) {
                $venmoContent.classList.add('active');
            }
            break;
        case possiblePaymentMethods.applePay:
            if ($applePayContent) {
                $applePayContent.classList.add('active');
            }
            break;
        default:
            break;
    }
}

/**
 * Removes an active 'class' from the payment method that is not longer used in Drop-in
 * @param {string} paymentMethodId A payment method id
 */
function removeDropInActivePaymentMethod(paymentMethodId) {
    switch (paymentMethodId) {
        case possiblePaymentMethods.paypal:
            if ($paypalContent) {
                $paypalContent.classList.remove('active');
            }
            break;
        case possiblePaymentMethods.card:
            if ($creditCardContent) {
                $creditCardContent.classList.remove('active');
            }
            break;
        case possiblePaymentMethods.googlePay:
            if ($googlePayContent) {
                $googlePayContent.classList.remove('active');
            }
            break;
        case possiblePaymentMethods.venmo:
            if ($venmoContent) {
                $venmoContent.classList.remove('active');
            }
            break;
        case possiblePaymentMethods.applePay:
            if ($applePayContent) {
                $applePayContent.classList.add('active');
            }
            break;
        default:
            break;
    }
}

/**
 * Handles which of the payment method is active in Drop-in on billing checkout page
 * @param {Object} event An object with a newViewId and a previousViewId
 * @param {string} pageFlow The current page flow
 */
function handleDropInActivePaymentMethodTab(event) {
    var $dropInContainer = document.getElementById('dropin-container');
    var newViewId = event.newViewId;
    var previousViewId = event.previousViewId;

    // Indicates active payment method in Drop-in
    if (newViewId !== previousViewId) {
        $dropInContainer.setAttribute('data-active-dropin-payment-method-type', newViewId);

        addDropInActivePaymentMethod(newViewId);
        removeDropInActivePaymentMethod(previousViewId);
    }
}

/**
 * Handles the Drop-in submit button on the Cart page
 * @param {string} viewId A new view id (card, venmo)
 * @param {string} flow page flow
 */
function handleCheckoutSubmitButton(viewId, flow) {
    var $submitButton = document.querySelector(`.js_dropin-${flow}-submit-btn`);
    var isToggleSubmitButton = viewId === 'methods';
    var currentPayingString = document.querySelector('.braintree-heading').innerHTML;

    if (isToggleSubmitButton) {
        if (flow === 'minicart') {
            $submitButton.click();
        } else {
            $submitButton.innerHTML = currentPayingString;
            dropInHelper.showHtmlElement($submitButton);
        }
    } else {
        dropInHelper.hideHtmlElement($submitButton);
    }
}

/**
 * Handles a billing address info alert on checkout page
 * @param {string} viewId A new view id (card, venmo)
 */
function handleBillingAddressInfoAlert(viewId) {
    var $billingAddressInfoAlertContainer = document.querySelector('.js_billingAddressInfoAlert');

    if (takeBillingFromBraintreeList.includes(viewId)) {
        dropInHelper.showHtmlElement($billingAddressInfoAlertContainer);
    } else {
        dropInHelper.hideHtmlElement($billingAddressInfoAlertContainer);
    }
}

/**
 * Handles a billing address functionality in checkout page
 * @param {string} viewId A new view id (card, venmo)
 */
function handleBillingAddressFunctiinality(viewId) {
    if (takeBillingFromBraintreeList.includes(viewId)) {
        billingFormHelper.disableBillingAddressFunctionality();
    } else {
        billingFormHelper.enableBillingAddressFunctionality();
    }
}

/**
 * Callback success response
 * @param {Object} response request response
 * @returns {void}
 */
function successResponseCallback(response) {
    const $shippingMethods = document.getElementById('shippingMethods');

    if ($shippingMethods) {
        let option;
        let estimatedArrivalTime;
        const shipping = response.order.shipping[0];
        const selectedShippingMethodId = shipping.selectedShippingMethod.ID;

        $shippingMethods.innerHTML = '';

        shipping.applicableShippingMethods.forEach((item) => {
            option = document.createElement('option');
            option.setAttribute('data-shipping-id', item.ID);
            option.selected = selectedShippingMethodId === item.ID;
            estimatedArrivalTime = item.estimatedArrivalTime ? `(${item.estimatedArrivalTime})` : '';
            option.textContent = `${item.displayName} ${estimatedArrivalTime}`.trim();

            $shippingMethods.appendChild(option);
        });

        $shippingMethods.dispatchEvent(new Event('change'));
    }
}

/**
 * Handles for update shipping methods list on event change active view
 * @param {Dropin~changeActiveView} event A Drop-in 'ChangeActiveView' event
 * @param {Object} dropinModelInstance A dropin model instance
 * @param {dropinInstance} dropinInstance A dropinInstance
 * @returns {void}
 */
function handleUpdateShippingMethodsList(event, dropinModelInstance, dropinInstance) {
    if (event.previousViewId === 'paypal' && event.newViewId === 'methods') {
        dropinModelInstance.dropinSdk.requestPaymentMethod(
            dropinInstance,
            dropinModelInstance.dropinConfigs
        )
        .then(function (payload) {
            requestHelper.updateShippingMethodsList(
                dropinModelInstance.payPalConfigurations.updateShippingMethodsListUrl,
                payPalCartPageHelper.prepareShippingAddressFormData(payload.details),
                successResponseCallback
            );
        });
    }
}

/**
 * Handles to override shipping address
 * @param {Dropin~changeActiveView} event A Drop-in 'ChangeActiveView' event
 * @param {Object} dropinModelInstance A dropin model instance
 * @param {dropinInstance} dropinInstance A dropin instance
 * @returns {void}
 */
function handleShippingAddressOverride(event, dropinModelInstance, dropinInstance) {
    if (['options', 'methods'].includes(event.previousViewId) && event.newViewId === 'paypal') {
        dropinModelInstance.dropinSdk.updateConfiguration(dropinInstance, {
            property: 'paypal',
            key: 'shippingAddressEditable',
            value: false
        });

        dropinModelInstance.dropinSdk.updateConfiguration(dropinInstance, {
            property: 'paypal',
            key: 'shippingAddressOverride',
            value: dropinModelInstance.basketData.shippingAddress
        });
    }
}

module.exports = {
    handleDropInActivePaymentMethodTab,
    removeDropInActivePaymentMethod,
    getCurrentViewIdsObject,
    handleDropInBillingCheckoutButtons,
    handleBillingAddressInfoAlert,
    handleBillingAddressFunctiinality,
    handleCheckoutSubmitButton,
    handleAddCardButton,
    handleUpdateShippingMethodsList,
    handleShippingAddressOverride
};
