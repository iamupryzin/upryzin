'use strict';

const billingCheckoutPageHelper = require('./helpers/billingCheckoutPageHelper');

/* --------------------------Checkout page------------------------- */
const $checkoutPage = document.querySelector('.js-dropin-checkout-page-billing-step');
const isCheckoutPage = Boolean($checkoutPage);
const dropinCheckoutComponent = require('./components/dropinCheckoutComponent');

// DropIn-UI on checkout page initialization
if (isCheckoutPage) {
    // Hides the 'Next:Place order button'
    const $checkoutMainContainer = document.getElementById('checkout-main');
    const $submitBtn = document.querySelector('.submit-shipping');
    document.querySelector('.submit-payment').style.display = 'none';

    // Start DropIn-UI initialization after filling form
    $submitBtn.addEventListener('click', function () {
        billingCheckoutPageHelper.fillPaymentSummaryContainer();
        dropinCheckoutComponent.init();
    });

    // Start DropIn-UI initialization after reloading page
    if ($checkoutMainContainer.dataset.checkoutStage === 'payment') {
        billingCheckoutPageHelper.fillPaymentSummaryContainer();
        dropinCheckoutComponent.init();
    }
}

/* --------------------------Cart page------------------------- */
const $cartPage = document.querySelector('.braintree-dropin-cart-wrap');
const isCartPage = Boolean($cartPage);
const dropinCartComponent = require('./components/dropinCartComponent');

// DropIn-UI on cart page initialization
if (isCartPage) {
    dropinCartComponent.init();
}

/* --------------------------Account page------------------------- */
const $accountPage = document.querySelector('.js-dropin-account-step');
const isAccountPage = Boolean($accountPage);
const dropinAccountComponent = require('./components/dropinAccountComponent');

// DropIn-UI on account page initialization
if (isAccountPage) {
    dropinAccountComponent.init();
}
/* --------------------------Mini Cart------------------------- */
const dropinMiniCartComponent = require('./components/dropinMiniCartComponent');

// DropIn-UI on mini cart page initialization
dropinMiniCartComponent.init();

/* --------------------------Pdp page ------------------------- */
const dropinPdpComponent = require('./components/dropinPdpComponent');
const $pdpPage = document.querySelector('.prices-add-to-cart-actions .js-dropin-pdp-page-billing-step');
const isPdpPage = Boolean($pdpPage);

if (isPdpPage) {
    dropinPdpComponent.init();
}
