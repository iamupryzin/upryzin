'use strict';

var dropInHelper = require('../helpers/dropInHelper');

/**
 * Create billing address data
 * @param {Object} payloadDetails BT paymload details
 * @returns {Object} Mapped billing data
 */
function createBillingAddressData(payloadDetails) {
    var billingAddress = payloadDetails.billingAddress;

    billingAddress.firstName = payloadDetails.firstName;
    billingAddress.lastName = payloadDetails.lastName;
    billingAddress.email = payloadDetails.email;
    billingAddress.phone = payloadDetails.phone;
    billingAddress.countryCodeAlpha2 = billingAddress.countryCode;
    billingAddress.streetAddress = billingAddress.line1;
    billingAddress.extendedAddress = billingAddress.line2;
    billingAddress.locality = billingAddress.city;
    billingAddress.region = billingAddress.state;

    return billingAddress;
}

/**
 * Create billig address FormData
 * @param {Object} paypalBillingFormFields PayPal billing form fields
 * @param {Object} billingAddressData Billing address data
 * @returns {FormData} Billing FormData
 */
function createPayPalBillingAddressFormData(paypalBillingFormFields, billingAddressData) {
    var billingAddressFormData;

    billingAddressFormData = dropInHelper.createPaymentFormData(paypalBillingFormFields, {
        firstName: billingAddressData.firstName,
        lastName: billingAddressData.lastName,
        address1: billingAddressData.streetAddress,
        address2: billingAddressData.extendedAddress || '',
        city: billingAddressData.locality,
        postalCode: billingAddressData.postalCode,
        stateCode: billingAddressData.state,
        country: billingAddressData.countryCodeAlpha2,
        email: billingAddressData.email,
        phone: billingAddressData.phone,
        paymentMethod: 'PayPal'
    });

    return billingAddressFormData;
}

/**
 * Append CSRF token to the billing FormData
 * @param {FormData} formData Billing form data
 * @param {Object} $csrfToken CSRF token js container
 */
function appendCsrfTokenToFormData(formData, $csrfToken) {
    formData.append($csrfToken.name, $csrfToken.value);
}

/**
 * Append fraud data to the FormData
 * @param {FormData} billingFromData billing FormData
 * @param {Object} fraudData fraud data
 */
function appendFraudDataToFormData(billingFromData, fraudData) {
    billingFromData.append('braintreePaypalRiskData', fraudData);
}

/**
 * Create shipping address data
 * @param {Object} payloadDetails BT payload details
 * @returns {Object} Shipping address
 */
function createShippingAddressData(payloadDetails) {
    var shippingAddressPayPalData = payloadDetails.shippingAddress;
    var shippingAddressData = {
        line1: shippingAddressPayPalData.line1,
        streetAddress: shippingAddressPayPalData.line1,
        city: shippingAddressPayPalData.city,
        locality: shippingAddressPayPalData.city,
        state: shippingAddressPayPalData.state,
        region: shippingAddressPayPalData.state,
        countryCode: shippingAddressPayPalData.countryCode,
        countryCodeAlpha2: shippingAddressPayPalData.countryCode,
        postalCode: shippingAddressPayPalData.postalCode,
        email: payloadDetails.email,
        phone: payloadDetails.phone
    };

    if (!shippingAddressPayPalData.recipientName) {
        shippingAddressData.firstName = payloadDetails.firstName;
        shippingAddressData.lastName = payloadDetails.lastName;
        shippingAddressData.recipientName = `${payloadDetails.firstName} ${payloadDetails.lastName}`;
    } else {
        shippingAddressData.recipientName = shippingAddressPayPalData.recipientName;
    }

    return shippingAddressData;
}

/**
 * Prepare Shipping Address FormData for UpdateShippingMethodsList
 * @param {Object} payloadDetails Payload details
 * @returns {FormData} Shipping form data
 */
function prepareShippingAddressFormData(payloadDetails) {
    const formData = new FormData();
    const shippingAddress = payloadDetails.shippingAddress;

    formData.append('firstName', payloadDetails.firstName);
    formData.append('lastName', payloadDetails.lastName);
    formData.append('address1', shippingAddress.line1);
    formData.append('address2', shippingAddress.line2 || '');
    formData.append('city', shippingAddress.city);
    formData.append('postalCode', decodeURIComponent(shippingAddress.postalCode));
    formData.append('stateCode', shippingAddress.state);
    formData.append('countryCode', shippingAddress.countryCode);
    formData.append('phone', payloadDetails.phone);

    return formData;
}

/**
 * Append Shipping data as a String to the FormData
 * @param {FormData} billingFromData Billing FormData
 * @param {Object} shippingData Shipping data
 */
function appendShippingDataAsStringToFormData(billingFromData, shippingData) {
    billingFromData.append('braintreePaypalShippingAddress', JSON.stringify(shippingData));
}

/**
 * Append billing address data as a string to the FromData
 * @param {FormData} billingFromData Billing FormData
 * @param {Object} billingData Billing data
 */
function appendBillingAddressAsStringToFormData(billingFromData, billingData) {
    billingFromData.append('braintreePaypalBillingAddress', JSON.stringify(billingData));
}

/**
 * Append email to the billing FormData
 * @param {FormData} formData billing form data
 * @param {string} email user email
 */
function appendEmailAsStringToFormData(formData, email) {
    formData.append('braintreePaypalEmail', email);
}

/**
 * Append BT payment fields to the FromData
 * @param {FormData} billingFromData Billing FormData
 * @param {Object} payload payload from BT
 */
function appendBtPaymentFieldsToFormData(billingFromData, payload) {
    billingFromData.append('braintreePaypalNonce', payload.nonce);
    billingFromData.append('braintreeSavePaypalAccount', true);
}

module.exports = {
    createBillingAddressData,
    createPayPalBillingAddressFormData,
    appendCsrfTokenToFormData,
    appendFraudDataToFormData,
    createShippingAddressData,
    appendShippingDataAsStringToFormData,
    appendBillingAddressAsStringToFormData,
    appendEmailAsStringToFormData,
    appendBtPaymentFieldsToFormData,
    prepareShippingAddressFormData
};
