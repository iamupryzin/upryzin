'use strict';

var ErrorHandlingBaseModel = require('./errorHandlingBaseModel');

/**
 * Error Handling Checkout model constructor
 * @param {Object} errorMessages object with error messages
 */
function ErrorHandlingCheckoutModel(errorMessages) {
    ErrorHandlingBaseModel.call(this, errorMessages);

    this.$topErrorMessageText = document.querySelector('.error-message-text');
    this.$topErrorMessageWrapper = document.querySelector('.error-message');

    this.errorMessages = errorMessages;
}

/**
 * ES5 inheritance
 */
ErrorHandlingCheckoutModel.prototype = Object.create(ErrorHandlingBaseModel.prototype);

// See corresponding method inside "ErrorHandlingBaseModel" model
ErrorHandlingCheckoutModel.prototype.hideError = function () {
    this.$topErrorMessageWrapper.style.display = 'none';
    this.$topErrorMessageText.innerHTML = '';
};

// See corresponding method inside "ErrorHandlingBaseModel" model
ErrorHandlingCheckoutModel.prototype.createErrorNotification = function (message) {
    this.$topErrorMessageText.textContent = '';
    this.$topErrorMessageText.append(message);

    this.$topErrorMessageWrapper.style.display = 'block';
    window.scrollTo(0, 0);
};

/**
 * Throw an error when threeDSecure finished unsuccessfully
 */
ErrorHandlingCheckoutModel.prototype.throwCreditCardVerificationFailedError = function () {
    throw this.createCustomErrorObject(
        this.errorMessages.secure3DFailed,
        'secure3DFailed'
    );
};

/**
 * Validates threeDSecure verification
 * @param {tokenizePayload} dropinResponse A tokenizePayload of payment method
 * @param {Object} dropinModelInstance A Dropin model instance
 * @param {dropinInstance} dropinInstance A dropinInstanse
 */
ErrorHandlingCheckoutModel.prototype.validateThreeDSecureVerification = function (dropinResponse, dropinModelInstance, dropinInstance) {
    var paymentMethodType = dropinResponse.type;

    if (paymentMethodType === 'CreditCard' || paymentMethodType === 'AndroidPayCard') {
        var liabilityShifted = dropinResponse.threeDSecureInfo.liabilityShifted;

        if (!liabilityShifted && !dropinModelInstance.dropinConfigs.isSkip3dSecureLiabilityResult) {
            dropinModelInstance.dropinSdk.clearSelectedPaymentMethod(dropinInstance);
            this.throwCreditCardVerificationFailedError();
        }
    }
};

module.exports = ErrorHandlingCheckoutModel;
