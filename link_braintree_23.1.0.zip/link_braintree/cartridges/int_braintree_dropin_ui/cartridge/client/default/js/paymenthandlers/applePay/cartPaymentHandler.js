'use strict';

var dropInHelper = require('../../helpers/dropInHelper');
var requestHelper = require('../../helpers/requestHelper');

var applePayCheckoutFormData;

/**
 * Expends Apple Pay Checkout Form with required data
 *
 * @param {Object} payload Payload data
 */
function expandApplePayCheckoutFormData(payload) {
    var csrfToken = document.querySelector('.braintree-dropin-cart-wrap  #csrf_token');

    applePayCheckoutFormData.append(csrfToken.name, csrfToken.value);
    applePayCheckoutFormData.append('braintreeApplePayNonce', payload.nonce);
    applePayCheckoutFormData.append('braintreeApplePayDeviceDataInput', payload.deviceData);
    applePayCheckoutFormData.append('braintreeApplePayShippingAddress',
        JSON.stringify(payload.shippingAddress) || '{}'
    );
    applePayCheckoutFormData.append('braintreeApplePayBillingAddress',
        JSON.stringify(payload.billingAddress) || '{}'
    );
}

/**
 * Process an Apple pay tokenizePayload from the Cart page
 * @param {tokenizePaylaod} payload An Apple pay tokenizePayload
 * @param {Object} dropinModelInstance A dropin model instance
 */
function paymentProcessing(payload, dropinModelInstance) {
    var billingAddressData = payload.billingAddress;
    var $dropinWrapper = document.querySelector('.braintree-dropin-cart-wrap');
    const placeOrderUrl = window.braintreeUrls.placeOrderUrl;
    const checkoutFromCartUrl = window.braintreeUrls.checkoutFromCartUrl;
    var checkoutFormFields = $dropinWrapper.getAttribute('data-checkout-form-fields');
    var paymentFieldData = dropInHelper.getPaymentFieldsData(
        billingAddressData,
        dropinModelInstance.applePayConfiguration.paymentMethodName
    );

    applePayCheckoutFormData = dropInHelper.createPaymentFormData(checkoutFormFields, paymentFieldData);

    expandApplePayCheckoutFormData(payload);

    // submit customer form with email (CheckoutServices-SubmitCustomer)
    // as we skip step "login via guest/registered user" while express checkout
    // email is set only in case of guest checkout and if email is not already set
    requestHelper.submitCustomerForm(payload.shippingAddress.email);

    $.ajax({
        type: 'POST',
        url: checkoutFromCartUrl,
        data: applePayCheckoutFormData,
        contentType: false,
        processData: false,
        success: function (data) {
            if (data.error) {
                var errorMessage = '';

                if (data.fieldErrors.length) {
                    data.fieldErrors.forEach(function (error, index) {
                        var keys = Object.keys(error);

                        if (keys.length) {
                            errorMessage += `${keys[index].replace('dwfrm_billing_', '').replace('_', ' ')} ${data.fieldErrors[index][keys[index]]}. `;
                        }
                    });
                    dropinModelInstance.errorHandlingModelInstance.showErrorByMessage(errorMessage);
                }

                if (data.serverErrors.length) {
                    data.serverErrors.forEach(function (error) {
                        errorMessage += `${error}. `;
                    });
                    dropinModelInstance.errorHandlingModelInstance.showErrorByMessage(errorMessage);
                }

                if (data.cartError) {
                    window.location.href = data.redirectUrl;
                }

                // eslint-disable-next-line no-undef
                dropinInstance.loader.hide();

                return;
            }

            window.location.href = placeOrderUrl;
            // eslint-disable-next-line no-undef
            dropinInstance.loader.hide();
        },
        error: function (err) {
            // eslint-disable-next-line no-undef
            dropinInstance.loader.hide();

            if (err && err.redirectUrl) {
                window.location.href = err.redirectUrl;
            }
        }
    });
}

module.exports = {
    paymentProcessing
};
