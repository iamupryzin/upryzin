'use strict';

var DropinBaseModel = require('../models/dropinBaseModel');
var ErrorHandlingMiniCartModel = require('../errorhandler/errorHandlingMiniCartModel');

var dropinDisplayBehavior = require('./dropinDisplayBehavior');

// Helpers
var dropInHelper = require('../helpers/dropInHelper');
var loaderInstance = require('../helpers/loaderHelper');

/**
 * Initiates all necessary drop-in components
 */
function initDropinOnMiniCart() {
    var $dropinWrapper = document.querySelector('.js-dropin-minicart-page-step');

    // Initiates a Mini cart page only when Dropin wrapper is initiated
    if ($dropinWrapper) {
        // Variables needed for creation of "DropinBaseModel" instance
        var $submitPaymentButton = document.querySelector('.js_dropin-minicart-submit-btn');
        var $dropinContainer = document.querySelector('.js-dropin-minicart-page-step #dropin-container');
        var $totalAmountElement = document.querySelector('.sub-total');
        var dropinLoader = loaderInstance(document.querySelector('.js_braintreeDropinLoader'));
        var paymentMethodsConfigurations = dropInHelper.getBraintreeConfigs($dropinContainer);
        var errorHandlingMiniCartModelInstance = new ErrorHandlingMiniCartModel(paymentMethodsConfigurations.dropinConfigs.errorMessages);
        var DropInModelInstance = new DropinBaseModel(
            dropinLoader,
            $totalAmountElement,
            errorHandlingMiniCartModelInstance,
            $submitPaymentButton,
            null,
            $dropinContainer,
            paymentMethodsConfigurations
        );

        // Case when buyer remove product from the Cart
        $('body').on('cart:update', function () {
            dropinDisplayBehavior.dropinMinicartBehavior($dropinWrapper);
        });

        DropInModelInstance.initDropIn();
    }
}

/**
 * Initiates Drop-in on the Mini cart Page
 */
function init() {
    var $minicartPopover = document.querySelector('.minicart .popover');
    var observer;

    // To avoid execution of this code on checkout page
    if ($minicartPopover) {
        observer = new MutationObserver(function (mutations) {
            mutations.forEach(function (mutation) {
                if (mutation.addedNodes.length < 2) {
                    return;
                }

                initDropinOnMiniCart();
            });
        });

        observer.observe($minicartPopover, { childList: true });
    }
}

module.exports = {
    init
};
