'use strict';

/**
 * Error Handling constructor
 * @param {Object} errorMessages object with error messages
 */
function ErrorHandlingBaseModel(errorMessages) {
    this.errorMessages = errorMessages;
}

/**
 * ---- General method which should be used all error cases----
 * Show error notification by error Object from BT or custom error
 * @param {Object} error error object
 */
ErrorHandlingBaseModel.prototype.showErrorByObject = function (error) {
    var msg = error.message;
    var code = error.code || '';
    var errorMessage = this.errorMessages[code] || msg || this.errorMessages.CLIENT_GATEWAY_NETWORK;

    this.createErrorNotification(errorMessage);
};

/**
 * ---- General method which should be used for cases when error came from Braintree ----
 * Show error notification by message
 * @param {string} message message to display inside error notification
 */
ErrorHandlingBaseModel.prototype.showErrorByMessage = function (message) {
    this.createErrorNotification(message);
};

/**
 * ---- Error container which will be used on Account and PDP ----
 * ---- For all other cases this method will be overwritten by corresponding one ----
 *
 * Method responsible for Error Notification generation
 * @param {string} message message to display inside error notification
 */
ErrorHandlingBaseModel.prototype.createErrorNotification = function (message) {
    var $errorContainer = $('.error-messaging');

    var errorHtml = `<div class="alert alert-danger alert-dismissible valid-cart-error fade show" role="alert">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
    </button>${message}</div>`;

    $errorContainer.append(errorHtml);
    $errorContainer.show();
    window.scrollTo(0, 0);
};

/**
 * ---- Method which should hide error container and make it empty. On Account and PDP we use this one ----
 * ---- For all other cases this method will be overwritten by corresponding one ----
 *
 * Hide error notification
 */
ErrorHandlingBaseModel.prototype.hideError = function () {
    var $errorContainer = $('.error-messaging');

    $errorContainer.hide();
    $errorContainer.empty();
};

/**
 * Creates a custom error object
 * @param {string} message An error message
 * @param {string} code An error code
 * @returns {Object} A custom error object
 */
ErrorHandlingBaseModel.prototype.createCustomErrorObject = function (message, code) {
    return {
        message: message,
        code: code,
        errorName: 'customError'
    };
};

/**
 * Throw "Billing Address is not Supported" error notification
 */
ErrorHandlingBaseModel.prototype.throwBillingAddressIsNotSupportedError = function () {
    throw this.createCustomErrorObject(
        this.errorMessages.PAYPAL_BILLING_ADDRESS_NOT_SUPPORTED,
        'PAYPAL_BILLING_ADDRESS_NOT_SUPPORTED'
    );
};

/**
 * Throw a PayPal "Zero Amount" error
 */
ErrorHandlingBaseModel.prototype.throwPayPalZeroAmountOnError = function () {
    throw this.createCustomErrorObject(
        this.errorMessages.CUSTOM_PAYPAL_ZERO_AMOUNT_ERROR,
        'CUSTOM_PAYPAL_ZERO_AMOUNT_ERROR'
    );
};

/**
 * Throw a Google Pay "Zero Amount" error
 */
ErrorHandlingBaseModel.prototype.throwGooglePayZeroAmountError = function () {
    throw this.createCustomErrorObject(
        this.errorMessages.CUSTOM_GOOGLE_PAY_ZERO_AMOUNT_ERROR,
        'CUSTOM_GOOGLE_PAY_ZERO_AMOUNT_ERROR'
    );
};

/**
 * A general method for handling of zero amount errors
 * @param {string} accountType A payment method account type
 */
ErrorHandlingBaseModel.prototype.throwZeroAmountError = function (accountType) {
    switch (accountType) {
        case 'PayPalAccount':
            this.throwPayPalZeroAmountOnError();
            break;
        case 'AndroidPayCard':
            this.throwGooglePayZeroAmountError();
            break;
        default:
            break;
    }
};

module.exports = ErrorHandlingBaseModel;
