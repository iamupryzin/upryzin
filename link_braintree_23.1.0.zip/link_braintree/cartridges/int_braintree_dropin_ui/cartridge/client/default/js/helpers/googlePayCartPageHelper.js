'use strict';

/**
 * Creates shipping address object
 * @param {Object} shippingData Shipping data object
 * @returns {Object} Shipping data object in required format
 */
function createGooglepayShippingAddressData(shippingData) {
    var shippingAddress = {};
    var recipientName = shippingData.name.split(' ');

    shippingAddress.firstName = recipientName[0];
    shippingAddress.lastName = recipientName[1];
    shippingAddress.phone = shippingData.phoneNumber;
    shippingAddress.countryCodeAlpha2 = shippingData.countryCode;
    shippingAddress.streetAddress = shippingData.address1;
    shippingAddress.extendedAddress = shippingData.address2;
    shippingAddress.locality = shippingData.locality;
    shippingAddress.region = shippingData.administrativeArea;
    shippingAddress.postalCode = shippingData.postalCode;

    return shippingAddress;
}

/**
 * Creates Google Pay billing address from payload data
 * @param {Object} data Data object
 * @returns {Objcet} billing address data object
 */
function createGooglepayBillingAddressData(data) {
    var billingData = data.paymentMethodData.info.billingAddress;
    var billingAddress = {};
    var recipientName = billingData.name.split(' ');

    billingAddress.firstName = recipientName[0];
    billingAddress.lastName = recipientName[1];
    billingAddress.phone = billingData.phoneNumber;
    billingAddress.countryCodeAlpha2 = billingData.countryCode;
    billingAddress.streetAddress = billingData.address1;
    billingAddress.extendedAddress = billingData.address2;
    billingAddress.locality = billingData.locality;
    billingAddress.stateCode = billingData.administrativeArea;
    billingAddress.postalCode = billingData.postalCode;
    billingAddress.email = data.email;

    return billingAddress;
}

module.exports = {
    createGooglepayShippingAddressData,
    createGooglepayBillingAddressData
};
