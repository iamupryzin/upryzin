'use strict';

var dropinHelper = require('../helpers/dropInHelper');

// For cases when basket amount changing without page reload
var dynamicBasketProductQuantity = -1;

/**
 * Is add to cart button disabled
 * @returns {boolean} "true" in case if add to cart button disabled
 */
function isAddToCartButtonDisabled() {
    var $addToCartButton = document.querySelector('.add-to-cart') || document.querySelector('.add-to-cart-global');

    return $addToCartButton.disabled;
}

/**
 * Check if PDP product price is zero
 * @returns {boolean} "true" in case if PDP product price is zero
 */
function isZeroPdpProductPrice() {
    var $productPriceSelector = document.querySelector('.price .sales .value');

    if ($productPriceSelector) {
        var price = parseInt($productPriceSelector.getAttribute('content'), 0);
        return price <= 0;
    }

    return true;
}

/**
 * Check if basket is empty based on attr which comes from server and "dynamicBasketProductQuantity" which updates on "cart:update" event
 * @param {Object} $dropinWrapper A dropin wrapper container
 * @returns {boolean} "true" in case if basket is not empty
 */
function isBasketNotEmpty($dropinWrapper) {
    return !JSON.parse($dropinWrapper.getAttribute('data-is-basket-empty')) || (dynamicBasketProductQuantity > 0 && dynamicBasketProductQuantity !== -1);
}

/**
 * Return mini cart quantity
 * @param {Object} $miniCartQuantitySelector Mini cart quantity selector
 * @returns {Int} Quantity
 */
function getMiniCartQuantity($miniCartQuantitySelector) {
    var quantity = null;

    if ($miniCartQuantitySelector) {
        quantity = parseInt($miniCartQuantitySelector.textContent, 0);
    }

    return quantity;
}

/**
 * Hides a Drop-in container
 * @param {Object} $dropinWrapper A Drop-in wrapper container
 */
function hideDropinContainer($dropinWrapper) {
    dropinHelper.hideHtmlElement($dropinWrapper);
}

/**
 * Shows a Drop-in container
 * @param {Object} $dropinWrapper A Drop-in wrapper container
 */
function showDropinContainer($dropinWrapper) {
    dropinHelper.showHtmlElement($dropinWrapper);
}

/**
 * Check if current total basket price is zero
 * @returns {boolean} "true" in case if current total basket price is zero
 */
function isCurrentTotalBasketPriceZero() {
    var $basketTotalAmount = document.querySelector('.sub-total');

    if ($basketTotalAmount) {
        var basketTotalAmount = $basketTotalAmount.textContent.slice(1);

        return parseInt(basketTotalAmount, 10) === 0;
    }

    return false;
}

/**
 * Show or hide Drop-in container
 * @param {DOMElement} $dropinWrapper A Drop-in wrapper container
 */
function dropinMinicartBehavior($dropinWrapper) {
    if (!isCurrentTotalBasketPriceZero()) {
        showDropinContainer($dropinWrapper);
    } else {
        hideDropinContainer($dropinWrapper);
    }
}

/**
 * Init Drop-in container display behavior. This code is handle both Drop-in on PDP and MiniCart pages
 * @param {Object} $dropinWrapper A Drop-in wrapper container
 */
function initProductPage($dropinWrapper) {
    var addToCartButtonDisabled = isAddToCartButtonDisabled();
    var zeroProductPrice = isZeroPdpProductPrice();
    var basketNotEmpty = isBasketNotEmpty($dropinWrapper);

    if (addToCartButtonDisabled || zeroProductPrice || basketNotEmpty) {
        hideDropinContainer($dropinWrapper);
    }

    $('body').on('product:afterAddToCart', function () {
        hideDropinContainer($dropinWrapper);
    });

    // Case when buyer remove product from Cart
    $('body').on('cart:update', function (_, data) {
        var $miniCartQuantityContainer = document.querySelector('.minicart-quantity');
        var miniCartQuantity = getMiniCartQuantity($miniCartQuantityContainer);
        var addToCartButtonEnabled = !isAddToCartButtonDisabled();
        zeroProductPrice = isZeroPdpProductPrice();

        if (data.basket) {
            dynamicBasketProductQuantity = data.basket.numItems;
        }

        if (miniCartQuantity === 0 && addToCartButtonEnabled && !zeroProductPrice) {
            showDropinContainer($dropinWrapper);
        } else {
            hideDropinContainer($dropinWrapper);
        }
    });

    // When buyer change collor/size of the product on PDP
    $('body').on('product:statusUpdate', function () {
        addToCartButtonDisabled = isAddToCartButtonDisabled();
        zeroProductPrice = isZeroPdpProductPrice();

        if (addToCartButtonDisabled || zeroProductPrice) {
            hideDropinContainer($dropinWrapper);
        } else {
            showDropinContainer($dropinWrapper);
        }
    });
}

module.exports = {
    dropinMinicartBehavior,
    initProductPage
};
