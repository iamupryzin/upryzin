'use strict';

var dropInSdkHelper = require('../helpers/dropInSdkHelper');

/**
 * Creates all necessary options for braintree.dropin (cart, mini-cart, checkout pages)
 * @param {Object} dropInModelInstance An instance of dropInBaseModel constructor
 * @returns {Object} dropInOptions
 */
function createDropInOptions(dropInModelInstance) {
    var dropinConfigs = dropInModelInstance.dropinConfigs;
    var dropInOptions = {
        authorization: dropinConfigs.clientToken,
        container: dropInModelInstance.$dropinContainer,
        dataCollector: dropinConfigs.isFraudToolsEnabled,
        vaultManager: dropinConfigs.isPaymentMethodRemovingAllowed
    };
    var isCreditCardEnabledInDropIn = dropinConfigs.isCreditCardEnabledInDropIn;

    if (dropinConfigs.is3DSecureEnabled && dropinConfigs.pageFlow === 'checkout') {
        dropInOptions.threeDSecure = true;
    }

    if (!isCreditCardEnabledInDropIn) {
        dropInOptions.card = false;
    } else {
        dropInOptions.card = {
            overrides: {
                fields: {
                    postalCode: null
                }
            },
            vault: {
                vaultCard: dropinConfigs.vaultModeEnabled
            }
        };
    }

    if (dropinConfigs.isPayPalEnabledInDropIn) {
        dropInOptions.paypal = dropInModelInstance.getPayPalConfigs();
        // Sets style into PayPal button
        dropInOptions.paypal.buttonStyle = dropinConfigs.payPalButtonStyle;

        if (dropinConfigs.isPayPalCreditEnabledInDropIn) {
            dropInOptions.paypalCredit = dropInModelInstance.getPayPalConfigs();
        }
    }

    if (dropinConfigs.isGooglePayEnabledInDropIn) {
        dropInOptions.googlePay = dropInModelInstance.getGooglePayConfigs(
            dropInSdkHelper.getTotalAmountAsString(dropInModelInstance)
        );
        dropInOptions.googlePay.button = dropinConfigs.googlePayButtonStyle;
    }

    if (dropinConfigs.isVenmoEnabledInDropIn) {
        dropInOptions.venmo = {
            allowNewBrowserTab: false,
            ignoreHistoryChanges: true,
            allowDesktop: true
        };
    }

    if (dropinConfigs.isApplePayEnabledInDropIn && window.ApplePaySession) {
        dropInOptions.applePay = dropInModelInstance.getApplePayConfigs(
            dropInSdkHelper.getTotalAmountAsString(dropInModelInstance)
        );
        dropInOptions.applePay.buttonStyle = dropinConfigs.applePayButtonStyle;
    }

    return dropInOptions;
}

/**
 * This event is emitted when the Drop-in view changes what is presented as the active view.
 * @param {dropinInstance} dropinInstance A drop-in instance
 * @param {string} dropinModelInstance A dropin model instance
 */
function onChangeActiveView(dropinInstance, dropinModelInstance) {
    dropinInstance.on('changeActiveView', function (event) {
        dropInSdkHelper.processOnChangeActiveViewResponse(event, dropinModelInstance, dropinInstance);
    });
}

/**
 * Removes the currently selected payment method and returns the customer to the payment options view.
 * Does not remove vaulted payment methods.
 * @param {dropinInstance} dropinInstance A drop-in instance
 */
function clearSelectedPaymentMethod(dropinInstance) {
    dropinInstance.clearSelectedPaymentMethod();
}

/**
 * Requests a payment method object which includes the payment method nonce used by the Braintree Server SDKs.
 * @param {dropinInstance} dropinInstance A drop-in instance
 * @param {Object} dropinConfigs A drop-in config
 * @returns {Promise} A promise that resolves with tokenizePaylaod or an error
 */
function requestPaymentMethod(dropinInstance, dropinConfigs) {
    // Flow with the threeDSecure
    if (dropinConfigs.is3DSecureEnabled && dropinConfigs.pageFlow === 'checkout') {
        var threeDSecureOptions = dropInSdkHelper.getThreeDSecureOptions(dropinConfigs.getOrderInfoUrl);

        dropinInstance.on('3ds:customer-canceled', function () {
            location.reload();
        });

        return dropinInstance.requestPaymentMethod(threeDSecureOptions);
    }

    // Flow without threeDSecure
    return dropinInstance.requestPaymentMethod();
}

/**
 * Modify a configuration initially set in
 * @param {dropinInstance} dropinInstance A drop-in instance
 * @param {Object} configObject An object with parameter needed to update
 */
function updateConfiguration(dropinInstance, configObject) {
    dropinInstance.updateConfiguration(
        configObject.property,
        configObject.key,
        configObject.value
    );
}

/**
 * Cleanly remove anything set up by dropin.create
 * @param {dropinInstance} dropinInstance A dropin instance
 */
function teardown(dropinInstance) {
    dropinInstance.teardown();
}

/**
 * An entry point for braintree.dropin (cart, mini-cart, checkout pages)
 * @param {Object} dropInModelInstance An instance of dropInBaseModel constructor
 * @returns {Promise} A promise that resolves with dropinInstance or an error
 */
function init(dropInModelInstance) {
    // eslint-disable-next-line no-undef
    return braintree.dropin.create(createDropInOptions(dropInModelInstance));
}

/**
 * An entry point for braintree.dropin (account page)
 * @param {Object} dropinAccountInstance An instance of dropinAccountModel constructor
 * @returns {Promise} A promise that resolves with dropinInstance or an error
 */
function initDropinOnAccountPage(dropinAccountInstance) {
    var dropinConfigs = dropinAccountInstance.dropinConfigs;
    var dropinOptions = {
        authorization: dropinConfigs.clientToken,
        container: dropinAccountInstance.$dropinContainer,
        vaultManager: dropinConfigs.isPaymentMethodRemovingAllowed,
        preselectVaultedPaymentMethod: false,
        card: {
            overrides: {
                fields: {
                    postalCode: null
                }
            }
        }
    };

    if (dropinConfigs.isPayPalEnabledInDropIn) {
        var payPalConfigs = dropinAccountInstance.getPayPalConfigs();

        dropinOptions.paypal = payPalConfigs;
    }

    // eslint-disable-next-line no-undef
    return braintree.dropin.create(dropinOptions);
}

/**
 * Check for duplicate credit card
 * @param {dropinInstance} dropinInstance A dropin instance
 * @param {Object} payload Payload from Braintree with submitted credit card data
 * @returns {void}
 */
function checkIfDuplicateCCSubmitted(dropinInstance, payload) {
    const samePaymentMethodAsPayload = dropinInstance._model._paymentMethods.filter((payment) => {
        return payment.nonce !== payload.nonce
            && payment.details.lastFour === payload.details.lastFour
            && payment.details.expirationMonth === payload.details.expirationMonth
            && payment.details.expirationYear === payload.details.expirationYear;
    });

    if (samePaymentMethodAsPayload.length) {
        const requestHelper = require('../helpers/requestHelper');
        const loaderInstance = require('../helpers/loaderHelper');
        const ErrorHandling = require('../errorhandler/errorHandlingDuplicateCCModel');
        const errorHandingInstance = new ErrorHandling();
        const parsedDatasetBraintree = JSON.parse(document.getElementById('dropin-container').dataset.braintree);
        const duplicateCreditCardControllerUrl = window.braintreeUrls.deleteDuplicateCreditCardUrl;

        errorHandingInstance.showDefaultErrorMessage();
        loaderInstance(document.querySelector('.js_braintreeDropinLoader')).show();

        requestHelper.submitDuplicateCreditCardDataToServerPromise(duplicateCreditCardControllerUrl, payload.details)
            .then((response) => {
                if (response.ok) {
                    location.reload();
                } else {
                    const defaultErrorMessage = parsedDatasetBraintree.dropinCustomConfigs.errorMessages.dropinDefaultErrorMessage;

                    loaderInstance(document.querySelector('.js_braintreeDropinLoader')).hide();
                    errorHandingInstance.hideError();
                    errorHandingInstance.createErrorNotification(defaultErrorMessage);
                }
            });
    }
}

module.exports = {
    init,
    requestPaymentMethod,
    onChangeActiveView,
    updateConfiguration,
    initDropinOnAccountPage,
    clearSelectedPaymentMethod,
    teardown,
    checkIfDuplicateCCSubmitted
};
