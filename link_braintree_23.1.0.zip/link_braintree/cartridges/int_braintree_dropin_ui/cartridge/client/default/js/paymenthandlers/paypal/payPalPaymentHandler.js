'use strict';

var checkoutPaymentHandler = require('../paypal/checkoutPaymentHandler');
var payPalExpressCheckoutPaymentHandler = require('../paypal/payPalExpressCheckoutPaymentHandler');

/**
 * Process a PayPal tokenizePayload in order to handle an order on the server side
 * @param {tokenizePayload} dropinResponse A PayPal tokenize payload
 * @param {string} pageFlow A current page flow
 * @param {Object} dropinInstance A Dropin model instance
 */
function paymentProcessing(dropinResponse, pageFlow, dropinInstance) {
    if (pageFlow === 'checkout') {
        checkoutPaymentHandler.paymentProcessing(dropinResponse, dropinInstance);
    } else {
        dropinInstance.loader.show();

        if (!dropinResponse.details.billingAddress) {
            // Throw "Billing Address is not Supported" error notification
            dropinInstance.errorHandlingModelInstance.throwBillingAddressIsNotSupportedError();
        }

        payPalExpressCheckoutPaymentHandler.paymentProcessing(
            dropinResponse,
            dropinInstance
        );
    }
}

module.exports = {
    paymentProcessing
};
