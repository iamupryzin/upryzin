'use strict';

var DropinBaseModel = require('./dropinBaseModel');
var dropinSdk = require('../dropinsdk/dropinSdk');

var dropinHelper = require('../helpers/dropInHelper');
var requestHelper = require('../helpers/requestHelper');
var dropinPaymentMethodHelper = require('../helpers/dropInPaymentMethodsHelper');

/**
 * A DropinPtoduct constructor
 * @param {Object} dropinLoader A dropin loader
 * @param {Object} errorHandlingModelInstance An error handling model instance
 * @param {DOMElement} $submitPaymentButton A Submit payment button
 * @param {DOMElement} $dropinContainer A dropinContainer
 * @param {Object} paymentMethodsConfigurations A payment methods configuration object
 */
function DropinProductModel(
    dropinLoader,
    errorHandlingModelInstance,
    $submitPaymentButton,
    $dropinContainer,
    paymentMethodsConfigurations
) {
    this.$submitPaymentButton = $submitPaymentButton;
    this.$dropinContainer = $dropinContainer;
    this.paymentMethodsConfigurations = paymentMethodsConfigurations;
    this.dropinConfigs = this.paymentMethodsConfigurations.dropinConfigs;
    this.basketDataUrl = this.dropinConfigs.getOrderInfoUrl;
    this.dropinSdk = dropinSdk;
    this.payPalConfigurations = this.paymentMethodsConfigurations.payPalButtonConfig;
    this.errorHandlingModelInstance = errorHandlingModelInstance;
    this.loader = dropinLoader;
}

// ES5 inheritance
DropinProductModel.prototype = Object.create(DropinBaseModel.prototype);

/**
 * Adds product to card in order to process payment from Pdp page
 */
DropinProductModel.prototype.addProductToCart = function () {
    requestHelper.addProductToCart();
};

/**
 * Initiates a Drop-in
 */
DropinProductModel.prototype.initDropIn = function () {
    var DropinProductModelInstance = this;

    // Clears a '__paypal_storage__' item from the local storage in order to avoid paypal sdk conflicts
    // Can happens when PayPal style configuration in bm was used
    window.localStorage.removeItem('__paypal_storage__');

    DropinProductModelInstance.dropinSdk.init(this)
        .then(function (dropinInstance) {
            var activePaymentMethod = dropinInstance._model._activePaymentMethod;
            // The methods string means that Drop-in contains the saved payment methods
            // The 'onChangeActiveView' returns methods string as newViewId(when newViewId is saved payment method)
            var methodsString = activePaymentMethod ? 'methods' : '';

            // Sets the page flow data attribute in order to split 'submitPayment' buttons
            // when Drop-in is displyed on two pages at the same time
            dropinHelper.setDataPageFlowAttribute(DropinProductModelInstance.dropinConfigs.pageFlow);

            // Shows or hides a submit button
            dropinPaymentMethodHelper.handleCheckoutSubmitButton(
                methodsString,
                DropinProductModelInstance.dropinConfigs.pageFlow
            );

            // Inits onChangeActive view event listener
            DropinProductModelInstance.dropinSdk.onChangeActiveView(dropinInstance, DropinProductModelInstance);

            // Add event listeners to the submitPayment button
            DropinProductModelInstance.$submitPaymentButton.addEventListener('click', function (e) {
                DropinProductModelInstance.dropinSdk.requestPaymentMethod(dropinInstance, DropinProductModelInstance.dropinConfigs)
                    .then(function (payload) {
                        DropinProductModelInstance.errorHandlingModelInstance.hideError();
                        DropinProductModelInstance.addProductToCart();
                        DropinProductModelInstance.processPayment(DropinProductModelInstance, payload);
                    })
                    .catch(function (error) {
                        DropinProductModelInstance.loader.hide();
                        e.stopPropagation();
                        DropinProductModelInstance.errorHandlingModelInstance.showErrorByObject(error);
                    });
            });
        })
        .catch(function (error) {
            DropinProductModelInstance.errorHandlingModelInstance.showErrorByObject(error);
        });
};

module.exports = DropinProductModel;
