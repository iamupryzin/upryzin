'use strict';

var dropInPaymentMethodsHelper = require('./dropInPaymentMethodsHelper');
var dropinAccountHelper = require('./dropinAccountHelper');
var requestHelper = require('./requestHelper');
var billingFormHelper = require('./billingFormHelper');

/**
 * Process all neseccary functionality when 'ChangeActiveView' triggered
 * @param {Dropin~changeActiveView} event A Drop-in 'ChangeActiveView' event
 * @param {Object} dropinModelInstance A dropin model instance
 * @param {dropinInstance} dropinInstance A dropinInstance
 */
function processOnChangeActiveViewResponse(event, dropinModelInstance, dropinInstance) {
    var pageFlow = dropinModelInstance.dropinConfigs.pageFlow;

    switch (pageFlow) {
        case 'cart':
            dropInPaymentMethodsHelper.handleUpdateShippingMethodsList(event, dropinModelInstance, dropinInstance);
            dropInPaymentMethodsHelper.handleCheckoutSubmitButton(event.newViewId, pageFlow);
            break;
        case 'checkout':
            var viewIdsObject = dropInPaymentMethodsHelper.getCurrentViewIdsObject(event);
            var newViewId = viewIdsObject.newViewId;

            // Handles the 'addCard' button which uses for adding the new Credit Card
            dropInPaymentMethodsHelper.handleAddCardButton(event.newViewId);

            // Sets or removes 'active' class to payment method tab, in order to send approrpiate payment method data
            dropInPaymentMethodsHelper.handleDropInActivePaymentMethodTab(viewIdsObject, pageFlow);

            // Handles all functionaluty related to the billling address on Checkout page
            dropInPaymentMethodsHelper.handleBillingAddressFunctiinality(newViewId);
            // Shows or hides the billing address info message depends of payment method
            dropInPaymentMethodsHelper.handleBillingAddressInfoAlert(newViewId);

            dropInPaymentMethodsHelper.handleCheckoutSubmitButton(event.newViewId, pageFlow);
            dropInPaymentMethodsHelper.handleShippingAddressOverride(event, dropinModelInstance, dropinInstance);
            break;
        case 'account':
            // Removes a Drop-in from the account page in case when there is no saved payment methods and vault is disabled
            if (event.newViewId === 'options' && event.previousViewId === 'delete-confirmation' &&
                !dropinModelInstance.dropinConfigs.vaultModeEnabled) {
                dropinModelInstance.dropinSdk.teardown(dropinInstance);
            }

            dropInPaymentMethodsHelper.handleAddCardButton(event.newViewId);

            dropinAccountHelper.removeBraintreeMethodCheckContainers();
            break;
        default:
            dropInPaymentMethodsHelper.handleCheckoutSubmitButton(event.newViewId, pageFlow);
            break;
    }
}

/**
 * Returns a total amount as string value
 * @param {Object} dropinModelInstance A Drop-in model instance
 * @returns {string} A total amount
 */
function getTotalAmountAsString(dropinModelInstance) {
    return String(dropinModelInstance.basketData.amount);
}

/**
 * Gets required additional shipping info for 3ds
 *
 * @param {Object} orderAddress - User's shipping address
 * @returns {Object} an object with required fields
 */
function getShippingAdditionalInfo(orderAddress) {
    return {
        workPhoneNumber: orderAddress.phone,
        shippingGivenName: orderAddress.recipientName.split(' ').slice(0, -1).join(' '),
        shippingSurname: orderAddress.recipientName.split(' ').slice(-1).join(' '),
        shippingPhone: orderAddress.phone,
        shippingAddress: {
            streetAddress: orderAddress.line1,
            extendedAddress: orderAddress.line2,
            locality: orderAddress.city,
            region: orderAddress.state,
            postalCode: orderAddress.postalCode,
            countryCodeAlpha2: orderAddress.countryCode
        }
    };
}

/**
 * Returns the threeDSecure options nedded for creating a Drop-in
 * @param {string} basketDataUrl Get basket info url as string
 * @returns {Object} ThreeDSecure options
 */
function getThreeDSecureOptions(basketDataUrl) {
    var basketData = requestHelper.getBasketData(basketDataUrl);
    var shippingAdditionalInfo = getShippingAdditionalInfo(basketData.shippingAddress);
    var billingData = billingFormHelper.getBillingAddressFormValues();

    return {
        threeDSecure: {
            amount: String(basketData.amount),
            email: document.querySelector('.customer-summary-email').textContent,
            additionalInformation: shippingAdditionalInfo,
            billingAddress: {
                givenName: billingData.firstName,
                surname: billingData.lastName,
                phoneNumber: billingData.phone,
                streetAddress: billingData.address1,
                extendedAddress: billingData.address2,
                locality: billingData.city,
                region: billingData.stateCode,
                postalCode: billingData.postalCode,
                countryCodeAlpha2: billingData.country
            }
        }
    };
}

module.exports = {
    processOnChangeActiveViewResponse,
    getTotalAmountAsString,
    getThreeDSecureOptions
};
