'use strict';

var DropinProductModel = require('../models/dropinProductModel');
var ErrorHandlingBaseModel = require('../errorhandler/errorHandlingBaseModel');

// Helpers
var dropinHelper = require('../helpers/dropInHelper');
var loaderInstance = require('../helpers/loaderHelper');

var dropinDisplayBehavior = require('../components/dropinDisplayBehavior');

/**
 * Initiates all necessary drop-in components
 */
function init() {
    // Variables needed for creation of "DropinBaseModel" instance
    var $submitPaymentButton = document.querySelector('.js_dropin-pdp-submit-btn');
    var $dropinWrapper = document.querySelector('.js-dropin-pdp-page-billing-step');
    var $dropinContainer = document.querySelector('.js-dropin-pdp-page-billing-step #dropin-container');
    var dropinLoader = loaderInstance(document.querySelector('.js_braintreeDropinLoader'));
    var paymentMethodsConfigurations = dropinHelper.getBraintreeConfigs($dropinContainer);
    var errorHandlingBaseModelInstance = new ErrorHandlingBaseModel(
        paymentMethodsConfigurations.dropinConfigs.errorMessages
    );
    var DropInModelInstance = new DropinProductModel(
        dropinLoader,
        errorHandlingBaseModelInstance,
        $submitPaymentButton,
        $dropinContainer,
        paymentMethodsConfigurations
    );

    dropinDisplayBehavior.initProductPage($dropinWrapper);

    DropInModelInstance.initDropIn();
}

module.exports = {
    init
};
