'use strict';

var dropinSdk = require('../dropinsdk/dropinSdk');

// Payment handlers
var payPalPaymentHandler = require('../paymenthandlers/paypal/payPalPaymentHandler');
var creditCardPaymentHandler = require('../paymenthandlers/creditCardPaymentHandler');
var googlePayPaymentHandler = require('../paymenthandlers/googlePay/googlePayPaymentHandler');
var venmoHandler = require('../paymenthandlers/venmoPaymentHandler');
var applePayPaymentHandler = require('../paymenthandlers/applePay/applePayPaymentHandler');

// Models
var GooglePayModel = require('../models/dropinGooglePayModel');
var ApplePayModel = require('../models/dropInApplePayModel');

// Helpers
var requestsHelper = require('../helpers/requestHelper');
var dropInHelper = require('../helpers/dropInHelper');
var billingFormHelper = require('../helpers/billingFormHelper');
var dropinSessionPaymentHelper = require('../helpers/dropInSessionPaymentHelper');
var billingCheckoutPageHelper = require('../helpers/billingCheckoutPageHelper');
var dropinPaymentMethodHelper = require('../helpers/dropInPaymentMethodsHelper');

var dropinAmountValueBehavior = require('../components/dropinAmountValueBehavior');


/**
 * A DropinBase constructor. Basicly use for the Billing Checkout, Cart, Mini cart pages
 * @param {Object} dropinLoader A dropin loader
 * @param {DOMElement} $totalAmountElement A total amount element
 * @param {Object} errorHandlingModelInstance An error handling model instance
 * @param {DOMElement} $submitPaymentButton A Submit payment button
 * @param {DOMElement} $addCardButton An Add card button
 * @param {DOMElement} $dropinContainer A dropinContainer
 * @param {Object} paymentMethodsConfigurations A payment methods configuration object
 * @param {Object} errorHandlingDuplicateCClModelInstance An error handling model instance
 * @param {DOMElement} $closeAlertButton A close alert button
 */
function DropinBaseModel(
    dropinLoader,
    $totalAmountElement,
    errorHandlingModelInstance,
    $submitPaymentButton,
    $addCardButton,
    $dropinContainer,
    paymentMethodsConfigurations,
    errorHandlingDuplicateCClModelInstance,
    $closeAlertButton
) {
    GooglePayModel.call(
        this,
        paymentMethodsConfigurations
    );

    ApplePayModel.call(
        this,
        paymentMethodsConfigurations
    );
    this.dropinSubmitButtons = [
        $submitPaymentButton,
        $addCardButton,
        $closeAlertButton
    ];
    this.paymentMethodsConfigurations = paymentMethodsConfigurations;
    this.dropinConfigs = this.paymentMethodsConfigurations.dropinConfigs;
    this.$dropinContainer = $dropinContainer;
    this.dropinSdk = dropinSdk;
    this.clientInstancePromise = dropInHelper.createClientInstance(this.dropinConfigs.clientToken);
    this.basketDataUrl = this.dropinConfigs.getOrderInfoUrl;
    this.basketData = requestsHelper.getBasketData(this.basketDataUrl);
    this.payPalConfigurations = this.paymentMethodsConfigurations.payPalButtonConfig;
    this.errorHandlingModelInstance = errorHandlingModelInstance;
    this.errorHandlingDuplicateCClModelInstance = errorHandlingDuplicateCClModelInstance;
    this.$totalAmountElement = $totalAmountElement;
    this.loader = dropinLoader;
}

// ES5 inheritance
DropinBaseModel.prototype = Object.assign(GooglePayModel.prototype, ApplePayModel.prototype);

/**
 * Gets a PayPal configs object for Drop-in
 * @returns {Object} A PayPal configs object for Drop-in
 */
DropinBaseModel.prototype.getPayPalConfigs = function () {
    var mainPayPalConfigurations = this.payPalConfigurations.options;

    var paymentObjectData = {
        currency: mainPayPalConfigurations.currency,
        flow: this.payPalConfigurations.vaultModeEnabled ? 'vault' : 'checkout',
        intent: mainPayPalConfigurations.intent,
        locale: mainPayPalConfigurations.locale,
        enableShippingAddress: mainPayPalConfigurations.enableShippingAddress,
        billingAgreementDescription: mainPayPalConfigurations.billingAgreementDescription,
        displayName: mainPayPalConfigurations.displayName
    };

    // The amount value is not available on PDP page
    // A Drop-in for PDP page will render only with 'vault' flow
    if (this.dropinConfigs.pageFlow !== 'pdp') {
        paymentObjectData.amount = this.basketData.amount;
    }

    return paymentObjectData;
};

/**
 * Process of the tokenizePayload of payment method
 * @param {Object} dropinModelInstance A Dropin model instance
 * @param {tokenizePayload} dropinResponse A tokenizePayload of payment method
 * @param {dropinInstance} dropinInstance A dropinInstanse
 */
DropinBaseModel.prototype.processPayment = function (dropinModelInstance, dropinResponse, dropinInstance) {
    var paymentMethodType = dropinResponse.type;
    var paypalAccountType = 'PayPalAccount';
    var dropinConfigs = dropinModelInstance.dropinConfigs;
    var pageFlow = dropinConfigs.pageFlow;
    var isCheckoutFlow = pageFlow === 'checkout';

    // Validates threeDSecure result
    if (dropinConfigs.is3DSecureEnabled && isCheckoutFlow) {
        dropinModelInstance.errorHandlingModelInstance.validateThreeDSecureVerification(
            dropinResponse,
            dropinModelInstance,
            dropinInstance
        );
    }

    // Shows error in case if current basket has zero total price (Google Pay, PapPal)
    // Except the PDP page when basket data does not exist
    if (dropinModelInstance.basketData && dropinModelInstance.basketData.amount === 0) {
        dropinModelInstance.errorHandlingModelInstance.throwZeroAmountError(paymentMethodType);
    }

    // Removes active payment data from inputs
    if (isCheckoutFlow) {
        dropinSessionPaymentHelper.removeActiveSessionPayment();
    }

    // The Billing address summary message is nedded only for the vaulted payPal payment method
    // Hides the billing address summary message on the order confirmation page
    if (paymentMethodType !== paypalAccountType && isCheckoutFlow) {
        billingFormHelper.hideBillingSummaryMessage();
    }

    switch (paymentMethodType) {
        case 'PayPalAccount':
            payPalPaymentHandler.paymentProcessing(
                dropinResponse,
                pageFlow,
                dropinModelInstance
            );
            break;
        case 'CreditCard':
            creditCardPaymentHandler.checkoutPaymentProcessing(dropinResponse);
            break;
        case 'AndroidPayCard':
            googlePayPaymentHandler.paymentProcessing(
                dropinResponse,
                pageFlow,
                dropinModelInstance
            );
            break;
        case 'VenmoAccount':
            venmoHandler.checkoutPaymentProcessing(dropinResponse);
            break;
        case 'ApplePayCard':
            applePayPaymentHandler.paymentProcessing(
                dropinResponse,
                pageFlow,
                dropinModelInstance
            );
            break;
        default:
            break;
    }
};

/**
 * Adds an event listener to the Drop-in buttons
 * @param {DOMElement} $button A button needed the event listener
 * @param {Object} DropinBaseModelInstance An instance of DropInBase constructor
 * @param {dropinInstance} dropinInstance A Dropin instance
 */
DropinBaseModel.prototype.addDropInEventListener = function ($button, DropinBaseModelInstance, dropinInstance) {
    if ($button) {
        $button.addEventListener('click', function (e) {
            e.preventDefault();
            DropinBaseModelInstance.dropinSdk.requestPaymentMethod(
                dropinInstance,
                DropinBaseModelInstance.dropinConfigs
            )
                .then(function (payload) {
                    DropinBaseModelInstance.errorHandlingModelInstance.hideError();
                    DropinBaseModelInstance.processPayment(DropinBaseModelInstance, payload, dropinInstance);

                    // Verifies if credit card isn't duplicated
                    if ($button.classList.contains('js_dropin-addCard-btn')) {
                        DropinBaseModelInstance.dropinSdk.checkIfDuplicateCCSubmitted(dropinInstance, payload);
                    }

                    // Closes alert message
                    if ($button.classList.contains('js-dropin-alert-container-close-btn')) {
                        DropinBaseModelInstance.errorHandlingDuplicateCClModelInstance.hideError();
                    }

                    // Immitates click of 'Next:Place Order' button on the billing checkout page
                    if ($button.classList.contains('js_dropin-checkout-submit-btn')
                        && DropinBaseModelInstance.dropinConfigs.pageFlow === 'checkout') {
                        document.querySelector('.submit-payment').click();
                    }
                })
                .catch(function (error) {
                    DropinBaseModelInstance.loader.hide();
                    e.stopPropagation();
                    DropinBaseModelInstance.errorHandlingModelInstance.showErrorByObject(error);
                });
        });
    }
};

/**
 * Initiates a Drop-in
 * @returns {Promise} DropIn instance
 */
DropinBaseModel.prototype.initDropIn = function () {
    var DropinBaseModelInstance = this;
    var isPaymentOptionsForDropin = this.dropinConfigs.isGooglePayEnabledInDropIn ||
        this.dropinConfigs.isVenmoEnabledInDropIn ||
        this.dropinConfigs.isPayPalEnabledInDropIn ||
        this.dropinConfigs.isCreditCardEnabledInDropIn ||
        (this.dropinConfigs.isApplePayEnabledInDropIn && window.ApplePaySession);

    // Clears a '__paypal_storage__' item from the local storage in order to avoid paypal sdk conflicts
    // Can happens when PayPal style configuration in bm was used
    window.localStorage.removeItem('__paypal_storage__');

    // Does not initate Drop-in in case if there are no available options(Apple pay, PayPal, Google Pay...)
    if (isPaymentOptionsForDropin) {
        return DropinBaseModelInstance.dropinSdk.init(DropinBaseModelInstance)
            .then(function (dropinInstance) {
                var pageFlow = DropinBaseModelInstance.dropinConfigs.pageFlow;
                var activePaymentMethod = dropinInstance._model._activePaymentMethod;
                // The methods string means that Drop-in contains the saved payment methods
                // The 'onChangeActiveView' returns methods string as newViewId(when newViewId is saved payment method)
                var methodsString = activePaymentMethod ? 'methods' : '';

                dropinAmountValueBehavior.initTotalAmountElementObserver(dropinInstance, DropinBaseModelInstance);

                // Sets the page flow data attribute in order to split 'submitPayment' buttons
                // when Drop-in is displyed on two pages at the same time
                dropInHelper.setDataPageFlowAttribute(pageFlow);

                if (pageFlow === 'checkout') {
                    billingCheckoutPageHelper.handleBillingCheckoutFunctionality(
                        activePaymentMethod,
                        DropinBaseModelInstance.$dropinContainer
                    );
                }

                // Shows or hides a submit button
                dropinPaymentMethodHelper.handleCheckoutSubmitButton(
                    methodsString,
                    pageFlow
                );

                // Inits onChangeActive view event listener
                DropinBaseModelInstance.dropinSdk.onChangeActiveView(dropinInstance, DropinBaseModelInstance);

                // Add event listeners to the 'addCard' and 'PlaceOrder' buttons
                // We need to add event listener to 'addCard' button in order to save credit card
                // All payment methods will submitted by 'placeOrder' button
                DropinBaseModelInstance.dropinSubmitButtons.forEach(function ($button) {
                    DropinBaseModelInstance.addDropInEventListener($button, DropinBaseModelInstance, dropinInstance);
                });
            })
            .catch(function (error) {
                DropinBaseModelInstance.loader.hide();
                DropinBaseModelInstance.errorHandlingModelInstance.showErrorByObject(error);
            });
    }
};

module.exports = DropinBaseModel;
