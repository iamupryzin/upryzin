'use strict';

/**
 * Returns shipping address based on Apple Pay payment shipping contact
 * @param {Object} shippingContact Shipping address data
 * @returns {Object} Shipping address with required fields
 */
function getShippingAddress(shippingContact) {
    return {
        streetAddress: shippingContact.addressLines[0],
        extendedAddress: shippingContact.addressLines[1],
        locality: shippingContact.locality,
        region: shippingContact.administrativeArea.toUpperCase(),
        postalCode: shippingContact.postalCode,
        countryCodeAlpha2: shippingContact.countryCode.toUpperCase(),
        firstName: shippingContact.givenName,
        lastName: shippingContact.familyName,
        phone: shippingContact.phoneNumber,
        email: shippingContact.emailAddress
    };
}

/**
 * Returns billing address based on Apple Pay payment billing contact
 * @param {Object} billingContact Billing address data
 * @param {string} email Email
 * @param {string} phone Phone number
 * @returns {Object} Billing address with required fields
 */
function getBillingAddress(billingContact, email, phone) {
    return {
        streetAddress: billingContact.addressLines[0],
        extendedAddress: billingContact.addressLines[1],
        locality: billingContact.locality,
        region: billingContact.administrativeArea.toUpperCase(),
        postalCode: billingContact.postalCode,
        countryCodeAlpha2: billingContact.countryCode.toUpperCase(),
        firstName: billingContact.givenName,
        lastName: billingContact.familyName,
        email: email,
        phone: phone
    };
}

/**
 * Returns Apple Pay payment object with required data for backend
 * @param {Object} tokenizedPayload Apple Pay payment data
 * @returns {Object} Apple Pay payment object with required fileds
 */
function getTokenizedPaymentData(tokenizedPayload) {
    var rawPaymentData = tokenizedPayload.details.rawPaymentData;
    var data = {
        nonce: tokenizedPayload.nonce,
        deviceData: tokenizedPayload.deviceData
    };
    var shippingAddressData = rawPaymentData.shippingContact;
    var billingAddressData = rawPaymentData.billingContact;

    if (shippingAddressData) {
        data.shippingAddress = getShippingAddress(shippingAddressData);
    }

    if (billingAddressData) {
        data.billingAddress = getBillingAddress(billingAddressData, shippingAddressData.emailAddress, shippingAddressData.phoneNumber);
    }

    return data;
}

module.exports = {
    getTokenizedPaymentData
};
