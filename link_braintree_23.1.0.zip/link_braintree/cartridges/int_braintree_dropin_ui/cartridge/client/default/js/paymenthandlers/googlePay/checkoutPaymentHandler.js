'use strict';

const billingFormHelper = require('../../helpers/billingFormHelper');

let gpbillingAddress;

/**
 * Returns a details object needed for updating of demandware billing address
 * @param {Object} details A details object from a Google Pay tokinizePayload
 * @returns {Object} A
 */
function getGooglePayDetailsObject(details) {
    var fullName = details.name.split(' ');

    return {
        firstName: fullName[0],
        lastName: fullName[1],
        phoneNumber: details.phoneNumber
    };
}

/**
 * Fills all Google pay payment fields that is necessary for process payment on the server side
 * @param {tokenizePayload} payload A Google pay tokenizePayload
 */
function fillGooglePayPaymentFields(payload) {
    var googlePayDetails = payload.details;
    var gpCardDescription = `${googlePayDetails.cardType} ${googlePayDetails.lastFour}`;

    document.querySelector('#braintreeGooglePayNonce').value = payload.nonce;
    document.querySelector('#braintreeGooglePayBillingAddress').value = JSON.stringify(gpbillingAddress);
    document.querySelector('#braintreeGooglePayCardDescription').value = gpCardDescription;
    document.querySelector('#braintreeGooglepayPaymentType').value = googlePayDetails.cardType;
}

/**
 * Process a Google pay tokenizePayload from the Checkout page
 * @param {tokenizePayload} payload A Google pay tokenizePayload
 */
function paymentProcessing(payload) {
    gpbillingAddress = payload.details.rawPaymentData.paymentMethodData.info.billingAddress;
    var gpDetails = getGooglePayDetailsObject(gpbillingAddress);

    fillGooglePayPaymentFields(payload);

    // Updating Storefront Billing Form data with GooglePay Billing
    var storeFrontBillingData = billingFormHelper.mapBraintreeWithDwBillingAddress(
        billingFormHelper.getSuitableGoogllePayBillingAddress(gpbillingAddress),
        gpDetails
    );

    billingFormHelper.updateBillingFormValues(storeFrontBillingData);
}

module.exports = {
    paymentProcessing
};
