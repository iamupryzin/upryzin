'use strict';

var applePaySdk = require('../dropinsdk/applePaySdk');
var applePayInstance;

/**
 * A DropinApplePay constructor
 * @param {Object} paymentMethodsConfigurations The payment methods configuration object
 */
function DropinApplePayModel(
    paymentMethodsConfigurations
) {
    this.applePayConfiguration = paymentMethodsConfigurations.applePayButtonConfig;
    this.applePaySdk = applePaySdk;
}

/**
 * Creates a Braintree Apple pay instace
 * @returns {Promise} A promise that resolves with applePayInstance
 */
DropinApplePayModel.prototype.createApplePayInstance = function () {
    return this.applePaySdk.createApplePayPayment(this.clientInstancePromise);
};

/**
 * Initiated a applePayInstance as a global variable
 * @param {applePayInstance} apInstace An Apple pay instance
 */
DropinApplePayModel.prototype.initApplePayInstance = function (apInstace) {
    applePayInstance = apInstace;
};

/**
 * Gets an Apple pay configs object from braintree
 * @param {string} amount A total amount
 * @returns {Object} An Apple pay config object
 */
DropinApplePayModel.prototype.getApplePayConfigs = function (amount) {
    var paymentDataRequest = this.applePaySdk.createPaymentDataRequest(
        applePayInstance,
        this.applePayConfiguration,
        amount
    );

    paymentDataRequest.requiredBillingContactFields = ['postalAddress', 'name'];
    paymentDataRequest.requiredShippingContactFields = ['postalAddress', 'name', 'phone', 'email'];

    // Saves an Apple pay payment object in order to update this object
    // in case when the total amount changed
    this.paymentRequest = paymentDataRequest;

    return {
        displayName: this.applePayConfiguration.options.displayName,
        paymentRequest: paymentDataRequest
    };
};

module.exports = DropinApplePayModel;
