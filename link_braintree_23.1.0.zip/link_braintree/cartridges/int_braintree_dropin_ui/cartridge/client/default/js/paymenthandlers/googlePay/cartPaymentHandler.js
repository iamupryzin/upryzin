'use strict';

var dropInHelper = require('../../helpers/dropInHelper');
var googlePayCarPagetHelper = require('../../helpers/googlePayCartPageHelper');
var requestHelper = require('../../helpers/requestHelper');

// Global variables
var googlepayCheckoutFormData;

/**
 * Expends Google Pay checkout form with required data
 *
 * @param {Object} payload Checkout required data
 */
function expandGooglePayCheckoutFormData(payload) {
    var payloadDetails = payload.details;
    var cardType = payloadDetails.cardType;
    var csrfToken = document.querySelector('.braintree-dropin-cart-wrap  #csrf_token');
    var googlePayCardDescription = `${cardType} ${payloadDetails.lastFour}`;
    var gpShippingAddress = googlePayCarPagetHelper.createGooglepayShippingAddressData(payloadDetails.rawPaymentData.shippingAddress);
    var gpBillingAddress = googlePayCarPagetHelper.createGooglepayBillingAddressData(payloadDetails.rawPaymentData);

    googlepayCheckoutFormData.append(csrfToken.name, csrfToken.value);
    googlepayCheckoutFormData.append('braintreeGooglePayNonce', payload.nonce);
    googlepayCheckoutFormData.append('braintreeGooglePayDeviceData', payload.deviceData);
    googlepayCheckoutFormData.append('braintreeGooglePayCardDescription', googlePayCardDescription);
    googlepayCheckoutFormData.append('braintreeGooglepayPaymentType', cardType);
    googlepayCheckoutFormData.append('braintreeGooglePayShippingAddress', JSON.stringify(gpShippingAddress) || '{}');
    googlepayCheckoutFormData.append('braintreeGooglePayBillingAddress', JSON.stringify(gpBillingAddress) || '{}');
}

/**
 * Process a Google pay tokenizePayload from the Cart page
 * @param {tokenizePaylaod} payload An Apple pay tokenizePayload
 * @param {Object} dropinInstance A dropin instance
 */
function paymentProcessing(payload, dropinInstance) {
    var rawPaymentData = payload.details.rawPaymentData;
    var gpBillingAddress = googlePayCarPagetHelper.createGooglepayBillingAddressData(
        rawPaymentData
    );
    var $dropinWrapper = document.querySelector('.braintree-dropin-cart-wrap');
    const placeOrderUrl = window.braintreeUrls.placeOrderUrl;
    const checkoutFromCartUrl = window.braintreeUrls.checkoutFromCartUrl;
    var checkoutFormFields = $dropinWrapper.getAttribute('data-checkout-form-fields');
    var paymentFieldsData = dropInHelper.getPaymentFieldsData(gpBillingAddress, dropinInstance.googlePayConfiguration.paymentMethodName);

    // Creates and updates Google Pay checkout form for service side
    googlepayCheckoutFormData = dropInHelper.createPaymentFormData(checkoutFormFields, paymentFieldsData);

    expandGooglePayCheckoutFormData(payload);

    // submit customer form with email (CheckoutServices-SubmitCustomer)
    // as we skip step "login via guest/registered user" while express checkout
    // email is set only in case of guest checkout and if email is not already set
    requestHelper.submitCustomerForm(rawPaymentData.email);

    $.ajax({
        type: 'POST',
        url: checkoutFromCartUrl,
        data: googlepayCheckoutFormData,
        contentType: false,
        processData: false,
        success: function (res) {
            if (res.error) {
                var errorMessage = '';

                if (res.fieldErrors.length) {
                    res.fieldErrors.forEach(function (error, index) {
                        var keys = Object.keys(error);

                        if (keys.length) {
                            errorMessage += `${keys[index].replace('dwfrm_billing_', '').replace('_', ' ')} ${res.fieldErrors[index][keys[index]]}. `;
                        }
                    });

                    dropinInstance.errorHandlingModelInstance.showErrorByMessage(errorMessage);
                }

                if (res.serverErrors.length) {
                    res.serverErrors.forEach(function (error) {
                        errorMessage += `${error}. `;
                    });
                    dropinInstance.errorHandlingModelInstance.showErrorByMessage(errorMessage);
                }

                if (res.cartError) {
                    window.location.href = res.redirectUrl;
                }

                dropinInstance.loader.hide();

                return;
            }

            sessionStorage.setItem('pageState', 'cart');
            // loader.hide()
            window.location.href = placeOrderUrl;
            dropinInstance.loader.hide();
        },
        error: function (err) {
            dropinInstance.loader.hide();

            if (err && err.redirectUrl) {
                window.location.href = err.redirectUrl;
            }
        }
    });
}

module.exports = {
    paymentProcessing
};
