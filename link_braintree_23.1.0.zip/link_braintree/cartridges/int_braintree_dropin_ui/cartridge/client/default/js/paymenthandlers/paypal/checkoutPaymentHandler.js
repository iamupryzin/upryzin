'use strict';

// helpers
const billingFormHelper = require('../../helpers/billingFormHelper');

let isPayPalBillingAddressExist;

/**
 * Fills all Paypal payment fields that is necessary for process payment on the server side
 * @param {tokenizePayload} payload A PayPal tokenizePayload
 */
function fillPayPalPaymentFields(payload) {
    document.querySelector('input[name=braintreePaypalNonce]').value = payload.nonce;
    document.querySelector('input[name=braintreePaypalEmail]').value = payload.details.email;
    document.querySelector('input[name=braintreePaypalRiskData]').value = payload.deviceData;
    document.querySelector('input[name=braintreeDropinIsPayPalBillingAddressExist]').value = isPayPalBillingAddressExist;
}

/**
 * Process a PayPal tokenizePayload on the Checkout page
 * @param {tokenizePayload} payload A PayPal tokenizePayload
 */
function paymentProcessing(payload) {
    var payloadDetails = payload.details;
    var billingAddress = payload.details.billingAddress;
    isPayPalBillingAddressExist = Boolean(billingAddress);

    // Whether show or hide a billing address on the order confirmation page
    billingFormHelper.handleSummaryBillingAddress(isPayPalBillingAddressExist);

    if (isPayPalBillingAddressExist && payloadDetails) {
        billingFormHelper.copyPayPalBillingAddressToDw(billingAddress, payloadDetails);
    }

    fillPayPalPaymentFields(payload);
}

module.exports = {
    paymentProcessing
};
