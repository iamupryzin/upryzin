'use strict';

var DropinBaseModel = require('../models/dropinBaseModel');
var ErrorHandlingCartModel = require('../errorhandler/errorHandlingCartModel');

// Helpers
var dropInHelper = require('../helpers/dropInHelper');
var loaderInstance = require('../helpers/loaderHelper');

/**
 * Initiates all necessary drop-in components
 */
function init() {
    // Variables needed for creation of "DropinBaseModel" instance
    var $submitPaymentButton = document.querySelector('.js_dropin-cart-submit-btn');
    var $dropinContainer = document.querySelector('.js-dropin-cart-page-step #dropin-container');
    var $totalAmountElement = document.querySelector('.grand-total');
    var dropinLoader = loaderInstance(document.querySelector('.js_braintreeDropinLoader'));
    var paymentMethodsConfigurations = dropInHelper.getBraintreeConfigs($dropinContainer);
    var dropinConfigs = paymentMethodsConfigurations.dropinConfigs;
    var errorHandlingCartModelInstance = new ErrorHandlingCartModel(dropinConfigs.errorMessages);
    var DropInModelInstance = new DropinBaseModel(
        dropinLoader,
        $totalAmountElement,
        errorHandlingCartModelInstance,
        $submitPaymentButton,
        null,
        $dropinContainer,
        paymentMethodsConfigurations
    );

    if (!dropinConfigs.isApplePayEnabledInDropIn || !window.ApplePaySession) {
        DropInModelInstance.initDropIn();
    } else {
        // Inits applePayInstance in order fill drop in component apple pay
        DropInModelInstance.createApplePayInstance()
            .then(function (apInstance) {
                DropInModelInstance.initApplePayInstance(apInstance);
                DropInModelInstance.initDropIn();
            })
            .catch(function (error) {
                errorHandlingCartModelInstance.showErrorByObject(error);
            });
    }
}

module.exports = {
    init
};
