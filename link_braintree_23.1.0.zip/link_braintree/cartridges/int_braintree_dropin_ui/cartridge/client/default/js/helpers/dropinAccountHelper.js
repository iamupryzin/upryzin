'use strict';

var dropinHelper = require('../helpers/dropInHelper');

/**
 * Handles visibility of the options (PayPal, Credit Card) in Drop-in
 * @param {Object} paymentMethodsConfigs A payment configurations object
 */
function handlePaymentOptionsInDropin(paymentMethodsConfigs) {
    var isVaultEnabled = paymentMethodsConfigs.prefs.vaultMode;
    var dropinConfigs = paymentMethodsConfigs.dropinConfigs;

    // Hides 'Add an another payment method' button when vault mode is disabled
    // Buyer will see just a list of saved payment methods
    if (!isVaultEnabled && dropinConfigs.isSavedVisibleDropinPaymentMethods) {
        var $braintreeLargeButton = document.querySelector('.braintree-large-button');

        dropinHelper.hideHtmlElement($braintreeLargeButton);
    }
}

/**
 * Modifies all Drop-in labels to appropriate account labels
 * @param {Object} dropinConfigs A Drop-in configs object
 */
function modifyDropinLabels(dropinConfigs) {
    var dropinLabels = dropinConfigs.dropinLabels;
    var $braintreeLargeButton = document.querySelector('.braintree-large-button > span');
    var $otherWayToPayLabel = document.querySelector('[data-braintree-id="other-ways-to-pay"]');
    var $braintreeCardSheetText = document.querySelector('.braintree-sheet__header .braintree-sheet__header-label .braintree-sheet__text');
    var $chooseWayToPayLabel = document.querySelector('[data-braintree-id="choose-a-way-to-pay"]');

    $braintreeLargeButton.innerHTML = dropinLabels.largeButtonLabel;
    $otherWayToPayLabel.innerHTML = dropinLabels.otherWayToPayLabel;
    $braintreeCardSheetText.innerHTML = dropinLabels.cardSheetTextLabel;
    $chooseWayToPayLabel.innerHTML = dropinLabels.chooseWayToPayLabel;
}

/**
 * Removes all the Braintree method check containers from Drop-in
 */
function removeBraintreeMethodCheckContainers() {
    var $braintreeMethodCheckContainers = document.querySelectorAll('.braintree-method__check-container');

    if ($braintreeMethodCheckContainers.length !== 0) {
        $braintreeMethodCheckContainers.forEach(function (el) {
            el.remove();
        });
    }
}

/**
 * Removes a methods label from Drop-in
 */
function removeMethodsLabelFromDropin() {
    var $methodsLabel = document.querySelector('[data-braintree-id="methods-label"]');

    if ($methodsLabel) {
        $methodsLabel.remove();
    }
}

/**
 * Creates Drop-in main label
 * @param {Object} dropinConfigs A Drop-in configs object
 */
function createDropinMainLabel(dropinConfigs) {
    var $dropinMainContainer = document.querySelector('.braintree-dropin');
    var $dropinMainLabel = document.createElement('div');

    $dropinMainLabel.setAttribute('data-braintree-id', 'methods-label');
    $dropinMainLabel.innerHTML = dropinConfigs.dropinLabels.mainLabel;
    $dropinMainLabel.style.marginBottom = '-1em';

    $dropinMainContainer.prepend($dropinMainLabel);
}

module.exports = {
    handlePaymentOptionsInDropin,
    modifyDropinLabels,
    removeBraintreeMethodCheckContainers,
    removeMethodsLabelFromDropin,
    createDropinMainLabel
};
