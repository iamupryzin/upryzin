'use strict';

/**
 * Creates Apple pay payment instance
 * @param {Promise} btClientInstancePromise A braintree client instance
 * @returns {Promise} A promise resolve with the Apple pay instance
 */
function createApplePayPayment(btClientInstancePromise) {
    return btClientInstancePromise
        .then(function (btClientInstance) {
            return braintree.applePay.create({
                client: btClientInstance
            });
        });
}

/**
 * Creates a configuration object for creation an Apple pay session
 * @param {applePayInstance} applePayInstance Apple pay instance
 * @param {Object} applePayConfigs Apple pay configs object
 * @param {number} amount Order total amount
 * @returns {Object} Configuration object
 */
function createPaymentDataRequest(applePayInstance, applePayConfigs, amount) {
    return applePayInstance.createPaymentRequest({
        total: {
            label: applePayConfigs.options.displayName,
            amount: amount
        }
    });
}

module.exports = {
    createPaymentDataRequest,
    createApplePayPayment
};
