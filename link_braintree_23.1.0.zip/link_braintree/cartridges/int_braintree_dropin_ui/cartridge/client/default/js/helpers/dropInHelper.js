'use strict';

/**
 * Gets a Braintree configs object
 * @param {DOMElement} $dropinContainer A drop-in container
 * @returns {Object} A Braintree configs object
 */
function getBraintreeConfigs($dropinContainer) {
    var braintreeConfigs;

    braintreeConfigs = JSON.parse($dropinContainer.getAttribute('data-braintree'));

    return braintreeConfigs;
}

/**
 * Create Braintree Client Instance from Client Token
 * @param {string} clientToken braintree client token
 * @returns {Promise} returns promise with Braintree Client Instance
 */
function createClientInstance(clientToken) {
    return braintree.client.create({
        authorization: clientToken
    });
}

/**
 * Converts credit card type to one style: first letter in upper case
 * to make session card type look like saved CC type
 * ex: MasterCard -> Mastercard
 * @param {string} type card type
 * @returns {string} converted card type
 */
function convertCreditCardType(type) {
    var cardType = type.toLowerCase();

    return cardType.replace(/_/g, ' ').replace(cardType.charAt(0), (cardType.charAt(0)).toUpperCase());
}

/**
 * Depends on the value flag, sets style.display to the $continueButton
 * @param {boolean} flag Boolean value
 * @returns {void}
 */
function continueButtonToggle(flag) {
    var $continueButton = document.querySelector('button.submit-payment');

    $continueButton.style.display = flag ? '' : 'none';
}

/**
 * Shows DOM element
 * @param {DOMElement} $element A DOM(HTML) element
 */
function showHtmlElement($element) {
    if ($element) {
        $element.classList.add('show');
        $element.classList.remove('hide');
    }
}

/**
 * Hides DOM element
 * @param {DOMElement} $element A DOM(HTML) element
 */
function hideHtmlElement($element) {
    if ($element) {
        $element.classList.add('hide');
        $element.classList.remove('show');
    }
}

/**
 * Create formData from fields data
 *
 * @param {Object} paymentFields fields data values
 * @param {Object} fieldsData fields data values
 * @returns {Object} cart billing form data
 */
function createPaymentFormData(paymentFields, fieldsData) {
    var paymentFieldsParsed;

    if (paymentFields instanceof Object) {
        paymentFieldsParsed = paymentFields;
    } else {
        paymentFieldsParsed = JSON.parse(paymentFields);
    }

    return Object.entries(paymentFieldsParsed).reduce(function (formData, entry) {
        const [key, field] = entry;
        if (field instanceof Object) {
            formData.append(field.name, fieldsData && fieldsData[key] !== null ? fieldsData[key] : field.value);
        }
        return formData;
    }, new FormData());
}

/**
 * Creates customer form with email to submit it to CheckoutServices-SubmitCustomer endpoint
 * @param {string} email email from payment method's response
 * @returns {Object} customer form data
 */
function createCustomerFormData(email) {
    var data = {
        email: email
    };

    var $braintreeDropinCartWrap = document.querySelector('.braintree-dropin-cart-wrap') ||
        document.querySelector('.braintree-dropin-cart-paypal-wrap');
    var csrfToken = $braintreeDropinCartWrap.querySelector('#csrf_token');

    var checkoutCustomerFormFields = $braintreeDropinCartWrap.getAttribute('data-checkout-customer-form-fields');
    var customerFormData = createPaymentFormData(checkoutCustomerFormFields, data);

    customerFormData.append(csrfToken.name, csrfToken.value);

    return customerFormData;
}

/**
 * Returns payment field data to be send on backend
 * @param {Object} addressData Address data to be set
 * @param {string} paymentMethodName Payment method name
 * @returns {Object} payment data
 */
function getPaymentFieldsData(addressData, paymentMethodName) {
    return {
        firstName: addressData.firstName,
        lastName: addressData.lastName,
        address1: addressData.streetAddress,
        address2: addressData.extendedAddress || '',
        city: addressData.locality,
        postalCode: addressData.postalCode,
        stateCode: addressData.stateCode || addressData.region,
        country: addressData.countryCodeAlpha2,
        phone: addressData.phone,
        paymentMethod: paymentMethodName
    };
}

/**
 * Sets a current page flow in data attribute
 * Use on cart,minicart,pdp pages
 * @param {string} pageFlow A page flow
 */
function setDataPageFlowAttribute(pageFlow) {
    var $braintreeHeading = document.querySelector('.braintree-heading');

    $braintreeHeading.setAttribute('data-page-flow', pageFlow);
}

module.exports = {
    getBraintreeConfigs,
    convertCreditCardType,
    createClientInstance,
    continueButtonToggle,
    showHtmlElement,
    hideHtmlElement,
    createCustomerFormData,
    createPaymentFormData,
    getPaymentFieldsData,
    setDataPageFlowAttribute
};
