'use strict';

var checkoutPaymentHandler = require('../googlePay/checkoutPaymentHandler');
var cartPaymentHandler = require('../googlePay/cartPaymentHandler');

/**
 * Process a Google pay tokenizePayload in order to handle an order on the server side
 * @param {tokenizePayload} dropinResponse A Google pay tokenizePayload
 * @param {string} pageFlow A current page flow
 * @param {Object} dropinInstance A Dropin instance

 */
function paymentProcessing(dropinResponse, pageFlow, dropinInstance) {
    if (pageFlow === 'checkout') {
        checkoutPaymentHandler.paymentProcessing(dropinResponse);
    } else {
        dropinInstance.loader.show();

        cartPaymentHandler.paymentProcessing(dropinResponse, dropinInstance);
    }
}

module.exports = {
    paymentProcessing
};
