'use strict';

var {
    isPaypalButtonEnabled
} = require('*/cartridge/scripts/braintree/helpers/paymentHelper');
const braintreeConstants = require('*/cartridge/config/braintreeConstants');

var middleware = {};

const eventNameRouteComplete = 'route:Complete';

/**
 * Validates a basket
 * @param {Object} req Request object of endpoint's
 * @param {Object} res Response object of endpoint's
 * @param {Function} next Next call in the middleware chain
 * @returns {void}
 */
middleware.isBasketExist = function (req, res, next) {
    var BasketMgr = require('dw/order/BasketMgr');
    var basket = BasketMgr.getCurrentBasket();

    if (!basket) {
        return this.emit(eventNameRouteComplete, req, res);
    }

    return next();
};

/**
 * Validates a PayPal on Pdp page
 * @param {Object} req Request object of endpoint's
 * @param {Object} res Response object of endpoint's
 * @param {Function} next Next call in the middleware chain
 * @returns {void}
 */
middleware.isPayPalEnabledOnPdp = function (req, res, next) {
    if (!isPaypalButtonEnabled(braintreeConstants.PAGE_FLOW_PDP)) {
        return this.emit(eventNameRouteComplete, req, res);
    }

    return next();
};

/**
 * Validates is set product type exist
 * @param {Object} req Request object of endpoint's
 * @param {Object} res Response object of endpoint's
 * @param {Function} next Next call in the middleware chain
 * @returns {void}
 */
middleware.isSetProductType = function (req, res, next) {
    var isSetProductType = !empty(res.getViewData().product.individualProducts);

    if (isSetProductType) {
        return this.emit(eventNameRouteComplete, req, res);
    }

    return next();
};

/**
 * Validates a PayPal on Mini cart page
 * @param {Object} req Request object of endpoint's
 * @param {Object} res Response object of endpoint's
 * @param {Function} next Next call in the middleware chain
 * @returns {void}
 */
middleware.isPayPalEnabledOnMiniCart = function (req, res, next) {
    if (!isPaypalButtonEnabled(braintreeConstants.PAGE_FLOW_MINICART)) {
        return this.emit(eventNameRouteComplete, req, res);
    }

    return next();
};

module.exports = middleware;
