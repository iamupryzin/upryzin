'use strict';

const braintreeDropInBusinessLogic = {};

/**
 * Returns the customers payment methods from Braintree
 * @returns {Object} A payment methods object
 */
braintreeDropInBusinessLogic.getCustomerPaymentMethods = function () {
    const btBusinessLogic = require('*/cartridge/scripts/braintree/braintreeAPI/braintreeBusinessLogic');

    const customerResponse = btBusinessLogic.getBraintreeCustomer(customer);
    let paymentMethods = null;

    if (!customerResponse.error) {
        paymentMethods = customerResponse.customerData[0].node.paymentMethods;
    }

    return paymentMethods;
};

/**
 * @returns {Array} array of orders with status Authorized or Submitted for Settlement/Settled filtered by payment method
 */
function getAuthorizedAndPartiallyCapturedOrders() {
    const btConstants = require('*/cartridge/config/braintreeConstants');

    return customer.orderHistory.orders.asList().toArray().filter(function (order) {
        const braintreeOrderStatus = order.custom.braintreePaymentStatus;
        const partialCaptureStatuses = [btConstants.TRANSACTION_STATUS_SUBMITTED_FOR_SETTLEMENT, btConstants.TRANSACTION_STATUS_SETTLED];

        return order.getPaymentInstruments(btConstants.PAYMENT_METHOD_CREDIT_CARD).length && (
            (order.custom.leftToSettle && partialCaptureStatuses.includes(braintreeOrderStatus)) ||
                braintreeOrderStatus === btConstants.TRANSACTION_STATUS_AUTHORIZED
        );
    });
}

/**
 * Returns true/false if payment method removal allowed/disallowed for current customer
 * @returns {boolean} true/false if payment method removal allowed/disallowed for current customer
 */
braintreeDropInBusinessLogic.paymentMethodRemovalVerification = function () {
    if (!customer.registered || !customer.orderHistory.getOrderCount()) {
        return true;
    }
    // If any order exist in status AUTHORIZED or partial captured, payment methods removall is not allowed
    const authorizedAndPartiallyCapturedOrders = getAuthorizedAndPartiallyCapturedOrders();

    return !authorizedAndPartiallyCapturedOrders.length;
};

/**
 * Deletes duplicate credit card if one has been added for current customer
 * @param {Object} profile current customer object
 * @param {Object} duplicateCCDetails duplicate credit card details
 * @returns {Function} function that deletes duplicate payment method from BT vault
 */
braintreeDropInBusinessLogic.deleteDuplicateCreditCard = function (profile, duplicateCCDetails) {
    const btBusinessLogic = require('*/cartridge/scripts/braintree/braintreeAPI/braintreeBusinessLogic');
    const existingPaymentMethods = btBusinessLogic.getBraintreeCustomer(customer).customerData[0].node.paymentMethods.edges;

    const paymentInstrumentToDelete = existingPaymentMethods
        // Finds duplicate credit cards among existing credit cards in BT vault
        .filter(function (method) {
            return method.node.details.last4 === duplicateCCDetails.lastFour
                && method.node.details.expirationMonth === duplicateCCDetails.expirationMonth
                && method.node.details.expirationYear === duplicateCCDetails.expirationYear;
        })
        // Maps objects so that there's the same structure that is needed for the deletePaymentMethod function in btBusinessLogic
        .map(function (method) {
            return {
                payment: {
                    creditCardToken: method.node.legacyId,
                    createdAt: method.node.createdAt
                }
            };
        })
        // Leaves out payment intruments that shouldn't be deleted based on creation time (duplicate payment method has the latest creaton time)
        .reduce(function (acc, next) {
            return acc.payment.createdAt < next.payment.createdAt ? next : acc;
        });

    return btBusinessLogic.deletePaymentMethod(paymentInstrumentToDelete, profile);
};

module.exports = braintreeDropInBusinessLogic;
