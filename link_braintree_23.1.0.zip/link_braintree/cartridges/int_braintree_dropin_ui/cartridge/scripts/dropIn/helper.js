'use strict';

var URLUtils = require('dw/web/URLUtils');
var prefs = require('*/cartridge/config/braintreePreferences');
var Resource = require('dw/web/Resource');

var paymentHelper = require('*/cartridge/scripts/braintree/helpers/paymentHelper');
var {
    getAmountPaid
} = require('*/cartridge/scripts/braintree/helpers/paymentHelper');
const braintreeConstants = require('*/cartridge/config/braintreeConstants');

var btDropInBusinessLogic = require('~/cartridge/scripts/braintree/braintreeDropInBusinessLogic');

var dropinHelper = {};

/**
 * Returns configuration style object for paypal button
 * @param {string} pageFlow Name of flow that called the method
 * @returns {Object} Style configuration object
 */
function getPaypalButtonStyles(pageFlow) {
    const payPalButtonConfigs = require('~/cartridge/scripts/braintree/configuration/paypalButtonConfigs');

    let styleConfigs;

    switch (pageFlow) {
        case braintreeConstants.PAGE_FLOW_PDP:
            styleConfigs = payPalButtonConfigs.PAYPAL_PDP_Button_Config.style;
            break;
        case braintreeConstants.PAGE_FLOW_CART:
            styleConfigs = payPalButtonConfigs.PAYPAL_Cart_Button_Config.style;
            break;
        case braintreeConstants.PAGE_FLOW_MINICART:
            styleConfigs = payPalButtonConfigs.PAYPAL_MiniCart_Button_Config.style;
            break;
        default:
            styleConfigs = payPalButtonConfigs.PAYPAL_Billing_Button_Config.style;
            break;
    }

    return styleConfigs;
}

/**
 * Returns whether saved credit card on braintree side is visible in Drop-in
 * For example: Apple pay, Google pay can be saved on braintree side
 * but Drop-in does not render them in the list of saved Payment methods
 * @param {CreditCardDetails} creditCardDetails CreditCardDetails type from GraphQl
 * @returns {boolean} true/false
 */
function isSavedVisibleCreditCardType(creditCardDetails) {
    if (creditCardDetails.__typename !== braintreeConstants.CREDIT_CARD_DETAILS_TYPE) {
        return false;
    }

    var paymentMethodOriginType = creditCardDetails.origin && creditCardDetails.origin.type;

    // Mastercard, Visa credit card type does not contain origin type and is visilbe in Drop-in
    if (!paymentMethodOriginType) {
        return true;
    // APPLE_PAY and GOOGLE_PAY origin type is not visible in Drop-in
    } else if (paymentMethodOriginType === braintreeConstants.APPLE_PAY_ORIGIN_TYPE ||
            paymentMethodOriginType === braintreeConstants.GOOGLE_PAY_ORIGIN_TYPE) {
        return false;
    }

    // Works in case when origin type exists but not equal whether APPLE_PAY or GOOGLE_PAY
    return true;
}

/**
 * Returns whether is saved PayPal payment method on Braintree or not
 * @returns {boolean} Whether is saved PayPal payment method on Braintree
 */
function isSavedPayPalPaymentMethodOnBraintree() {
    if (!customer.registered) {
        return false;
    }

    var paymentMethods = btDropInBusinessLogic.getCustomerPaymentMethods();

    if (!paymentMethods || paymentMethods.edges.length === 0) {
        return false;
    }

    return paymentMethods.edges.some(function (paymentMethod) {
        return paymentMethod.node.details.__typename === braintreeConstants.PAYPAL_ACCOUNT_DETAILS_TYPE;
    });
}

/**
 * Returns whether is saved the visible payment methods for Dropin (PayPal, Credit Card)
 * A saved Venmo payment method is not visible in Dropin
 * @returns {boolean} Whether is saved PayPal payment method on Braintree
 */
function isSavedVisibleDropinPaymentMethods() {
    var paymentMethods = btDropInBusinessLogic.getCustomerPaymentMethods();

    if (!paymentMethods || paymentMethods.edges.length === 0) {
        return false;
    }

    return paymentMethods.edges.some(function (paymentMethod) {
        return paymentMethod.node.details.__typename === braintreeConstants.PAYPAL_ACCOUNT_DETAILS_TYPE ||
            isSavedVisibleCreditCardType(paymentMethod.node.details);
    });
}

/**
 * Returns whether is the PayPal payment method enabled in Drop-in
 * @param {string} flow The current page flow
 * @returns {boolean} Whether is the PayPal payment method enabled in Drop-in
 */
function isPayPalEnabledInDropIn(flow) {
    var isPayPalPaymentMethodActive = prefs.paymentMethods.BRAINTREE_PAYPAL.isActive || false;
    var _isPayPalEnabledInDropIn;

    if (flow === braintreeConstants.PAGE_FLOW_CART) {
        _isPayPalEnabledInDropIn = isPayPalPaymentMethodActive &&
        paymentHelper.isPaypalButtonEnabled(flow) && !isSavedPayPalPaymentMethodOnBraintree();
    } else if (flow === braintreeConstants.PAGE_FLOW_MINICART || flow === braintreeConstants.PAGE_FLOW_PDP) {
        _isPayPalEnabledInDropIn = isPayPalPaymentMethodActive && !isSavedPayPalPaymentMethodOnBraintree();
    // Checkout billing and account flow
    } else {
        _isPayPalEnabledInDropIn = isPayPalPaymentMethodActive;
    }

    return _isPayPalEnabledInDropIn;
}

/**
 * Returns whether is the Google Pay payment method enabled in Drop-in
 * @param {string} flow The current page flow
 * @returns {boolean} Whether is the Google pay payment method enabled in Drop-in
 */
function isGooglePayEnabledInDropIn(flow) {
    var isGooglePayPaymentMethodActive = prefs.paymentMethods.BRAINTREE_GOOGLEPAY.isActive || false;
    var _isGooglePayEnabledInDropIn;

    switch (flow) {
        case braintreeConstants.PAGE_FLOW_CART:
            _isGooglePayEnabledInDropIn = isGooglePayPaymentMethodActive && prefs.googlepayVisibilityOnCart;
            break;
        case braintreeConstants.PAGE_FLOW_CHECKOUT:
            _isGooglePayEnabledInDropIn = isGooglePayPaymentMethodActive;
            break;
        default:
            _isGooglePayEnabledInDropIn = false;
            break;
    }

    return _isGooglePayEnabledInDropIn;
}

/**
 * Returns whether is the Apple Pay payment method enabled in Drop-in
 * @param {string} flow The current page flow
 * @returns {boolean} Whether is the Apple pay payment method enabled in Drop-in
 */
function isApplePayEnabledInDropIn(flow) {
    var isApplePayPaymentMethodActive = prefs.paymentMethods.BRAINTREE_APPLEPAY.isActive || false;
    var _isApplePayEnabledInDropIn;

    switch (flow) {
        case braintreeConstants.PAGE_FLOW_CART:
            _isApplePayEnabledInDropIn = isApplePayPaymentMethodActive && prefs.applepayVisibilityOnCart;
            break;
        case braintreeConstants.PAGE_FLOW_CHECKOUT:
            _isApplePayEnabledInDropIn = isApplePayPaymentMethodActive;
            break;
        default:
            _isApplePayEnabledInDropIn = false;
            break;
    }

    return _isApplePayEnabledInDropIn;
}

/**
 * Returns whether is the Venmo payment method enabled in Drop-in
 * @param {string} flow The current page flow
 * @returns {boolean} Whether is the Venmo payment method enabled in Drop-in
 */
function isVenmoEnabledInDropIn(flow) {
    var _isVenmoEnabledInDropIn;

    if (flow === braintreeConstants.PAGE_FLOW_CHECKOUT) {
        _isVenmoEnabledInDropIn = prefs.paymentMethods.BRAINTREE_VENMO.isActive || false;
    } else {
        _isVenmoEnabledInDropIn = false;
    }

    return _isVenmoEnabledInDropIn;
}

/**
 * Returns whether is the Credit Card payment method enabled in Drop-in
 * @param {string} flow The page flow
 * @returns {boolean} Whether is the Credit Card payment method enabled in Drop-in
 */
function isCreditCardEnabledInDropin(flow) {
    var isCreditCardEnabled;

    isCreditCardEnabled = flow === braintreeConstants.PAGE_FLOW_CHECKOUT ||
        flow === braintreeConstants.PAGE_FLOW_ACCOUNT;

    return isCreditCardEnabled;
}

/**
 * Returns a braintree error message object
 * @returns {Object} A Braintree Error message object
 */
function getBraintreeErrorMessages() {
    return {
        secure3DFailed: Resource.msg('braintree.creditcard.error.secure3DFailed', 'locale', null),
        CLIENT_REQUEST_TIMEOUT: Resource.msg('braintree.error.CLIENT_REQUEST_TIMEOUT', 'locale', null),
        CLIENT_GATEWAY_NETWORK: Resource.msg('braintree.error.CLIENT_GATEWAY_NETWORK', 'locale', null),
        CLIENT_REQUEST_ERROR: Resource.msg('braintree.error.CLIENT_REQUEST_ERROR', 'locale', null),
        CLIENT_MISSING_GATEWAY_CONFIGURATION: Resource.msg('braintree.error.CLIENT_MISSING_GATEWAY_CONFIGURATION', 'locale', null),
        PAYPAL_ACCOUNT_TOKENIZATION_FAILED: Resource.msg('braintree.error.PAYPAL_ACCOUNT_TOKENIZATION_FAILED', 'locale', null),
        PAYPAL_INVALID_PAYMENT_OPTION: Resource.msg('braintree.error.PAYPAL_INVALID_PAYMENT_OPTION', 'locale', null),
        PAYPAL_FLOW_FAILED: Resource.msg('braintree.error.PAYPAL_FLOW_FAILED', 'locale', null),
        PAYPAL_BROWSER_NOT_SUPPORTED: Resource.msg('braintree.error.PAYPAL_BROWSER_NOT_SUPPORTED', 'locale', null),
        PAYPAL_BILLING_ADDRESS_NOT_SUPPORTED: Resource.msg('braintree.error.PAYPAL_BILLING_ADDRESS_NOT_SUPPORTED', 'locale', null),
        CUSTOM_PAYPAL_ZERO_AMOUNT_ERROR: Resource.msg('braintree.error.CUSTOM_PAYPAL_ZERO_AMOUNT_ERROR', 'locale', null),
        CUSTOM_GOOGLE_PAY_ZERO_AMOUNT_ERROR: Resource.msg('braintree.error.CUSTOM_GOOGLE_PAY_ZERO_AMOUNT_ERROR', 'locale', null),
        VENMO_ACCOUNT_TOKENIZATION_FAILED: Resource.msg('braintree.error.VENMO_ACCOUNT_TOKENIZATION_FAILED', 'locale', null),
        VENMO_BROWSER_NOT_SUPPORTED: Resource.msg('braintree.error.VENMO_BROWSER_NOT_SUPPORTED', 'locale', null)
    };
}

/**
 * Returns a general Drop-in configs for all pages
 * @param {Object} braintree A braintree configuration object
 * @param {string} flow The page flow
 * @returns {Object} A general Drop-in cinfigs object
 */
function getGeneralDropInConfigs(braintree, flow) {
    var generalConfigs = {
        clientToken: braintree.clientToken,
        pageFlow: flow,
        errorMessages: getBraintreeErrorMessages(),
        isFraudToolsEnabled: prefs.isPaypalFraudToolsEnabled,
        getOrderInfoUrl: URLUtils.url('Braintree-GetOrderInfo').toString(),
        is3DSecureEnabled: prefs.is3DSecureEnabled,
        isSkip3dSecureLiabilityResult: prefs.is3DSecureSkipClientValidationResult,
        vaultModeEnabled: prefs.vaultMode,
        isPayPalCreditEnabledInDropIn: prefs.isPayPalCreditEnabledInDropIn
    };

    const isPayPalButtonConfig = braintree.payPalButtonConfig !== null;
    const isApplePayButtonConfig = braintree.applePayButtonConfig !== null;
    const isGooglePayButtonConfig = braintree.googlepayButtonConfig !== null;

    if (flow !== braintreeConstants.PAGE_FLOW_ACCOUNT && isPayPalButtonConfig) {
        const payPalButtonStyles = getPaypalButtonStyles(flow);

        generalConfigs.payPalButtonStyle = {
            color: payPalButtonStyles.color,
            shape: payPalButtonStyles.shape,
            label: payPalButtonStyles.label,
            size: payPalButtonStyles.size
        };
    }

    const SUPPORT_FLOWS = [braintreeConstants.PAGE_FLOW_CART, braintreeConstants.PAGE_FLOW_CHECKOUT];

    if (isApplePayButtonConfig && SUPPORT_FLOWS.includes(flow)) {
        generalConfigs.applePayButtonStyle = braintree.applePayButtonConfig.applePayConfig.style.buttonStyle;
    }

    if (isGooglePayButtonConfig && SUPPORT_FLOWS.includes(flow)) {
        generalConfigs.googlePayButtonStyle = braintree.googlepayButtonConfig.googlePayConfig.style;
    }

    // PayPal Credit button should be displayed on the Billing page only
    if (flow !== braintreeConstants.PAGE_FLOW_CHECKOUT) {
        generalConfigs.isPayPalCreditEnabledInDropIn = false;
    }

    return generalConfigs;
}

/**
 * Returns an object with all enabled payment methods on Drop-in
 * @param {string} flow The Current flow
 * @returns {Object} An object with all enabled payment methods on Drop-in
 */
function getEnabledDropinPaymentOptions(flow) {
    return {
        isCreditCardEnabledInDropIn: isCreditCardEnabledInDropin(flow),
        isGooglePayEnabledInDropIn: isGooglePayEnabledInDropIn(flow),
        isVenmoEnabledInDropIn: isVenmoEnabledInDropIn(flow),
        isApplePayEnabledInDropIn: isApplePayEnabledInDropIn(flow),
        isPayPalEnabledInDropIn: isPayPalEnabledInDropIn(flow)
    };
}

/**
 * Returns all necessary configurations for Drop-in (checkout, cart, mini cart pages)
 * @param {Object} braintree A braintree configuration object
 * @param {string} flow The page flow
 * @returns {Object} A Drop-in configuration object
 */
dropinHelper.getDropInConfigs = function (braintree, flow) {
    var currentBasket = require('dw/order/BasketMgr').currentBasket;
    var amount = getAmountPaid(currentBasket);
    var paypalBasketPaymentInstrument = currentBasket.getPaymentInstruments(prefs.paymentMethods.BRAINTREE_PAYPAL.paymentMethodId);
    var isShowSummaryBillingAddress = empty(paypalBasketPaymentInstrument) ?
        true : paypalBasketPaymentInstrument[0].custom.braintreeDropinIsPayPalBillingAddressExist;
    var specificConfigs = Object.assign(getEnabledDropinPaymentOptions(flow), {
        // Works when buyer used a vaulted Paypal payment method
        billingAddressInfoMessage: Resource.msg('braintree.billingaddress.vaultedpaymentmethod.message', 'locale', null),
        isShowSummaryBillingAddress: isShowSummaryBillingAddress,
        amount: parseFloat(amount.getValue())
    });

    return Object.assign(specificConfigs, getGeneralDropInConfigs(braintree, flow));
};

/**
 * Returns all necessary configurations for Drop-in
 * @param {Object} braintree A braintree configuration object
 * @param {string} flow The page flow
 * @returns {Object} A Drop-in configuration object
 */
dropinHelper.getAccountDropInConfigs = function (braintree, flow) {
    var specificConfigs = Object.assign(getEnabledDropinPaymentOptions(flow), {
        dropinLabels: {
            largeButtonLabel: Resource.msg('braintree.dropin.account.largebutton.label', 'locale', null),
            cardSheetTextLabel: Resource.msg('braintree.dropin.account.cardsheettext.label', 'locale', null),
            chooseWayToPayLabel: Resource.msg('braintree.dropin.account.choosewaytopaylabel.label', 'locale', null),
            otherWayToPayLabel: Resource.msg('braintree.dropin.account.otherwaytopay.label', 'locale', null),
            mainLabel: Resource.msg('braintree.dropin.account.mainlabel.label', 'locale', null)
        },
        isSavedVisibleDropinPaymentMethods: isSavedVisibleDropinPaymentMethods()
    });

    return Object.assign(specificConfigs, getGeneralDropInConfigs(braintree, flow));
};

/**
 * Returns all necessary configurations for Drop-in
 * @param {Object} braintree A braintree configuration object
 * @param {string} flow The page flow
 * @returns {Object} A Drop-in configuration object
 */
dropinHelper.getProductPageDropinConfigs = function (braintree, flow) {
    return Object.assign(getEnabledDropinPaymentOptions(flow), getGeneralDropInConfigs(braintree, flow));
};

module.exports = dropinHelper;
