/* eslint-disable no-shadow */
'use strict';

var page = module.superModule;
var server = require('server');

var prefs = require('*/cartridge/config/braintreePreferences');

server.extend(page);

server.append('SubmitPayment', function (req, res, next) {
    this.on('route:BeforeComplete', function (req, res) { // eslint-disable-line no-unused-vars
        var Transaction = require('dw/system/Transaction');
        var currentBasket = require('dw/order/BasketMgr').currentBasket;
        var body = request.httpParameterMap;
        var paypalBasketPaymentInstrument = currentBasket.getPaymentInstruments(prefs.paymentMethods.BRAINTREE_PAYPAL.paymentMethodId);

        if (!empty(paypalBasketPaymentInstrument)) {
            Transaction.wrap(function () {
                paypalBasketPaymentInstrument[0].custom.braintreeDropinIsPayPalBillingAddressExist = body.braintreeDropinIsPayPalBillingAddressExist.booleanValue;
            });
        }
    });

    next();
});

module.exports = server.exports();
