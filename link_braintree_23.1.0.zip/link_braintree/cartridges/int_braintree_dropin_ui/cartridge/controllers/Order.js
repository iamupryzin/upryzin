'use strict';

var page = module.superModule;
var server = require('server');

var prefs = require('*/cartridge/config/braintreePreferences');

server.extend(page);

server.append('Confirm', function (req, res, next) {
    var OrderMgr = require('dw/order/OrderMgr');
    var order = OrderMgr.getOrder(req.form.orderID, req.form.orderToken);
    var { braintree } = res.getViewData();
    var paypalOrderPaymentInstrument = order.getPaymentInstruments(prefs.paymentMethods.BRAINTREE_PAYPAL.paymentMethodId);
    var isShowSummaryBillingAddress = empty(paypalOrderPaymentInstrument) ?
        true : paypalOrderPaymentInstrument[0].custom.braintreeDropinIsPayPalBillingAddressExist;

    braintree.dropinConfigs = {
        isShowSummaryBillingAddress: isShowSummaryBillingAddress
    };

    return next();
});

module.exports = server.exports();
