'use strict';

const page = module.superModule;
const server = require('server');

const csrfProtection = require('*/cartridge/scripts/middleware/csrf');
const middleware = require('*/cartridge/scripts/braintree/middleware');

server.extend(page);
server.append('Show',
    csrfProtection.generateToken,
    middleware.isPayPalEnabledOnPdp,
    middleware.isSetProductType,
    function (req, res, next) {
        const helper = require('~/cartridge/scripts/dropIn/helper');
        const braintreeConstants = require('*/cartridge/config/braintreeConstants');

        const { braintree } = res.getViewData();
        // Sets drop-in configs into braintree object
        braintree.dropinConfigs = helper.getProductPageDropinConfigs(braintree, braintreeConstants.PAGE_FLOW_PDP);

        return next();
    }
);

module.exports = server.exports();
