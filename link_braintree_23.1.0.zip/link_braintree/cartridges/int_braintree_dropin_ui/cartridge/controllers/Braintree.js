'use strict';

const server = require('server');

const page = module.superModule;


server.extend(page);

server.post('DeleteDuplicateCreditCard', function (req, res, next) {
    const Encoding = require('dw/crypto/Encoding');
    const btDropInBusinessLogic = require('~/cartridge/scripts/braintree/braintreeDropInBusinessLogic');

    try {
        const requestBodyAsString = Encoding.fromBase64(request.httpParameterMap.requestBodyAsString);
        const duplicateCCDetails = JSON.parse(requestBodyAsString);

        btDropInBusinessLogic.deleteDuplicateCreditCard(req.currentCustomer, duplicateCCDetails);
    } catch (error) {
        res.json({
            success: false,
            error: error
        });
        res.setStatusCode(500);

        return next();
    }

    res.json({
        success: true
    });

    return next();
});

module.exports = server.exports();
