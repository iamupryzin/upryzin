'use strict';

const server = require('server');

const page = module.superModule;

server.extend(page);

server.append('Show', function (req, res, next) {
    const Resource = require('dw/web/Resource');
    const helper = require('~/cartridge/scripts/dropIn/helper');
    const braintreeConstants = require('*/cartridge/config/braintreeConstants');
    const btDropInBusinessLogic = require('~/cartridge/scripts/braintree/braintreeDropInBusinessLogic');

    const { braintree } = res.getViewData();

    // Sets drop-in configs into braintree object
    braintree.dropinConfigs = helper.getAccountDropInConfigs(braintree, braintreeConstants.PAGE_FLOW_ACCOUNT);
    braintree.dropinConfigs.isPaymentMethodRemovingAllowed = btDropInBusinessLogic.paymentMethodRemovalVerification();
    // Sets url to controller Braintree-DeleteDuplicateCreditCard and error message into braintree object
    braintree.dropinCustomConfigs = {
        errorMessages: {
            dropinDefaultErrorMessage: Resource.msg('braintree.dropin.creditcard.error.defaulterror', 'locale', null),
            failOnDuplicateCreditCardErrorMessage: Resource.msg('braintree.dropin.creditcard.error.duplicate', 'locale', null)
        }
    };

    return next();
});

module.exports = server.exports();
