'use strict';

const page = module.superModule;
const server = require('server');

const csrfProtection = require('*/cartridge/scripts/middleware/csrf');
const middleware = require('*/cartridge/scripts/braintree/middleware');

const helper = require('~/cartridge/scripts/dropIn/helper');
const braintreeConstants = require('*/cartridge/config/braintreeConstants');

server.extend(page);

server.append('Show',
    csrfProtection.generateToken,
    middleware.isBasketExist,
    function (req, res, next) {
        const applePayButtonConfig = require('~/cartridge/scripts/braintree/configuration/applePayButtonConfig');
        const googlePayButtonConfig = require('~/cartridge/scripts/braintree/configuration/googlePayButtonConfig');

        const { braintree } = res.getViewData();

        braintree.applePayButtonConfig.applePayConfig = applePayButtonConfig.APPLEPAY_Cart_Button_Config;
        braintree.googlepayButtonConfig.googlePayConfig = googlePayButtonConfig.GOOGLEPAY_Cart_Button_Config;
        // Sets drop-in configs into braintree object
        braintree.dropinConfigs = helper.getDropInConfigs(braintree, braintreeConstants.PAGE_FLOW_CART);

        return next();
    }
);

server.extend(page);
server.append('MiniCartShow',
    csrfProtection.generateToken,
    middleware.isBasketExist,
    middleware.isPayPalEnabledOnMiniCart,
    function (req, res, next) {
        const { braintree } = res.getViewData();

        if (braintree) {
            // Sets drop-in configs into braintree object
            braintree.dropinConfigs = helper.getDropInConfigs(braintree, braintreeConstants.PAGE_FLOW_MINICART);
        }

        return next();
    }
);

module.exports = server.exports();
