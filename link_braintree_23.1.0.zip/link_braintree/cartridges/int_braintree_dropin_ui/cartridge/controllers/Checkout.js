/* eslint-disable no-shadow */
'use strict';

const page = module.superModule;
const server = require('server');

const middleware = require('*/cartridge/scripts/braintree/middleware');

server.extend(page);

server.append('Begin',
    middleware.isBasketExist,
    function (req, res, next) {
        const Resource = require('dw/web/Resource');
        const helper = require('~/cartridge/scripts/dropIn/helper');
        const braintreeConstants = require('*/cartridge/config/braintreeConstants');
        const btDropInBusinessLogic = require('~/cartridge/scripts/braintree/braintreeDropInBusinessLogic');
        const applePayButtonConfig = require('~/cartridge/scripts/braintree/configuration/applePayButtonConfig');
        const googlePayButtonConfig = require('~/cartridge/scripts/braintree/configuration/googlePayButtonConfig');

        const { braintree } = res.getViewData();

        braintree.applePayButtonConfig.applePayConfig = applePayButtonConfig.APPLEPAY_Billing_Button_Config;
        braintree.googlepayButtonConfig.googlePayConfig = googlePayButtonConfig.GOOGLEPAY_Billing_Button_Config;
        // Sets drop-in configs into braintree object
        braintree.dropinConfigs = helper.getDropInConfigs(braintree, braintreeConstants.PAGE_FLOW_CHECKOUT);
        braintree.dropinConfigs.isPaymentMethodRemovingAllowed = btDropInBusinessLogic.paymentMethodRemovalVerification();
        // Sets url to controller Braintree-DeleteDuplicateCreditCard and error message into braintree object
        braintree.dropinCustomConfigs = {
            errorMessages: {
                dropinDefaultErrorMessage: Resource.msg('braintree.dropin.creditcard.error.defaulterror', 'locale', null),
                failOnDuplicateCreditCardErrorMessage: Resource.msg('braintree.dropin.creditcard.error.duplicate', 'locale', null)
            }
        };

        return next();
    }
);

module.exports = server.exports();
