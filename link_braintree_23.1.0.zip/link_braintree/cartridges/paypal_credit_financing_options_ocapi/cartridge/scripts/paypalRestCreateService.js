'use strict';
/**
 * Defines callbacks for use with the LocalServiceRegistry.
 *
 * @param {Object} prefs - BraintreeHelper custom preferences
 * @returns {Object} Request object to give to the execute method.
 */
const getServiceConfig = function () {
    return {
        /**
         * @param {dw.svc.HTTPService} service - Service, which will be used for the call
         * @param {string} methodType - Method type (DELETE, GET, PATCH, POST, PUT, REDIRECT)
         * @param {string} path - Resource/Endpoint
         * @param {Object} data - Request data
         * @param {string} contentType - Content type
         * @param {Object} paypalApi - API calls helper
         * @param {boolean} isUpadateBearToken - Is need Bear Token updating
         * @returns {string} String for request
         */
        createRequest: function (service, methodType, path, data, contentType, paypalApi, isUpadateBearToken) {
            const credential = service.getConfiguration().getCredential();
            // eslint-disable-next-line no-undef
            if (!(credential instanceof dw.svc.ServiceCredential)) {
                throw new Error('Credential for int_paypal.http.rest.credit is not set. Create and set cridential BM > Administration > Operations > Services');
            }

            let url = credential.getURL();
            const currentDate = Date.now();

            if (!url.match(/.+\/$/)) {
                url += '/';
            }

            url += 'v1/' + path;
            service.setURL(url);

            if (contentType === 'undefined') { // It's strange behaviour of DW and createRequest
                contentType = null; // eslint-disable-line no-param-reassign
            }
            contentType = contentType || 'application/json'; // eslint-disable-line no-param-reassign

            service.setRequestMethod(methodType);
            service.addHeader('Content-Type', contentType);

            let token = credential.custom.BRAINTREE_PAYPAL_RESTAPI_TempToken;
            const tokenExpiredTime = credential.custom.BRAINTREE_PAYPAL_RESTAPI_TempTokenExpiredTime;
            if (path !== 'oauth2/token') {
                if (isUpadateBearToken || !token || tokenExpiredTime < (currentDate + 10000)) {
                    const tokenResponseData = paypalApi.oauth2.getToken();
                    token = tokenResponseData.access_token;
                }
                service.addHeader('Authorization', 'Bearer ' + token);
            }

            if (contentType === 'application/x-www-form-urlencoded') {
                Object.keys(data).forEach(function (fieldName) {
                    service.addParam(fieldName, data[fieldName]);
                });
            }
            if (contentType === 'application/json') {
                return JSON.stringify(data);
            }
            return '';
        },

        parseResponse: function (service, httpClient) {
            return JSON.parse(httpClient.getText());
        },

        getRequestLogMessage: function (request) {
            return request;
        },

        getResponseLogMessage: function (response) {
            return response.text;
        }
    };
};

module.exports = function () {
    return require('dw/svc').LocalServiceRegistry.createService('int_paypal.http.rest.credit', getServiceConfig());
};
