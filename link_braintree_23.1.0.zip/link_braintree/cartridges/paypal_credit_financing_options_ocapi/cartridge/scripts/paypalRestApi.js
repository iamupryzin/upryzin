'use strict';

const Resource = require('dw/web/Resource');

const logger = require('*/cartridge/scripts/braintree/helpers/paymentHelper').getLogger();

// https://developer.paypal.com/docs/api/overview/

const paypalApi = {};

/**
 * Executes request
 *
 * @param {string} methodType - Method type (DELETE, GET, PATCH, POST, PUT, REDIRECT)
 * @param {string} path - Resource/Endpoint
 * @param {Object} data - Request data
 * @param {string} contentType - Content type
 * @param {boolean} isUpadateBearToken - Is need Bear Token updating
 * @returns {Object} Response object
 */
paypalApi.call = function (methodType, path, data, contentType, isUpadateBearToken) {
    const createService = require('./paypalRestCreateService');
    let service;
    let result;
    let errorMsg;
    let responseData;

    try {
        service = createService();
    } catch (error) {
        errorMsg = Resource.msg('service.is.undefined', 'error', null);
        logger.error(errorMsg);
        throw new Error(errorMsg);
    }

    try {
        result = service.setThrowOnError().call(methodType, path, data, contentType, paypalApi, isUpadateBearToken);
    } catch (error) {
        logger.error(error);
        throw new Error(error);
    }

    if (result.isOk()) {
        responseData = service.getResponse();
    } else {
        if (result.getErrorMessage() === null) {
            errorMsg = Resource.msgf('endpoint.is.not.supported', 'error', null, path);
            logger.error(errorMsg);
            throw new Error(errorMsg);
        }
        responseData = JSON.parse(result.getErrorMessage());
        if (responseData.error === 'invalid_client') {
            const errorMessage = Resource.msg('service.credentials.are.incorect', 'error', null);
            logger.error(errorMessage + service.getConfiguration().getCredential().getID());
        }
        if (responseData.error === 'invalid_token') {
            return paypalApi.call(methodType, path, data, contentType, true);
        }
    }

    return responseData;
};

paypalApi.oauth2 = {};
/**
 * Gets oauth2 token
 * https://developer.paypal.com/docs/limited-release/financing-options/api/#active-merchant-financing-options
 * @returns {Object} Response object
 */
paypalApi.oauth2.getToken = function () {
    return paypalApi.call('POST', 'oauth2/token', {
        grant_type: 'client_credentials'
    }, 'application/x-www-form-urlencoded');
};

paypalApi.activities = {};
paypalApi.payments = {};
paypalApi.customer = {};
paypalApi.identity = {};
paypalApi.invoicing = {};

module.exports = paypalApi;
