'use strict';

const ProductMgr = require('dw/catalog/ProductMgr');
const Status = require('dw/system/Status');
const Locale = require('dw/util/Locale');
const Site = require('dw/system/Site');
const Logger = require('dw/system/Logger');

const braintreeConstants = require('*/cartridge/scripts/util/braintreeConstants');
const creditFinancialOptionsHelper = require('~/cartridge/scripts/paypalCreditFinancingOptionsHelper');

/**
 * The hook that performs the adding of additional PayPal credit financial info when we search products
 * @param {Object} productSearchResult object which represents the response document we are modifying
 * @returns {Status} status of hook execution
**/
function modifyGETResponse(productSearchResult) {
    try {
        productSearchResult.hits.toArray().forEach(function (hit) {
            const product = ProductMgr.getProduct(hit.productId);
            const minPrice = product.priceModel.minPrice.value || product.priceModel.minPricePerUnit.value;
            const countryCode = Locale.getLocale(request.locale).country;
            const braintreeMerchantAccountId = Site.current.getCustomPreferenceValue('BRAINTREE_Merchant_Account_IDs')[0];
            const currencyCode = braintreeMerchantAccountId.split(':')[0];

            hit.c_lowestPossibleMonthlyCost = creditFinancialOptionsHelper.getLowestPossibleMonthlyCost(minPrice, currencyCode, countryCode);
        });
    } catch (error) {
        Logger.error(error);
        return new Status(Status.ERROR, braintreeConstants.CUSTOM_ERROR_TYPE, error);
    }
}

exports.modifyGETResponse = modifyGETResponse;
