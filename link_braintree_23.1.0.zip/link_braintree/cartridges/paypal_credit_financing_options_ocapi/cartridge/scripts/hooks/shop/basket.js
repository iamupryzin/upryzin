'use strict';

const Status = require('dw/system/Status');
const Locale = require('dw/util/Locale');
const Resource = require('dw/web/Resource');
const Logger = require('dw/system/Logger');

const hooksHelper = require('*/cartridge/scripts/braintree/helpers/hooksHelper');
const braintreeConstants = require('*/cartridge/scripts/util/braintreeConstants');
const creditFinancialOptionsHelper = require('~/cartridge/scripts/paypalCreditFinancingOptionsHelper');

// Hook dw.ocapi.shop.basket.beforeGET functionality

/**
 * The function is called before the basket response had returned
 * Validates a pageId query string from request
 * @param {string} basketId string which represents current basket ID
 * @returns {Status} new Status. Depends of hook execution OK/ERROR
 */
function beforeGET(basketId) {
    try {
        if (!basketId) {
            throw new Error(Resource.msg('basket.id.are.not.passed', 'error', null));
        }

        const { validateRequestStringValue } = require('*/cartridge/scripts/braintree/helpers/validationHelper');

        const queryStringObject = hooksHelper.createObjectFromQueryString();
        // Validates a 'pageId' query string
        if (!validateRequestStringValue(queryStringObject.pageId)) {
            throw new Error(Resource.msg('braintree.ocapi.error.addproducttocart.pageid.querystring.invalid', 'locale', null));
        }
    } catch (error) {
        Logger.error(error);
        return new Status(Status.ERROR, braintreeConstants.CUSTOM_ERROR_TYPE, error);
    }
}

// Hook dw.ocapi.shop.basket.modifyGETResponse functionality

/**
 * The hook that performs the adding of additional PayPal credit financial info when we call the basket
 * @param {dw.order.Basket} _ The target basket
 * @param {Object} basketResponse object which represents the response document we are modifying
 * @returns {Status} status of hook execution
**/
function modifyGETResponse(_, basketResponse) {
    try {
        const value = Number(basketResponse.productTotal);
        const countryCode = Locale.getLocale(request.locale).country;
        const currencyCode = basketResponse.currency;

        if (!value || !currencyCode || !countryCode) {
            throw new Error(Resource.msg('not.all.parameters.are.passed', 'error', null));
        }

        const allOptionsData = creditFinancialOptionsHelper.getDataForAllOptionsBanner(value, currencyCode, countryCode);
        const lowestPossibleMonthlyCost = creditFinancialOptionsHelper.getLowestPossibleMonthlyCost(value, currencyCode, countryCode);

        allOptionsData.lowestPossibleMonthlyCost = {
            value: lowestPossibleMonthlyCost.value,
            currencyCode: lowestPossibleMonthlyCost.currencyCode,
            formatted: lowestPossibleMonthlyCost.formatted
        };

        basketResponse.c_allOptionsData = allOptionsData;
    } catch (error) {
        Logger.error(error);
        return new Status(Status.ERROR, braintreeConstants.CUSTOM_ERROR_TYPE, error);
    }
}

exports.beforeGET = beforeGET;
exports.modifyGETResponse = modifyGETResponse;
