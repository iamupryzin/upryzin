'use strict';

const Status = require('dw/system/Status');
const Locale = require('dw/util/Locale');
const Site = require('dw/system/Site');
const Resource = require('dw/web/Resource');
const Logger = require('dw/system/Logger');
const ProductMgr = require('dw/catalog/ProductMgr');

const braintreeConstants = require('*/cartridge/scripts/util/braintreeConstants');
const creditFinancialOptionsHelper = require('~/cartridge/scripts/paypalCreditFinancingOptionsHelper');

// Hook dw.ocapi.shop.product.beforeGET functionality

/**
 * The hook that checks does merchant send correct product ID
 * @param {string} productId string which represents current product Id
 * @returns {Status} status of hook execution
**/
function beforeGET(productId) {
    try {
        if (!productId) {
            throw new Error(Resource.msg('product.id.are.not.passed', 'error', null));
        }

        const currentProduct = ProductMgr.getProduct(productId);

        if (!currentProduct) {
            throw new Error(Resource.msg('current.product.does.not.exist', 'error', null));
        }
    } catch (error) {
        Logger.error(error);
        return new Status(Status.ERROR, braintreeConstants.CUSTOM_ERROR_TYPE, error);
    }
}

// Hook dw.ocapi.shop.product.modifyGETResponse functionality

/**
 * The hook that performs the adding of additional PayPal credit financial info when we choose some product
 * @param {dw.catalog.Product} product the object which represents the current product
 * @param {Object} productSearchResult object which represents the response document we are modifying
 * @returns {Status} status of hook execution
**/
function modifyGETResponse(product, productSearchResult) {
    try {
        const minPrice = product.priceModel.minPrice.value || product.priceModel.minPricePerUnit.value;
        const countryCode = Locale.getLocale(request.locale).country;
        const braintreeMerchantAccountId = Site.current.getCustomPreferenceValue('BRAINTREE_Merchant_Account_IDs')[0];
        const currencyCode = braintreeMerchantAccountId.split(':')[0];

        if (!minPrice || !currencyCode || !countryCode) {
            throw new Error(Resource.msg('not.all.parameters.are.passed', 'error', null));
        }

        const allOptionsData = creditFinancialOptionsHelper.getDataForAllOptionsBanner(minPrice, currencyCode, countryCode);
        const lowestPossibleMonthlyCost = creditFinancialOptionsHelper.getLowestPossibleMonthlyCost(minPrice, currencyCode, countryCode);

        allOptionsData.lowestPossibleMonthlyCost = {
            value: lowestPossibleMonthlyCost.value,
            currencyCode: lowestPossibleMonthlyCost.currencyCode,
            formatted: lowestPossibleMonthlyCost.formatted
        };

        productSearchResult.c_allOptionsData = allOptionsData;
    } catch (error) {
        Logger.error(error);
        return new Status(Status.ERROR, braintreeConstants.CUSTOM_ERROR_TYPE, error);
    }
}

exports.beforeGET = beforeGET;
exports.modifyGETResponse = modifyGETResponse;
