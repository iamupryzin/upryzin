CHANGELOG
=========

## 18.2.1

* SFRA support up to 4.2.1 and SG up to 104.3.1

## 19.1.0

* Remove deprecated logs and move to LocalServiceRegistry

## 19.1.2

* SFRA support up to 4.4.0
* Added option to show PayPal button on PDP and minicart
* Added 3DS version 2
* Moved PayPal button and Hosted Fileds styling to local .js files
* Bug fixing in Braintree BM modules

## 20.1.0

* SFRA support up to 4.4.1 and SG to 105.0.0
* Add Venmo payment method
* Add bundled client side js for SFRA
* BM cartridge doesn't require storefront cartridge as dependency
* Replace most of jQuery usage to native functions
* Custom preferences are now cached with Custom Cache

## 20.2.0

* Update SFRA support to 5.0.1
* Update PayPal button to latest PayPal Smart Button. Please enter client id in Credential section.
* Remove SiteGenesis cartridge, SiteGenesis is no longer supported
* Add Local Payment Method payment method

## 20.2.1

* Add Google Pay payment method

## 20.2.2

* Update SFRA support to 5.1.0 only
* Add paypal_pay_later cartridge to enable Pay Later payment offer for PayPal Smart Button
* Reduce custom preferece number. Vault and Settle options is now single for all payment methods
* If Vault option is enabled all customer will be vaulted on Braintree side.
* PayPal Financial Options become separate cartridge
* Add bm_paypal_configuration cartridge to configure PayPal Smart Button and Pay Later banners from BM

## 21.1.0

* Update SFRA support to 5.3.0 only
* Partially replace Braintree XML API to Braintree GraphQL API
* Update Braintree Client SDK to 3.76.4
* Remove Braintree Customer module from Business Manager
* Sending of Device and Risk data for each payment method to Braintree side
* Add Venmo for desktop support
* Add SRC payment method
* Add session account for SRC
* Google Pay, SRC were moved in to one tab in Account page. Stored payments were moved in to the Credit Card dropdown on the Checkout page
* Add partial capture for PayPal and non PayPal transaction
* Remove "make default payment method" checkbox from checkout (new added payment becomes default one)
* Add session account for Credit Card payment method.
* Remove Braintree Logs module from Business Manager

## 21.2.0

* Server side refactoring
* Add payment_method_revoked_by_customer webhook (webhook which is called when buyer revokes a billing agreement within PayPal buyer account)
* Add Payment Method site verification guide for Apple Pay inside project documentation

## 22.1.0

* Update SFRA support to 6.0.0 only
* Update Braintree Client SDK to 3.83.0
* Frontend Refactoring
* Add Change Payment Method button for Checkout Page
* Add update of billing address for already stored PayPal account when buyer goes through checkout via new PayPal account with the same email as already stored
* Remove Braintree XML API usage
* Remove ability to store Google Pay cards on My Account level
* Changing of billing addresses on billing checkout step is restricted for all payment methods except Credit Card and Venmo

## 22.2.0

* Update SFRA support to 6.1.0 only
* Add Change Payment Method Button to Cart, MiniCart, PDP pages
* Add Dropin UI implementation as separate cartridge
* Remove PayPal static button functionality
* Block for user posibility to remove saved CC, SRC and Venmo in case is made by PM transaction wasn't handled (captured) by merchant
* Identify payment as PayPal, PayPal Debit/Credit, PayLater button through PayPal Smart Button
* Use shipping address as billing address if billing address can't be retrieved from PayPal
* Improve Venmo session account functionality

## 23.1.0

* Update SFRA support to 6.3.0
* Braintree OCAPI Cartridges
* Save CC to the storefront wallet when 3DS is enabled on My Account Page
* Add/Update Billing Address form for payment method (CC) on My Account
* Retrieve billing address for Credit Card in checkout from billing flow
* Dropin UI: validate duplicate payment instrumnet when adding new Credit Card or PayPal
* Dropin UI: Apple Pay Button styles configurator
* Google Pay button configurator
* Apple Pay button configurator
* Ability for customer to edit Shipping Address within Google Pay flow (pop-up)
* Connect with PayPal
* 3ds fallback site preference
* Re-Verify on checkout
* Display Credit Card expiration date (My Account)
* Update SFRA support to 6.3.0
* Braintree OCAPI Cartridges
* Save CC to the storefront wallet when 3DS is enabled on My Account Page
* Add/Update Billing Address form for payment method (CC) on My Account
* Retrieve billing address for Credit Card in checkout from billing flow
* Dropin UI: validate duplicate payment instrument when adding new Credit Card or PayPal
* Dropin UI: Apple Pay Button styles configurator
* Google Pay button configurator
* Apple Pay button configurator
* Ability for customer to edit Shipping Address within Google Pay flow (pop-up)
* Connect with PayPal
* 3ds fallback site preference
* Re-Verify on checkout
* Display Credit Card expiration date (My Accoun
