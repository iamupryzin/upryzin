/* eslint-disable new-cap */
const { bm_braintree: { btTransactionActionsPath } } = require('../path.json');

const { expect } = require('chai');
const { it, describe, after } = require('mocha');
const { stub } = require('sinon');

const proxyquire = require('proxyquire').noCallThru();

const submitForSettlement = stub();
const submitForPartialSettlement = stub();
const refundTransaction = stub();
const voidTransaction = stub();
const createTransactionFromVault = stub();

const reqData = {
    orderToken: null
};

const btTransactionActions = proxyquire(btTransactionActionsPath, {
    '*/cartridge/models/btOrderMgr': function () {
        this.updateBtPaymentStatusfterSettlement = () => {};
        this.updateBtPaymentStatusAfterPartialSettlement = () => {};
        return this;
    },
    '*/cartridge/models/btGraphQLSdk': function () {
        this.submitForSettlement = submitForSettlement;
        this.submitForPartialSettlement = submitForPartialSettlement;
        this.refundTransaction = refundTransaction;
        this.voidTransaction = voidTransaction;
        this.createTransactionFromVault = createTransactionFromVault;
        return this;
    }
});

describe('btTransactionActions file', () => {
    const TransactionActionsModel = new btTransactionActions();

    describe('submitForSettlement', () => {
        after(() => {
            submitForSettlement.reset();
        });

        it('instance must has submitForSettlement property', () => {
            expect(TransactionActionsModel).has.property('submitForSettlement');
        });

        it('must execute without any errors and returns result object', () => {
            submitForSettlement.returns({
                result: 'OK'
            });

            expect(TransactionActionsModel.submitForSettlement(reqData)).to.be.deep.equal({
                result: 'OK'
            });
        });
    });

    describe('submitPartialSettlement', () => {
        after(() => {
            submitForPartialSettlement.reset();
        });

        it('instance must has submitPartialSettlement property', () => {
            expect(TransactionActionsModel).has.property('submitPartialSettlement');
        });

        it('must execute without any errors and returns result object', () => {
            submitForPartialSettlement.returns({
                result: 'OK'
            });

            expect(TransactionActionsModel.submitPartialSettlement(reqData)).to.deep.equal({
                result: 'OK'
            });
        });
    });

    describe('refund', () => {
        after(() => {
            refundTransaction.reset();
        });

        it('instance must has refund property', () => {
            expect(TransactionActionsModel).has.property('refund');
        });

        it('must execute without any errors', () => {
            expect(TransactionActionsModel.refund(reqData)).to.be.undefined;
            expect(refundTransaction.calledOnce).to.be.true;
        });
    });

    describe('void', () => {
        after(() => {
            voidTransaction.reset();
        });

        it('instance must has void property', () => {
            expect(TransactionActionsModel).has.property('void');
        });

        it('must execute without any errors', () => {
            expect(TransactionActionsModel.void()).to.be.undefined;
            expect(voidTransaction.calledOnce).to.be.true;
        });
    });

    describe('voidWithoutUpdate', () => {
        after(() => {
            voidTransaction.reset();
        });

        it('instance must has voidWithoutUpdate property', () => {
            expect(TransactionActionsModel).has.property('voidWithoutUpdate');
        });

        it('must execute without any errors', () => {
            expect(TransactionActionsModel.voidWithoutUpdate()).to.be.undefined;
            expect(voidTransaction.calledOnce).to.be.true;
        });
    });

    describe('newTransactionFromVault', () => {
        after(() => {
            createTransactionFromVault.reset();
        });

        it('instance must has newTransactionFromVault property', () => {
            expect(TransactionActionsModel).has.property('newTransactionFromVault');
        });

        it('must execute without any errors', () => {
            expect(TransactionActionsModel.newTransactionFromVault()).to.be.undefined;
            expect(createTransactionFromVault.calledOnce).to.be.true;
        });
    });
});
