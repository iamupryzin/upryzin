const { bm_braintree: { coreHelpersPath } } = require('../path.json');
const { expect } = require('chai');
const { it, describe } = require('mocha');

const proxyquire = require('proxyquire').noCallThru();

const arr = [{
    color: 'green'
},
{
    color: 'red'
},
{
    color: 'blue'
}];

const coreHelpers = proxyquire(coreHelpersPath, {});

describe('coreHelpers file', () => {
    describe('pluralize', () => {
        it('if value includes', () => {
            expect(coreHelpers.pluralize(1, 'word')).to.be.equal('word');
        });

        it('if value do not includes', () => {
            expect(coreHelpers.pluralize(10, 'word')).to.be.equal('words');
        });
    });

    describe('sortByProperty', () => {
        it('must return sorted array of objects by property', () => {
            expect(coreHelpers.sortByProperty(arr, 'color')).to.be.deep.equal([
                {
                    color: 'blue'
                },
                {
                    color: 'green'
                },
                {
                    color: 'red'
                }
            ]);
        });
    });

    describe('filterByProperty', () => {
        it('must return filtered array of objects by property', () => {
            expect(coreHelpers.filterByProperty(arr, 'color', 'blue')).to.be.deep.equal([
                {
                    color: 'blue'
                }
            ]);
        });
    });
});
