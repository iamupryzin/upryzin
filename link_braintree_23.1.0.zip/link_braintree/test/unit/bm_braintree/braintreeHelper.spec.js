const { describe, it, before, after, beforeEach, afterEach } = require('mocha');
const { expect } = require('chai');
const { stub } = require('sinon');

const { bm_braintree: { braintreeHelperPath } } = require('../path.json');

require('dw-api-mock/demandware-globals');

const prefs = { loggingMode: 'none' };
const pluralize = stub();

const bmBraintreeHelper = require('proxyquire').noCallThru()(braintreeHelperPath, {
    'dw/system': dw.system,
    'dw/order/PaymentMgr': dw.order.PaymentMgr,
    'dw/object/SystemObjectMgr': dw.object.SystemObjectMgr,
    'dw/web/Resource': dw.web.Resource,
    '~/cartridge/config/bmBraintreePreferences': prefs,
    '~/cartridge/config/braintreeConstants': {
        PROCESSOR_NAME_BT_CREDIT: 'BT_CREDIT',
        PROCESSOR_NAME_BT_PAYPAL: 'BT_PAYPAL',
        PROCESSOR_NAME_BT_APPLEPAY: 'BT_APPLEPAY',
        PROCESSOR_NAME_BT_VENMO: 'BT_VENMO',
        PROCESSOR_NAME_BT_LOCAL: 'BT_LOCAL',
        PROCESSOR_NAME_BT_GOOGLEPAY: 'BT_GOOGLEPAY',
        PROCESSOR_NAME_BT_SR: 'BT_SR',
        SEARCH_BY_ORDER_NUMBER: 'by order number',
        SEARCH_BY_PAYMENT_METHOD: 'by payment method',
        SEARCH_BY_PAYMENT_STATUS: 'by payment status',
        SEARCH_BY_TRANSACTION_ID: 'by transaction id',
        TRANSACTION_STATUSES: ['new', 'declined', 'settled'],
        TRANSACTION_FAILED_STATUSES: ['declined']
    },
    '~/cartridge/scripts/helpers/coreHelpers': {
        pluralize,
        filterByProperty: (arr, prop, val) => arr.filter((obj) => obj[prop].includes(val)),
        sortByProperty: (arr, val) => arr.sort((prev, next) => prev[val] - next[val])
    }
});

describe('bmBraintreeHelper file', () => {
    const log = {};

    before(() => {
        stub(dw.system.Logger, 'getLogger').returns({
            error: (msg) => Object.assign(log, { error: msg.toString() }),
            info: (msg) => Object.assign(log, { info: msg.toString() }),
            warn: (msg) => Object.assign(log, { warn: msg.toString() })
        });
    });

    after(() => {
        dw.system.Logger.getLogger.restore();
    });

    describe('getLogger', () => {
        afterEach(() => {
            prefs.loggingMode = 'none';
        });

        it('log object should be empty if errorMode is false and getLogger().error method is run', () => {
            bmBraintreeHelper.getLogger().error('error');
            expect(log).to.deep.equal({});
        });

        it('log object should be empty if errorMode is false and getLogger().info method is run', () => {
            bmBraintreeHelper.getLogger().info('info');
            expect(log).to.deep.equal({});
        });

        it('log object should be empty if errorMode is false and getLogger().warn method is run', () => {
            bmBraintreeHelper.getLogger().warn('warn');
            expect(log).to.deep.equal({});
        });

        it('log.error should equal "error" if errorMode isn\'t false and getLogger().error method is run', () => {
            prefs.loggingMode = true;
            bmBraintreeHelper.getLogger().error('error');
            expect(log.error).to.equal('error');
        });

        it('log.info should equal "info" if errorMode isn\'t false and getLogger().info method is run', () => {
            prefs.loggingMode = true;
            bmBraintreeHelper.getLogger().info('info');
            expect(log.info).to.equal('info');
        });

        it('log.warn should equal "warn" if errorMode isn\'t false and getLogger().warn method is run', () => {
            prefs.loggingMode = true;
            bmBraintreeHelper.getLogger().warn('warn');
            expect(log.warn).to.equal('warn');
        });
    });

    describe('parseStatus', () => {
        afterEach(() => {
            prefs.loggingMode = 'none';
            log.error = null;
        });

        it('result should be a string if paymentStatus is a string', () => {
            expect(bmBraintreeHelper.parseStatus('created')).to.equal('Created');
        });

        it('result shouldn\'t be a string & error should be logged if paymentStatus isn\'t a string and logginMode is true', () => {
            prefs.loggingMode = true;

            expect(bmBraintreeHelper.parseStatus(null)).to.be.null;
            expect(log).to.have.property('error').which.includes('TypeError');
        });
    });

    describe('getBraintreePaymentInstrument', () => {
        const lineItemContainer = {
            getPaymentInstruments: () => {
                return {
                    paymentInstruments: [{
                        getPaymentMethod: () => 'paypal'
                    }],
                    iterator: function () {
                        return new dw.util.Iterator(this.paymentInstruments);
                    }

                };
            }
        };

        before(() => {
            stub(dw.order.PaymentMgr, 'getPaymentMethod');
        });

        after(() => {
            dw.order.PaymentMgr.getPaymentMethod.restore();
        });

        it('result should be an object with the function that returns payment method if payment processor exists', () => {
            dw.order.PaymentMgr.getPaymentMethod.returns({
                getPaymentProcessor: () => {
                    return {
                        getID: () => 'BT_PAYPAL'
                    };
                }
            });

            expect(bmBraintreeHelper.getBraintreePaymentInstrument(lineItemContainer).getPaymentMethod()).to.equal('paypal');
        });

        it('result should be null if payment processor doesn\'t exist', () => {
            dw.order.PaymentMgr.getPaymentMethod.returns({
                getPaymentProcessor: () => {
                    return {
                        getID: () => 'BT_TEST'
                    };
                }
            });

            expect(bmBraintreeHelper.getBraintreePaymentInstrument(lineItemContainer)).to.be.null;
        });
    });

    describe('getApplicablePaymentMethods', () => {
        const paymentInstruments = [
            { paymentProcessor: { ID: 'BT_PAYPAL' } }
        ];

        beforeEach(() => {
            stub(dw.order.PaymentMgr, 'getActivePaymentMethods').returns({
                paymentInstruments: paymentInstruments,
                iterator: function () {
                    return new dw.util.Iterator(this.paymentInstruments);
                }
            });
        });

        afterEach(() => {
            dw.order.PaymentMgr.getActivePaymentMethods.restore();
        });

        it('result should be an array', () => {
            expect(bmBraintreeHelper.getApplicablePaymentMethods()).to.deep.equal([
                { paymentProcessor: { ID: 'BT_PAYPAL' } }
            ]);
        });

        it('result shouldn\'t include a payment instrument which does\'s have a payment processor', () => {
            paymentInstruments[1] = {};

            expect(bmBraintreeHelper.getApplicablePaymentMethods()).to.deep.equal([
                { paymentProcessor: { ID: 'BT_PAYPAL' } }
            ]);
        });

        it('result shouldn\'t include a payment intrument with a payment processor that isn\'t among applicable payment methods', () => {
            paymentInstruments[0].paymentProcessor.ID = 'BT_TEST';

            expect(bmBraintreeHelper.getApplicablePaymentMethods()).to.deep.equal([]);
        });
    });

    describe('getPaymentStatusTransactionStatistics', () => {
        before(() => {
            stub(dw.object.SystemObjectMgr, 'querySystemObjects').returns({ count: 0 });
            pluralize.returns('transactions');
        });

        after(() => {
            dw.object.SystemObjectMgr.querySystemObjects.restore();
            pluralize.reset();
        });

        it('result should be an array of four objects structured accordingly', () => {
            expect(bmBraintreeHelper.getPaymentStatusTransactionStatistics())
                .to.be.an('array')
                .which.has.lengthOf(4)
                .and.deep.includes({
                    color: 'success',
                    count: 0,
                    label: 'New',
                    title: 'New transactions',
                    value: 'new'
                });
        });

        it('result should be sorted alphabetically with color:"success" going first', () => {
            expect(bmBraintreeHelper.getPaymentStatusTransactionStatistics())
                .to.satisfy((arr) => arr[0].value.includes('new') && arr[1].value.includes('settled') && arr[2].value.includes('declined') && arr[3].value === null);
        });
    });

    describe('isSearchQueryEmpty', () => {
        const transactionId = { value: null };
        const paymentMethod = { stringValue: null };
        const orderNo = { stringValue: null };
        const paymentStatus = { stringValue: null };

        afterEach(() => {
            transactionId.value = null;
            paymentMethod.stringValue = null;
            orderNo.stringValue = null;
            paymentStatus.stringValue = null;
        });

        it('result should be true if arguments\' values are null', () => {
            expect(bmBraintreeHelper.isSearchQueryEmpty(transactionId, paymentMethod, orderNo, paymentStatus)).to.be.true;
        });

        it('result should be false if transactionId.value isn\'t null', () => {
            transactionId.value = '000123';
            expect(bmBraintreeHelper.isSearchQueryEmpty(transactionId, paymentMethod, orderNo, paymentStatus)).to.be.false;
        });

        it('result should be false if paymentMethod.stringValue isn\'t null', () => {
            paymentMethod.stringValue = 'bt_paypal';
            expect(bmBraintreeHelper.isSearchQueryEmpty(transactionId, paymentMethod, orderNo, paymentStatus)).to.be.false;
        });

        it('result should be false if orderNo.stringValue isn\'t null', () => {
            orderNo.stringValue = '00001';
            expect(bmBraintreeHelper.isSearchQueryEmpty(transactionId, paymentMethod, orderNo, paymentStatus)).to.be.false;
        });

        it('result should be false if paymentStatus.stringValue isn\'t null', () => {
            paymentStatus.stringValue = 'paid';
            expect(bmBraintreeHelper.isSearchQueryEmpty(transactionId, paymentMethod, orderNo, paymentStatus)).to.be.false;
        });

        it('result should be false if all arguments\' values aren\'t null', () => {
            transactionId.value = '000123';
            paymentMethod.stringValue = 'bt_paypal';
            orderNo.stringValue = '00001';
            paymentStatus.stringValue = 'paid';
            expect(bmBraintreeHelper.isSearchQueryEmpty(transactionId, paymentMethod, orderNo, paymentStatus)).to.be.false;
        });
    });

    describe('getSearchType', () => {
        const transactionId = { submitted: null };
        const paymentMethod = {
            submitted: null,
            stringValue: null
        };
        const paymentStatus = {
            submitted: null,
            stringValue: null
        };

        afterEach(() => {
            transactionId.submitted = null;
            paymentMethod.submitted = null;
            paymentMethod.stringValue = null;
            paymentStatus.submitted = null;
            paymentStatus.stringValue = null;
        });

        it('result should equal to "by order number" if there\'re no needed values for transactionId, paymentMethod & paymentStatus', () => {
            expect(bmBraintreeHelper.getSearchType(transactionId, paymentMethod, paymentStatus)).to.equal('by order number');
        });

        it('result should equal to "by transaction id" if transactionId.submitted isn\'t null', () => {
            transactionId.submitted = true;

            expect(bmBraintreeHelper.getSearchType(transactionId, paymentMethod, paymentStatus)).to.equal('by transaction id');
        });

        it('result should equal to "by payment method" if paymentMethod.submitted & paymentMethod.stringValue aren\'t null', () => {
            paymentMethod.submitted = true;
            paymentMethod.stringValue = true;

            expect(bmBraintreeHelper.getSearchType(transactionId, paymentMethod, paymentStatus)).to.equal('by payment method');
        });

        it('result should equal to "by payment status" if paymentStatus.submitted & paymentStatus.stringValue aren\'t null', () => {
            paymentStatus.submitted = true;
            paymentStatus.stringValue = true;

            expect(bmBraintreeHelper.getSearchType(transactionId, paymentMethod, paymentStatus)).to.equal('by payment status');
        });
    });

    describe('convertToDate', () => {
        it('result should equal to "Wed, 05 Oct 2022 14:48:00 GMT"', () => {
            const isoString = '2022-10-05T14:48:00.000000Z';
            const date = new Date(isoString);
            expect(bmBraintreeHelper.convertToDate(isoString)).to.deep.equal(date);
        });
    });

    describe('submitForSettlement', () => {
        const params = {
            paymentTransaction: {
                getAmount: () => ({
                    subtract: () => 0,
                    value: { toString: () => 10 }
                })
            },
            reqData: {
                leftToSettle: 10
            },
            btTransactionActionsModel: {
                submitForSettlement: () => 'submitted',
                submitPartialSettlement: () => 'submitted-partial'
            },
            amount: 100,
            isPaypalPaymentMethod: false
        };

        it('If transaction was submited for settlement', () => {
            const result = bmBraintreeHelper.submitForSettlement(params);

            expect(result).to.be.an('object');
            expect(result).to.deep.equal({
                transaction: 'submitted',
                updatePartialList: false
            });
        });

        it('If transaction was not submited for settlement', () => {
            params.reqData.leftToSettle = 15;
            params.isPaypalPaymentMethod = true;

            const result = bmBraintreeHelper.submitForSettlement(params);

            expect(result).to.be.an('object');
            expect(result).to.deep.equal({
                transaction: 'submitted-partial',
                updatePartialList: true
            });
        });
    });
});
