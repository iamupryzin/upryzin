const { describe, it } = require('mocha');
const { expect } = require('chai');
const { stub } = require('sinon');

const { bm_braintree: { btOrdersPagingPath } } = require('../path.json');

const proxyquire = require('proxyquire').noCallThru();

const btOrdersPaging = proxyquire(btOrdersPagingPath, {
    'dw/web/PagingModel': () => ({})
});

const obj = {
    pagingModel: 'default'
};

describe('btOrdersPaging file', () => {
    describe('OrdersPagingModel', () => {
        it('obj property OrdersPagingModel should be equal to -> null', () => {
            btOrdersPaging.call(obj);

            expect(obj.pagingModel).equal(null);
        });
    });

    describe('createPagingModel', () => {
        const orders = {
            getCount: () => 100
        };
        let searchByPaymentMethodFlag = true;
        let context = {};

        afterEach(() => {
            context = {};
        });

        it('If paging model for search by payment method was created', () => {
            btOrdersPaging.prototype.createPagingModel.call(context, orders, searchByPaymentMethodFlag);

            expect(context.pagingModel).to.deep.equal({});
        });

        it('If default paging model was created', () => {
            searchByPaymentMethodFlag = false;
            btOrdersPaging.prototype.createPagingModel.call(context, orders, searchByPaymentMethodFlag);

            expect(context.pagingModel).to.deep.equal({});
        });
    });

    describe('setPagingModelSize', () => {
        const context = {
            pagingModel: {
                setPageSize: stub(),
                setStart: stub()
            }
        };

        it('If page size for paging model was set', () => {
            const pagingModel = {};
            const page = {};
            const pagesize = {};

            btOrdersPaging.prototype.setPagingModelSize.call(context, pagingModel, page, pagesize);

            expect(context.pagingModel.setPageSize.calledWith(10)).to.be.true;
            expect(context.pagingModel.setStart.calledWith(0)).to.be.true;
        });
    });
});

