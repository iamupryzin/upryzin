const { expect } = require('chai');
const { stub } = require('sinon');
const { bm_braintree: { btTransactionMgrPath } } = require('../path.json');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const error = stub();

const btTransactionMgr = proxyquire(btTransactionMgrPath, {
    'dw/value/Money': dw.value.Money,
    '*/cartridge/scripts/braintree/bmBraintreeHelper': {
        getLogger: () => ({ error }),
        getBraintreePaymentInstrument: {}
    },
    '*/cartridge/config/braintreeConstants': {
        TYPE_TRANSACTION: 'TRANSACTION',
        STATUS_SETTLED: 'SETTLED',
        TYPE_REFUND: 'REFUND',
        STATUS_VOIDED: 'VOIDED',
        STATUS_AUTHORIZED: 'AUTHORIZED',
        STATUS_SETTLEMENT_PENDING: 'PENDING'
    },
    '*/cartridge/models/btGraphQLSdk': () => {
        return {
            searchTransactionById: obj => obj,
            searchRefundTransactionById: obj => obj
        };
    }
});

describe('btTransactionMgr file', () => {
    describe('TransactionMgrModel', () => {
        it('should be a function', () => {
            expect(btTransactionMgr).to.be.a('function');
            expect(btTransactionMgr()).to.equal(undefined);
        });
    });

    describe('defineTransactionType', () => {
        const defineTransactionType = btTransactionMgr.__get__('defineTransactionType');
        let transactionType;

        describe('If transactionType is empty', () => {
            before(() => {
                transactionType = null;
            });

            it('response type should be equal -> string', () => {
                expect(defineTransactionType(transactionType)).to.be.a('string');
            });

            it('response should be equal -> TRANSACTION', () => {
                expect(defineTransactionType(transactionType)).equal('TRANSACTION');
            });
        });

        describe('If transactionType isnot empty', () => {
            before(() => {
                transactionType = 'payment';
            });

            it('response type should be equal -> string', () => {
                expect(defineTransactionType(transactionType)).to.be.a('string');
            });

            it('response should be equal -> TRANSACTION', () => {
                expect(defineTransactionType(transactionType)).equal('PAYMENT');
            });
        });
    });

    describe('findTransactionById', () => {
        const findTransactionById = btTransactionMgr.__get__('findTransactionById');
        const id = '2155874';

        it('response type should be equal -> object', () => {
            expect(findTransactionById(id)).to.be.a('object');
        });

        it('response object should be deep equal -> { transactionId: "2155874" }', () => {
            expect(findTransactionById(id)).deep.equal({ transactionId: '2155874' });
        });
    });

    describe('findRefundTransactionById', () => {
        const findRefundTransactionById = btTransactionMgr.__get__('findRefundTransactionById');
        const id = '2155874';

        it('response type should be equal -> object', () => {
            expect(findRefundTransactionById(id)).to.be.a('object');
        });

        it('response object should be deep equal -> { transactionId: "2155874" }', () => {
            expect(findRefundTransactionById(id)).deep.equal({ transactionId: '2155874' });
        });
    });

    describe('getFullOrderTransactionIdsList', () => {
        const getFullOrderTransactionIdsList = btTransactionMgr.__get__('getFullOrderTransactionIdsList');
        const order = {
            custom: { partialTransactions: '' }
        };
        const initialOrderTransactionId = '122143';

        describe('If partialTransactionsIds.length === 0', () => {
            it('response type should be equal -> array', () => {
                expect(getFullOrderTransactionIdsList(order, initialOrderTransactionId)).to.be.a('array');
            });

            it('response type should be equal -> array', () => {
                expect(getFullOrderTransactionIdsList(order, initialOrderTransactionId)).deep.equal(['122143']);
            });
        });

        describe('If partialTransactionsIds.length > 0', () => {
            before(() => {
                order.custom = { partialTransactions: '122144,122145,122146' };
            });

            it('response type should be equal -> array', () => {
                expect(getFullOrderTransactionIdsList(order, initialOrderTransactionId)).to.be.a('array');
            });

            it('response type should be equal -> array', () => {
                expect(getFullOrderTransactionIdsList(order, initialOrderTransactionId)).deep.equal(['122143', '122144', '122145', '122146']);
            });
        });
    });

    describe('calculateSettleRefundValue', () => {
        const calculateSettleRefundValue = btTransactionMgr.__get__('calculateSettleRefundValue');

        const refundTransactions = [{ status: 'SETTLED', amount: { value: 10 } }, { status: 'AUTHORIZED', amount: { value: 15 } }];
        const currency = 'USD';

        it('If expected refundedAmount returned', () => {
            const result = calculateSettleRefundValue(refundTransactions, currency);

            expect(result.getValue()).to.equal(10);
        });
    });

    describe('findTransaction', () => {
        const type = 'Transaction';
        const transactionId = 'id';

        before(() => {
            btTransactionMgr.__set__('defineTransactionType', () => 'TRANSACTION');
            btTransactionMgr.__set__('findTransactionById', () => ({ node: { custom: {} } }));
            btTransactionMgr.__set__('findRefundTransactionById', () => {
                throw Error('Error message');
            });
        });

        after(() => {
            btTransactionMgr.__ResetDependency__('defineTransactionType');
            btTransactionMgr.__ResetDependency__('findTransactionById');
            btTransactionMgr.__ResetDependency__('findRefundTransactionById');

            error.reset();
        });

        it('If transaction details successfully returned', () => {
            const result = btTransactionMgr.prototype.findTransaction(type, transactionId);

            expect(result).to.be.an('object');
            expect(result.isTransactionRefund).to.equal(false);
        });

        it('If transaction is empty', () => {
            btTransactionMgr.__set__('findTransactionById', () => ({ node: null }));

            const result = btTransactionMgr.prototype.findTransaction(type, transactionId);

            expect(result).to.equal(null);
        });

        it('If error was thrown', () => {
            btTransactionMgr.__set__('defineTransactionType', () => 'REFUND');

            expect(() => btTransactionMgr.prototype.findTransaction(type, transactionId)).to.throw(Error);
            expect(error.calledWith('Error message')).to.be.true;
        });
    });

    describe('getTransactionsDetails', () => {
        const transactionIdsList = ['id'];

        before(() => {
            btTransactionMgr.__set__('findTransactionById', () => ({ node: {} }));
        });

        after(() => {
            btTransactionMgr.__ResetDependency__('findTransactionById');

            error.reset();
        });

        it('If transactions list was returned successfully', () => {
            const result = btTransactionMgr.prototype.getTransactionsDetails(transactionIdsList);

            expect(result).to.be.an('array');
            expect(result[0]).to.deep.equal({});
        });

        it('If error was thrown', () => {
            btTransactionMgr.__set__('findTransactionById', () => { });

            btTransactionMgr.prototype.getTransactionsDetails(transactionIdsList);

            expect(error.calledOnce).to.be.true;
        });
    });

    describe('getRefundTransactionsDetails', () => {
        const refundTransactionsList = [{ legacyId: 'id' }];

        before(() => {
            btTransactionMgr.__set__('findRefundTransactionById', () => ({}));
        });

        after(() => {
            btTransactionMgr.__ResetDependency__('findRefundTransactionById');

            error.reset();
        });

        it('If transactions details list was returned successfully', () => {
            const result = btTransactionMgr.prototype.getRefundTransactionsDetails(refundTransactionsList);

            expect(result).to.be.an('array');
            expect(result[0]).to.deep.equal({});
        });

        it('If error was thrown', () => {
            btTransactionMgr.__set__('findRefundTransactionById', () => { throw new Error(); });

            btTransactionMgr.prototype.getRefundTransactionsDetails(refundTransactionsList);

            expect(error.calledOnce).to.be.true;
        });
    });

    describe('calculateTransactionsAmountValue', () => {
        const transactions = [{ status: 'CAPTURED', amount: { value: 100 } }, { status: 'AUTHORIZED' }];
        const currency = 'USD';

        it('If expected amount was returned', () => {
            const result = btTransactionMgr.prototype.calculateTransactionsAmountValue(transactions, currency);

            expect(result.getValue()).to.equal(100);
        });
    });

    describe('calculateLeftAmount', () => {
        const amount = new dw.value.Money(100, 'USD');
        const refundedOrSettledAmount = new dw.value.Money(50, 'USD');

        it('If amount that is available to refund/settle was returned', () => {
            const result = btTransactionMgr.prototype.calculateLeftAmount(amount, refundedOrSettledAmount);

            expect(result.getValue()).to.equal(50);
        });
    });

    describe('calculateTotalRefund', () => {
        const orderTransactions = [{ refunds: [{}] }, { refunds: [] }];
        const currency = 'USD';

        before(() => {
            btTransactionMgr.__set__('calculateSettleRefundValue', () => new dw.value.Money(50, 'USD'));
        });

        after(() => {
            btTransactionMgr.__ResetDependency__('calculateSettleRefundValue');
        });

        it('If total refund was successfully returned', () => {
            const result = btTransactionMgr.prototype.calculateTotalRefund.call({ getRefundTransactionsDetails: () => { } }, orderTransactions, currency);

            expect(result.getValue()).to.equal(50);
        });
    });

    describe('getInitialOrderTransactionAmount', () => {
        const initialOrderTransactionId = 'id';
        const transaction = {
            legacyId: 'id',
            statusHistory: [{ status: 'AUTHORIZED', amount: { value: 100 } }, { status: 'VOIDED' }]
        };
        const orderTransactions = [transaction, { legacyId: 'wrong-id' }];
        const currency = 'USD';

        it('If authorized amount was successfully returned', () => {
            const result = btTransactionMgr.prototype.getInitialOrderTransactionAmount(initialOrderTransactionId, orderTransactions, currency);

            expect(result.getValue()).to.equal(100);
        });
    });

    describe('getInitialOrderTransactionId', () => {
        before(() => {
            btTransactionMgr.__set__('getBraintreePaymentInstrument', () => ({
                getPaymentTransaction: () => ({ getTransactionID: () => 'id' })
            }));
        });

        after(() => {
            btTransactionMgr.__ResetDependency__('getBraintreePaymentInstrument');
        });

        it('If transaction id was returned', () => {
            expect(btTransactionMgr.prototype.getInitialOrderTransactionId()).to.equal('id');
        });
    });

    describe('getDetailedTransactionsList', () => {
        before(() => {
            btTransactionMgr.__set__('getFullOrderTransactionIdsList', () => []);
        });

        after(() => {
            btTransactionMgr.__ResetDependency__('getFullOrderTransactionIdsList');
        });

        it('If transactionsDetailsList was returned', () => {
            expect(btTransactionMgr.prototype.getDetailedTransactionsList.call({ getTransactionsDetails: () => [] })).to.deep.equal([]);
        });
    });

    describe('getTransactionHistoryList', () => {
        const transaction = {
            legacyId: 'id',
            refunds: [{ legacyId: 'r-id' }]
        };
        const orderTransactions = [transaction, { legacyId: 'l-id' }];

        it('If transactions ids array was returned', () => {
            const result = btTransactionMgr.prototype.getTransactionHistoryList(orderTransactions);

            expect(result).to.be.an('array');
            expect(result[0]).to.deep.equal({
                type: 'Transaction',
                id: 'id'
            });
            expect(result[1]).to.deep.equal({
                type: 'Refund',
                id: 'r-id'
            });
        });
    });

    describe('getPaymentMethodName', () => {
        /* eslint-disable no-global-assign */
        const order = {
            getPaymentInstruments: () => [{ paymentMethod: 'PayPal' }, { paymentMethod: 'Gift Certificate' }]
        };
        const originalArray = Array;

        before(() => {
            Object.assign(Array, { some: (arr, cb) => arr.some(cb) });
        });

        after(() => {
            Array = originalArray;
        });

        it('If payment method name was returned', () => {
            const result = btTransactionMgr.prototype.getPaymentMethodName(order);

            expect(result).to.be.a('string');
            expect(result).to.equal('PayPal');
        });
    });
});
