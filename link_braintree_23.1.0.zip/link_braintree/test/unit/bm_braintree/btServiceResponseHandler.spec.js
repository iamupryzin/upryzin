const { bm_braintree: { btServiceResponseHandlerPath } } = require('../path.json');

const { it, describe, before, after, beforeEach, afterEach } = require('mocha');
const { stub } = require('sinon');
const { expect } = require('chai');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');

require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const btServiceResponseHandler = proxyquire(btServiceResponseHandlerPath, {
    'dw/web/Resource': dw.web.Resource,
    '~/cartridge/config/braintreeConstants': {
        STATUS_SETTLEMENT_DECLINED: 'SETTLEMENT_DECLINED',
        STATUS_PROCESSOR_DECLINED: 'STATUS_PROCESSOR_DECLINED'
    }
});

describe('btServiceResponseHandler file', () => {
    const checkStr = (res, stringToCheck) => {
        expect(res).to.be.an('string');
        expect(res).to.equal(stringToCheck);
    };

    const checkObj = (res, objectToCheck) => {
        expect(res).to.be.an('object');
        expect(res).to.deep.equal(objectToCheck);
    };

    describe('btServiceResponseHandler', () => {
        it('If btServiceResponseHandler is function', () => {
            expect(btServiceResponseHandler).to.be.a('function');
            expect(btServiceResponseHandler()).to.equal(undefined);
        });
    });

    describe('validateLegacyIdConverterResponse', () => {
        const response = {
            data: {
                idFromLegacyId: 'test-id'
            }
        };

        it('If converted legacy id was returned', () => {
            const result = btServiceResponseHandler.prototype.validateLegacyIdConverterResponse(response);

            checkStr(result, 'test-id');
        });

        it('If passed response has error property', () => {
            response.error = true;
            response.message = 'error-message';

            const validateLegacyIdConverterResponse = btServiceResponseHandler.prototype.validateLegacyIdConverterResponse.bind({}, response);

            expect(() => validateLegacyIdConverterResponse()).to.throw(Object).with.property('isBusinessLogic');
        });
    });

    describe('validateSearchTransactionByIdResponse', () => {
        const response = {
            data: {
                search: {
                    transactions: {
                        edges: ['edge']
                    }
                }
            }
        };

        it('If found transaction data was returned', () => {
            const result = btServiceResponseHandler.prototype.validateSearchTransactionByIdResponse(response);

            checkStr(result, 'edge');
        });

        it('If passed response has error property', () => {
            response.error = true;
            response.message = 'error-message';

            const validateSearchTransactionByIdResponse = btServiceResponseHandler.prototype.validateSearchTransactionByIdResponse.bind({}, response);

            expect(() => validateSearchTransactionByIdResponse()).to.throw(Object).with.property('isBusinessLogic');
        });
    });

    describe('validateSearchRefundTransactionByIdResponse', () => {
        const response = {
            data: {
                search: {
                    refunds: {
                        edges: [{ node: 'node' }]
                    }
                }
            }
        };

        it('If found refund transaction data was returned', () => {
            const result = btServiceResponseHandler.prototype.validateSearchRefundTransactionByIdResponse(response);

            checkStr(result, 'node');
        });

        it('If passed response has error property', () => {
            response.error = true;
            response.message = 'error-message';

            const validateSearchRefundTransactionByIdResponse = btServiceResponseHandler.prototype.validateSearchRefundTransactionByIdResponse.bind({}, response);

            expect(() => validateSearchRefundTransactionByIdResponse()).to.throw(Object).with.property('isBusinessLogic');
        });
    });

    describe('validateTransactionRefundResponse', () => {
        const response = {
            data: {
                refundTransaction: {
                    refund: {}
                }
            }
        };

        it('If refund data was returned', () => {
            const result = btServiceResponseHandler.prototype.validateTransactionRefundResponse(response);

            checkObj(result, {});
        });

        it('If passed response has error property', () => {
            response.error = true;
            response.message = 'error-message';

            const validateTransactionRefundResponse = btServiceResponseHandler.prototype.validateTransactionRefundResponse.bind({}, response);

            expect(() => validateTransactionRefundResponse()).to.throw(Object).with.property('isBusinessLogic');
        });
    });

    describe('validateTransactionVoidResponse', () => {
        const response = {
            data: {
                reverseTransaction: {
                    reversal: {}
                }
            }
        };

        it('If void data was returned', () => {
            const result = btServiceResponseHandler.prototype.validateTransactionVoidResponse(response);

            checkObj(result, {});
        });

        it('If passed response has error property', () => {
            response.error = true;
            response.message = 'error-message';

            const validateTransactionVoidResponse = btServiceResponseHandler.prototype.validateTransactionVoidResponse.bind({}, response);

            expect(() => validateTransactionVoidResponse()).to.throw(Object).with.property('isBusinessLogic');
        });
    });

    describe('validateSubmitForSettlementResponse', () => {
        let response;

        before(() => {
            stub(dw.web.Resource, 'msg');
        });

        after(() => {
            dw.web.Resource.msg.restore();
        });

        beforeEach(() => {
            response = {
                data: {
                    captureTransaction: {
                        transaction: {
                            status: 'SETTLED'
                        }
                    }
                }
            };
        });

        afterEach(() => {
            dw.web.Resource.msg.reset();
        });

        it('If submit for settlement data was returned', () => {
            const result = btServiceResponseHandler.prototype.validateSubmitForSettlementResponse(response);

            checkObj(result, { status: 'SETTLED' });
        });

        it('If passed response has error property', () => {
            response.error = true;
            response.message = 'error-message';

            const validateSubmitForSettlementResponse = btServiceResponseHandler.prototype.validateSubmitForSettlementResponse.bind({}, response);

            expect(() => validateSubmitForSettlementResponse()).to.throw(Object).with.property('isBusinessLogic');
        });

        it('If settlement was declined and error was thrown', () => {
            response.data.captureTransaction.transaction.status = 'SETTLEMENT_DECLINED';

            const validateSubmitForSettlementResponse = btServiceResponseHandler.prototype.validateSubmitForSettlementResponse.bind({}, response);

            expect(() => validateSubmitForSettlementResponse()).to.throw(Object).with.property('isBusinessLogic');
            expect(dw.web.Resource.msg.calledOnce).to.be.true;
        });
    });

    describe('validateSubmitForPartialSettlementResponse', () => {
        let response;

        before(() => {
            stub(dw.web.Resource, 'msg');
        });

        after(() => {
            dw.web.Resource.msg.restore();
        });

        beforeEach(() => {
            response = {
                data: {
                    partialCaptureTransaction: {
                        capture: {
                            status: 'SETTLED'
                        }
                    }
                }
            };
        });

        afterEach(() => {
            dw.web.Resource.msg.reset();
        });

        it('If submit for partial settlement data was returned', () => {
            const result = btServiceResponseHandler.prototype.validateSubmitForPartialSettlementResponse(response);

            checkObj(result, { status: 'SETTLED' });
        });

        it('If passed response has error property', () => {
            response.error = true;
            response.message = 'error-message';

            const validateSubmitForPartialSettlementResponse = btServiceResponseHandler.prototype.validateSubmitForPartialSettlementResponse.bind({}, response);

            expect(() => validateSubmitForPartialSettlementResponse()).to.throw(Object).with.property('isBusinessLogic');
        });

        it('If settlement was declined and error was thrown', () => {
            response.data.partialCaptureTransaction.capture.status = 'SETTLEMENT_DECLINED';

            const validateSubmitForPartialSettlementResponse = btServiceResponseHandler.prototype.validateSubmitForPartialSettlementResponse.bind({}, response);

            expect(() => validateSubmitForPartialSettlementResponse()).to.throw(Object).with.property('isBusinessLogic');
            expect(dw.web.Resource.msg.calledOnce).to.be.true;
        });
    });

    describe('validateTransactionFromVaultResponse', () => {
        let response;

        before(() => {
            stub(dw.web.Resource, 'msg');
        });

        after(() => {
            dw.web.Resource.msg.restore();
        });

        beforeEach(() => {
            response = {
                data: {
                    chargePaymentMethod: {
                        transaction: {
                            status: 'SETTLED'
                        }
                    }
                }
            };
        });

        afterEach(() => {
            dw.web.Resource.msg.reset();
        });

        it('If transaction data was returned', () => {
            const result = btServiceResponseHandler.prototype.validateTransactionFromVaultResponse(response);

            checkObj(result, { status: 'SETTLED' });
        });

        it('If passed response has error property', () => {
            response.error = true;
            response.message = 'error-message';

            const validateTransactionFromVaultResponse = btServiceResponseHandler.prototype.validateTransactionFromVaultResponse.bind({}, response);

            expect(() => validateTransactionFromVaultResponse()).to.throw(Object).with.property('isBusinessLogic');
        });

        it('If settlement was declined and error was thrown', () => {
            response.data.chargePaymentMethod.transaction.status = 'STATUS_PROCESSOR_DECLINED';

            const validateTransactionFromVaultResponse = btServiceResponseHandler.prototype.validateTransactionFromVaultResponse.bind({}, response);

            expect(() => validateTransactionFromVaultResponse()).to.throw(Object).with.property('isBusinessLogic');
            expect(dw.web.Resource.msg.calledOnce).to.be.true;
        });
    });
});
