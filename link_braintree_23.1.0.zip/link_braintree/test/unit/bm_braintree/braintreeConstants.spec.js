const { expect } = require('chai');
const { bm_braintree: { braintreeConstantsPath } } = require('../path.json');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');

const bmBraintreeConstants = proxyquire(braintreeConstantsPath, {});

describe('bmBraintreeConstants', () => {
    it('response type should be object', () => {
        expect(bmBraintreeConstants).to.be.a('object');
    });
    it('response object should consist property SERVICE_NAME', () => {
        expect(bmBraintreeConstants).has.property('SERVICE_NAME');
    });
    it('response object should consist property SEARCH_BY_ORDER_NUMBER', () => {
        expect(bmBraintreeConstants).has.property('SEARCH_BY_ORDER_NUMBER');
    });
    it('response object should consist property SEARCH_BY_TRANSACTION_ID', () => {
        expect(bmBraintreeConstants).has.property('SEARCH_BY_TRANSACTION_ID');
    });
    it('response object should consist property SEARCH_BY_PAYMENT_METHOD', () => {
        expect(bmBraintreeConstants).has.property('SEARCH_BY_PAYMENT_METHOD');
    });
    it('response object should consist property TYPE_REFUND', () => {
        expect(bmBraintreeConstants).has.property('TYPE_REFUND');
    });
});
