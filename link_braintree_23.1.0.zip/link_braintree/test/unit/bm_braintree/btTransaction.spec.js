const { bm_braintree: { btTransactionPath } } = require('../path.json');

const { it, describe } = require('mocha');
const { stub } = require('sinon');
const { expect } = require('chai');

const proxyquire = require('proxyquire').noCallThru();

const error = stub();
const getPaymentTransaction = stub();

const btTransaction = proxyquire(btTransactionPath, {
    'dw/value/Money': () => { },
    '*/cartridge/scripts/braintree/bmBraintreeHelper': {
        getBraintreePaymentInstrument: () => ({
            getPaymentTransaction
        }),
        getLogger: () => {
            return { error };
        }
    },
    '*/cartridge/config/braintreeConstants': {
        PAYMENT_METHOD_ID_PAYPAL: 'PayPal'
    },
    '*/cartridge/models/btTransactionMgr': () => ({
        getInitialOrderTransactionId: () => '00000',
        getDetailedTransactionsList: () => [],
        getRefundTransactionsDetails: () => ({}),
        calculateTransactionsAmountValue: () => 5,
        getInitialOrderTransactionAmount: () => 1,
        calculateTotalRefund: () => 2,
        calculateLeftAmount: () => ({
            add: () => ({ getValue: () => 5 }),
            getValue: () => 3
        }),
        getTransactionHistoryList: () => [],
        getPaymentMethodName: () => 'PayPal'
    })
});

describe('btTransaction path', () => {
    describe('TransactionModel', () => {
        const order = {
            getPaymentInstruments: () => ['PayPal']
        };
        let transactionObject = {
            amount: {
                currencyCode: 'USD',
                value: 100
            },
            refunds: [],
            legacyId: '00000',
            paymentMethod: {
                legacyId: 'id'
            }
        };

        const expectedProps = ['currency', 'initialOrderTransactionAmount', 'settledAmount', 'transactionsRefundedAmount', 'leftToSettle', 'refundedAmount', 'leftToRefund',
            'braintreeRequest', 'braintreeResponse', 'transactionHistoryList', 'isDataUpdateRequired', 'isAbleToCapture', 'isAbleToCaptureByNewTransaction', 'isAbleToRefund',
            'isPaypal', 'paymentMethodName', 'amount', 'refunds', 'legacyId', 'paymentMethod'];

        afterEach(() => {
            transactionObject = {
                amount: {
                    currencyCode: 'USD',
                    value: 100
                },
                refunds: [],
                legacyId: '00000',
                paymentMethod: {
                    legacyId: 'id'
                }
            };
            getPaymentTransaction.reset();
        });

        it('If transaction model successfully created', () => {
            const context = {};
            getPaymentTransaction.returns({ custom: {} });

            btTransaction.call(context, order, transactionObject);

            expect(context).to.have.all.keys(expectedProps);
            expect(context.braintreeRequest).to.equal('');
            expect(context.braintreeResponse).to.equal('');
            expect(context.currency).to.equal('USD');
            expect(context.initialOrderTransactionAmount).to.equal(1);
        });

        it('If transaction model with refunds, braintreeRequest/Response was created', () => {
            const context = {};
            transactionObject = {
                amount: {
                    currencyCode: 'USD',
                    value: 100
                },
                refunds: [{}, {}],
                legacyId: '00000',
                paymentMethod: {
                    legacyId: 'id'
                }
            };
            getPaymentTransaction.returns({
                custom: {
                    braintreeRequest: JSON.stringify({}),
                    braintreeResponse: JSON.stringify({})
                }
            });

            btTransaction.call(context, order, transactionObject);

            expect(context.braintreeRequest).to.not.equal('');
            expect(context.braintreeResponse).to.not.equal('');
            expect(context.refundedAmount).to.equal(5);
        });

        it('If error was thrown', () => {
            const fakeTransactionObject = {};
            const context = {};

            expect(() => btTransaction.call(context, order, fakeTransactionObject)).to.throw(Error);
            expect(error.calledOnce).to.be.true;
        });
    });
});
