const { bm_braintree: { braintreeGraphQLServicePath } } = require('../path.json');

const { it, describe, before, after } = require('mocha');
const { stub } = require('sinon');
const { expect } = require('chai');

const proxyquire = require('proxyquire').noCallThru();

require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const createService = stub();
const msgf = stub();

const braintreeGraphQLService = proxyquire(braintreeGraphQLServicePath, {
    'dw/web/Resource': { msgf },
    'dw/svc/LocalServiceRegistry': {
        createService
    },
    '~/cartridge/scripts/braintree/bmBraintreeHelper': { getLogger: () => ({ error: () => {} }) },
    '~/cartridge/config/braintreeConstants': {}
});

describe('braintreeGraphQLService file', () => {
    describe('createGraphQLService', () => {
        const createGraphQLService = braintreeGraphQLService.__get__('createGraphQLService');

        it('should be called during createService function call', () => {
            braintreeGraphQLService();

            expect(createService.calledOnce).to.be.true;
        });

        it('should return object with callbacks', () => {
            const result = createGraphQLService();

            expect(result).to.be.an('object');
            expect(result).to.have.all.keys('createRequest', 'parseResponse', 'filterLogMessage', 'getRequestLogMessage', 'getResponseLogMessage');
        });

        describe('createRequest', () => {
            const createRequest = createGraphQLService().createRequest;

            const getCredential = stub();
            const addHeader = stub();

            const service = {
                getConfiguration: () => ({ getCredential }),
                addHeader
            };

            before(() => {
                msgf.returns('Credentials is not set');
            });

            after(() => {
                msgf.reset();
            });

            it('If service credentials is not set and getCredential threw an error', () => {
                getCredential.throws(Error);

                expect(() => createRequest(service, {})).to.throw(Error);
            });

            it('If service credentials is not set and getCredential returns undefined', () => {
                getCredential.returns();

                expect(() => createRequest(service, {})).to.throw(Error);
            });

            it('If service credentials is set and getCredential returns object', () => {
                getCredential.returns({});

                expect(createRequest(service, {})).to.deep.equal({});
                expect(addHeader.calledWithExactly('Braintree-Version', '2021-01-13')).to.be.true;
                expect(addHeader.calledWithExactly('Content-Type', 'application/json')).to.be.true;
            });
        });

        describe('parseResponse', () => {
            const parseResponse = createGraphQLService().parseResponse;

            const getText = stub();
            const service = {};
            const httpClient = { getText };

            it('If JSON.parse threw an error', () => {
                getText.returns({});

                expect(() => parseResponse(service, httpClient)).to.throw(Error);
            });

            it('If no response was returned', () => {
                getText.returns('null');

                expect(() => parseResponse(service, httpClient)).to.throw(Error);
            });

            it('If response was returned with errors and errorCode is not set', () => {
                getText.returns(JSON.stringify({
                    errors: [{
                        message: 'Error'
                    }],
                    data: 'data'
                }));

                const result = parseResponse(service, httpClient);

                expect(result).to.be.an('object');
                expect(result).to.deep.equal({
                    error: true,
                    data: 'data',
                    message: 'Error'
                });
            });

            it('If response was returned with errors and errorCode is set', () => {
                getText.returns(JSON.stringify({
                    errors: [{
                        message: 'Error',
                        extensions: { legacyCode: 'test-code' }
                    }],
                    data: 'data'
                }));

                const result = parseResponse(service, httpClient);

                expect(result).to.be.an('object');
                expect(result).to.deep.equal({
                    error: true,
                    data: 'data',
                    message: 'Error'
                });
            });

            it('If response was successfully returned', () => {
                getText.returns(JSON.stringify({
                    data: 'data'
                }));

                const result = parseResponse(service, httpClient);

                expect(result).to.be.an('object');
                expect(result).to.deep.equal({
                    error: false,
                    data: 'data',
                    message: ''
                });
            });
        });

        describe('filterLogMessage', () => {
            const filterLogMessage = createGraphQLService().filterLogMessage;

            it('should return message', () => {
                const msg = 'message';

                expect(filterLogMessage(msg)).to.equal(msg);
            });
        });

        describe('getRequestLogMessage', () => {
            const getRequestLogMessage = createGraphQLService().getRequestLogMessage;

            it('should return request message', () => {
                const reqmsg = 'req-message';

                expect(getRequestLogMessage(reqmsg)).to.equal(reqmsg);
            });
        });

        describe('getResponseLogMessage', () => {
            const getResponseLogMessage = createGraphQLService().getResponseLogMessage;

            it('should return request message', () => {
                const response = {
                    text: 'res-message'
                };

                expect(getResponseLogMessage(response)).to.equal(response.text);
            });
        });
    });
});
