const { describe, it, before, after } = require('mocha');
const { expect } = require('chai');
const { stub } = require('sinon');

const { bm_braintree: { responseHelperPath } } = require('../path.json');

require('dw-api-mock/demandware-globals');

const responseHelper = require('proxyquire').noCallThru()(responseHelperPath, {
    'dw/template/ISML': dw.template.ISML
});

describe('responseHelper file', () => {
    describe('render', () => {
        const templateName = 'template';
        const templateData = {};

        before(() => {
            stub(dw.template.ISML, 'renderTemplate');
        });

        after(() => {
            dw.template.ISML.renderTemplate.restore();
        });

        afterEach(() => {
            dw.template.ISML.renderTemplate.reset();
        });

        it('If template was rendered', () => {
            expect(responseHelper.render(templateName, templateData)).to.be.a('undefined');
            expect(dw.template.ISML.renderTemplate.calledOnce).to.be.true;
        });

        it('If template data type was not a object', () => {
            responseHelper.render(templateName, '');

            expect(dw.template.ISML.renderTemplate.calledWith(templateName, {})).to.be.true;
        });

        it('If error was thrown', () => {
            dw.template.ISML.renderTemplate.throws(Error);

            expect(() => responseHelper.render(templateName, templateData)).to.throw(Error);
        });
    });

    describe('renderJson', () => {
        const message = 'Some message';
        const additionalData = {};
        const result = {};

        describe('If result is empty', () => {
            it('response type should be undefined', () => {
                expect(responseHelper.renderJson(null, null, null)).to.be.a('undefined');
            });
        });

        describe('If result is not empty', () => {
            it('response type should be undefined', () => {
                expect(responseHelper.renderJson(result, message, additionalData)).to.be.a('undefined');
            });
        });
    });

    describe('renderError', () => {
        let errorStr = 'Error message';
        it('response type should be undefined', () => {
            expect(responseHelper.renderError(errorStr)).to.be.a('undefined');
        });
    });
});
