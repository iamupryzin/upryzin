const { bm_braintree: { btOrderMgrPath } } = require('../path.json');
const { expect } = require('chai');
const { it, describe, beforeEach } = require('mocha');
const { stub } = require('sinon');

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const proxyquire = require('proxyquire').noCallThru();

const error = stub();
const searchTransactionById = stub();
const hasNext = stub();

const order = {
    getPaymentInstruments: null,
    custom: {
        partialTransactions: null,
        braintreePaymentStatus: null,
        isBraintreeIntentOrder: true
    }
};
const transaction = {
    status: null,
    orderId: null,
    amount: {
        value: null
    }
};

const BtOrderMgr = proxyquire(btOrderMgrPath, {
    'dw/system/Transaction': dw.system.Transaction,
    'dw/object/SystemObjectMgr': dw.object.SystemObjectMgr,
    'dw/util/ArrayList': dw.util.ArrayList,
    'dw/order/OrderMgr': dw.order.OrderMgr,
    'dw/value/Money': function () {
        return this;
    },
    '*/cartridge/scripts/braintree/bmBraintreeHelper': {
        getLogger: () => ({
            error: error
        })
    },
    '*/cartridge/config/braintreeConstants': {},
    '*/cartridge/models/btGraphQLSdk': function () {
        this.searchTransactionById = searchTransactionById;
        return this;
    }
});

describe('btOrderMgr file', () => {
    const OrderMgrModel = new BtOrderMgr();

    describe('createOrdersListByOrderNo', () => {
        const createOrdersListByOrderNo = BtOrderMgr.__get__('createOrdersListByOrderNo');

        before(() => {
            stub(dw.object.SystemObjectMgr, 'querySystemObjects');
        });

        after(() => {
            dw.object.SystemObjectMgr.querySystemObjects.restore();
        });

        it('must call querySystemObjects function from SystemObjectMgr object', () => {
            createOrdersListByOrderNo();
            expect(dw.object.SystemObjectMgr.querySystemObjects.calledOnce).to.be.true;
        });
    });

    describe('filterOrdersByPaymentMethod', () => {
        const filterOrdersByPaymentMethod = BtOrderMgr.__get__('filterOrdersByPaymentMethod');

        before(() => {
            stub(dw.object.SystemObjectMgr, 'querySystemObjects');
            dw.object.SystemObjectMgr.querySystemObjects.returns({
                hasNext: hasNext,
                next: () => order
            });
        });

        after(() => {
            dw.object.SystemObjectMgr.querySystemObjects.restore();
        });

        beforeEach(() => {
            hasNext.onFirstCall().returns(true).onSecondCall().returns(false);
        });

        afterEach(() => {
            hasNext.reset();
        });

        it('if order has payment instruments', () => {
            order.getPaymentInstruments = () => [''];

            expect(filterOrdersByPaymentMethod()).to.be.an('object');
        });

        it('if order has no payment instruments', () => {
            order.getPaymentInstruments = () => [];

            expect(filterOrdersByPaymentMethod()).to.be.an('object').that.is.empty;
        });
    });

    describe('filterOrdersByPaymentStatus', () => {
        const filterOrdersByPaymentStatus = BtOrderMgr.__get__('filterOrdersByPaymentStatus');

        before(() => {
            stub(dw.object.SystemObjectMgr, 'querySystemObjects');
            dw.object.SystemObjectMgr.querySystemObjects.returns({
                asList: () => 'list'
            });
        });

        after(() => {
            dw.object.SystemObjectMgr.querySystemObjects.restore();
        });

        it('if paymentStatusName is not null', () => {
            const paymentStatusName = 'paymentStatusName';

            expect(filterOrdersByPaymentStatus(paymentStatusName)).to.be.equal('list');
        });

        it('if paymentStatusName is null', () => {
            const paymentStatusName = 'null';

            expect(filterOrdersByPaymentStatus(paymentStatusName)).to.be.equal('list');
        });
    });

    describe('getOrdersByTransactionId', () => {
        before(() => {
            BtOrderMgr.__set__('createOrdersListByOrderNo', () => ({ name: 'order object' }));
        });

        after(() => {
            BtOrderMgr.__ResetDependency__('createOrdersListByOrderNo');
            error.reset();
        });

        it('if transaction data is available use its order number', () => {
            searchTransactionById.returns({
                node: {
                    orderId: 'orderId'
                }
            });

            expect(OrderMgrModel.getOrdersByTransactionId()).to.be.deep.equal({ name: 'order object' });
        });

        it('if transaction data is not available set empty array', () => {
            searchTransactionById.returns();

            expect(OrderMgrModel.getOrdersByTransactionId()).to.be.deep.equal([]);
        });

        it('if there is an error', () => {
            searchTransactionById.throws();
            OrderMgrModel.getOrdersByTransactionId();

            expect(error.calledOnce).to.be.true;
        });
    });

    describe('getOrdersByTrgetOrdersByPaymentMethod', () => {
        before(() => {
            BtOrderMgr.__set__('filterOrdersByPaymentMethod', () => 'filterOrdersByPaymentMethod was called');
        });

        after(() => {
            BtOrderMgr.__ResetDependency__('filterOrdersByPaymentMethod');
        });

        it('must call filterOrdersByPaymentMethod function', () => {
            expect(OrderMgrModel.getOrdersByPaymentMethod()).to.be.equal('filterOrdersByPaymentMethod was called');
        });
    });

    describe('getOrdersByPaymentStatus', () => {
        before(() => {
            BtOrderMgr.__set__('filterOrdersByPaymentStatus', () => 'filterOrdersByPaymentStatus was called');
        });

        after(() => {
            BtOrderMgr.__ResetDependency__('filterOrdersByPaymentStatus');
        });

        it('must call filterOrdersByPaymentMethod function', () => {
            expect(OrderMgrModel.getOrdersByPaymentStatus()).to.be.equal('filterOrdersByPaymentStatus was called');
        });
    });

    describe('getOrdersByOrderNo', () => {
        before(() => {
            BtOrderMgr.__set__('createOrdersListByOrderNo', () => 'createOrdersListByOrderNo was called');
        });

        after(() => {
            BtOrderMgr.__ResetDependency__('createOrdersListByOrderNo');
        });

        it('must call filterOrdersByPaymentMethod function', () => {
            expect(OrderMgrModel.getOrdersByOrderNo()).to.be.equal('createOrdersListByOrderNo was called');
        });
    });

    describe('getAllOrders', () => {
        before(() => {
            BtOrderMgr.__set__('createOrdersListByOrderNo', () => 'createOrdersListByOrderNo was called');
        });

        after(() => {
            BtOrderMgr.__ResetDependency__('createOrdersListByOrderNo');
        });

        it('must call filterOrdersByPaymentMethod function', () => {
            expect(OrderMgrModel.getAllOrders()).to.be.equal('createOrdersListByOrderNo was called');
        });
    });

    describe('updateBtPaymentStatusOfOrder', () => {
        const transactionId = 'transactionId';
        const transactionStatus = 'status';

        const originalUpdateBraintreePaymentStatus = OrderMgrModel.updateBraintreePaymentStatus;

        before(() => {
            OrderMgrModel.updateBraintreePaymentStatus = () => {};
        });

        after(() => {
            OrderMgrModel.updateBraintreePaymentStatus = originalUpdateBraintreePaymentStatus;
            order.custom.partialTransactions = null;
            order.custom.braintreePaymentStatus = null;
        });

        it('if isBtPaymentStatusUpdateRequired true', () => {
            order.custom.partialTransactions = null;
            order.custom.braintreePaymentStatus = 'status';

            expect(OrderMgrModel.updateBtPaymentStatusOfOrder(order, transactionStatus, transactionId)).to.be.undefined;
        });

        it('if isBtPaymentStatusUpdateRequired true', () => {
            order.custom.partialTransactions = ['Id'];
            order.custom.braintreePaymentStatus = 'status';

            expect(OrderMgrModel.updateBtPaymentStatusOfOrder(order, transactionStatus, transactionId)).to.be.undefined;
        });
    });

    describe('updatePartialTransactionsList', () => {
        after(() => {
            order.custom.partialTransactions = null;
        });

        it('if transactionIds is empty', () => {
            const partialTransactionId = 'NewPartialTransactionId';
            order.custom.partialTransactions = [];

            OrderMgrModel.updatePartialTransactionsList(order, partialTransactionId);
            expect(order.custom.partialTransactions).to.be.deep.equal(['NewPartialTransactionId']);
        });

        it('if transactionIds is not empty and contains partialTransactionId', () => {
            const partialTransactionId = 'ExistedPartialTransactionId';
            order.custom.partialTransactions = ['ExistedPartialTransactionId'];

            OrderMgrModel.updatePartialTransactionsList(order, partialTransactionId);
            expect(order.custom.partialTransactions).to.be.deep.equal(['ExistedPartialTransactionId']);
        });
    });

    describe('updateBtPaymentStatusfterSettlement', () => {
        before(() => {
            stub(dw.order.OrderMgr, 'getOrder');
            dw.order.OrderMgr.getOrder.returns(order);
            transaction.status = 'status';
            transaction.orderId = 'orderId';
        });

        after(() => {
            dw.order.OrderMgr.getOrder.restore();
            transaction.status = null;
            transaction.orderId = null;
            order.custom.partialTransactions = null;
        });

        it('if order and transaction has different status', () => {
            order.custom.braintreePaymentStatus = 'enotherStatus';

            expect(OrderMgrModel.updateBtPaymentStatusfterSettlement(transaction, '')).to.be.undefined;
        });

        it('if order and transaction the same status', () => {
            order.custom.braintreePaymentStatus = 'status';

            expect(OrderMgrModel.updateBtPaymentStatusfterSettlement(transaction, '')).to.be.undefined;
        });
    });

    describe('updateBtPaymentStatusAfterPartialSettlement', () => {
        before(() => {
            stub(dw.order.OrderMgr, 'getOrder');
            dw.order.OrderMgr.getOrder.returns(order);
            transaction.status = 'status';
            transaction.orderId = 'orderId';
        });

        after(() => {
            dw.order.OrderMgr.getOrder.restore();
            order.custom.partialTransactions = null;
            transaction.status = null;
            transaction.orderId = null;
        });

        it('if order and transaction has different status', () => {
            order.custom.braintreePaymentStatus = 'enotherStatus';

            expect(OrderMgrModel.updateBtPaymentStatusAfterPartialSettlement(transaction, '')).to.be.undefined;
        });

        it('if order and transaction the same status', () => {
            order.custom.braintreePaymentStatus = 'status';

            expect(OrderMgrModel.updateBtPaymentStatusAfterPartialSettlement(transaction, '')).to.be.undefined;
        });
    });

    describe('updateIntentOrderData', () => {
        const paymentTransaction = {
            setTransactionID: () => {},
            setAmount: () => {},
            getAmount: () => ({
                getCurrencyCode: () => {}
            })
        };

        before(() => {
            transaction.status = 'transactionStatus';
            stub(dw.order.OrderMgr, 'getOrder');
            dw.order.OrderMgr.getOrder.returns(order);
        });

        after(() => {
            dw.order.OrderMgr.getOrder.restore();
            transaction.status = null;
            transaction.orderId = null;
            order.custom.isBraintreeIntentOrder = true;
        });

        it('must change order object', () => {
            OrderMgrModel.updateIntentOrderData(order, paymentTransaction, transaction);

            expect(order.custom.isBraintreeIntentOrder).to.be.false;
            expect(order.custom.braintreePaymentStatus).to.be.equal('transactionStatus');
        });
    });
});
