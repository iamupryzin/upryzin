const { describe, it, before, after, afterEach } = require('mocha');
const { expect } = require('chai');
const { stub } = require('sinon');

const { bm_braintree: { braintreeApiCallsPath } } = require('../path.json');

require('dw-api-mock/demandware-globals');

const createGQService = stub();

const bmBraintreeApiCall = require('proxyquire').noCallThru()(braintreeApiCallsPath, {
    'dw/web/Resource': dw.web.Resource,
    '~/cartridge/scripts/braintree/bmBraintreeHelper': { getLogger: () => {
        return { error: () => {} };
    } },
    '~/cartridge/config/braintreeConstants': {},
    '~/cartridge/scripts/service/bmBraintreeGraphQLService': createGQService
});

describe('bmBraintreeApiCalls file', () => {
    describe('call', () => {
        const requestData = {};

        before(() => {
            stub(dw.web.Resource, 'msg').returns('server error');
            stub(dw.web.Resource, 'msgf').returns('error');
        });

        after(() => {
            dw.web.Resource.msg.restore();
            dw.web.Resource.msgf.restore();
        });

        afterEach(() => {
            createGQService.reset();
        });

        it('result should be {} if everything is ok', () => {
            createGQService.returns({
                call: () => {
                    return { isOk: () => true };
                },
                getResponse: () => requestData
            });

            expect(bmBraintreeApiCall.call(requestData)).to.deep.equal({});
        });

        it('result should be an error if createGQService throws an error', () => {
            createGQService.throws(Error);

            expect(() => bmBraintreeApiCall.call(requestData)).to.throw('error').with.property('isBusinessLogic', true);
        });

        it('result should be an error if createGQService.call() throws an error', () => {
            createGQService.returns({
                call: () => {
                    throw new Error();
                }
            });

            expect(() => bmBraintreeApiCall.call(requestData)).to.throw('server error').with.property('isBusinessLogic', true);
        });

        it('result should be an error if createGQService.call.isOk() returns false', () => {
            createGQService.returns({
                call: () => {
                    return { isOk: () => false };
                }
            });

            expect(() => bmBraintreeApiCall.call(requestData)).to.throw('server error').with.property('isBusinessLogic', true);
        });
    });
});
