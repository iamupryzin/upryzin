const { expect } = require('chai');
const { bm_braintree: { bmBraintreePreferencesPath } } = require('../path.json');

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const bmBraintreePreferences = require('proxyquire').noCallThru()(bmBraintreePreferencesPath, {
    'dw/system/Site': {
        getCurrent: () => {
            return {
                getCustomPreferenceValue: mode => mode
            };
        }
    },
    'dw/svc/LocalServiceRegistry': {
        createService: (serviceName, obj) => { // eslint-disable-line no-unused-vars
            return {
                configuration: {
                    credential: {
                        custom: {
                            BRAINTREE_Tokenization_Key: 'dDssw2-ewrt43-2234WE-fdsw3w'
                        }
                    }
                }
            };
        }
    }
});

const resposeObject = {
    vaultMode: 'BRAINTREE_Vault_Mode',
    isSettle: 'BRAINTREE_SETTLE',
    loggingMode: 'all',
    tokenizationKey: 'dDssw2-ewrt43-2234WE-fdsw3w',
    merchantAccountIDs: 'BRAINTREE_Merchant_Account_IDs',
    apiVersion: 4,
    clientSdk3ClientUrl: 'https://js.braintreegateway.com/web/3.85.3/js/client.min.js',
    clientSdk3HostedFieldsUrl: 'https://js.braintreegateway.com/web/3.85.3/js/hosted-fields.min.js',
    braintreeEditStatus: 'Submitted for settlement',
    braintreeChannel: 'SFCC_BT_SFRA_23_1_0',
    userAgent: 'Braintree DW_Braintree_BM 23.1.0'
};

describe('bmBraintreePreferences file', () => {
    before(() => {
        bmBraintreePreferences.__set__('getTokenizationKey', () => {
            return 'dDssw2-ewrt43-2234WE-fdsw3w';
        });
    });
    after(() => {
        bmBraintreePreferences.__ResetDependency__('getTokenizationKey');
    });

    describe('getTokenizationKey', () => {
        const getTokenizationKey = bmBraintreePreferences.__get__('getTokenizationKey');
        it('response type should be equal -> string', () => {
            expect(getTokenizationKey()).to.be.a('string');
        });
        it('response should be equal -> dDssw2-ewrt43-2234WE-fdsw3w', () => {
            expect(getTokenizationKey()).equal('dDssw2-ewrt43-2234WE-fdsw3w');
        });
    });

    describe('bmBraintreePreferences exports', () => {
        it('response type should be equal -> object', () => {
            expect(bmBraintreePreferences).to.be.a('object');
        });
        it('response object should be deep equal', () => {
            expect(bmBraintreePreferences).deep.equal(resposeObject);
        });
    });
});
