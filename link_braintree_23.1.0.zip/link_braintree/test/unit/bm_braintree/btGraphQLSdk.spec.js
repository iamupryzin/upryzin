/* eslint-disable new-cap */
const { bm_braintree: { btGraphQLSdkPath } } = require('../path.json');

const { it, describe, before, after } = require('mocha');
const { stub } = require('sinon');
const { expect } = require('chai');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const addVariables = stub();
const call = stub();
const getOrder = stub();
const funcCall = stub();

const paymentTransaction = {
    custom: {
        braintreeRequest: '',
        braintreeResponse: ''
    }
};

let isSettle = true;

const btGraphQLSdk = proxyquire(btGraphQLSdkPath, {
    'dw/system/Transaction': dw.system.Transaction,
    'dw/web/Resource': dw.web.Resource,
    'dw/order/OrderMgr': {
        getOrder: getOrder
    },
    '~/cartridge/config/bmBraintreePreferences': {
        merchantAccountIDs: {
            ID1: 'usd:usd'
        },
        isSettle: isSettle
    },
    '~/cartridge/scripts/query/queries': {
        addVariables
    },
    '~/cartridge/config/braintreeConstants': {
        QUERY_NAME_SALE: 'sale',
        QUERY_NAME_AUTHORIZATION: 'authorization',
        TYPE_TRANSACTION: 'TRANSACTION'
    },
    '~/cartridge/scripts/braintree/bmBraintreeApiCalls': {
        call
    },
    '~/cartridge/scripts/braintree/helpers/paymentHelper': {
        defineCreateTransactionQueryName: () => {}
    },
    '~/cartridge/models/btServiceResponseHandler': function () {
        this.validateSearchTransactionByIdResponse = funcCall;
        this.validateSearchRefundTransactionByIdResponse = funcCall;
        this.validateTransactionVoidResponse = funcCall;
        this.validateTransactionRefundResponse = funcCall;
        this.validateSubmitForSettlementResponse = funcCall;
        this.validateSubmitForPartialSettlementResponse = funcCall;
        this.validateTransactionFromVaultResponse = funcCall;
        this.validateLegacyIdConverterResponse = () => {};

        return this;
    },
    '~/cartridge/scripts/braintree/bmBraintreeHelper': {
        getBraintreePaymentInstrument: () => ({
            getPaymentTransaction: () => paymentTransaction
        })
    }
});

describe('btGraphQLSdk file', () => {
    const btGraphQLSdkModel = new btGraphQLSdk();

    before(() => {
        btGraphQLSdk.__set__('validateReqData', () => { return {}; });
    });

    after(() => {
        btGraphQLSdk.__ResetDependency__('validateReqData');
    });

    describe('createGraphQLCallRequest', () => {
        const createGraphQLCallRequest = btGraphQLSdk.__get__('createGraphQLCallRequest');

        after(() => {
            addVariables.reset();
        });

        it('If graphQL request data was created', () => {
            createGraphQLCallRequest();
            expect(addVariables.calledOnce).to.be.true;
        });
    });

    describe('getMerchantAccountID', () => {
        const getMerchantAccountID = btGraphQLSdk.__get__('getMerchantAccountID');

        it('must return merchant account ID', () => {
            expect(getMerchantAccountID('usd')).to.be.equal('usd');
        });
    });

    describe('defineQueryName', () => {
        const defineQueryName = btGraphQLSdk.__get__('defineQueryName');
        let submitForSettlement;

        it('If submitForSettlement is undefined and prefs.isSettle false', () => {
            isSettle = false;
            expect(defineQueryName(submitForSettlement)).to.be.equal('sale');
        });

        it('If submitForSettlement is not undefined and equal to false', () => {
            expect(defineQueryName(false)).to.be.equal('authorization');
        });
    });

    describe('legacyIdConverter', () => {
        const legacyIdConverter = btGraphQLSdk.__get__('legacyIdConverter');

        before(() => {
            btGraphQLSdk.__set__('createGraphQLCallRequest', function () {
                return 'graphQLRequestData-for-legacyIdConverter';
            });
        });

        after(() => {
            btGraphQLSdk.__ResetDependency__('createGraphQLCallRequest');
        });

        it('If legacy ID converted into graphQL ID', () => {
            expect(legacyIdConverter()).to.be.undefined;
            expect(call.calledWith('graphQLRequestData-for-legacyIdConverter')).to.be.true;
        });
    });

    describe('validateReqData', () => {
        const validateReqData = btGraphQLSdk.__get__('validateReqData');
        const data = {};

        before(() => {
            stub(dw.web.Resource, 'msg');

            dw.web.Resource.msg.withArgs('braintree.error.empty.data', 'braintreebm', null).returns('No data provided for call.');
        });

        after(() => {
            dw.web.Resource.msg.restore();
        });

        it('If passed data is invalid', () => {
            expect(() => validateReqData(data)).to.throw(Error, 'No data provided for call.');
            expect(dw.web.Resource.msg.calledOnce).to.be.true;
        });

        it('If passed data is valid', () => {
            data.key = 'test';

            expect(validateReqData(data)).to.deep.equal(data);
        });
    });

    describe('saveTransationRequestAndResponse', () => {
        const saveTransationRequestAndResponse = btGraphQLSdk.__get__('saveTransationRequestAndResponse');

        const data = {
            orderNo: 'orderNo',
            orderToken: 'orderToken'
        };

        before(() => {
            stub(dw.system.Transaction, 'wrap', (callback) => callback());
            getOrder.returns({});
        });

        after(() => {
            dw.system.Transaction.wrap.restore();
            getOrder.reset();
        });

        it('if requestData and responseData are string', () => {
            saveTransationRequestAndResponse(data, 'requestData', 'responseData');
            expect(paymentTransaction.custom.braintreeRequest).to.be.equal('requestData');
            expect(paymentTransaction.custom.braintreeResponse).to.be.equal('responseData');
        });

        it('if requestData and responseData are object', () => {
            saveTransationRequestAndResponse(data, { requestData: 'requestData' }, { responseData: 'responseData' });
            expect(paymentTransaction.custom.braintreeRequest).to.be.equal('{"requestData":"requestData"}');
            expect(paymentTransaction.custom.braintreeResponse).to.be.equal('{"responseData":"responseData"}');
        });

        it('if thre is no order', () => {
            getOrder.returns(null);

            expect(saveTransationRequestAndResponse(data, {}, {})).to.be.undefined;
        });
    });

    describe('searchTransactionById', () => {
        before(() => {
            btGraphQLSdk.__set__('validateReqData', () => ({
                transactionId: 'transactionId'
            }));
        });

        after(() => {
            btGraphQLSdk.__ResetDependency__('validateReqData');
            funcCall.reset();
        });

        it('must execute without errors', () => {
            expect(btGraphQLSdkModel.searchTransactionById()).to.be.undefined;
            expect(funcCall.calledOnce).to.be.true;
        });
    });

    describe('searchRefundTransactionById', () => {
        before(() => {
            btGraphQLSdk.__set__('validateReqData', () => ({
                transactionId: 'transactionId'
            }));
        });

        after(() => {
            btGraphQLSdk.__ResetDependency__('validateReqData');
            funcCall.reset();
        });

        it('must execute without errors', () => {
            expect(btGraphQLSdkModel.searchRefundTransactionById()).to.be.undefined;
            expect(funcCall.calledOnce).to.be.true;
        });
    });

    describe('voidTransaction', () => {
        before(() => {
            btGraphQLSdk.__set__('validateReqData', () => ({
                transactionId: 'transactionId'
            }));
            btGraphQLSdk.__set__('saveTransationRequestAndResponse', () => {});
        });

        after(() => {
            btGraphQLSdk.__ResetDependency__('validateReqData');
            btGraphQLSdk.__ResetDependency__('saveTransationRequestAndResponse');
            funcCall.reset();
        });

        it('must execute without errors', () => {
            expect(btGraphQLSdkModel.voidTransaction()).to.be.undefined;
            expect(funcCall.calledOnce).to.be.true;
        });
    });

    describe('refundTransaction', () => {
        before(() => {
            btGraphQLSdk.__set__('validateReqData', () => ({
                transactionId: 'transactionId'
            }));
            btGraphQLSdk.__set__('saveTransationRequestAndResponse', () => {});
        });

        after(() => {
            btGraphQLSdk.__ResetDependency__('validateReqData');
            btGraphQLSdk.__ResetDependency__('saveTransationRequestAndResponse');
            funcCall.reset();
        });

        it('must execute without errors', () => {
            expect(btGraphQLSdkModel.refundTransaction()).to.be.undefined;
            expect(funcCall.calledOnce).to.be.true;
        });
    });

    describe('submitForSettlement', () => {
        before(() => {
            btGraphQLSdk.__set__('validateReqData', () => ({
                transactionId: 'transactionId'
            }));
            btGraphQLSdk.__set__('saveTransationRequestAndResponse', () => {});
        });

        after(() => {
            btGraphQLSdk.__ResetDependency__('validateReqData');
            btGraphQLSdk.__ResetDependency__('saveTransationRequestAndResponse');
            funcCall.reset();
        });

        it('must execute without errors', () => {
            expect(btGraphQLSdkModel.submitForSettlement()).to.be.undefined;
            expect(funcCall.calledOnce).to.be.true;
        });
    });

    describe('submitForPartialSettlement', () => {
        before(() => {
            btGraphQLSdk.__set__('validateReqData', () => ({
                transactionId: 'transactionId'
            }));
            btGraphQLSdk.__set__('saveTransationRequestAndResponse', () => {});
        });

        after(() => {
            btGraphQLSdk.__ResetDependency__('validateReqData');
            btGraphQLSdk.__ResetDependency__('saveTransationRequestAndResponse');
            funcCall.reset();
        });

        it('must execute without errors', () => {
            expect(btGraphQLSdkModel.submitForPartialSettlement()).to.be.undefined;
            expect(funcCall.calledOnce).to.be.true;
        });
    });

    describe('createTransactionFromVault', () => {
        const reqData = {
            transactionId: 'transactionId',
            token: 'token',
            orderNo: null,
            tax: null,
            customFields: null
        };

        before(() => {
            btGraphQLSdk.__set__('defineQueryName', () => {});
            btGraphQLSdk.__set__('getMerchantAccountID', () => {});
            btGraphQLSdk.__set__('saveTransationRequestAndResponse', () => {});
        });

        after(() => {
            btGraphQLSdk.__ResetDependency__('validateReqData');
            btGraphQLSdk.__ResetDependency__('defineQueryName');
            btGraphQLSdk.__ResetDependency__('getMerchantAccountID');
            btGraphQLSdk.__ResetDependency__('saveTransationRequestAndResponse');
        });

        afterEach(() => {
            funcCall.reset();
        });

        it('If reqData is empty', () => {
            btGraphQLSdk.__set__('validateReqData', () => reqData);
            expect(btGraphQLSdkModel.createTransactionFromVault()).to.be.undefined;
            expect(funcCall.calledOnce).to.be.true;
        });

        it('If reqData is not empty', () => {
            reqData.orderNo = 'orderNo';
            reqData.tax = 'tax';
            reqData.customFields = 'customFields';

            btGraphQLSdk.__set__('validateReqData', () => reqData);

            expect(btGraphQLSdkModel.createTransactionFromVault()).to.be.undefined;
            expect(funcCall.calledOnce).to.be.true;
        });

        it('If there is no reqData', () => {
            reqData.token = null;
            btGraphQLSdk.__set__('validateReqData', () => reqData);

            expect(() => btGraphQLSdkModel.createTransactionFromVault()).to.throw();
        });
    });
});
