const { int_braintree_ocapi: { accountButtonConfigHelperPath } } = require('../path.json');

const { expect } = require('chai');
const { it, describe, before, after } = require('mocha');
const { stub } = require('sinon');

const proxyquire = require('proxyquire').noCallThru();

const msg = stub();

const prefs = {
    paymentMethods: {
        BRAINTREE_PAYPAL: { paymentMethodId: 'BRAINTREE_PAYPAL' },
        BRAINTREE_APPLEPAY: { paymentMethodId: 'BRAINTREE_APPLEPAY' },
        BRAINTREE_VENMO: { paymentMethodId: 'BRAINTREE_VENMO' },
        BRAINTREE_LOCAL: { paymentMethodIds: 'BRAINTREE_LOCAL' },
        BRAINTREE_GOOGLEPAY: { paymentMethodId: 'BRAINTREE_GOOGLEPAY' },
        BRAINTREE_SRC: { paymentMethodId: 'BRAINTREE_SRC' }
    },
    SRCAccountButtonConfig: { style: {} }
};

const accountButtonConfigHelper = proxyquire(accountButtonConfigHelperPath, {
    'dw/web/Resource': {
        msg
    },
    '~/cartridge/config/braintreePreferences': prefs,
    '~/cartridge/scripts/braintree/helpers/paymentHelper': {
        createSRCImageUrl: () => {}
    },
    '~/cartridge/scripts/util/braintreeConstants': {}
});

describe('accountButtonConfigHelper file', () => {
    describe('createGeneralButtonConfig', () => {
        before(() => {
            msg.withArgs('braintree.ocapi.error.CLIENT_REQUEST_TIMEOUT', 'locale', null).returns('Request timeout :(');
            msg.withArgs('braintree.ocapi.error.CLIENT_GATEWAY_NETWORK', 'locale', null).returns('Gateway error');
            msg.withArgs('braintree.ocapi.error.CLIENT_REQUEST_ERROR', 'locale', null).returns('Bad request');
            msg.withArgs('braintree.ocapi.error.CLIENT_MISSING_GATEWAY_CONFIGURATION', 'locale', null).returns('Gateway config missed');
        });

        after(() => {
            msg.reset();
        });

        it('Button config should be returned without options property', () => {
            const result = accountButtonConfigHelper.createGeneralButtonConfig('BRAINTREE_PAYPAL');

            expect(result).to.be.an('object');
            expect(result).to.have.keys('paymentMethodName', 'messages');
            expect(result).to.not.have.key('options');
            expect(result.messages).to.deep.equal({
                CLIENT_REQUEST_TIMEOUT: 'Request timeout :(',
                CLIENT_GATEWAY_NETWORK: 'Gateway error',
                CLIENT_REQUEST_ERROR: 'Bad request',
                CLIENT_MISSING_GATEWAY_CONFIGURATION: 'Gateway config missed'
            });
        });

        it('Button config should be returned with options property (SRC)', () => {
            const result = accountButtonConfigHelper.createGeneralButtonConfig('BRAINTREE_SRC');

            expect(result).to.be.an('object');
            expect(result).to.have.keys('paymentMethodName', 'messages', 'options');
            expect(result.options).to.deep.equal({
                amount: '0.00',
                isAccount: true
            });
            expect(result.messages).to.deep.equal({
                CLIENT_REQUEST_TIMEOUT: 'Request timeout :(',
                CLIENT_GATEWAY_NETWORK: 'Gateway error',
                CLIENT_REQUEST_ERROR: 'Bad request',
                CLIENT_MISSING_GATEWAY_CONFIGURATION: 'Gateway config missed'
            });
        });

        it('Button config should be returned without options property', () => {
            const result = accountButtonConfigHelper.createGeneralButtonConfig('BRAINTREE_GOOGLEPAY');

            expect(result).to.be.an('object');
            expect(result).to.have.keys('paymentMethodName', 'messages', 'options');
            expect(result.options).to.deep.equal({
                amount: '0.00',
                isAccount: true
            });
            expect(result.messages).to.deep.equal({
                CLIENT_REQUEST_TIMEOUT: 'Request timeout :(',
                CLIENT_GATEWAY_NETWORK: 'Gateway error',
                CLIENT_REQUEST_ERROR: 'Bad request',
                CLIENT_MISSING_GATEWAY_CONFIGURATION: 'Gateway config missed'
            });
        });
    });

    describe('createPaypalAccountButtonConfig', () => {
        it('Config for PayPal button should be returned with empty ppDisplayName and ppBAdescription', () => {
            const result = accountButtonConfigHelper.createPaypalAccountButtonConfig();

            expect(result).to.be.an('object');
            expect(result).to.have.keys('paymentMethodName', 'messages', 'options', 'paypalConfig');
            expect(result.options.displayName).to.equal('');
            expect(result.options.billingAgreementDescription).to.equal('');
        });

        it('Config for PayPal button should be returned', () => {
            prefs.paypalDisplayName = 'ppName';
            prefs.paypalBillingAgreementDescription = 'ppDesc';

            const result = accountButtonConfigHelper.createPaypalAccountButtonConfig();

            expect(result).to.be.an('object');
            expect(result).to.have.keys('paymentMethodName', 'messages', 'options', 'paypalConfig');
            expect(result.options.displayName).to.equal('ppName');
            expect(result.options.billingAgreementDescription).to.equal('ppDesc');
        });
    });

    describe('createAccountSrcButtonConfig', () => {
        it('Config for SRC button should be returned', () => {
            const result = accountButtonConfigHelper.createAccountSrcButtonConfig();

            expect(result).to.be.an('object');
            expect(result).to.have.keys('paymentMethodName', 'messages', 'options', 'SRCImageUrl', 'settings');
        });
    });

    describe('createAccountVenmoButtonConfig', () => {
        it('Config for Venmo button should be returned', () => {
            const result = accountButtonConfigHelper.createAccountVenmoButtonConfig();

            expect(result).to.be.an('object');
            expect(result).to.have.keys('paymentMethodName', 'messages', 'options', 'venmoAccountPage');
            expect(result.venmoAccountPage).to.be.true;
        });
    });
});
