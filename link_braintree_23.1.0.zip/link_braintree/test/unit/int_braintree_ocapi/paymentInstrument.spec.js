const { int_braintree_ocapi: { paymentInstrumentPath } } = require('../path.json');
const { expect } = require('chai');
const { it, describe, before, after } = require('mocha');
const { stub } = require('sinon');

const proxyquire = require('proxyquire').noCallThru();

const Status = stub();
const func = stub();
const areRequiredFieldsFilled = stub();
const isSavedPaymentMethod = stub();

const paymentInstrument = proxyquire(paymentInstrumentPath, {
    'dw/system/Status': Status,

    'dw/web/Resource': dw.web.Resource,
    'dw/system/Logger': dw.system.Logger,

    '~/cartridge/scripts/util/braintreeConstants': {
        CUSTOM_ERROR_TYPE: 'CUSTOM_ERROR_TYPE'
    },

    '~/cartridge/scripts/braintree/braintreeAPI/braintreeBusinessLogic': {
        deletePaymentMethod: func,
        createPaymentMethodOnBraintreeSide: func
    },
    '~/cartridge/scripts/braintree/payment/processor/processorHelper': {
        savePaymentInstrument: func
    },
    '~/cartridge/scripts/braintree/helpers/paymentHelper': {
        areRequiredFieldsFilled: areRequiredFieldsFilled,
        isSavedPaymentMethod: isSavedPaymentMethod
    }
});

describe('paymentInstrument file', () => {
    let paymentInstrumentsArr;

    const paymentInstruments = {
        empty: false,
        toArray: () => paymentInstrumentsArr
    };

    const paymentInstrumentObj = {
        c_braintreePaymentMethodNonce: 'c_braintreePaymentMethodNonce',
        c_braintreePaymentMethodAccount: 'c_braintreePaymentMethodAccount',
        c_braintreeDefaultCard: 'c_braintreeDefaultCard',
        c_braintreePaypalAccountAddresses: 'c_braintreePaypalAccountAddresses'
    };

    const customer = {
        getProfile: () => ({
            getWallet: () => ({
                getPaymentInstruments: () => paymentInstruments
            })
        })
    };

    describe('beforeDELETE', () => {
        before(() => {
            stub(dw.web.Resource, 'msg');
        });

        after(() => {
            dw.web.Resource.msg.restore();

            func.reset();
            Status.reset();
        });

        afterEach(() => {
            paymentInstruments.empty = false;
        });

        it('if paymentInstruments is empty', () => {
            paymentInstruments.empty = true;

            expect(paymentInstrument.beforeDELETE(customer)).to.be.deep.equal({});
            expect(Status.calledWith(Status.ERROR, 'CUSTOM_ERROR_TYPE', undefined)).to.be.true;
            expect(dw.web.Resource.msg.calledWith('no.payment.instrument.to.delete', 'error', null)).to.be.true;
        });

        it('if there is no current payment instrument', () => {
            paymentInstrumentsArr = [];

            expect(paymentInstrument.beforeDELETE(customer)).to.be.deep.equal({});
            expect(Status.calledWith(Status.ERROR, 'CUSTOM_ERROR_TYPE', undefined)).to.be.true;
            expect(dw.web.Resource.msg.calledWith('no.payment.instrument.with.current.UUID', 'error', null)).to.be.true;
        });

        it('if there is all needed parameters', () => {
            paymentInstrumentsArr = [{}, {}];

            expect(paymentInstrument.beforeDELETE(customer)).to.be.deep.equal({});
            expect(func.calledOnce).to.be.true;
            expect(Status.calledWith(Status.OK)).to.be.true;
        });
    });

    describe('afterPOST', () => {
        after(() => {
            Status.reset();
        });


        it('if there is all needed parameters and no errors', () => {
            func.returns({
                error: null
            });

            expect(paymentInstrument.afterPOST(customer, paymentInstrumentObj)).to.be.deep.equal({});
            expect(Status.calledWith(Status.OK)).to.be.true;
        });

        it('if createPaymentMethodResponseData has an error', () => {
            paymentInstrumentObj.c_braintreeDefaultCard = null;
            paymentInstrumentObj.c_braintreePaypalAccountAddresses = null;

            func.returns({
                error: {}
            });

            expect(paymentInstrument.afterPOST(customer, paymentInstrumentObj)).to.be.deep.equal({});
            expect(Status.calledWith(Status.ERROR, 'CUSTOM_ERROR_TYPE', {})).to.be.true;
        });
    });

    describe('beforePOST', () => {
        before(() => {
            stub(dw.web.Resource, 'msg');

            dw.web.Resource.msg.returns('Resource.msg.error.text');
        });

        after(() => {
            dw.web.Resource.msg.restore();

            areRequiredFieldsFilled.reset();
            isSavedPaymentMethod.reset();
        });

        it('if areRequiredFieldsFilled is false', () => {
            areRequiredFieldsFilled.returns(false);

            expect(paymentInstrument.beforePOST(customer)).to.be.deep.equal({});
            expect(dw.web.Resource.msg.calledWith('required.fields.are.not.filled', 'error', null)).to.be.true;
            expect(Status.calledWith(Status.ERROR, 'CUSTOM_ERROR_TYPE', 'Resource.msg.error.text')).to.be.true;
        });

        it('if isSavedPaymentMethod is true', () => {
            areRequiredFieldsFilled.returns(true);
            isSavedPaymentMethod.returns(true);

            expect(paymentInstrument.beforePOST(customer)).to.be.deep.equal({});
            expect(dw.web.Resource.msg.calledWith('payment.instrument.already.exist', 'error', null)).to.be.true;
            expect(Status.calledWith(Status.ERROR, 'CUSTOM_ERROR_TYPE', 'Resource.msg.error.text')).to.be.true;
        });

        it('if areRequiredFieldsFilled is true and isSavedPaymentMethod is false', () => {
            areRequiredFieldsFilled.returns(true);
            isSavedPaymentMethod.returns(false);

            expect(paymentInstrument.beforePOST(customer)).to.be.undefined;
        });

        it('if there is an error', () => {
            areRequiredFieldsFilled.throws(new Error('error'));

            expect(paymentInstrument.beforePOST(customer)).to.be.deep.equal({});
            expect(Status.calledWith(Status.ERROR, 'CUSTOM_ERROR_TYPE', 'error')).to.be.true;
        });
    });
});
