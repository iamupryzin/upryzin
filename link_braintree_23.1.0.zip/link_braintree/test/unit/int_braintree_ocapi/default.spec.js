const { int_braintree_ocapi: { defaultPath } } = require('../path.json');
const { expect } = require('chai');
const { it, describe, before, after } = require('mocha');

const price = {
    available: null,
    getDecimalValue: () => ({
        get: () => 1000,
        toString: () => '1000.00'
    }),
    getCurrencyCode: () => 'CurrencyCode'
};

const proxyquire = require('proxyquire').noCallThru();

const DefaultPrice = proxyquire(defaultPath, {
    'dw/util/StringUtils': {
        formatMoney: () => 'formatMoney'
    }
});

describe('deafault file', () => {
    describe('toPriceModel', () => {
        const toPriceModel = DefaultPrice.__get__('toPriceModel');

        after(() => {
            price.available = null;
        });

        it('if price is unavailable', () => {
            expect(toPriceModel(price)).to.be.deep.equal({
                currency: null,
                decimalPrice: undefined,
                formatted: null,
                value: null
            });
        });

        it('if price is available', () => {
            price.available = true;

            expect(toPriceModel(price)).to.be.deep.equal({
                currency: 'CurrencyCode',
                decimalPrice: '1000.00',
                formatted: 'formatMoney',
                value: 1000
            });
        });
    });

    describe('DefaultPrice', () => {
        before(() => {
            DefaultPrice.__set__('toPriceModel', (value) => {
                if (value === 'salesPrice' || value === 'listPrice') {
                    return value;
                }
            });
        });

        after(() => {
            DefaultPrice.__ResetDependency__('toPriceModel');
        });

        it('if two parameters in the constructor', () => {
            const DefaultPriceModel = new DefaultPrice('salesPrice', 'listPrice');

            expect(DefaultPriceModel).to.be.deep.equal({
                list: 'listPrice',
                sales: 'salesPrice'
            });
        });

        it('if only one parameter in the constructor', () => {
            const DefaultPriceModel = new DefaultPrice('salesPrice');

            expect(DefaultPriceModel).to.be.deep.equal({
                list: null,
                sales: 'salesPrice'
            });
        });
    });
});
