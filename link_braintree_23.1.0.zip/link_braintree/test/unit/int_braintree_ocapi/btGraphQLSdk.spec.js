/* eslint-disable new-cap */
const { int_braintree_ocapi: { btGraphQLSdkPath } } = require('../path.json');

const { it, describe, before, after } = require('mocha');
const { stub } = require('sinon');
const { expect } = require('chai');

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const proxyquire = require('proxyquire').noCallThru();

const addVariables = stub();
const call = stub();
const func = stub();

const btGraphQLSdk = proxyquire(btGraphQLSdkPath, {
    'dw/web/Resource': dw.web.Resource,
    '~/cartridge/config/braintreePreferences': {},
    '~/cartridge/scripts/query/queries': {
        addVariables
    },
    '~/cartridge/scripts/braintree/braintreeAPI/braintreeApiCalls': {
        call
    },
    '~/cartridge/scripts/util/braintreeConstants': {
        QUERY_NAME_CLIENT_ID: 'QUERY_CLIENT_ID',
        QUERY_NAME_SEARCH_TRANSACTION: 'QUERY_SEARCH_TRANSACTION',
        QUERY_NAME_LEGACY_ID_CONVERTER: 'QUERY_LEGACY_ID_CONVERTER',
        QUERY_NAME_VAULT_PAYMENT_METHOD: 'QUERY_VAULT_PAYMENT_METHOD',
        QUERY_NAME_DELETE_PAYMENT_METHOD: 'QUERY_DELETE_PAYMENT_METHOD',
        QUERY_NAME_SEARCH_CUSTOMER: 'QUERY_SEARCH_CUSTOMER',
        QUERY_NAME_CREATE_CUSTOMER: 'QUERY_CREATE_CUSTOMER',
        LEGACY_ID_TYPE_CUSTOMER: 'LEGACY_ID_TYPE_CUSTOMER',
        LEGACY_ID_TYPE_PAYMENT_METHOD: 'LEGACY_ID_TYPE_PAYMENT_METHOD'
    },
    '~/cartridge/scripts/braintree/helpers/paymentHelper': {
        defineCreateTransactionQueryName: func
    },
    '~/cartridge/models/btServiceResponseHandler': function () {
        this.validateLegacyIdConverterResponse = func;
        this.validateSearchTransactionsByIdsResponse = func;
        this.validateCreateClientTokenResponse = func;
        this.validateVaultPaymentMethodResponse = func;
        this.validateDeletePaymentMethodFromVaultResponse = func;
        this.validateFindCustomerResponse = func;
        this.validateCreateCustomerResponse = func;
        this.validateCreateTransactionResponse = func;
        return this;
    }
});

describe('btGraphQLSdk file', () => {
    const btGraphQLSdkModel = new btGraphQLSdk();

    describe('createGraphQLCallRequest', () => {
        const createGraphQLCallRequest = btGraphQLSdk.__get__('createGraphQLCallRequest');

        after(() => {
            addVariables.reset();
        });

        it('If graphQL request data was created', () => {
            createGraphQLCallRequest();
            expect(addVariables.calledOnce).to.be.true;
        });
    });

    describe('validateReqData', () => {
        const validateReqData = btGraphQLSdk.__get__('validateReqData');
        const data = {};

        before(() => {
            stub(dw.web.Resource, 'msg');

            dw.web.Resource.msg.withArgs('braintree.error.empty.data', 'locale', null).returns('No data provided for call.');
        });

        after(() => {
            dw.web.Resource.msg.restore();
        });

        it('If passed data is invalid', () => {
            expect(() => validateReqData(data)).to.throw(Error, 'No data provided for call.');
            expect(dw.web.Resource.msg.calledOnce).to.be.true;
        });

        it('If passed data is valid', () => {
            data.key = 'test';

            expect(validateReqData(data)).to.deep.equal(data);
        });
    });

    describe('legacyIdConverter', () => {
        before(() => {
            btGraphQLSdk.__set__('createGraphQLCallRequest', () => 'graphQLRequestData-for-legacyIdConverter');
        });

        after(() => {
            btGraphQLSdk.__ResetDependency__('createGraphQLCallRequest');
            func.reset();
        });

        it('If legacy ID converted into graphQL ID', () => {
            expect(btGraphQLSdkModel.legacyIdConverter()).to.be.undefined;
            expect(call.calledWith('graphQLRequestData-for-legacyIdConverter')).to.be.true;
            expect(func.calledOnce).to.be.true;
        });
    });

    describe('searchTransactionsByIds', () => {
        before(() => {
            btGraphQLSdk.__set__('createGraphQLCallRequest', () => 'graphQLRequestData-for-legacyIdConverter');
            btGraphQLSdk.__set__('validateReqData', () => ({
                accId: 'transactionId'
            }));
        });

        after(() => {
            btGraphQLSdk.__ResetDependency__('createGraphQLCallRequest');
            btGraphQLSdk.__ResetDependency__('validateReqData');
            func.reset();
        });

        it('must execute without errors', () => {
            expect(btGraphQLSdkModel.searchTransactionsByIds()).to.be.undefined;
            expect(func.calledOnce).to.be.true;
        });
    });

    describe('createClientToken', () => {
        const data = {
            btCustomerId: null
        };

        before(() => {
            btGraphQLSdk.__set__('validateReqData', () => ({
                accId: 'accId'
            }));
        });

        after(() => {
            btGraphQLSdk.__ResetDependency__('validateReqData');
            func.reset();
        });

        it('if there is no btCustomerId', () => {
            expect(btGraphQLSdkModel.createClientToken(data)).to.be.undefined;
            expect(func.calledOnce).to.be.true;
        });

        it('if there is btCustomerId', () => {
            data.btCustomerId = 'btCustomerId';

            expect(btGraphQLSdkModel.createClientToken(data)).to.be.undefined;
            expect(addVariables.calledWith('QUERY_CLIENT_ID', {
                input: {
                    clientToken: {
                        merchantAccountId: 'accId',
                        customerId: 'btCustomerId'
                    }
                }
            })).to.be.true;
        });
    });

    describe('vaultPaymentMethod', () => {
        before(() => {
            btGraphQLSdk.__set__('createGraphQLCallRequest', () => {});
            btGraphQLSdk.__set__('validateReqData', () => ({
                accId: 'transactionId'
            }));
        });

        after(() => {
            btGraphQLSdk.__ResetDependency__('createGraphQLCallRequest');
            btGraphQLSdk.__ResetDependency__('validateReqData');
            func.reset();
        });

        it('must execute without errors', () => {
            expect(btGraphQLSdkModel.vaultPaymentMethod()).to.be.undefined;
            expect(func.calledTwice).to.be.true;
        });
    });

    describe('deletePaymentMethodFromVault', () => {
        before(() => {
            func.reset();
            btGraphQLSdk.__set__('createGraphQLCallRequest', () => {});
            btGraphQLSdk.__set__('validateReqData', () => ({
                accId: 'transactionId'
            }));
        });

        after(() => {
            btGraphQLSdk.__ResetDependency__('createGraphQLCallRequest');
            btGraphQLSdk.__ResetDependency__('validateReqData');
            func.reset();
        });

        it('must execute without errors', () => {
            expect(btGraphQLSdkModel.deletePaymentMethodFromVault()).to.be.undefined;
            expect(func.calledTwice).to.be.true;
        });
    });

    describe('findCustomer', () => {
        before(() => {
            func.reset();
            btGraphQLSdk.__set__('createGraphQLCallRequest', () => {});
            btGraphQLSdk.__set__('validateReqData', () => ({
                accId: 'transactionId'
            }));
        });

        after(() => {
            btGraphQLSdk.__ResetDependency__('createGraphQLCallRequest');
            btGraphQLSdk.__ResetDependency__('validateReqData');
            func.reset();
        });

        it('must execute without errors', () => {
            expect(btGraphQLSdkModel.findCustomer()).to.be.undefined;
            expect(func.calledTwice).to.be.true;
        });
    });

    describe('createCustomer', () => {
        before(() => {
            func.reset();
            btGraphQLSdk.__set__('createGraphQLCallRequest', () => {});
            btGraphQLSdk.__set__('validateReqData', () => ({
                accId: 'transactionId'
            }));
        });

        after(() => {
            btGraphQLSdk.__ResetDependency__('createGraphQLCallRequest');
            btGraphQLSdk.__ResetDependency__('validateReqData');
            func.reset();
        });

        it('must execute without errors', () => {
            expect(btGraphQLSdkModel.createCustomer()).to.be.undefined;
            expect(func.calledOnce).to.be.true;
        });
    });

    describe('createTransaction', () => {
        before(() => {
            btGraphQLSdk.__set__('createGraphQLCallRequest', () => 'graphQLRequestData-for-createTransaction');
        });

        after(() => {
            btGraphQLSdk.__ResetDependency__('createGraphQLCallRequest');
        });

        it('If request data is empty', () => {
            btGraphQLSdk.__set__('validateReqData', () => ({}));

            expect(btGraphQLSdk.prototype.createTransaction()).to.be.undefined;
            expect(call.calledWith('graphQLRequestData-for-createTransaction')).to.be.true;
        });

        it('If request data has customerId property', () => {
            btGraphQLSdk.__set__('validateReqData', () => ({ customerId: 'some-id' }));

            expect(btGraphQLSdk.prototype.createTransaction()).to.be.undefined;
            expect(call.calledWith('graphQLRequestData-for-createTransaction')).to.be.true;
        });

        it('If request data has vaultPaymentMethodAfterTransacting property', () => {
            btGraphQLSdk.__set__('validateReqData', () => ({ vaultPaymentMethodAfterTransacting: 'some-payment-method' }));

            expect(btGraphQLSdk.prototype.createTransaction()).to.be.undefined;
            expect(call.calledWith('graphQLRequestData-for-createTransaction')).to.be.true;
        });

        it('If request data has shipping property', () => {
            btGraphQLSdk.__set__('validateReqData', () => ({ shipping: 'shipping' }));

            expect(btGraphQLSdk.prototype.createTransaction()).to.be.undefined;
            expect(call.calledWith('graphQLRequestData-for-createTransaction')).to.be.true;
        });

        it('If request data has shippingAmount property', () => {
            btGraphQLSdk.__set__('validateReqData', () => ({ shippingAmount: 'shippingAmount' }));

            expect(btGraphQLSdk.prototype.createTransaction()).to.be.undefined;
            expect(call.calledWith('graphQLRequestData-for-createTransaction')).to.be.true;
        });

        it('If request data has descriptor property', () => {
            btGraphQLSdk.__set__('validateReqData', () => ({ descriptor: 'descriptor' }));

            expect(btGraphQLSdk.prototype.createTransaction()).to.be.undefined;
            expect(call.calledWith('graphQLRequestData-for-createTransaction')).to.be.true;
        });

        it('If request data has customFields property', () => {
            btGraphQLSdk.__set__('validateReqData', () => ({ customFields: 'customFields' }));

            expect(btGraphQLSdk.prototype.createTransaction()).to.be.undefined;
            expect(call.calledWith('graphQLRequestData-for-createTransaction')).to.be.true;
        });

        it('If request data has taxAmount property', () => {
            btGraphQLSdk.__set__('validateReqData', () => ({ taxAmount: 'taxAmount' }));

            expect(btGraphQLSdk.prototype.createTransaction()).to.be.undefined;
            expect(call.calledWith('graphQLRequestData-for-createTransaction')).to.be.true;
        });

        it('If request data has discountAmount property', () => {
            btGraphQLSdk.__set__('validateReqData', () => ({ discountAmount: 'discountAmount' }));

            expect(btGraphQLSdk.prototype.createTransaction()).to.be.undefined;
            expect(call.calledWith('graphQLRequestData-for-createTransaction')).to.be.true;
        });

        it('If request data has lineItems property', () => {
            btGraphQLSdk.__set__('validateReqData', () => ({ lineItems: 'lineItems' }));

            expect(btGraphQLSdk.prototype.createTransaction()).to.be.undefined;
            expect(call.calledWith('graphQLRequestData-for-createTransaction')).to.be.true;
        });
    });
});
