const { int_braintree_ocapi: { braintreePayPalPath } } = require('../path.json');

const { expect } = require('chai');
const { it, describe, before, after } = require('mocha');
const { stub } = require('sinon');

const proxyquire = require('proxyquire').noCallThru();

require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const prefs = {
    paymentMethods: {
        BRAINTREE_PAYPAL: {
            paymentMethodId: 'PayPal'
        }
    },
    vaultMode: true
};

const updatePaypalAccountBillingAddress = stub();
const getPaypalCustomerPaymentInstrumentByEmail = stub();
const setBraintreeDefaultCard = stub();

const braintreePayPal = proxyquire(braintreePayPalPath, {
    '~/cartridge/config/braintreePreferences': prefs,
    '~/cartridge/scripts/braintree/braintreeAPI/braintreeBusinessLogic': {
        createPaymentMethod: () => 'token'
    },
    '~/cartridge/scripts/braintree/payment/processor/processorHelper': {
        createBaseSaleTransactionData: () => ({}),
        saveGeneralTransactionData: () => { },
        verifyTransactionStatus: () => { },
        savePaypalAccount: () => { }
    },
    '~/cartridge/scripts/braintree/helpers/customerHelper': {
        clearDefaultProperty: () => { },
        getCustomerPaymentInstruments: () => { },
        setBraintreeDefaultCard,
        getPaypalCustomerPaymentInstrumentByEmail
    },
    '*/cartridge/models/btGraphQLSdk': () => ({
        createTransaction: () => ({
            transaction: {
                paymentMethodSnapshot: {
                    payer: { email: 'email@email.com' }
                },
                paymentMethod: {
                    legacyId: 'id'
                }
            }
        })
    })
});

describe('braintreePayPal file', () => {
    describe('createSaleTransactionData', () => {
        const createSaleTransactionData = braintreePayPal.__get__('createSaleTransactionData');

        const paymentInstrument = {
            custom: {
                braintreeFraudRiskData: 'braintreeFraudRiskData'
            }
        };
        const order = {};

        it('If data was returned and fraud tools disabled', () => {
            const result = createSaleTransactionData(order, paymentInstrument);

            expect(result).to.be.an('object');
            expect(result.isPaypal).to.be.true;
            expect(result).to.not.have.key('deviceData');
        });

        it('If data was returned and fraud tools enabled', () => {
            prefs.isPaypalFraudToolsEnabled = true;

            const result = createSaleTransactionData(order, paymentInstrument);

            expect(result).to.be.an('object');
            expect(result.isPaypal).to.be.true;
            expect(result.deviceData).to.equal('braintreeFraudRiskData');
        });
    });

    describe('saveTransactionData', () => {
        const saveTransactionData = braintreePayPal.__get__('saveTransactionData');

        const order = {};
        const paymentInstrument = {};
        const response = {
            transaction: {},
            billingAgreementWithPurchasePaymentMethod: {
                legacyId: 'id'
            }
        };

        it('Token should be saved', () => {
            saveTransactionData(order, paymentInstrument, response);

            expect(paymentInstrument.creditCardToken).to.equal('id');
        });

        it('Token should not be updated', () => {
            paymentInstrument.creditCardToken = 'token';

            saveTransactionData(order, paymentInstrument, response);

            expect(paymentInstrument.creditCardToken).to.equal('token');
        });
    });

    describe('createPaypalBillingAddress', () => {
        const createPaypalBillingAddress = braintreePayPal.__get__('createPaypalBillingAddress');

        const order = {
            getBillingAddress: () => ({
                getFirstName: () => 'fname',
                getLastName: () => 'lname',
                getCountryCode: () => ({ value: 'US' }),
                getCity: () => 'City',
                getAddress1: () => 'address1',
                getAddress2: () => 'address2',
                getPostalCode: () => '24915',
                getStateCode: () => 'AL',
                getPhone: () => '13-19432-2234-1'
            })
        };
        const originalDecodeURIComponent = decodeURIComponent;

        /* eslint-disable no-global-assign */
        before(() => {
            decodeURIComponent = () => '24915';
        });

        after(() => {
            decodeURIComponent = originalDecodeURIComponent;
        });

        it('Billing address should be created', () => {
            const result = createPaypalBillingAddress(order);

            expect(result).to.be.an('object');
            expect(result).to.deep.equal({
                firstName: 'fname',
                lastName: 'lname',
                countryCodeAlpha2: 'US',
                locality: 'City',
                streetAddress: 'address1',
                extendedAddress: 'address2',
                postalCode: '24915',
                region: 'AL',
                phone: '13-19432-2234-1'
            });
        });
    });

    describe('updatePaypalAccountBillingAddress', () => {
        /* eslint-disable no-shadow */
        const updatePaypalAccountBillingAddress = braintreePayPal.__get__('updatePaypalAccountBillingAddress');

        const customerPaymentInstruments = [{ custom: { braintreePaymentMethodAccount: 'account1' } }, { custom: { braintreePaymentMethodAccount: 'account2' } }];
        const createPaymentMethodResponseData = {
            details: { email: 'account1' }
        };
        const createPaymentMethodResponseData2 = {
            transaction: { paymentMethodSnapshot: { payer: { email: 'account1' } } }
        };
        const accountAddresses = 'addresses';
        const customer = {
            getProfile: () => ({
                getWallet: () => ({
                    getPaymentInstruments: () => ({
                        toArray: () => customerPaymentInstruments
                    })
                })
            })
        };

        it('If buyer account was found and billing address was updated', () => {
            updatePaypalAccountBillingAddress(createPaymentMethodResponseData, accountAddresses, customer);

            expect(customerPaymentInstruments[0].custom.braintreePaypalAccountAddresses).to.equal('addresses');
        });

        it('If buyer account was found and billing address was updated, but paypal email was taken from transaction', () => {
            updatePaypalAccountBillingAddress(createPaymentMethodResponseData2, accountAddresses, customer);

            expect(customerPaymentInstruments[0].custom.braintreePaypalAccountAddresses).to.equal('addresses');
        });
    });

    describe('mainFlow', () => {
        const mainFlow = braintreePayPal.__get__('mainFlow');

        let order;
        let paymentInstrument;

        before(() => {
            braintreePayPal.__set__('createSaleTransactionData', () => ({}));
            braintreePayPal.__set__('createPaypalBillingAddress', () => ({}));
            braintreePayPal.__set__('saveTransactionData', () => { });
            braintreePayPal.__set__('updatePaypalAccountBillingAddress', updatePaypalAccountBillingAddress);

            getPaypalCustomerPaymentInstrumentByEmail.returns({});
        });

        after(() => {
            braintreePayPal.__ResetDependency__('createSaleTransactionData');
            braintreePayPal.__ResetDependency__('createPaypalBillingAddress');
            braintreePayPal.__ResetDependency__('saveTransactionData');
            braintreePayPal.__ResetDependency__('updatePaypalAccountBillingAddress');

            getPaypalCustomerPaymentInstrumentByEmail.reset();
            setBraintreeDefaultCard.reset();
        });

        beforeEach(() => {
            order = {
                customer: {
                    authenticated: true
                }
            };
            paymentInstrument = {
                custom: {
                    braintreeSaveCreditCard: true
                }
            };
        });

        afterEach(() => {
            updatePaypalAccountBillingAddress.reset();
        });

        it('Case when buyer go with new PayPal account with the same email as already stored', () => {
            mainFlow(order, paymentInstrument);

            expect(paymentInstrument.custom.braintreeSaveCreditCard).to.be.null;
            expect(updatePaypalAccountBillingAddress.calledOnce).to.be.true;
        });

        it('Case when customer is not authenticated', () => {
            order.customer.authenticated = false;

            mainFlow(order, paymentInstrument);

            expect(paymentInstrument.custom.braintreeSaveCreditCard).to.be.null;
            expect(updatePaypalAccountBillingAddress.calledOnce).to.be.false;
        });

        it('Case when paymentInstrument.custom.braintreeSaveCreditCard === false', () => {
            paymentInstrument.custom.braintreeSaveCreditCard = false;

            mainFlow(order, paymentInstrument);

            expect(paymentInstrument.custom.braintreeSaveCreditCard).to.be.null;
            expect(updatePaypalAccountBillingAddress.calledOnce).to.be.false;
        });

        it('Case when buyer procceed with new PayPal account', () => {
            getPaypalCustomerPaymentInstrumentByEmail.returns();

            mainFlow(order, paymentInstrument);

            expect(paymentInstrument.custom.braintreeSaveCreditCard).to.be.null;
            expect(updatePaypalAccountBillingAddress.calledOnce).to.be.false;
            expect(setBraintreeDefaultCard.calledOnce).to.be.true;
        });
    });

    describe('intentOrderFlow', () => {
        const intentOrderFlow = braintreePayPal.__get__('intentOrderFlow');

        let order;
        let paymentInstrument;

        beforeEach(() => {
            order = {
                custom: {}
            };
            paymentInstrument = {
                custom: {}
            };
        });

        it('If token was saved', () => {
            intentOrderFlow(order, paymentInstrument);

            expect(paymentInstrument.creditCardToken).to.equal('token');
        });

        it('If token was not saved', () => {
            paymentInstrument.creditCardToken = 'test';

            intentOrderFlow(order, paymentInstrument);

            expect(paymentInstrument.creditCardToken).to.equal('test');
        });
    });

    describe('authorize', () => {
        const order = {};
        const paymentInstrument = {};

        const intentOrderFlow = stub();
        const mainFlow = stub();

        before(() => {
            braintreePayPal.__set__('intentOrderFlow', intentOrderFlow);
            braintreePayPal.__set__('mainFlow', mainFlow);
        });

        after(() => {
            braintreePayPal.__ResetDependency__('intentOrderFlow');
            braintreePayPal.__ResetDependency__('mainFlow');
        });

        it('If intentOrderFlow was executed', () => {
            prefs.paypalOrderIntent = true;

            braintreePayPal.authorize(order, paymentInstrument);

            expect(intentOrderFlow.calledOnce).to.be.true;
        });

        it('If mainFlow was executed', () => {
            prefs.paypalOrderIntent = false;

            braintreePayPal.authorize(order, paymentInstrument);

            expect(mainFlow.calledOnce).to.be.true;
        });

        it('If error was thrown', () => {
            mainFlow.throws();

            expect(() => braintreePayPal.authorize(order, paymentInstrument)).to.throw(Error);
        });
    });
});
