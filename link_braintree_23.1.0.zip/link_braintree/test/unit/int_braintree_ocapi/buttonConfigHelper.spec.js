const { int_braintree_ocapi: { buttonConfigHelperPath } } = require('../path.json');

const { expect } = require('chai');
const { it, describe, after } = require('mocha');
const { stub } = require('sinon');

const proxyquire = require('proxyquire').noCallThru();

const getInstanceTypeStub = stub();

const prefs = {
    paypalPdpButtonConfig: 'paypalPdpButtonConfig',
    paypalCartButtonConfig: 'paypalCartButtonConfig',
    paypalMiniCartButtonConfig: 'paypalMiniCartButtonConfig',
    paypalBillingButtonConfig: 'paypalBillingButtonConfig',
    enableFundingList: [],
    disableFundingList: [],
    vaultMode: true,
    paymentMethods: {
        BRAINTREE_APPLEPAY: {
            paymentMethodId: 'ApplePay'
        },
        BRAINTREE_GOOGLEPAY: {
            paymentMethodId: 'GooglePay'
        },
        BRAINTREE_PAYPAL: {
            paymentMethodId: 'PayPal'
        },
        BRAINTREE_VENMO: {
            paymentMethodId: 'Venmo'
        },
        BRAINTREE_LOCAL: {
            paymentMethodId: 'LPM'
        },
        BRAINTREE_SRC: {
            paymentMethodId: 'SRC'
        }
    },
    venmoDisplayName: 'Venmo',
    srcDisplayName: 'SRC',
    paypalDisplayName: 'PayPal',
    paypalBillingAgreementDescription: 'pp-descr'
};

const buttonConfigHelper = proxyquire(buttonConfigHelperPath, {
    'dw/system/Site': {
        getCurrent: () => ({
            getDefaultLocale: () => 'US'
        })
    },
    'dw/web/Resource': { msg: () => '' },
    'dw/system/System': {
        PRODUCTION_SYSTEM: 'PRODUCTION',
        getInstanceType: getInstanceTypeStub
    },
    '~/cartridge/config/braintreePreferences': prefs,
    '~/cartridge/scripts/braintree/helpers/paymentHelper': {
        getAmountPaid: () => ({
            valueOrNull: 100,
            getValue: () => 100,
            getCurrencyCode: () => 'USD'
        }),
        createSRCImageUrl: () => 'src-url'
    },
    '~/cartridge/scripts/util/braintreeConstants': {
        PRODUCTION_SYSTEM_TYPE: 'prod',
        DEVELOPMENT_SYSTEM_TYPE: 'dev',
        PAGE_FLOW_PDP: 'pdp',
        PAGE_FLOW_CART: 'cart',
        PAGE_FLOW_MINICART: 'minicart',
        PAGE_FLOW_BILLING: 'billing'
    }
});

describe('buttonConfigHelper file', () => {
    describe('getInstanceType', () => {
        const getInstanceType = buttonConfigHelper.__get__('getInstanceType');

        after(() => {
            getInstanceTypeStub.reset();
        });

        it('If production system type was returned', () => {
            getInstanceTypeStub.returns('PRODUCTION');

            const result = getInstanceType();

            expect(result).to.be.a('string');
            expect(result).to.equal('prod');
        });

        it('If development system type was returned', () => {
            getInstanceTypeStub.returns('DEVELOPMENT');

            const result = getInstanceType();

            expect(result).to.be.a('string');
            expect(result).to.equal('dev');
        });
    });

    describe('getPaypalButtonStyleConfigs', () => {
        const getPaypalButtonStyleConfigs = buttonConfigHelper.__get__('getPaypalButtonStyleConfigs');

        it('If page flow is pdp', () => {
            const result = getPaypalButtonStyleConfigs('pdp');

            expect(result).to.be.a('string');
            expect(result).to.equal('paypalPdpButtonConfig');
        });

        it('If page flow is cart', () => {
            const result = getPaypalButtonStyleConfigs('cart');

            expect(result).to.be.a('string');
            expect(result).to.equal('paypalCartButtonConfig');
        });

        it('If page flow is minicart', () => {
            const result = getPaypalButtonStyleConfigs('minicart');

            expect(result).to.be.a('string');
            expect(result).to.equal('paypalMiniCartButtonConfig');
        });

        it('If page flow is billing', () => {
            const result = getPaypalButtonStyleConfigs('billing');

            expect(result).to.be.a('string');
            expect(result).to.equal('paypalBillingButtonConfig');
        });
    });

    describe('getGeneralPdpConfig', () => {
        const getGeneralPdpConfig = buttonConfigHelper.__get__('getGeneralPdpConfig');

        it('General pdp config should be returned', () => {
            const testCustomer = {
                isAuthenticated: () => true
            };

            const result = getGeneralPdpConfig(testCustomer);

            expect(result).to.be.an('object');
            expect(result).to.deep.equal({
                messages: {
                    CLIENT_REQUEST_TIMEOUT: '',
                    CLIENT_GATEWAY_NETWORK: '',
                    CLIENT_REQUEST_ERROR: '',
                    CLIENT_MISSING_GATEWAY_CONFIGURATION: ''
                },
                isBuyerAuthenticated: true,
                options: {
                    amount: 0
                }
            });
        });
    });

    describe('createGeneralButtonConfig', () => {
        const basket = {
            customer: {
                isAuthenticated: () => true
            }
        };

        it('General button config should be returned', () => {
            const result = buttonConfigHelper.createGeneralButtonConfig(basket);

            expect(result).to.be.an('object');
            expect(result).to.deep.equal({
                messages: {
                    CLIENT_REQUEST_TIMEOUT: '',
                    CLIENT_GATEWAY_NETWORK: '',
                    CLIENT_REQUEST_ERROR: '',
                    CLIENT_MISSING_GATEWAY_CONFIGURATION: ''
                },
                options: {
                    amount: 100,
                    currency: 'USD'
                },
                isBuyerAuthenticated: true
            });
        });
    });

    describe('createBraintreePayPalButtonConfig', () => {
        const basket = {
            customer: {
                isAuthenticated: () => true
            }
        };
        const customer = {
            isAuthenticated: () => true
        };
        let currentFlow = 'pdp';

        it('If PayPal button config was returned with vaultModeEnabled and flow is not billing', () => {
            prefs.paypalOrderIntent = true;

            buttonConfigHelper.createBraintreePayPalButtonConfig(basket, currentFlow, customer);
        });

        it('If PayPal button config was returned', () => {
            prefs.vaultMode = false;
            prefs.isSettle = true;
            prefs.paypalOrderIntent = false;
            prefs.paypalDisplayName = '';
            prefs.paypalBillingAgreementDescription = '';
            prefs.enableFundingList = ['en-fun', 'en-fun'];
            prefs.disableFundingList = ['dis-fun', 'dis-fun'];

            currentFlow = 'billing';

            buttonConfigHelper.createBraintreePayPalButtonConfig(basket, currentFlow);
        });
    });

    describe('createBraintreeApplePayButtonConfig', () => {
        const basket = {
            customer: {
                isAuthenticated: () => true
            }
        };
        const currentFlow = 'pdp';

        it('ApplePay button config should be returned', () => {
            const result = buttonConfigHelper.createBraintreeApplePayButtonConfig(basket, currentFlow);

            expect(result).to.be.an('object');
            expect(result.isRequiredBillingContactFields).to.be.true;
            expect(result.isRequiredShippingContactFields).to.be.false;
        });
    });

    describe('createBraintreeVenmoButtonConfig', () => {
        const basket = {
            customer: {
                isAuthenticated: () => true
            }
        };

        it('Venmo button config should be returned', () => {
            const result = buttonConfigHelper.createBraintreeVenmoButtonConfig(basket);

            expect(result).to.be.an('object');
            expect(result.paymentMethodName).to.equal('Venmo');
        });
    });

    describe('createBraintreeLocalPaymentMethodButtonConfig', () => {
        const basket = {
            customer: {
                isAuthenticated: () => true
            }
        };

        it('LPM button config should be returned', () => {
            const result = buttonConfigHelper.createBraintreeLocalPaymentMethodButtonConfig(basket);

            expect(result).to.be.an('object');
            expect(result.options.displayName).to.equal('');
        });
    });

    describe('createBraintreeGooglePayButtonConfig', () => {
        const basket = {
            customer: {
                isAuthenticated: () => true
            }
        };
        const flow = 'cart';

        it('GooglePay button config should be returned', () => {
            const result = buttonConfigHelper.createBraintreeGooglePayButtonConfig(basket, flow);

            expect(result).to.be.an('object');
            expect(result.options.isShippingAddressRequired).to.be.true;
        });
    });

    describe('createBraintreeSrcButtonConfig', () => {
        const basket = {
            customer: {
                isAuthenticated: () => true
            }
        };
        let flow = 'cart';

        it('SRC button config should be returned and displayName is returned', () => {
            const result = buttonConfigHelper.createBraintreeSrcButtonConfig(basket, flow);

            expect(result).to.be.an('object');
            expect(result.SRCImageUrl).to.equal('src-url');
            expect(result.options.displayName).to.equal('SRC');
        });

        it('SRC button config should be returned and displayName is not returned', () => {
            flow = 'billing';

            const result = buttonConfigHelper.createBraintreeSrcButtonConfig(basket, flow);

            expect(result).to.be.an('object');
            expect(result.SRCImageUrl).to.equal('src-url');
            expect(result.options).to.not.have.key('displayName');
        });
    });
});
