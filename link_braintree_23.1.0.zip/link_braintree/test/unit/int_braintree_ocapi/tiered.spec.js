const { int_braintree_ocapi: { tieredPath } } = require('../path.json');
const { expect } = require('chai');
const { it, describe } = require('mocha');

const priceTable = {
    getQuantities: () => ({
        toArray: () => [{ getValue: () => 500 }, { getValue: () => 1000 }]
    }),
    getPrice: (quantity) => quantity.getValue()
};

const proxyquire = require('proxyquire').noCallThru();

const TieredPrice = proxyquire(tieredPath, {
    '*/cartridge/models/price/default': function (value) {
        this.sales = {
            value: value
        };
        return this;
    }
});

describe('tiered file', () => {
    describe('TieredPrice', () => {
        it('if useSimplePrice is true', () => {
            const useSimplePrice = true;
            const TieredPriceModel = new TieredPrice(priceTable, useSimplePrice);

            expect(TieredPriceModel).to.be.deep.equal({
                startingFromPrice: {
                    sales: {
                        value: 500
                    }
                },
                tiers: [
                    {
                        price: {
                            sales: {
                                value: 500
                            }
                        },
                        quantity: 500
                    },
                    {
                        price: {
                            sales: {
                                value: 1000
                            }
                        },
                        quantity: 1000
                    }
                ],
                type: 'tiered',
                useSimplePrice: true
            });
        });

        it('if useSimplePrice is false', () => {
            const useSimplePrice = false;
            const TieredPriceModel = new TieredPrice(priceTable, useSimplePrice);

            expect(TieredPriceModel.useSimplePrice).to.be.false;
        });
    });
});
