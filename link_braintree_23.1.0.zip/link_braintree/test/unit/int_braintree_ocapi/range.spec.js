const { int_braintree_ocapi: { rangePath } } = require('../path.json');
const { expect } = require('chai');
const { it, describe } = require('mocha');

const proxyquire = require('proxyquire').noCallThru();

const RangePrice = proxyquire(rangePath, {
    '*/cartridge/models/price/default': function (value) {
        this.value = value;
        return this;
    }
});

describe('range file', () => {
    describe('RangePrice', () => {
        it('if two parameters in the constructor', () => {
            const RangePriceModel = new RangePrice('minPrice', 'maxPrice');

            expect(RangePriceModel).to.be.deep.equal({
                type: 'range',
                min: {
                    value: 'minPrice'
                },
                max: {
                    value: 'maxPrice'
                }
            });
        });
    });
});
