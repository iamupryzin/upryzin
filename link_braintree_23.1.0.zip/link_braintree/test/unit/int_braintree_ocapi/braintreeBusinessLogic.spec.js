const { int_braintree_ocapi: { braintreeBusinessLogicPath } } = require('../path.json');

const { expect } = require('chai');
const { it, describe, before, after } = require('mocha');
const { stub } = require('sinon');

const proxyquire = require('proxyquire').noCallThru();

const prefs = {
    tokenizationKey: 'tokenizationKey'
};

const error = stub();
const getMerchantAccountID = stub();
const createClientToken = stub();
const getCustomerId = stub();
const createCustomer = stub();
const findCustomer = stub();
const vaultPaymentMethod = stub();
const deletePaymentMethodFromVault = stub();
const searchTransactionsByIds = stub();

const braintreeBusinessLogic = proxyquire(braintreeBusinessLogicPath, {
    '~/cartridge/scripts/braintree/helpers/paymentHelper': {
        getMerchantAccountID,
        getLogger: () => ({ error })
    },
    '~/cartridge/scripts/braintree/helpers/customerHelper': {
        getCustomerId
    },
    '~/cartridge/scripts/braintree/payment/processor/processorHelper': {
        createGuestCustomerData: () => {}
    },
    '~/cartridge/scripts/util/braintreeConstants': {
        LEGACY_ID_TYPE_TRANSACTION: 'TRANSACTION'
    },
    '~/cartridge/models/btGraphQLSdk': function () {
        return {
            createClientToken,
            findCustomer,
            vaultPaymentMethod,
            createCustomer,
            deletePaymentMethodFromVault,
            searchTransactionsByIds,
            legacyIdConverter: () => 'id'
        };
    },
    '~/cartridge/config/braintreePreferences': prefs
});

describe('braintreeBusinessLogic file', () => {
    describe('getClientToken', () => {
        const testCustomer = {};
        const currency = 'USD';

        before(() => {
            createClientToken.withArgs({ accId: 'accId', btCustomerId: 'btCustomerId' }).returns('specific-client-token');
            createClientToken.withArgs({ accId: 'accId' }).returns('client-token');

            getCustomerId.returns('btCustomerId');
        });

        after(() => {
            getMerchantAccountID.reset();
            createClientToken.reset();
            getCustomerId.reset();
            error.reset();
        });

        it('If tokenizationKey was returned', () => {
            const result = braintreeBusinessLogic.getClientToken();

            expect(result).to.be.an('string');
            expect(result).to.equal('tokenizationKey');
        });

        it('If error was thrown and client token was not returned', () => {
            prefs.tokenizationKey = '';
            getMerchantAccountID.throws(new Error());

            expect(() => braintreeBusinessLogic.getClientToken(testCustomer, currency)).to.throw(Error);
        });

        it('If customer is authenticated and specific client token was returned', () => {
            testCustomer.authenticated = true;
            getMerchantAccountID.returns('accId');

            const result = braintreeBusinessLogic.getClientToken(testCustomer, currency);

            expect(result).to.be.an('string');
            expect(result).to.equal('specific-client-token');
        });

        it('If customer is not authenticated and client token was returned', () => {
            testCustomer.authenticated = false;

            const result = braintreeBusinessLogic.getClientToken(testCustomer, currency);

            expect(result).to.be.an('string');
            expect(result).to.equal('client-token');
        });
    });

    describe('getBraintreeCustomer', () => {
        const customer = {};

        before(() => {
            getCustomerId.returns('id');
        });

        after(() => {
            findCustomer.reset();
            getCustomerId.reset();

            error.reset();
        });

        it('If error was thrown and response returned with error', () => {
            findCustomer.throws(new Error());

            const result = braintreeBusinessLogic.getBraintreeCustomer(customer);

            expect(result).to.be.an('object');
            expect(result.error).to.be.true;
        });

        it('If response returned successfully', () => {
            findCustomer.returns({});

            const result = braintreeBusinessLogic.getBraintreeCustomer(customer);

            expect(result).to.be.an('object');
            expect(result.error).to.be.false;
            expect(result.customerData).to.deep.equal({});
        });
    });

    describe('createPaymentMethodOnBraintreeSide', () => {
        const nonce = '';

        before(() => {
            getCustomerId.returns('id');
        });

        after(() => {
            vaultPaymentMethod.reset();
            getCustomerId.reset();

            error.reset();
        });

        it('If error was thrown and response returned with error', () => {
            vaultPaymentMethod.throws(new Error('Error'));

            const result = braintreeBusinessLogic.createPaymentMethodOnBraintreeSide(nonce);

            expect(result).to.be.an('object');
            expect(result.error).to.equal('Error');
        });

        it('If response returned successfully', () => {
            vaultPaymentMethod.returns({});

            const result = braintreeBusinessLogic.createPaymentMethodOnBraintreeSide(nonce);

            expect(result).to.be.an('object');
            expect(result).to.deep.equal({});
        });
    });

    describe('createPaymentMethod', () => {
        const braintreePaymentMethodNonce = 'nonce';
        const order = {};

        const originalCustomer = customer;

        before(() => {
            getCustomerId.returns('registered-id');
            createCustomer.returns('id');

            vaultPaymentMethod.withArgs({ customerId: 'registered-id', paymentMethodNonce: 'nonce' }).returns({ paymentMethod: { legacyId: 'r-id' } });
            vaultPaymentMethod.withArgs({ customerId: 'id', paymentMethodNonce: 'nonce' }).returns({ paymentMethod: { legacyId: 'id' } });
        });

        after(() => {
            vaultPaymentMethod.reset();
            createCustomer.reset();
            getCustomerId.reset();

            customer = originalCustomer;
        });

        it('If customer is registered and payment method was returned', () => {
            customer.isRegistered = () => true;

            const result = braintreeBusinessLogic.createPaymentMethod(braintreePaymentMethodNonce, order);

            expect(result).to.be.a('string');
            expect(result).to.equal('r-id');
        });

        it('If customer is not registered and payment method was returned', () => {
            customer.isRegistered = () => false;

            const result = braintreeBusinessLogic.createPaymentMethod(braintreePaymentMethodNonce, order);

            expect(result).to.be.a('string');
            expect(result).to.equal('id');
        });
    });

    describe('deletePaymentMethod', () => {
        const creditCardToken = 'token';

        after(() => {
            deletePaymentMethodFromVault.reset();
        });

        afterEach(() => {
            error.reset();
        });

        it('If error appeared and was logged', () => {
            deletePaymentMethodFromVault.throws(new Error());

            braintreeBusinessLogic.deletePaymentMethod(creditCardToken);

            expect(error.calledOnce).to.be.true;
        });

        it('If payment method successfully deleted', () => {
            deletePaymentMethodFromVault.returns();

            braintreeBusinessLogic.deletePaymentMethod(creditCardToken);

            expect(error.calledOnce).to.be.false;
        });
    });

    describe('createCustomerOnBraintreeSide', () => {
        const originalCustomer = customer;
        const testCustomer = {
            getProfile: () => ({
                firstName: 'firstName',
                lastName: 'lastName',
                email: 'email',
                phone: 'phone',
                custom: {}
            })
        };

        after(() => {
            customer = originalCustomer;

            createCustomer.reset();
            error.reset();
        });

        it('If error was returned', () => {
            createCustomer.throws(new Error('Error'));

            const result = braintreeBusinessLogic.createCustomerOnBraintreeSide(testCustomer);

            expect(result).to.be.an('object');
            expect(result.error).to.equal('Error');
            expect(error.calledOnce).to.be.true;
        });

        it('If customer was successfully created', () => {
            createCustomer.returns();

            expect(braintreeBusinessLogic.createCustomerOnBraintreeSide(testCustomer)).to.be.true;
        });
    });

    describe('searchTransactionsByIds', () => {
        const orders = { id: {} };

        after(() => {
            searchTransactionsByIds.reset();
        });

        it('If transactions was successfully returned', () => {
            searchTransactionsByIds.returns({ transaction: 'transaction' });

            const result = braintreeBusinessLogic.searchTransactionsByIds(orders);

            expect(result).to.be.an('object');
            expect(result).to.deep.equal({ transaction: 'transaction' });
        });

        it('If error was thrown', () => {
            searchTransactionsByIds.throws(new Error());

            const result = braintreeBusinessLogic.searchTransactionsByIds(orders);

            expect(result).to.be.an('object');
            expect(result).to.deep.equal({});
        });
    });
});
