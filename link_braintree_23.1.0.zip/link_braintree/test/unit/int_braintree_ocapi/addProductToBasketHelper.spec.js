const { int_braintree_ocapi: { addProductToBasketHelperPath } } = require('../path.json');
const { expect } = require('chai');
const { it, describe, after, before } = require('mocha');
const { stub } = require('sinon');

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const getDefaultCustomerPaypalPaymentInstrument = stub();
const getPreferredAddress = stub();
const getDefaultCustomerShippingAddress = stub();

const basket = {
    customer: {
        getAddressBook: () => ({
            getPreferredAddress
        })
    }
};

const proxyquire = require('proxyquire').noCallThru();

const braintreePreferences = {
    paymentMethods: {
        BRAINTREE_PAYPAL: {
            isActive: true
        },
        BRAINTREE_VENMO: {
            isActive: true
        },
        BRAINTREE_APPLEPAY: {
            isActive: true
        },
        BRAINTREE_CREDIT: {
            isActive: true
        },
        BRAINTREE_LOCAL: {
            isActive: true
        },
        BRAINTREE_GOOGLEPAY: {
            isActive: true
        },
        BRAINTREE_SRC: {
            isActive: true
        }
    },
    applepayVisibilityOnCart: true,
    googlepayVisibilityOnCart: true,
    srcVisibilityOnCart: true
};

const paymentHelper = {
    isPaypalButtonEnabled: () => true,
    getApplicableLocalPaymentMethods: () => {},
    getApplicablePaymentMethods: () => {}
};

const buttonConfigHelper = {
    createBraintreePayPalButtonConfig: () => 'PayPalButtonConfig',
    createBraintreeVenmoButtonConfig: () => 'VenmoButtonConfig',
    createBraintreeApplePayButtonConfig: () => 'ApplePayButtonConfig',
    createBraintreeGooglePayButtonConfig: () => 'GooglePayButtonConfig',
    createBraintreeSrcButtonConfig: () => 'SrcButtonConfig',
    createBraintreeLocalPaymentMethodButtonConfig: () => 'LocalPaymentMethodButtonConfig'
};

const hooksHelper = {
    createHostedFieldsConfig: () => 'HostedFieldsConfig'
};

const Locale = {
    getLocale: () => ({
        country: 'UA'
    })
};

const customerHelper = {
    getDefaultCustomerPaypalPaymentInstrument,
    getDefaultCustomerShippingAddress
};

const addProductToBasketHelper = proxyquire(addProductToBasketHelperPath, {
    'dw/util/Locale': Locale,
    '~/cartridge/scripts/braintree/helpers/paymentHelper': paymentHelper,
    '~/cartridge/scripts/braintree/helpers/customerHelper': customerHelper,
    '~/cartridge/scripts/braintree/helpers/buttonConfigHelper': buttonConfigHelper,
    '~/cartridge/scripts/braintree/helpers/hooksHelper': hooksHelper,
    '~/cartridge/config/braintreePreferences': braintreePreferences
});

describe('addProductToBasketHelper file', () => {
    describe('processPayPalConfigs', () => {
        const processPayPalConfigs = addProductToBasketHelper.__get__('processPayPalConfigs');

        after(() => {
            braintreePreferences.paymentMethods.BRAINTREE_PAYPAL.isActive = true;

            getDefaultCustomerPaypalPaymentInstrument.reset();
            getPreferredAddress.reset();
            getDefaultCustomerShippingAddress.reset();
        });

        it('if defaultPayPalPI is empty', () => {
            expect(processPayPalConfigs(basket)).to.be.deep.equal({
                payPalButtonConfig: 'PayPalButtonConfig',
                dafaultPaypalShippingAddress: null
            });
        });

        it('if defaultPaypalAddress is empty', () => {
            getDefaultCustomerPaypalPaymentInstrument.returns('defaultPayPalPI');

            expect(processPayPalConfigs(basket)).to.be.deep.equal({
                payPalButtonConfig: 'PayPalButtonConfig',
                dafaultPaypalShippingAddress: null
            });
        });

        it('if defaultPaypalAddress is not empty', () => {
            getPreferredAddress.returns('preferredAddress');
            getDefaultCustomerShippingAddress.returns('ShippingAddress');

            expect(processPayPalConfigs(basket)).to.be.deep.equal({
                payPalButtonConfig: 'PayPalButtonConfig',
                dafaultPaypalShippingAddress: 'ShippingAddress'
            });
        });

        it('if BM payment methods is not active', () => {
            braintreePreferences.paymentMethods.BRAINTREE_PAYPAL.isActive = false;

            expect(processPayPalConfigs(basket)).to.be.deep.equal({
                payPalButtonConfig: null,
                dafaultPaypalShippingAddress: null
            });
        });
    });

    describe('getMiniCartPageConfigs', () => {
        before(() => {
            addProductToBasketHelper.__set__('processPayPalConfigs', () => 'called');
        });

        after(() => {
            addProductToBasketHelper.__ResetDependency__('processPayPalConfigs');
        });


        it('must call processPayPalConfigs function', () => {
            expect(addProductToBasketHelper.getMiniCartPageConfigs()).to.be.equal('called');
        });
    });

    describe('getCheckoutPageConfigs', () => {
        after(() => {
            braintreePreferences.paymentMethods.BRAINTREE_PAYPAL.isActive = true;
            braintreePreferences.paymentMethods.BRAINTREE_VENMO.isActive = true;
            braintreePreferences.paymentMethods.BRAINTREE_APPLEPAY.isActive = true;
            braintreePreferences.paymentMethods.BRAINTREE_CREDIT.isActive = true;
            braintreePreferences.paymentMethods.BRAINTREE_LOCAL.isActive = true;
            braintreePreferences.paymentMethods.BRAINTREE_GOOGLEPAY.isActive = true;
            braintreePreferences.paymentMethods.BRAINTREE_SRC.isActive = true;
        });

        it('if all paymentMethods are active', () => {
            expect(addProductToBasketHelper.getCheckoutPageConfigs(basket)).to.be.deep.equal({
                applePayButtonConfig: 'ApplePayButtonConfig',
                googlepayButtonConfig: 'GooglePayButtonConfig',
                hostedFieldsConfig: 'HostedFieldsConfig',
                isActiveLpmPaymentOptions: true,
                isSettle: undefined,
                lpmButtonConfig: 'LocalPaymentMethodButtonConfig',
                lpmPaymentOptions: undefined,
                payPalButtonConfig: 'PayPalButtonConfig',
                srcButtonConfig: 'SrcButtonConfig',
                venmoButtonConfig: 'VenmoButtonConfig'
            });
        });

        it('if all paymentMethods are inactive', () => {
            braintreePreferences.paymentMethods.BRAINTREE_PAYPAL.isActive = false;
            braintreePreferences.paymentMethods.BRAINTREE_VENMO.isActive = false;
            braintreePreferences.paymentMethods.BRAINTREE_APPLEPAY.isActive = false;
            braintreePreferences.paymentMethods.BRAINTREE_CREDIT.isActive = false;
            braintreePreferences.paymentMethods.BRAINTREE_LOCAL.isActive = false;
            braintreePreferences.paymentMethods.BRAINTREE_GOOGLEPAY.isActive = false;
            braintreePreferences.paymentMethods.BRAINTREE_SRC.isActive = false;

            expect(addProductToBasketHelper.getCheckoutPageConfigs(basket)).to.be.deep.equal({
                applePayButtonConfig: null,
                googlepayButtonConfig: null,
                hostedFieldsConfig: null,
                isActiveLpmPaymentOptions: null,
                isSettle: null,
                lpmButtonConfig: null,
                lpmPaymentOptions: null,
                payPalButtonConfig: null,
                srcButtonConfig: null,
                venmoButtonConfig: null
            });
        });
    });

    describe('getCartPageConfigs', () => {
        before(() => {
            addProductToBasketHelper.__set__('processPayPalConfigs', () => {});
        });

        after(() => {
            braintreePreferences.paymentMethods.BRAINTREE_APPLEPAY.isActive = true;
            braintreePreferences.paymentMethods.BRAINTREE_GOOGLEPAY.isActive = true;
            braintreePreferences.paymentMethods.BRAINTREE_SRC.isActive = true;

            addProductToBasketHelper.__ResetDependency__('processPayPalConfigs');
        });

        it('if all paymentMethods are active and VisibilityOnCart is true', () => {
            expect(addProductToBasketHelper.getCartPageConfigs(basket)).to.be.deep.equal({
                applePayButtonConfig: 'ApplePayButtonConfig',
                googlepayButtonConfig: 'GooglePayButtonConfig',
                srcButtonConfig: 'SrcButtonConfig'
            });
        });

        it('if all paymentMethods are inactive', () => {
            braintreePreferences.paymentMethods.BRAINTREE_APPLEPAY.isActive = false;
            braintreePreferences.paymentMethods.BRAINTREE_GOOGLEPAY.isActive = false;
            braintreePreferences.paymentMethods.BRAINTREE_SRC.isActive = false;

            expect(addProductToBasketHelper.getCartPageConfigs(basket)).to.be.deep.equal({
                applePayButtonConfig: null,
                googlepayButtonConfig: null,
                srcButtonConfig: null
            });
        });
    });
});
