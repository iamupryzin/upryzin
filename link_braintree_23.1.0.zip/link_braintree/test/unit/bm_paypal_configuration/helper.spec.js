const { bm_paypal_configuration: { helperPath } } = require('../path.json');
const { expect } = require('chai');
const { it, describe } = require('mocha');

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const proxyquire = require('proxyquire').noCallThru();

const customPreference = '"customPreference"';

const helper = proxyquire(helperPath, {});

describe('helper file', () => {
    describe('parseCustomPreference', () => {
        it('if there is customPreference', () => {
            expect(helper.parseCustomPreference(customPreference)).to.be.equal('customPreference');
        });

        it('if there is no customPreference', () => {
            expect(helper.parseCustomPreference()).to.be.deep.equal({});
        });
    });
});
