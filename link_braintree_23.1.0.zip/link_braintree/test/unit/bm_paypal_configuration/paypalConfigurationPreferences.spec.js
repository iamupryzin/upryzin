const { bm_paypal_configuration: { paypalConfigurationPreferencesPath } } = require('../path.json');
const { expect } = require('chai');
const { it, describe } = require('mocha');

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const proxyquire = require('proxyquire').noCallThru();

const paypalConfigurationPreferences = proxyquire(paypalConfigurationPreferencesPath, {});

describe('paypalConfigurationPreferences file', () => {
    describe('getPaypalConfigurationPreferences', () => {
        it('it must have googlePaySDK url', () => {
            expect(paypalConfigurationPreferences).to.have.property('googlePaySDK');
            expect(paypalConfigurationPreferences.googlePaySDK).to.be.equal('https://pay.google.com/gp/p/js/pay.js');
        });

        it('it must have applePayButtonSdk url', () => {
            expect(paypalConfigurationPreferences).to.have.property('applePayButtonSdk');
            expect(paypalConfigurationPreferences.applePayButtonSdk).to.be.equal('https://applepay.cdn-apple.com/jsapi/v1/apple-pay-sdk.js');
        });
    });
});
