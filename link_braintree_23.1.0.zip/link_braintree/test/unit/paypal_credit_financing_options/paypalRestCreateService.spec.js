const { expect } = require('chai');
const { paypal_credit_financing_options: { paypalRestCreateServicePath } } = require('../path.json');
const { stub } = require('sinon');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');

const getCredential = stub();
const setURL = stub();
const setRequestMethod = stub();
const addHeader = stub();
const addParam = stub();

const service = {
    setURL: setURL,
    setRequestMethod: setRequestMethod,
    addHeader: addHeader,
    addParam: addParam,
    getConfiguration: () => ({
        getCredential: getCredential
    })
};

const LocalServiceRegistry = {
    createService: (serviceName, serviceConfig) => {
        return {
            serviceName: serviceName,
            serviceConfig: serviceConfig
        };
    }
};

const paypalRestCreateService = proxyquire(paypalRestCreateServicePath, {
    'dw/svc': {
        LocalServiceRegistry
    },
    'dw/system/Transaction': dw.system.Transaction
});

describe('paypalRestCreateService file', () => {
    describe('paypalRestCreateService export', () => {
        it('response type should be equal -> object', () => {
            expect(paypalRestCreateService()).to.be.a('object');
        });
        it('response object should consist property -> createRequest', () => {
            expect(paypalRestCreateService().serviceConfig).has.property('createRequest');
        });
        it('response property createRequest type should be equal -> function', () => {
            expect(paypalRestCreateService().serviceConfig.createRequest).to.be.a('function');
        });
        it('response object should consist property -> parseResponse', () => {
            expect(paypalRestCreateService().serviceConfig).has.property('parseResponse');
        });
        it('response property parseResponse type should be equal -> function', () => {
            expect(paypalRestCreateService().serviceConfig.parseResponse).to.be.a('function');
        });
        it('response object should consist property -> getRequestLogMessage', () => {
            expect(paypalRestCreateService().serviceConfig).has.property('getRequestLogMessage');
        });
        it('response property getRequestLogMessage type should be equal -> function', () => {
            expect(paypalRestCreateService().serviceConfig.getRequestLogMessage).to.be.a('function');
        });
        it('response object should consist property -> getResponseLogMessage', () => {
            expect(paypalRestCreateService().serviceConfig).has.property('getResponseLogMessage');
        });
        it('response property getResponseLogMessage type should be equal -> function', () => {
            expect(paypalRestCreateService().serviceConfig.getResponseLogMessage).to.be.a('function');
        });
    });

    describe('getServiceConfig', () => {
        const getServiceConfig = paypalRestCreateService.__get__('getServiceConfig');
        const serviceConfig = getServiceConfig();

        describe('createRequest', () => {
            const data = {
                val1: 'val1'
            };
            const paypalApi = {
                oauth2: {
                    getToken: () => ({
                        expires_in: 10
                    })
                }
            };

            let contentType = '';
            let url = 'https://test.com/';

            const mySvc = { ServiceCredential: function () {
                this.getURL = () => url;
                this.custom = {
                    BRAINTREE_PAYPAL_RESTAPI_TempToken: 'TempToken',
                    BRAINTREE_PAYPAL_RESTAPI_TempTokenExpiredTime: Date.now() + 100000
                };
                return this;
            } };

            const originalDW = dw;

            beforeEach(() => {
                Object.assign(dw, { svc: mySvc });
            });

            after(() => {
                dw = originalDW;
            });

            it('if credential  is not instanceof dw.svc.ServiceCredential', () => {
                getCredential.returns({});

                expect(() => serviceConfig.createRequest(service)).to.throw(Error, 'Credential for int_paypal.http.rest.credit is not set. Create and set cridential BM > Administration > Operations > Services');
            });

            it('if contentType is application/x-www-form-urlencoded', () => {
                contentType = 'application/x-www-form-urlencoded';
                getCredential.returns(new dw.svc.ServiceCredential());

                expect(serviceConfig.createRequest(service, {}, 'oauth2/token', data, contentType)).to.be.equal('');
            });

            it('if contentType is undefined', () => {
                contentType = 'undefined';
                getCredential.returns(new dw.svc.ServiceCredential());

                expect(serviceConfig.createRequest(service, {}, '', data, contentType, {}, false)).to.be.equal('{"val1":"val1"}');
            });

            it('if isUpadateBearToken is true', () => {
                contentType = 'undefined';
                getCredential.returns(new dw.svc.ServiceCredential());

                expect(serviceConfig.createRequest(service, {}, '', data, contentType, paypalApi, true)).to.be.equal('{"val1":"val1"}');
            });

            it('if isUpadateBearToken is true', () => {
                getCredential.returns(new dw.svc.ServiceCredential());

                url = 'https://test.com';

                expect(serviceConfig.createRequest(service, {}, '', data, contentType, paypalApi, true)).to.be.equal('{"val1":"val1"}');
            });
        });

        describe('parseResponse', () => {
            const httpClient = {
                getText: () => '"text"'
            };

            it('must retrun parsered text', () => {
                expect(serviceConfig.parseResponse(service, httpClient)).to.be.equal('text');
            });
        });

        describe('getRequestLogMessage', () => {
            it('must retrun parsered text', () => {
                expect(serviceConfig.getRequestLogMessage({ log: 'message' })).to.be.deep.equal({ log: 'message' });
            });
        });

        describe('getResponseLogMessage', () => {
            it('must retrun response text', () => {
                expect(serviceConfig.getResponseLogMessage({ text: 'text' })).to.be.equal('text');
            });
        });
    });
});
