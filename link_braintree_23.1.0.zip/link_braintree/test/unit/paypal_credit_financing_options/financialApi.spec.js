const { expect } = require('chai');
const { paypal_credit_financing_options: { financialApiPath } } = require('../path.json');
const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');

const financialApi = proxyquire(financialApiPath, {
    './paypalRestApi': {
        call: (type, url, data) => {
            return {
                requestType: type,
                requestUrl: 'https://developer.paypal.com/docs/limited-release/financing-options/api/' + url,
                requestData: data
            };
        }
    }
});

const responseObject = {
    requestType: 'POST',
    requestUrl: 'https://developer.paypal.com/docs/limited-release/financing-options/api/credit/calculated-financing-options',
    requestData: {}
};

describe('financialApi file', () => {
    describe('getCalculatedFinancingOptions', () => {
        const data = {};
        it('response type should be equal -> object', () => {
            expect(financialApi.getCalculatedFinancingOptions(data)).to.be.a('object');
        });
        it('response object should be deep equal -> responseObject', () => {
            expect(financialApi.getCalculatedFinancingOptions(data)).deep.equal(responseObject);
        });
    });
});
