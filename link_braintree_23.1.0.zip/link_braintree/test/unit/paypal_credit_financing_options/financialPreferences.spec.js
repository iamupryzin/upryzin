const { expect } = require('chai');
const { paypal_credit_financing_options: { financialPreferencesPath } } = require('../path.json');

require('dw-api-mock/demandware-globals');

let campaignResponse;
const resposeObj = {
    bannerSize: '190x100',
    publisherID: 'PP_Merchant_Publisher_ID',
    isActive: 'PP_ShowCreditFinancialBanners'
};

const financialPreferences = require('proxyquire').noCallThru()(financialPreferencesPath, {
    'dw/system/Site': {
        current: {
            getCustomPreferenceValue: ccID => ccID
        }
    },
    'dw/campaign/PromotionMgr': {
        getCampaign: () => campaignResponse
    }
});

describe('financialPreferences', () => {
    describe('getCreditBannerData', () => {
        before(() => {
            campaignResponse = {
                isActive: () => true
            };
        });
        it('response type should be equal -> object', () => {
            expect(financialPreferences).to.be.a('object');
        });
        it('response should be deep equal -> responseObj', () => {
            expect(financialPreferences).deep.equal(resposeObj);
        });
    });
});

