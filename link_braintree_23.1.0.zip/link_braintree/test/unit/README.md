# Braintree unit test

## Before runinng
To run integration test node version 8+ required.

Also you have to have access to `git+ssh://git@github.com/SalesforceCommerceCloud/dw-api-mock.git` repo

Install all dependencies from package.json in the root folder with `npm install` command

## Test run
To run test use: `npm run test`

## Test lint
To run linter for test files use: `npm run lint:test`
