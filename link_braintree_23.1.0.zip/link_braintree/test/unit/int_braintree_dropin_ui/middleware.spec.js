const { int_braintree_dropin_ui: { middlewarePath } } = require('../path.json');

const { expect } = require('chai');
const { it, describe, before, after } = require('mocha');
const { stub } = require('sinon');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const isPaypalButtonEnabled = stub();

const middleware = proxyquire(middlewarePath, {
    'dw/order/BasketMgr': dw.order.BasketMgr,
    '*/cartridge/scripts/braintree/helpers/paymentHelper': {
        isPaypalButtonEnabled
    },
    '*/cartridge/config/braintreeConstants': {
        PAGE_FLOW_PDP: 'PAGE_FLOW_PDP',
        PAGE_FLOW_MINICART: 'PAGE_FLOW_MINICART'
    }
});

describe('middleware file', () => {
    const emit = stub();
    const req = {};
    let res = {};

    describe('isBasketExist', () => {
        const next = stub();

        before(() => {
            stub(dw.order.BasketMgr, 'getCurrentBasket');
        });

        after(() => {
            dw.order.BasketMgr.getCurrentBasket.restore();
        });

        it('response should be route:Complete emitted if there\'s no basket', () => {
            dw.order.BasketMgr.getCurrentBasket.returns(null);

            expect(middleware.isBasketExist.call({ emit }, req, res, next)).to.be.undefined;
            expect(emit.calledWith('route:Complete', req, res)).to.be.true;
        });

        it('response should be next method called if there\'s basket', () => {
            dw.order.BasketMgr.getCurrentBasket.returns({});

            expect(middleware.isBasketExist(req, res, next)).to.be.undefined;
            expect(next.calledOnce).to.be.true;
        });
    });

    describe('isPayPalEnabledOnPdp', () => {
        const next = stub();

        after(() => {
            isPaypalButtonEnabled.reset();
        });

        it('response should be route:Complete emitted if Paypal button isn\'t enabled on PDP', () => {
            isPaypalButtonEnabled.returns(false);

            expect(middleware.isPayPalEnabledOnPdp.call({ emit }, req, res, next)).to.be.undefined;
            expect(emit.calledWith('route:Complete', req, res)).to.be.true;
        });

        it('response should be next method called if Paypal button is enabled on PDP', () => {
            isPaypalButtonEnabled.returns(true);

            expect(middleware.isPayPalEnabledOnPdp(req, res, next)).to.be.undefined;
            expect(next.calledOnce).to.be.true;
        });
    });

    describe('isSetProductType', () => {
        const next = stub();

        after(() => {
            res = {};
        });

        it('response should be route:Complete emitted if res.getViewData().product.individualProducts isn\'t empty', () => {
            res = { getViewData: () => ({ product: { individualProducts: {} } }) };

            expect(middleware.isSetProductType.call({ emit }, req, res, next)).to.be.undefined;
            expect(emit.calledWith('route:Complete', req, res)).to.be.true;
        });

        it('response should be next method called if res.getViewData().product.individualProducts is empty', () => {
            res = { getViewData: () => ({ product: { individualProducts: null } }) };

            expect(middleware.isSetProductType(req, res, next)).to.be.undefined;
            expect(next.calledOnce).to.be.true;
        });
    });

    describe('isPayPalEnabledOnMiniCart', () => {
        const next = stub();

        after(() => {
            isPaypalButtonEnabled.reset();
        });

        it('response should be route:Complete emitted if Paypal button isn\'t enabled on MiniCart', () => {
            isPaypalButtonEnabled.returns(false);

            expect(middleware.isPayPalEnabledOnMiniCart.call({ emit }, req, res, next)).to.be.undefined;
            expect(emit.calledWith('route:Complete', req, res)).to.be.true;
        });

        it('response should be next method called if Paypal button is enabled on MiniCart', () => {
            isPaypalButtonEnabled.returns(true);

            expect(middleware.isPayPalEnabledOnMiniCart(req, res, next)).to.be.undefined;
            expect(next.calledOnce).to.be.true;
        });
    });
});
