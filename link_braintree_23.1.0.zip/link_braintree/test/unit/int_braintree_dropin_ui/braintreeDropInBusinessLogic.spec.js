const { int_braintree_dropin_ui: { braintreeDropInBusinessLogicPath } } = require('../path.json');

const { expect } = require('chai');
const { it, describe, before, after } = require('mocha');
const { stub } = require('sinon');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const getBraintreeCustomer = stub();

const braintreeDropInBusinessLogic = proxyquire(braintreeDropInBusinessLogicPath, {
    '*/cartridge/scripts/braintree/braintreeAPI/braintreeBusinessLogic': {
        getBraintreeCustomer,
        deletePaymentMethod: (paymentInstrumentToDelete) => paymentInstrumentToDelete
    },
    '*/cartridge/config/braintreeConstants': {
        TRANSACTION_STATUS_SUBMITTED_FOR_SETTLEMENT: 'TRANSACTION_STATUS_SUBMITTED_FOR_SETTLEMENT',
        TRANSACTION_STATUS_SETTLED: 'TRANSACTION_STATUS_SETTLED',
        TRANSACTION_STATUS_AUTHORIZED: 'TRANSACTION_STATUS_AUTHORIZED',
        PAYMENT_METHOD_CREDIT_CARD: 'PAYMENT_METHOD_CREDIT_CARD'
    }
});

describe('braintreeDropInBusinessLogic file', () => {
    describe('getCustomerPaymentMethods', () => {
        after(() => {
            getBraintreeCustomer.reset();
        });

        it('response should be null if there\'s an error', () => {
            getBraintreeCustomer.returns({ error: true });

            expect(braintreeDropInBusinessLogic.getCustomerPaymentMethods()).to.be.null;
        });

        it('response should be an array of objects', () => {
            getBraintreeCustomer.returns({ customerData: [{ node: { paymentMethods: [{}] } }] });

            expect(braintreeDropInBusinessLogic.getCustomerPaymentMethods()).to.deep.equal([{}]);
        });
    });

    describe('getAuthorizedAndPartiallyCapturedOrders', () => {
        const getAuthorizedAndPartiallyCapturedOrders = braintreeDropInBusinessLogic.__get__('getAuthorizedAndPartiallyCapturedOrders');
        const getPaymentInstruments = () => ['PAYMENT_METHOD_CREDIT_CARD'];
        const responseObj = [{
            custom: { braintreePaymentStatus: 'TRANSACTION_STATUS_AUTHORIZED' },
            getPaymentInstruments
        }, {
            custom: { braintreePaymentStatus: 'TRANSACTION_STATUS_SETTLED', leftToSettle: true },
            getPaymentInstruments
        }];

        before(() => {
            customer.orderHistory = { orders: {
                asList: () => ({
                    toArray: () => [{
                        custom: { braintreePaymentStatus: 'TRANSACTION_STATUS_AUTHORIZED' },
                        getPaymentInstruments
                    }, {
                        custom: { braintreePaymentStatus: 'TRANSACTION_STATUS_SETTLED', leftToSettle: true },
                        getPaymentInstruments
                    }, {
                        custom: { braintreePaymentStatus: 'TRANSACTION_STATUS_SUBMITTED_FOR_SETTLEMENT', leftToSettle: false },
                        getPaymentInstruments
                    }]
                })
            } };
        });

        after(() => {
            customer.orderHistory = null;
        });

        it('response should be an array of payment intruments with status AUTHORIZED or SETTLED/SUBMITTED FOR SETTLEMENT & leftToSettle property set to true', () => {
            expect(getAuthorizedAndPartiallyCapturedOrders()).to.deep.equal(responseObj);
        });
    });

    describe('paymentMethodRemovalVerification', () => {
        after(() => {
            customer.registered = false;
            customer.orderHistory = null;
            braintreeDropInBusinessLogic.__ResetDependency__('getAuthorizedAndPartiallyCapturedOrders');
        });

        it('response should be true if customer isn\'t registered', () => {
            expect(braintreeDropInBusinessLogic.paymentMethodRemovalVerification()).to.be.true;
        });

        it('response should be true if customer\'s order count is 0', () => {
            customer.registered = true;
            customer.orderHistory = { getOrderCount: () => 0 };

            expect(braintreeDropInBusinessLogic.paymentMethodRemovalVerification()).to.be.true;
        });

        it('response should be false if getAuthorizedAndPartiallyCapturedOrders returns not empty array', () => {
            customer.orderHistory = { getOrderCount: () => 1 };
            braintreeDropInBusinessLogic.__set__('getAuthorizedAndPartiallyCapturedOrders', () => [{}]);

            expect(braintreeDropInBusinessLogic.paymentMethodRemovalVerification()).to.be.false;
        });
    });

    describe('deleteDuplicateCreditCard', () => {
        const profile = {};
        const duplicateCCDetails = {
            lastFour: '1111',
            expirationMonth: '12',
            expirationYear: '2024'
        };
        const responseObj = { payment: { creditCardToken: '0002', createdAt: 'Dec 28 2020' } };

        before(() => {
            getBraintreeCustomer.returns({
                customerData: [{
                    node: {
                        paymentMethods: {
                            edges: [
                                {
                                    node: {
                                        details: { last4: '1111', expirationMonth: '12', expirationYear: '2024' },
                                        legacyId: '0001',
                                        createdAt: 'Dec 12 2020'
                                    }
                                }, {
                                    node: {
                                        details: { last4: '1111', expirationMonth: '12', expirationYear: '2024' },
                                        legacyId: '0002',
                                        createdAt: 'Dec 28 2020'
                                    }
                                }, {
                                    node: {
                                        details: { last4: '1111', expirationMonth: '12', expirationYear: '2024' },
                                        legacyId: '0003',
                                        createdAt: 'Dec 25 2020'
                                    }
                                }
                            ]
                        }
                    }
                }]
            });
        });

        after(() => {
            getBraintreeCustomer.reset();
        });

        it('response should equal responseObj', () => {
            expect(braintreeDropInBusinessLogic.deleteDuplicateCreditCard(profile, duplicateCCDetails)).to.deep.equal(responseObj);
        });
    });
});
