const { int_braintree_dropin_ui: { helperPath } } = require('../path.json');

const { expect } = require('chai');
const { it, describe, before, after } = require('mocha');
const { stub } = require('sinon');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const getCustomerPaymentMethods = stub();
const BRAINTREE_PAYPAL = { isActive: true };
const BRAINTREE_GOOGLEPAY = { isActive: true };
const BRAINTREE_APPLEPAY = { isActive: true };
const BRAINTREE_VENMO = { isActive: true };

const helper = proxyquire(helperPath, {
    'dw/web/URLUtils': dw.web.URLUtils,
    'dw/web/Resource': dw.web.Resource,
    'dw/order/BasketMgr': dw.order.BasketMgr,
    '*/cartridge/config/braintreePreferences': {
        paymentMethods: {
            BRAINTREE_PAYPAL,
            BRAINTREE_GOOGLEPAY,
            BRAINTREE_APPLEPAY,
            BRAINTREE_VENMO
        },
        googlepayVisibilityOnCart: true,
        applepayVisibilityOnCart: true,
        isPaypalFraudToolsEnabled: true,
        is3DSecureEnabled: false,
        is3DSecureSkipClientValidationResult: false,
        vaultMode: true,
        isPayPalCreditEnabledInDropIn: true
    },
    '*/cartridge/scripts/braintree/helpers/paymentHelper': {
        isPaypalButtonEnabled: () => true,
        getAmountPaid: () => ({ getValue: () => 25 })
    },
    '*/cartridge/config/braintreeConstants': {
        PAGE_FLOW_PDP: 'PAGE_FLOW_PDP',
        PAGE_FLOW_CART: 'PAGE_FLOW_CART',
        PAGE_FLOW_MINICART: 'PAGE_FLOW_MINICART',
        PAGE_FLOW_CHECKOUT: 'PAGE_FLOW_CHECKOUT',
        PAGE_FLOW_ACCOUNT: 'PAGE_FLOW_ACCOUNT',
        CREDIT_CARD_DETAILS_TYPE: 'CREDIT_CARD_DETAILS_TYPE',
        PAYPAL_ACCOUNT_DETAILS_TYPE: 'PAYPAL_ACCOUNT_DETAILS_TYPE',
        APPLE_PAY_ORIGIN_TYPE: 'APPLE_PAY_ORIGIN_TYPE',
        GOOGLE_PAY_ORIGIN_TYPE: 'GOOGLE_PAY_ORIGIN_TYPE'
    },
    '~/cartridge/scripts/braintree/braintreeDropInBusinessLogic': {
        getCustomerPaymentMethods
    },
    '~/cartridge/scripts/braintree/configuration/paypalButtonConfigs': {
        PAYPAL_PDP_Button_Config: { style: 'PAYPAL_PDP_Button_Config' },
        PAYPAL_Cart_Button_Config: { style: 'PAYPAL_Cart_Button_Config' },
        PAYPAL_MiniCart_Button_Config: { style: 'PAYPAL_MiniCart_Button_Config' },
        PAYPAL_Billing_Button_Config: { style: 'PAYPAL_Billing_Button_Config' }
    }
});

describe('helper file', () => {
    describe('getPaypalButtonStyles', () => {
        const getPaypalButtonStyles = helper.__get__('getPaypalButtonStyles');
        let pageFlow;

        it('response should equal PAYPAL_PDP_Button_Config if pageFlow is PAGE_FLOW_PDP', () => {
            pageFlow = 'PAGE_FLOW_PDP';

            expect(getPaypalButtonStyles(pageFlow)).to.equal('PAYPAL_PDP_Button_Config');
        });

        it('response should equal PAYPAL_Cart_Button_Config if pageFlow is PAGE_FLOW_CART', () => {
            pageFlow = 'PAGE_FLOW_CART';

            expect(getPaypalButtonStyles(pageFlow)).to.equal('PAYPAL_Cart_Button_Config');
        });

        it('response should equal PAYPAL_MiniCart_Button_Config if pageFlow is PAGE_FLOW_MINICART', () => {
            pageFlow = 'PAGE_FLOW_MINICART';

            expect(getPaypalButtonStyles(pageFlow)).to.equal('PAYPAL_MiniCart_Button_Config');
        });

        it('response should equal PAYPAL_Billing_Button_Config if pageFlow is PAGE_FLOW_CHECKOUT', () => {
            pageFlow = 'PAGE_FLOW_CHECKOUT';

            expect(getPaypalButtonStyles(pageFlow)).to.equal('PAYPAL_Billing_Button_Config');
        });
    });

    describe('isSavedVisibleCreditCardType', () => {
        const isSavedVisibleCreditCardType = helper.__get__('isSavedVisibleCreditCardType');
        const creditCardDetails = {
            origin: { type: 'APPLE_PAY_ORIGIN_TYPE' },
            __typename: 'test'
        };

        it('response should be false if creditCardDetails.__typename isn\'t CREDIT_CARD_DETAILS_TYPE', () => {
            expect(isSavedVisibleCreditCardType(creditCardDetails)).to.be.false;
        });

        it('response should be false if creditCardDetails.origin.type is APPLE_PAY_ORIGIN_TYPE', () => {
            creditCardDetails.__typename = 'CREDIT_CARD_DETAILS_TYPE';

            expect(isSavedVisibleCreditCardType(creditCardDetails)).to.be.false;
        });

        it('response should be false if creditCardDetails.origin.type is GOOGLE_PAY_ORIGIN_TYPE', () => {
            creditCardDetails.origin.type = 'GOOGLE_PAY_ORIGIN_TYPE';

            expect(isSavedVisibleCreditCardType(creditCardDetails)).to.be.false;
        });

        it('response should be true if creditCardDetails.origin.type is CREDIT_CARD_ORIGIN_TYPE', () => {
            creditCardDetails.origin.type = 'CREDIT_CARD_ORIGIN_TYPE';

            expect(isSavedVisibleCreditCardType(creditCardDetails)).to.be.true;
        });

        it('response should be true if there\'s no creditCardDetails.origin.type', () => {
            creditCardDetails.origin.type = null;

            expect(isSavedVisibleCreditCardType(creditCardDetails)).to.be.true;
        });
    });

    describe('isSavedPayPalPaymentMethodOnBraintree', () => {
        const isSavedPayPalPaymentMethodOnBraintree = helper.__get__('isSavedPayPalPaymentMethodOnBraintree');

        before(() => {
            getCustomerPaymentMethods.returns({ edges: [
                { node: { details: { __typename: 'CREDIT_CARD_DETAILS_TYPE' } } },
                { node: { details: { __typename: 'PAYPAL_ACCOUNT_DETAILS_TYPE' } } }
            ] });
        });

        after(() => {
            customer.registered = false;
            getCustomerPaymentMethods.reset();
        });

        it('response should be false if customer isn\'t registered', () => {
            expect(isSavedPayPalPaymentMethodOnBraintree()).to.be.false;
        });

        it('response should be true if customer is registered and there\'re payment instruments with typename PAYPAL_ACCOUNT_DETAILS_TYPE', () => {
            customer.registered = true;

            expect(isSavedPayPalPaymentMethodOnBraintree()).to.be.true;
        });
    });

    describe('isSavedVisibleDropinPaymentMethods', () => {
        const isSavedVisibleDropinPaymentMethods = helper.__get__('isSavedVisibleDropinPaymentMethods');

        after(() => {
            getCustomerPaymentMethods.reset();
        });

        it('response should be false if there\'re no payment instruments', () => {
            getCustomerPaymentMethods.returns({ edges: [] });

            expect(isSavedVisibleDropinPaymentMethods()).to.be.false;
        });

        it('response should be true if there\'s PAYPAL payment instrument', () => {
            getCustomerPaymentMethods.returns({ edges: [
                { node: { details: { __typename: 'PAYPAL_ACCOUNT_DETAILS_TYPE' } } }
            ] });

            expect(isSavedVisibleDropinPaymentMethods()).to.be.true;
        });

        it('response should be true if there\'s CREDIT_CARD payment instrument', () => {
            getCustomerPaymentMethods.returns({ edges: [
                { node: { details: { __typename: 'CREDIT_CARD_DETAILS_TYPE' } } }
            ] });

            expect(isSavedVisibleDropinPaymentMethods()).to.be.true;
        });
    });

    describe('isPayPalEnabledInDropIn', () => {
        const isPayPalEnabledInDropIn = helper.__get__('isPayPalEnabledInDropIn');
        let pageFlow;

        after(() => {
            BRAINTREE_PAYPAL.isActive = true;
            helper.__ResetDependency__('isSavedPayPalPaymentMethodOnBraintree');
        });

        it('response should be true if page flow is CART & Paypal button enabled but Paypal PI not saved on Braintree', () => {
            helper.__set__('isSavedPayPalPaymentMethodOnBraintree', () => false);
            pageFlow = 'PAGE_FLOW_CART';

            expect(isPayPalEnabledInDropIn(pageFlow)).to.be.true;
        });

        it('response should be true if page flow is MINICART & Paypal PI isn\'t saved on Braintree', () => {
            pageFlow = 'PAGE_FLOW_PDP';

            expect(isPayPalEnabledInDropIn(pageFlow)).to.be.true;
        });

        it('response should be false if page flow is PDP & Paypal PI is saved on Braintree', () => {
            helper.__set__('isSavedPayPalPaymentMethodOnBraintree', () => true);
            pageFlow = 'PAGE_FLOW_MINICART';

            expect(isPayPalEnabledInDropIn(pageFlow)).to.be.false;
        });

        it('response should be false if page flow is CHECKOUT & Paypal PI isn\'t active', () => {
            BRAINTREE_PAYPAL.isActive = null;
            pageFlow = 'PAGE_FLOW_CHECKOUT';

            expect(isPayPalEnabledInDropIn(pageFlow)).to.be.false;
        });
    });

    describe('isGooglePayEnabledInDropIn', () => {
        const isGooglePayEnabledInDropIn = helper.__get__('isGooglePayEnabledInDropIn');
        let pageFlow;

        after(() => {
            BRAINTREE_GOOGLEPAY.isActive = true;
        });

        it('response should be true if page flow is CHECKOUT & Google Pay payment method is active', () => {
            pageFlow = 'PAGE_FLOW_CHECKOUT';

            expect(isGooglePayEnabledInDropIn(pageFlow)).to.be.true;
        });

        it('response should be true if page flow is CART & Google Pay payment method is active', () => {
            pageFlow = 'PAGE_FLOW_CART';

            expect(isGooglePayEnabledInDropIn(pageFlow)).to.be.true;
        });

        it('response should be false if page flow is CART & Google Pay payment method isn\'t active', () => {
            pageFlow = 'PAGE_FLOW_CART';
            BRAINTREE_GOOGLEPAY.isActive = false;

            expect(isGooglePayEnabledInDropIn(pageFlow)).to.be.false;
        });

        it('response should be false if page flow isn\'t CART or CHECKOUT', () => {
            pageFlow = 'PAGE_FLOW_PDP';

            expect(isGooglePayEnabledInDropIn(pageFlow)).to.be.false;
        });
    });

    describe('isApplePayEnabledInDropIn', () => {
        const isApplePayEnabledInDropIn = helper.__get__('isApplePayEnabledInDropIn');
        let pageFlow;

        after(() => {
            BRAINTREE_APPLEPAY.isActive = true;
        });

        it('response should be true if page flow is CHECKOUT & Google Pay payment method is active', () => {
            pageFlow = 'PAGE_FLOW_CHECKOUT';

            expect(isApplePayEnabledInDropIn(pageFlow)).to.be.true;
        });

        it('response should be true if page flow is CART & Google Pay payment method is active', () => {
            pageFlow = 'PAGE_FLOW_CART';

            expect(isApplePayEnabledInDropIn(pageFlow)).to.be.true;
        });

        it('response should be false if page flow is CART & Google Pay payment method isn\'t active', () => {
            pageFlow = 'PAGE_FLOW_CART';
            BRAINTREE_APPLEPAY.isActive = false;

            expect(isApplePayEnabledInDropIn(pageFlow)).to.be.false;
        });

        it('response should be false if page flow isn\'t CART or CHECKOUT', () => {
            pageFlow = 'PAGE_FLOW_PDP';

            expect(isApplePayEnabledInDropIn(pageFlow)).to.be.false;
        });
    });

    describe('isVenmoEnabledInDropIn', () => {
        const isVenmoEnabledInDropIn = helper.__get__('isVenmoEnabledInDropIn');
        let pageFlow;

        after(() => {
            BRAINTREE_VENMO.isActive = true;
        });

        it('response should be true if page flow is CHECKOUT and Venmo is enabled', () => {
            pageFlow = 'PAGE_FLOW_CHECKOUT';

            expect(isVenmoEnabledInDropIn(pageFlow)).to.be.true;
        });

        it('response should be false if page flow is CHECKOUT and Venmo isn\'t enabled', () => {
            BRAINTREE_VENMO.isActive = false;

            expect(isVenmoEnabledInDropIn(pageFlow)).to.be.false;
        });

        it('response should be false if pageflow isn\'t CHECKOUT', () => {
            pageFlow = 'PAGE_FLOW_CART';

            expect(isVenmoEnabledInDropIn(pageFlow)).to.be.false;
        });
    });

    describe('isCreditCardEnabledInDropin', () => {
        const isCreditCardEnabledInDropin = helper.__get__('isCreditCardEnabledInDropin');
        let pageFlow;

        it('response should be true if page flow is CHECKOUT', () => {
            pageFlow = 'PAGE_FLOW_CHECKOUT';

            expect(isCreditCardEnabledInDropin(pageFlow)).to.be.true;
        });

        it('response should be true if page flow is ACCOUNT', () => {
            pageFlow = 'PAGE_FLOW_ACCOUNT';

            expect(isCreditCardEnabledInDropin(pageFlow)).to.be.true;
        });

        it('response should be false if page flow isn\'t ACCOUNT or CHECKOUT', () => {
            pageFlow = 'PAGE_FLOW_PDP';

            expect(isCreditCardEnabledInDropin(pageFlow)).to.be.false;
        });
    });

    describe('getBraintreeErrorMessages', () => {
        const getBraintreeErrorMessages = helper.__get__('getBraintreeErrorMessages');
        const errorMessages = {
            secure3DFailed: 'secure3DFailed',
            CLIENT_REQUEST_TIMEOUT: 'CLIENT_REQUEST_TIMEOUT',
            CLIENT_GATEWAY_NETWORK: 'CLIENT_GATEWAY_NETWORK',
            CLIENT_REQUEST_ERROR: 'CLIENT_REQUEST_ERROR',
            CLIENT_MISSING_GATEWAY_CONFIGURATION: 'CLIENT_MISSING_GATEWAY_CONFIGURATION',
            PAYPAL_ACCOUNT_TOKENIZATION_FAILED: 'PAYPAL_ACCOUNT_TOKENIZATION_FAILED',
            PAYPAL_INVALID_PAYMENT_OPTION: 'PAYPAL_INVALID_PAYMENT_OPTION',
            PAYPAL_FLOW_FAILED: 'PAYPAL_FLOW_FAILED',
            PAYPAL_BROWSER_NOT_SUPPORTED: 'PAYPAL_BROWSER_NOT_SUPPORTED',
            PAYPAL_BILLING_ADDRESS_NOT_SUPPORTED: 'PAYPAL_BILLING_ADDRESS_NOT_SUPPORTED',
            CUSTOM_PAYPAL_ZERO_AMOUNT_ERROR: 'CUSTOM_PAYPAL_ZERO_AMOUNT_ERROR',
            CUSTOM_GOOGLE_PAY_ZERO_AMOUNT_ERROR: 'CUSTOM_GOOGLE_PAY_ZERO_AMOUNT_ERROR',
            VENMO_ACCOUNT_TOKENIZATION_FAILED: 'VENMO_ACCOUNT_TOKENIZATION_FAILED',
            VENMO_BROWSER_NOT_SUPPORTED: 'VENMO_BROWSER_NOT_SUPPORTED'
        };

        before(() => {
            stub(dw.web.Resource, 'msg');
            dw.web.Resource.msg.withArgs('braintree.creditcard.error.secure3DFailed', 'locale', null).returns('secure3DFailed');
            dw.web.Resource.msg.withArgs('braintree.error.CLIENT_REQUEST_TIMEOUT', 'locale', null).returns('CLIENT_REQUEST_TIMEOUT');
            dw.web.Resource.msg.withArgs('braintree.error.CLIENT_GATEWAY_NETWORK', 'locale', null).returns('CLIENT_GATEWAY_NETWORK');
            dw.web.Resource.msg.withArgs('braintree.error.CLIENT_REQUEST_ERROR', 'locale', null).returns('CLIENT_REQUEST_ERROR');
            dw.web.Resource.msg.withArgs('braintree.error.CLIENT_MISSING_GATEWAY_CONFIGURATION', 'locale', null).returns('CLIENT_MISSING_GATEWAY_CONFIGURATION');
            dw.web.Resource.msg.withArgs('braintree.error.PAYPAL_ACCOUNT_TOKENIZATION_FAILED', 'locale', null).returns('PAYPAL_ACCOUNT_TOKENIZATION_FAILED');
            dw.web.Resource.msg.withArgs('braintree.error.PAYPAL_INVALID_PAYMENT_OPTION', 'locale', null).returns('PAYPAL_INVALID_PAYMENT_OPTION');
            dw.web.Resource.msg.withArgs('braintree.error.PAYPAL_FLOW_FAILED', 'locale', null).returns('PAYPAL_FLOW_FAILED');
            dw.web.Resource.msg.withArgs('braintree.error.PAYPAL_BROWSER_NOT_SUPPORTED', 'locale', null).returns('PAYPAL_BROWSER_NOT_SUPPORTED');
            dw.web.Resource.msg.withArgs('braintree.error.PAYPAL_BILLING_ADDRESS_NOT_SUPPORTED', 'locale', null).returns('PAYPAL_BILLING_ADDRESS_NOT_SUPPORTED');
            dw.web.Resource.msg.withArgs('braintree.error.CUSTOM_PAYPAL_ZERO_AMOUNT_ERROR', 'locale', null).returns('CUSTOM_PAYPAL_ZERO_AMOUNT_ERROR');
            dw.web.Resource.msg.withArgs('braintree.error.CUSTOM_GOOGLE_PAY_ZERO_AMOUNT_ERROR', 'locale', null).returns('CUSTOM_GOOGLE_PAY_ZERO_AMOUNT_ERROR');
            dw.web.Resource.msg.withArgs('braintree.error.VENMO_ACCOUNT_TOKENIZATION_FAILED', 'locale', null).returns('VENMO_ACCOUNT_TOKENIZATION_FAILED');
            dw.web.Resource.msg.withArgs('braintree.error.VENMO_BROWSER_NOT_SUPPORTED', 'locale', null).returns('VENMO_BROWSER_NOT_SUPPORTED');
        });

        after(() => {
            dw.web.Resource.msg.restore();
        });

        it('response should be an object equal to errorMessages', () => {
            expect(getBraintreeErrorMessages()).to.deep.equal(errorMessages);
        });
    });

    describe('getGeneralDropInConfigs', () => {
        const getGeneralDropInConfigs = helper.__get__('getGeneralDropInConfigs');
        const braintree = {
            clientToken: 'clientToken',
            payPalButtonConfig: {},
            applePayButtonConfig: { applePayConfig: { style: { buttonStyle: 'applepay button style' } } },
            googlepayButtonConfig: { googlePayConfig: { style: 'googlepay button style' } }
        };
        const responseObj = {
            clientToken: 'clientToken',
            pageFlow: 'PAGE_FLOW_PDP',
            errorMessages: 'error messages',
            isFraudToolsEnabled: true,
            getOrderInfoUrl: 'Braintree-GetOrderInfo',
            is3DSecureEnabled: false,
            isSkip3dSecureLiabilityResult: false,
            vaultModeEnabled: true,
            isPayPalCreditEnabledInDropIn: false,
            payPalButtonStyle: {
                color: 'color',
                label: 'label',
                shape: 'shape',
                size: 'size'
            }
        };
        let pageFlow;

        before(() => {
            helper.__set__('getBraintreeErrorMessages', () => 'error messages');
            helper.__set__('getPaypalButtonStyles', () => ({ color: 'color', shape: 'shape', label: 'label', size: 'size' }));
            stub(dw.web.URLUtils, 'url').withArgs('Braintree-GetOrderInfo').returns('Braintree-GetOrderInfo');
        });

        after(() => {
            helper.__ResetDependency__('getBraintreeErrorMessages');
            helper.__ResetDependency__('getPaypalButtonStyles');
            dw.web.URLUtils.url.restore();
        });

        it('response should equal responseObj if page flow is PDP & braintree.payPalButtonConfig isn\'t null', () => {
            pageFlow = 'PAGE_FLOW_PDP';

            expect(getGeneralDropInConfigs(braintree, pageFlow)).to.deep.equal(responseObj);
        });

        it('response object isPayPalCreditEnabledInDropIn property should be true if page flow is CHECKOUT', () => {
            pageFlow = 'PAGE_FLOW_CHECKOUT';

            expect(getGeneralDropInConfigs(braintree, pageFlow)).to.have.property('isPayPalCreditEnabledInDropIn', true);
        });

        it('response object should have property applePayButtonStyle if page flow is CHECKOUT', () => {
            expect(getGeneralDropInConfigs(braintree, pageFlow)).to.have.property('applePayButtonStyle', 'applepay button style');
        });

        it('response object should have property googlePayButtonStyle if page flow is CHECKOUT', () => {
            expect(getGeneralDropInConfigs(braintree, pageFlow)).to.have.property('googlePayButtonStyle', 'googlepay button style');
        });

        it('response object shouldn\'t have property payPalButtonStyle if page flow is ACCOUNT', () => {
            pageFlow = 'PAGE_FLOW_ACCOUNT';

            expect(getGeneralDropInConfigs(braintree, pageFlow)).to.not.have.property('payPalButtonStyle');
        });
    });

    describe('getEnabledDropinPaymentOptions', () => {
        const getEnabledDropinPaymentOptions = helper.__get__('getEnabledDropinPaymentOptions');
        const pageFlow = 'PAGE_FLOW_CHECKOUT';
        const responseObj = {
            isCreditCardEnabledInDropIn: true,
            isGooglePayEnabledInDropIn: true,
            isVenmoEnabledInDropIn: true,
            isApplePayEnabledInDropIn: true,
            isPayPalEnabledInDropIn: true
        };

        before(() => {
            helper.__set__('isCreditCardEnabledInDropin', () => true);
            helper.__set__('isGooglePayEnabledInDropIn', () => true);
            helper.__set__('isVenmoEnabledInDropIn', () => true);
            helper.__set__('isApplePayEnabledInDropIn', () => true);
            helper.__set__('isPayPalEnabledInDropIn', () => true);
        });

        after(() => {
            helper.__ResetDependency__('isCreditCardEnabledInDropin');
            helper.__ResetDependency__('isGooglePayEnabledInDropIn');
            helper.__ResetDependency__('isVenmoEnabledInDropIn');
            helper.__ResetDependency__('isApplePayEnabledInDropIn');
            helper.__ResetDependency__('isPayPalEnabledInDropIn');
        });

        it('response should equal responseObj', () => {
            expect(getEnabledDropinPaymentOptions(pageFlow)).to.deep.equal(responseObj);
        });
    });

    describe('getDropInConfigs', () => {
        const braintree = {};
        const pageFlow = 'PAGE_FLOW_CHECKOUT';
        const responseObj = {
            isPayPalEnabledInDropIn: true,
            generalDropinConfigs: {},
            billingAddressInfoMessage: 'billingAddressInfoMessage',
            isShowSummaryBillingAddress: true,
            amount: 25
        };

        before(() => {
            helper.__set__('getEnabledDropinPaymentOptions', () => ({ isPayPalEnabledInDropIn: true }));
            helper.__set__('getGeneralDropInConfigs', () => ({ generalDropinConfigs: {} }));
            stub(dw.web.Resource, 'msg').withArgs('braintree.billingaddress.vaultedpaymentmethod.message', 'locale', null).returns('billingAddressInfoMessage');
        });

        after(() => {
            helper.__ResetDependency__('getEnabledDropinPaymentOptions');
            helper.__ResetDependency__('getGeneralDropInConfigs');
            dw.web.Resource.msg.restore();
            dw.order.BasketMgr.currentBasket = null;
        });

        it('response should be equal responseObj', () => {
            dw.order.BasketMgr.currentBasket = { getPaymentInstruments: () => [] };

            expect(helper.getDropInConfigs(braintree, pageFlow)).to.deep.equal(responseObj);
        });

        it('response object isShowSummaryBillingAddress property should be true if there\'s PI in basket and braintreeDropinIsPayPalBillingAddressExist is true', () => {
            dw.order.BasketMgr.currentBasket = { getPaymentInstruments: () => [{ custom: { braintreeDropinIsPayPalBillingAddressExist: true } }] };

            expect(helper.getDropInConfigs(braintree, pageFlow)).to.have.property('isShowSummaryBillingAddress', true);
        });

        it('response object isShowSummaryBillingAddress property should be false if there\'s PI in basket and braintreeDropinIsPayPalBillingAddressExist is false', () => {
            dw.order.BasketMgr.currentBasket = { getPaymentInstruments: () => [{ custom: { braintreeDropinIsPayPalBillingAddressExist: false } }] };

            expect(helper.getDropInConfigs(braintree, pageFlow)).to.have.property('isShowSummaryBillingAddress', false);
        });
    });

    describe('getAccountDropInConfigs', () => {
        const braintree = {};
        const pageFlow = 'PAGE_FLOW_ACCOUNT';
        const responseObj = {
            isCreditCardEnabledInDropIn: true,
            generalDropinConfigs: {},
            isSavedVisibleDropinPaymentMethods: true,
            dropinLabels: {
                largeButtonLabel: 'largeButtonLabel',
                cardSheetTextLabel: 'cardSheetTextLabel',
                chooseWayToPayLabel: 'chooseWayToPayLabel',
                otherWayToPayLabel: 'otherWayToPayLabel',
                mainLabel: 'mainLabel'
            }
        };

        before(() => {
            helper.__set__('getEnabledDropinPaymentOptions', () => ({ isCreditCardEnabledInDropIn: true }));
            helper.__set__('isSavedVisibleDropinPaymentMethods', () => true);
            helper.__set__('getGeneralDropInConfigs', () => ({ generalDropinConfigs: {} }));
            stub(dw.web.Resource, 'msg');
            dw.web.Resource.msg.withArgs('braintree.dropin.account.largebutton.label', 'locale', null).returns('largeButtonLabel');
            dw.web.Resource.msg.withArgs('braintree.dropin.account.cardsheettext.label', 'locale', null).returns('cardSheetTextLabel');
            dw.web.Resource.msg.withArgs('braintree.dropin.account.choosewaytopaylabel.label', 'locale', null).returns('chooseWayToPayLabel');
            dw.web.Resource.msg.withArgs('braintree.dropin.account.otherwaytopay.label', 'locale', null).returns('otherWayToPayLabel');
            dw.web.Resource.msg.withArgs('braintree.dropin.account.mainlabel.label', 'locale', null).returns('mainLabel');
        });

        after(() => {
            helper.__ResetDependency__('getEnabledDropinPaymentOptions');
            helper.__ResetDependency__('isSavedVisibleDropinPaymentMethods');
            helper.__ResetDependency__('getGeneralDropInConfigs');
            dw.web.Resource.msg.restore();
        });

        it('response should equal responseObj', () => {
            expect(helper.getAccountDropInConfigs(braintree, pageFlow)).to.deep.equal(responseObj);
        });
    });

    describe('getProductPageDropinConfigs', () => {
        const braintree = {};
        const pageFlow = 'PAGE_FLOW_PDP';
        const responseObj = {
            isPayPalEnabledInDropIn: true,
            generalDropinConfigs: {}
        };

        before(() => {
            helper.__set__('getEnabledDropinPaymentOptions', () => ({ isPayPalEnabledInDropIn: true }));
            helper.__set__('getGeneralDropInConfigs', () => ({ generalDropinConfigs: {} }));
        });

        after(() => {
            helper.__ResetDependency__('getEnabledDropinPaymentOptions');
            helper.__ResetDependency__('getGeneralDropInConfigs');
        });

        it('response should equal responseObj', () => {
            expect(helper.getProductPageDropinConfigs(braintree, pageFlow)).to.deep.equal(responseObj);
        });
    });
});
