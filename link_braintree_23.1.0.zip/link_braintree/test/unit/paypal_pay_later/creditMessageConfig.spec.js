const { expect } = require('chai');
const { paypal_pay_later: { creditMessageConfigPath } } = require('../path.json');
const proxyquire = require('proxyquire').noCallThru();
require('dw-api-mock/demandware-globals');

const creditMessageConfig = proxyquire(creditMessageConfigPath, {
    'dw/system/Site': {
        current: {
            getCustomPreferenceValue: () => {
                return JSON.stringify({
                    cartCreditConfig: {},
                    productCreditConfig: {},
                    categoryCreditConfig: {}
                });
            }
        }
    }
});

describe('bannerConfig file', () => {
    it('response type should be equal -> object', () => {
        expect(creditMessageConfig).to.be.a('object');
    });
    it('response object should consist property -> cartMessageConfig', () => {
        expect(creditMessageConfig).has.property('cartMessageConfig');
    });
    it('response object property cartMessageConfig type should be equal -> object', () => {
        expect(creditMessageConfig.cartMessageConfig).to.be.a('object');
    });
    it('response object should consist property -> productDetailMessageConfig', () => {
        expect(creditMessageConfig).has.property('productDetailMessageConfig');
    });
    it('response object property productDetailMessageConfig type should be equal -> object', () => {
        expect(creditMessageConfig.productDetailMessageConfig).to.be.a('object');
    });
    it('response object should consist property -> categoryMessageConfig', () => {
        expect(creditMessageConfig).has.property('categoryMessageConfig');
    });
    it('response object property categoryMessageConfig type should be equal -> object', () => {
        expect(creditMessageConfig.categoryMessageConfig).to.be.a('object');
    });
});
