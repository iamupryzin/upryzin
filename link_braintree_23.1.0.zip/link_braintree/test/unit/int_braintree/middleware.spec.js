const { int_braintree: { middlewarePath } } = require('../path.json');

const { it, describe, before, after, afterEach } = require('mocha');
const { stub } = require('sinon');
const { expect } = require('chai');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');

require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const getForm = stub();
const getPaypalCustomerPaymentInstrumentByEmail = stub();

const middleware = proxyquire(middlewarePath, {
    'server': {
        forms: { getForm }
    },
    '~/cartridge/scripts/braintree/helpers/customerHelper': {
        getPaypalCustomerPaymentInstrumentByEmail
    },
    'dw/web/Resource': dw.web.Resource,
    '~/cartridge/config/braintreeConstants': {
        ENDPOINT_ACCOUNT_ADD_SRC_HANDLE_NAME: 'AccountAddSrcHandle',
        ENDPOINT_ACCOUNT_ADD_GOOGLE_PAY_HANDLE_NAME: 'AccountAddGooglePayHandle',
        ENDPOINT_ACCOUNT_ADD_CREDIT_CARD_HANDLE_NAME: 'AccountAddCreditCardHandle',
        ENDPOINT_ACCOUNT_ADD_VENMO_HANDLE_NAME: 'AccountAddVenmoHandle'
    }
});

describe('middleware file', () => {
    describe('getFormFileds', () => {
        const getFormFileds = middleware.__get__('getFormFileds');

        before(() => {
            getForm.withArgs('braintreesecureremotecommerceaccount').returns({ nonce: 'test-src-nonce' });
            getForm.withArgs('braintreegooglepayaccount').returns({ nonce: 'test-googlepay-nonce' });
            getForm.withArgs('braintreevenmoaccount').returns({ nonce: 'test-venmo-nonce' });
            getForm.withArgs('creditCard').returns({ cardOwner: 'Harry Potter' });
        });

        after(() => {
            getForm.reset();
        });

        it('If endpointName === braintreeConstants.ENDPOINT_ACCOUNT_ADD_SRC_HANDLE_NAME', () => {
            const result = getFormFileds('AccountAddSrcHandle');

            expect(result).to.be.an('object');
            expect(result).to.deep.equal({ nonce: 'test-src-nonce' });
        });

        it('If endpointName === braintreeConstants.ENDPOINT_ACCOUNT_ADD_GOOGLE_PAY_HANDLE_NAME', () => {
            const result = getFormFileds('AccountAddGooglePayHandle');

            expect(result).to.be.an('object');
            expect(result).to.deep.equal({ nonce: 'test-googlepay-nonce' });
        });

        it('If endpointName === braintreeConstants.ENDPOINT_ACCOUNT_ADD_CREDIT_CARD_HANDLE_NAME', () => {
            const result = getFormFileds('AccountAddCreditCardHandle');

            expect(result).to.be.an('object');
            expect(result).to.deep.equal({ cardOwner: 'Harry Potter' });
        });

        it('If endpointName === braintreeConstants.ENDPOINT_ACCOUNT_ADD_VENMO_HANDLE_NAME', () => {
            const result = getFormFileds('AccountAddVenmoHandle');

            expect(result).to.be.an('object');
            expect(result).to.deep.equal({ nonce: 'test-venmo-nonce' });
        });

        it('If default clause executed', () => {
            const result = getFormFileds();

            expect(result).to.be.an('object');
            expect(result).to.deep.equal({});
        });
    });

    describe('renderError', () => {
        const renderError = middleware.__get__('renderError');

        before(() => {
            stub(dw.web.Resource, 'msgf').returns('Field is not valid');
        });

        after(() => {
            dw.web.Resource.msgf.restore();
        });

        it('If error was rendered', () => {
            const res = {
                json: () => {}
            };
            const FieldName = 'field';

            expect(renderError(res, FieldName)).to.equal(undefined);
            expect(dw.web.Resource.msgf.calledOnce).to.be.true;
        });
    });

    describe('validateBraintreePaypalAccountForm', () => {
        const req = {};
        const res = {};
        const next = stub();

        before(() => {
            stub(dw.web.Resource, 'msg').returns('Form is not valid');
            getForm.withArgs('braintreepaypalaccount').returns({ valid: true });
        });

        after(() => {
            getForm.reset();
            dw.web.Resource.msg.restore();
        });

        afterEach(() => {
            next.reset();
        });

        it('If valid form was returned from the server', () => {
            expect(middleware.validateBraintreePaypalAccountForm(req, res, next)).to.equal(undefined);
            expect(next.calledOnce).to.be.true;
        });

        it('If invalid form was returned from the server', () => {
            getForm.withArgs('braintreepaypalaccount').returns({ valid: false });

            expect(middleware.validateBraintreePaypalAccountForm(req, res, next)).to.equal(undefined);
            expect(next.calledWith(new Error('Form is not valid'))).to.be.true;
            expect(dw.web.Resource.msg.calledOnce).to.be.true;
        });
    });

    describe('validatePaypalCustomerEmail', () => {
        const req = {
            form: {
                dwfrm_braintreepaypalaccount_email: 'test@mail.com'
            }
        };
        const res = {
            json: () => {},
            setStatusCode: () => {}
        };
        const next = stub();
        const emit = stub();
        const context = { emit };

        before(() => {
            stub(dw.web.Resource, 'msgf').returns('Account already exists');
            getPaypalCustomerPaymentInstrumentByEmail.returns({});
        });

        after(() => {
            getPaypalCustomerPaymentInstrumentByEmail.reset();
            dw.web.Resource.msgf.restore();
        });

        afterEach(() => {
            next.reset();
        });

        it('If customer has payment instruments', () => {
            expect(middleware.validatePaypalCustomerEmail.call(context, req, res, next)).to.equal(undefined);
            expect(emit.calledOnce).to.be.true;
            expect(emit.calledWith('route:Complete', req, res)).to.be.true;
        });

        it('If customer has not payment instruments', () => {
            getPaypalCustomerPaymentInstrumentByEmail.returns(null);

            expect(middleware.validatePaypalCustomerEmail(req, res, next)).to.equal(undefined);
            expect(next.calledOnce).to.be.true;
        });
    });

    describe('validateBraintreePaymentMethodNonce', () => {
        const req = {
            httpParameterMap: {
                braintreePaymentMethodNonce: {
                    submitted: false
                }
            }
        };
        const res = { json: () => {} };
        const next = stub();
        const emit = stub();
        const context = { emit };

        afterEach(() => {
            next.reset();
        });

        it('If payment method nonce is invalid', () => {
            expect(middleware.validateBraintreePaymentMethodNonce.call(context, req, res, next)).to.equal(undefined);
            expect(emit.calledOnce).to.be.true;
            expect(emit.calledWith('route:Complete', req, res)).to.be.true;
        });

        it('If payment method nonce is valid', () => {
            req.httpParameterMap.braintreePaymentMethodNonce.submitted = true;

            expect(middleware.validateBraintreePaymentMethodNonce(req, res, next)).to.equal(undefined);
            expect(next.calledOnce).to.be.true;
        });
    });

    describe('validateBraintreePaymentMethodNonce', () => {
        const req = {};
        const res = { json: () => {} };
        const next = stub();
        const emit = stub();
        const context = { emit };

        before(() => {
            middleware.__set__('getFormFileds', function () {
                return {
                    field: {
                        valid: false
                    }
                };
            });
        });

        after(() => {
            middleware.__ResetDependency__('getFormFileds');
        });

        afterEach(() => {
            next.reset();
        });

        it('If form has invalid fields', () => {
            expect(middleware.validateFormField.call(context, req, res, next)).to.equal(undefined);
            expect(emit.calledOnce).to.be.true;
            expect(emit.calledWith('route:Complete', req, res)).to.be.true;
        });

        it('If all form fields are valid', () => {
            middleware.__set__('getFormFileds', function () {
                return {
                    field: {
                        valid: true
                    }
                };
            });

            expect(middleware.validateFormField(req, res, next)).to.equal(undefined);
            expect(next.calledOnce).to.be.true;
        });
    });
});
