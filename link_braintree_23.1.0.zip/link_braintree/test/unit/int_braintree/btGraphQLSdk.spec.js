const { int_braintree: { btGraphQLSdkPath } } = require('../path.json');

const { it, describe, before, after } = require('mocha');
const { stub } = require('sinon');
const { expect } = require('chai');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');

require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const addVariables = stub();
const call = stub();

const func = () => {
    return {};
};

const btGraphQLSdk = proxyquire(btGraphQLSdkPath, {
    'dw/web/Resource': dw.web.Resource,
    'dw/system/Site': {
        current: {
            allowedCurrencies: {
                toArray: () => ['USD', 'EUR', 'JPY', 'CNY']
            },
            getDefaultCurrency: () => ['USD']
        }
    },
    '~/cartridge/config/braintreePreferences': {},
    '*/cartridge/scripts/query/queries': {
        addVariables
    },
    '*/cartridge/config/braintreeConstants': {},
    '~/cartridge/scripts/braintree/braintreeAPI/braintreeApiCalls': {
        call
    },
    '~/cartridge/config/braintreeConstants': {},
    '~/cartridge/scripts/braintree/helpers/paymentHelper': {
        findCurrentSiteCurrency: func,
        getMerchantAccountID: func,
        defineCreateTransactionQueryName: func
    },
    '*/cartridge/models/btServiceResponseHandler': function () {
        return {
            validateLegacyIdConverterResponse: func,
            validateSearchTransactionsByIdsResponse: func,
            validateCreateClientTokenResponse: func,
            validateVaultPaymentMethodResponse: func,
            validateDeletePaymentMethodFromVaultResponse: func,
            validateFindCustomerResponse: func,
            validateCreateCustomerResponse: func,
            validateCreateTransactionResponse: func
        };
    }
});

describe('btGraphQLSdk file', () => {
    before(() => {
        btGraphQLSdk.__set__('validateReqData', () => { return {}; });
    });

    after(() => {
        btGraphQLSdk.__ResetDependency__('validateReqData');
    });

    const defaultObjCheck = (res) => {
        expect(res).to.be.an('object');
        expect(res).to.deep.equal({});
    };

    describe('createGraphQLCallRequest', () => {
        const createGraphQLCallRequest = btGraphQLSdk.__get__('createGraphQLCallRequest');

        it('If graphQL request data was created', () => {
            createGraphQLCallRequest();
            expect(addVariables.calledOnce).to.be.true;
        });
    });

    describe('validateReqData', () => {
        const data = {};
        const validateReqData = btGraphQLSdk.__get__('validateReqData');

        before(() => {
            stub(dw.web.Resource, 'msg');

            dw.web.Resource.msg.withArgs('braintree.error.empty.data', 'locale', null).returns('No data provided for call.');
        });

        after(() => {
            dw.web.Resource.msg.restore();
        });

        it('If passed data is invalid', () => {
            expect(() => validateReqData(data)).to.throw(Error, 'No data provided for call.');
            expect(dw.web.Resource.msg.calledOnce).to.be.true;
        });

        it('If passed data is valid', () => {
            data.key = 'test';

            expect(validateReqData(data)).to.deep.equal(data);
        });
    });

    describe('btGraphQLSdk', () => {
        it('If btGraphQLSdk is function', () => {
            expect(btGraphQLSdk).to.be.a('function');
            expect(btGraphQLSdk()).to.equal(undefined);
        });
    });

    describe('legacyIdConverter', () => {
        before(() => {
            btGraphQLSdk.__set__('createGraphQLCallRequest', function () {
                return 'graphQLRequestData-for-legacyIdConverter';
            });
        });

        after(() => {
            btGraphQLSdk.__ResetDependency__('createGraphQLCallRequest');
        });

        it('If legacy ID converted into graphQL ID', () => {
            const result = btGraphQLSdk.prototype.legacyIdConverter();

            defaultObjCheck(result);
            expect(call.calledWith('graphQLRequestData-for-legacyIdConverter')).to.be.true;
        });
    });

    describe('searchTransactionsByIds', () => {
        before(() => {
            btGraphQLSdk.__set__('createGraphQLCallRequest', function () {
                return 'graphQLRequestData-for-searchTransactionsByIds';
            });
        });

        after(() => {
            btGraphQLSdk.__ResetDependency__('createGraphQLCallRequest');
        });

        const data = {};

        it('If transaction was found', () => {
            const result = btGraphQLSdk.prototype.searchTransactionsByIds(data);

            defaultObjCheck(result);
            expect(call.calledWith('graphQLRequestData-for-searchTransactionsByIds')).to.be.true;
        });
    });

    describe('createClientToken', () => {
        before(() => {
            btGraphQLSdk.__set__('createGraphQLCallRequest', function () {
                return 'graphQLRequestData-for-createClientToken';
            });
        });

        after(() => {
            btGraphQLSdk.__ResetDependency__('createGraphQLCallRequest');
        });

        const data = {};

        it('If client token was created', () => {
            const result = btGraphQLSdk.prototype.createClientToken(data);

            defaultObjCheck(result);
            expect(call.calledWith('graphQLRequestData-for-createClientToken')).to.be.true;
        });

        it('If client token was created and data has btCustomerId property', () => {
            data.btCustomerId = 'some-customer-id';
            const result = btGraphQLSdk.prototype.createClientToken(data);

            defaultObjCheck(result);
            expect(call.calledWith('graphQLRequestData-for-createClientToken')).to.be.true;
        });
    });

    describe('vaultPaymentMethod', () => {
        before(() => {
            btGraphQLSdk.__set__('createGraphQLCallRequest', function () {
                return 'graphQLRequestData-for-vaultPaymentMethod';
            });
        });

        after(() => {
            btGraphQLSdk.__ResetDependency__('createGraphQLCallRequest');
        });

        const data = {};

        it('If payment method was added to vault', () => {
            const result = btGraphQLSdk.prototype.vaultPaymentMethod(data);

            defaultObjCheck(result);
            expect(call.calledWith('graphQLRequestData-for-vaultPaymentMethod')).to.be.true;
        });
    });

    describe('deletePaymentMethodFromVault', () => {
        before(() => {
            btGraphQLSdk.__set__('createGraphQLCallRequest', function () {
                return 'graphQLRequestData-for-deletePaymentMethodFromVault';
            });
        });

        after(() => {
            btGraphQLSdk.__ResetDependency__('createGraphQLCallRequest');
        });

        const data = {};

        it('If payment method was deleted from vault', () => {
            const result = btGraphQLSdk.prototype.deletePaymentMethodFromVault(data);

            defaultObjCheck(result);
            expect(call.calledWith('graphQLRequestData-for-deletePaymentMethodFromVault')).to.be.true;
        });
    });

    describe('findCustomer', () => {
        before(() => {
            btGraphQLSdk.__set__('createGraphQLCallRequest', function () {
                return 'graphQLRequestData-for-findCustomer';
            });
        });

        after(() => {
            btGraphQLSdk.__ResetDependency__('createGraphQLCallRequest');
        });

        const data = {};

        it('If customer was found', () => {
            const result = btGraphQLSdk.prototype.findCustomer(data);

            defaultObjCheck(result);
            expect(call.calledWith('graphQLRequestData-for-findCustomer')).to.be.true;
        });
    });

    describe('createCustomer', () => {
        before(() => {
            btGraphQLSdk.__set__('createGraphQLCallRequest', function () {
                return 'graphQLRequestData-for-createCustomer';
            });
        });

        after(() => {
            btGraphQLSdk.__ResetDependency__('createGraphQLCallRequest');
        });

        const data = {};

        it('If customer was created', () => {
            const result = btGraphQLSdk.prototype.createCustomer(data);

            defaultObjCheck(result);
            expect(call.calledWith('graphQLRequestData-for-createCustomer')).to.be.true;
        });
    });

    describe('createTransaction', () => {
        before(() => {
            btGraphQLSdk.__set__('createGraphQLCallRequest', function () {
                return 'graphQLRequestData-for-createTransaction';
            });
        });

        after(() => {
            btGraphQLSdk.__ResetDependency__('createGraphQLCallRequest');
        });

        it('If request data is empty', () => {
            const result = btGraphQLSdk.prototype.createTransaction();

            defaultObjCheck(result);
            expect(call.calledWith('graphQLRequestData-for-createTransaction')).to.be.true;
        });

        it('If request data has customerId property', () => {
            btGraphQLSdk.__set__('validateReqData', () => { return { customerId: 'some-id' }; });

            const result = btGraphQLSdk.prototype.createTransaction();

            defaultObjCheck(result);
            expect(call.calledWith('graphQLRequestData-for-createTransaction')).to.be.true;
        });

        it('If request data has vaultPaymentMethodAfterTransacting property', () => {
            btGraphQLSdk.__set__('validateReqData', () => { return { vaultPaymentMethodAfterTransacting: 'some-payment-method' }; });

            const result = btGraphQLSdk.prototype.createTransaction();

            defaultObjCheck(result);
            expect(call.calledWith('graphQLRequestData-for-createTransaction')).to.be.true;
        });

        it('If request data has shipping property', () => {
            btGraphQLSdk.__set__('validateReqData', () => { return { shipping: 'shipping' }; });

            const result = btGraphQLSdk.prototype.createTransaction();

            defaultObjCheck(result);
            expect(call.calledWith('graphQLRequestData-for-createTransaction')).to.be.true;
        });

        it('If request data has shippingAmount property', () => {
            btGraphQLSdk.__set__('validateReqData', () => { return { shippingAmount: 'shippingAmount' }; });

            const result = btGraphQLSdk.prototype.createTransaction();

            defaultObjCheck(result);
            expect(call.calledWith('graphQLRequestData-for-createTransaction')).to.be.true;
        });

        it('If request data has descriptor property', () => {
            btGraphQLSdk.__set__('validateReqData', () => { return { descriptor: 'descriptor' }; });

            const result = btGraphQLSdk.prototype.createTransaction();

            defaultObjCheck(result);
            expect(call.calledWith('graphQLRequestData-for-createTransaction')).to.be.true;
        });

        it('If request data has customFields property', () => {
            btGraphQLSdk.__set__('validateReqData', () => { return { customFields: 'customFields' }; });

            const result = btGraphQLSdk.prototype.createTransaction();

            defaultObjCheck(result);
            expect(call.calledWith('graphQLRequestData-for-createTransaction')).to.be.true;
        });

        it('If request data has taxAmount property', () => {
            btGraphQLSdk.__set__('validateReqData', () => { return { taxAmount: 'taxAmount' }; });

            const result = btGraphQLSdk.prototype.createTransaction();

            defaultObjCheck(result);
            expect(call.calledWith('graphQLRequestData-for-createTransaction')).to.be.true;
        });

        it('If request data has discountAmount property', () => {
            btGraphQLSdk.__set__('validateReqData', () => { return { discountAmount: 'discountAmount' }; });

            const result = btGraphQLSdk.prototype.createTransaction();

            defaultObjCheck(result);
            expect(call.calledWith('graphQLRequestData-for-createTransaction')).to.be.true;
        });

        it('If request data has lineItems property', () => {
            btGraphQLSdk.__set__('validateReqData', () => { return { lineItems: 'lineItems' }; });

            const result = btGraphQLSdk.prototype.createTransaction();

            defaultObjCheck(result);
            expect(call.calledWith('graphQLRequestData-for-createTransaction')).to.be.true;
        });
    });
});
