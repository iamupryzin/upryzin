const { int_braintree: { webHookInitPath } } = require('../path.json');

const { expect } = require('chai');
const { stub } = require('sinon');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const signatureWithPayloadComparizon = stub();

const webHookInit = proxyquire(webHookInitPath, {
    'dw/web/Resource': dw.web.Resource,
    'dw/crypto/Encoding': dw.crypto.Encoding,
    'dw/crypto/WeakMessageDigest': {},
    'dw/crypto/WeakMac': {},
    '~/cartridge/scripts/braintree/helpers/xmlHelper': {
        parseXml: xmlPayload => xmlPayload
    },
    '~/cartridge/scripts/braintree/helpers/paymentMethodWhHelper': {
        getBtServiceCredentials: () => 'BRAINTREE_CREDENTIALS',
        signatureWithPayloadComparizon: signatureWithPayloadComparizon,
        getSha1HexDigestValue: () => {}
    }
});

describe('webHookInit file', () => {
    describe('webHookInitF function', () => {
        const webHookInitFunction = webHookInit.__get__('webHookInit');
        let webHookInitModel = {
            credentials: null
        };

        it('current webHookInitModel type should be equal to object', () => {
            webHookInitFunction.call(webHookInitModel);
            expect(webHookInitModel).to.be.a('object');
        });

        it('current webHookInitModel should has property credentials', () => {
            webHookInitFunction.call(webHookInitModel);
            expect(webHookInitModel).has.property('credentials');
        });

        it('current webHookInitModel property credentials type should be equal string', () => {
            webHookInitFunction.call(webHookInitModel);
            expect(webHookInitModel.credentials).to.be.a('string');
        });

        it('current function should change value of property credentials from null to BRAINTREE_CREDENTIALS', () => {
            webHookInitFunction.call(webHookInitModel);
            expect(webHookInitModel.credentials).equal('BRAINTREE_CREDENTIALS');
        });
    });

    describe('matchingSignature function', () => {
        const matchingSignature = webHookInit.__get__('matchingSignature');
        const credentialsObj = {
            credentials: {
                user: 'John Smith'
            }
        };
        let signaturePairs = [];

        it('response type should be a string', () => {
            signaturePairs = [
                ['John Smith', 'joHnSmitHSignature'],
                ['John Jons', 'joHnJonsSignature']
            ];

            expect(matchingSignature.call(credentialsObj, signaturePairs)).to.equal('joHnSmitHSignature');
        });

        it('response should be null if credentials.user !== publicKey', () => {
            signaturePairs = [
                ['John Smit', 'joHnSmitHSignature'],
                ['John Jons', 'joHnJonsSignature']
            ];

            expect(matchingSignature.call(credentialsObj, signaturePairs)).equal(null);
        });
    });

    describe('parsePayload', () => {
        let payload = true;

        before(() => {
            stub(dw.web.Resource, 'msg');
            dw.web.Resource.msg.withArgs('braintree.paymentMethod.webhook.payload.not.exist', 'locale', 'null').returns('payload parameter is required');
            dw.web.Resource.msg.withArgs('braintree.paymentMethod.webhook.payload.contains.illegal.characters', 'locale', 'null').returns('payload contains illegal characters');
            stub(dw.crypto.Encoding, 'fromBase64');
            dw.crypto.Encoding.fromBase64.withArgs(payload).returns('optimal_payload');
        });

        after(() => {
            dw.web.Resource.msg.restore();
            dw.crypto.Encoding.fromBase64.restore();
        });

        it('response should be be a string if payload exists ', () => {
            expect(webHookInit.prototype.parsePayload(payload)).to.equal('optimal_payload');
        });

        it('response type should be an error if no payload', () => {
            payload = false;

            expect(() => webHookInit.prototype.parsePayload(payload)).to.throw('payload parameter is required');
        });
    });

    describe('validateSignature', () => {
        const self = {
            credentials: {
                password: 'JohnSmithPassword'
            }
        };
        const signature = 'joHnSmitHSignature';
        let signatureString = 'JohnSmith|joHnSmitHSignature&JohnJons|joHnJonsSignature';
        let payload = true;

        before(() => {
            stub(dw.web.Resource, 'msg');
            dw.web.Resource.msg.withArgs('braintree.paymentMethod.webhook.signature.not.exist', 'locale', 'null').returns('signature doesn"t exist');
            dw.web.Resource.msg.withArgs('braintree.paymentMethod.webhook.signature.nomatch.public.key', 'locale', 'null').returns('signature doesn"t match publicKey');
            dw.web.Resource.msg.withArgs('braintree.paymentMethod.webhook.signature.doesnot.match.payload', 'locale', 'null').returns('signature doesn"t match payload');
            signatureWithPayloadComparizon.returns({
                signature: signature,
                sha1HexDigestValue: 'value'
            });
        });

        after(() => {
            webHookInit.__ResetDependency__('matchingSignature');
            dw.web.Resource.msg.restore();
            signatureWithPayloadComparizon.reset();
        });

        it('response type should be true if signatureString and payload exist', () => {
            webHookInit.__set__('matchingSignature', () => signature);
            expect(webHookInit.prototype.validateSignature.call(self, signatureString, payload)).to.be.true;
        });

        it('response type should be an error if signatureString is null', () => {
            signatureString = null;

            expect(() => webHookInit.prototype.validateSignature.call(self, signatureString, payload)).to.throw('signature doesn"t exist');
        });

        it('response type should be an error if signatureString doesn\'t match publicKey', () => {
            signatureString = 'JohnSmith|joHnSmitHSignature&JohnJons|joHnJonsSignature';
            webHookInit.__set__('matchingSignature', () => null);

            expect(() => webHookInit.prototype.validateSignature.call(self, signatureString, payload)).to.throw('signature doesn"t match publicKey');
        });

        it('response type should be true if signatureString and payload exist', () => {
            webHookInit.__set__('matchingSignature', () => signature);
            signatureWithPayloadComparizon.returns(false);

            expect(() => webHookInit.prototype.validateSignature.call(self, signatureString, payload)).to.throw('signature doesn"t match payload');
        });
    });
});
