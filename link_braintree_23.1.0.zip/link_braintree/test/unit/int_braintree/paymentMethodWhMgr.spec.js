const { int_braintree: { paymentMethodWhMgrPath } } = require('../path.json');

const { it, describe, before, after } = require('mocha');
const { stub } = require('sinon');
const { expect } = require('chai');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');

const find = stub().callsArgWith(1, { creditCardToken: 'token' });
const deletePaymentMethod = stub();

const paymentMethodWhMgr = proxyquire(paymentMethodWhMgrPath, {
    '~/cartridge/models/webHookInit': {
        apply: () => {},
        prototype: {}
    },
    '~/cartridge/scripts/braintree/braintreeAPI/braintreeBusinessLogic': {
        deletePaymentMethod
    },
    '~/cartridge/config/braintreePreferences': {
        paymentMethods: {
            BRAINTREE_PAYPAL: { paymentMethodId: 'id' }
        }
    },
    '*/cartridge/scripts/util/array': {
        find
    },
    '~/cartridge/scripts/braintree/helpers/paymentHelper': {
        setAndReturnNewDefaultCard: () => {}
    },
    'dw/customer/CustomerMgr': dw.customer.CustomerMgr,
    'dw/web/Resource': dw.web.Resource
});

describe('paymentMethodWhMgr file', () => {
    describe('paymentMethodWhMgr', () => {
        it('If paymentMethodWhMgr is function', () => {
            expect(paymentMethodWhMgr).to.be.a('function');
            expect(paymentMethodWhMgr()).to.equal(undefined);
        });
    });

    describe('deleteRevokedPaymentMethod', () => {
        const paypalAccount = {
            customerId: 'some-id',
            token: 'token'
        };

        before(() => {
            stub(dw.customer.CustomerMgr, 'queryProfile');
            stub(dw.web.Resource, 'msg');

            dw.customer.CustomerMgr.queryProfile.withArgs('custom.braintreeCustomerId = {0}', 'some-id').returns({
                wallet: { paymentInstruments: {} }
            });
            dw.customer.CustomerMgr.queryProfile.withArgs('customerNo = {0}', 'some-id').returns(null);
            dw.web.Resource.msg.withArgs('braintree.server.error.custom', 'locale', null).returns('Server custom error');

            find.returns({ custom: {} });
        });

        after(() => {
            dw.customer.CustomerMgr.queryProfile.restore();
            dw.web.Resource.msg.restore();

            find.reset();
        });

        afterEach(() => {
            deletePaymentMethod.reset();
        });

        it('If customerProfile exists and new default PayPal card did not set', () => {
            expect(paymentMethodWhMgr.prototype.deleteRevokedPaymentMethod(paypalAccount)).to.equal(undefined);
            expect(deletePaymentMethod.calledOnce).to.be.true;
        });

        it('If customer was created by legacy API', () => {
            dw.customer.CustomerMgr.queryProfile.withArgs('custom.braintreeCustomerId = {0}', 'some-id').returns(null);

            expect(() => paymentMethodWhMgr.prototype.deleteRevokedPaymentMethod(paypalAccount)).to.throw(Error, 'Server custom error');
            expect(deletePaymentMethod.calledOnce).to.be.false;
        });

        it('If customerProfile exists and new default PayPal card was set', () => {
            dw.customer.CustomerMgr.queryProfile.withArgs('custom.braintreeCustomerId = {0}', 'some-id').returns({
                wallet: { paymentInstruments: {} }
            });
            find.returns({ custom: { braintreeDefaultCard: true } });

            expect(paymentMethodWhMgr.prototype.deleteRevokedPaymentMethod(paypalAccount)).to.equal(undefined);
            expect(deletePaymentMethod.calledOnce).to.be.true;
        });
    });
});
