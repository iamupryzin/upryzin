const { int_braintree: { paymentPath } } = require('../path.json');

const { expect } = require('chai');
const { it, describe } = require('mocha');

const proxyquire = require('proxyquire').noCallThru();

require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

Object.setPrototypeOf(
    module,
    Object.assign(Object.getPrototypeOf(module), {
        superModule: {
            call: () => {}
        }
    })
);

const payment = proxyquire(paymentPath, {
    '*/cartridge/scripts/util/collections': {
        map: (array, func) => {
            const result = [];
            for (const el of array) {
                result.push(func(el));
            }
            return result;
        }
    }
});

describe('payment file', () => {
    describe('getSelectedPaymentInstruments', () => {
        const getSelectedPaymentInstruments = payment.__get__('getSelectedPaymentInstruments');

        it('If paymentInstrument.paymentMethod equals GIFT_CERTIFICATE', () => {
            const selectedPaymentInstruments = [{
                paymentMethod: 'GIFT_CERTIFICATE',
                paymentTransaction: { amount: { value: 100 } },
                giftCertificateCode: 'gift-certificate-code',
                maskedGiftCertificateCode: 'masked-gift-certificate-code'
            }];

            const result = getSelectedPaymentInstruments(selectedPaymentInstruments);

            expect(result).to.be.an('array').that.have.lengthOf(1);
            expect(result).to.deep.equal([{
                paymentMethod: 'GIFT_CERTIFICATE',
                amount: 100,
                giftCertificateCode: 'gift-certificate-code',
                maskedGiftCertificateCode: 'masked-gift-certificate-code'
            }]);
        });

        it('If paymentInstrument.paymentMethod equals GooglePay', () => {
            const selectedPaymentInstruments = [{
                paymentMethod: 'GooglePay',
                paymentTransaction: { amount: { value: 100 } },
                creditCardType: 'Visa',
                custom: {
                    braintreeGooglePayCardDescription: '00000'
                }
            }];

            const result = getSelectedPaymentInstruments(selectedPaymentInstruments);

            expect(result).to.be.an('array').that.have.lengthOf(1);
            expect(result).to.deep.equal([{
                paymentMethod: 'GooglePay',
                amount: 100,
                maskedCreditCardNumber: '00000',
                type: 'Visa'
            }]);
        });

        it('If paymentInstrument.paymentMethod equals SRC', () => {
            const selectedPaymentInstruments = [{
                paymentMethod: 'SRC',
                paymentTransaction: { amount: { value: 100 } },
                creditCardType: 'Visa',
                custom: {
                    braintreeSrcCardDescription: '00000'
                }
            }];

            const result = getSelectedPaymentInstruments(selectedPaymentInstruments);

            expect(result).to.be.an('array').that.have.lengthOf(1);
            expect(result).to.deep.equal([{
                paymentMethod: 'SRC',
                amount: 100,
                maskedCreditCardNumber: '00000',
                type: 'Visa'
            }]);
        });

        it('If paymentInstrument.paymentMethod equals PayPal', () => {
            const selectedPaymentInstruments = [{
                paymentMethod: 'PayPal',
                paymentTransaction: { amount: { value: 100 } },
                custom: {
                    braintreePaypalEmail: 'paypal@email.com',
                    payPalFundingSource: 'funding-source'
                }
            }];

            const result = getSelectedPaymentInstruments(selectedPaymentInstruments);

            expect(result).to.be.an('array').that.have.lengthOf(1);
            expect(result).to.deep.equal([{
                paymentMethod: 'PayPal',
                amount: 100,
                braintreePaypalEmail: 'paypal@email.com',
                fundingSource: 'funding-source'
            }]);
        });

        it('If paymentInstrument.paymentMethod equals Venmo', () => {
            const selectedPaymentInstruments = [{
                paymentMethod: 'Venmo',
                paymentTransaction: { amount: { value: 100 } },
                custom: {
                    braintreeVenmoUserId: 'venmo-user-id'
                }
            }];

            const result = getSelectedPaymentInstruments(selectedPaymentInstruments);

            expect(result).to.be.an('array').that.have.lengthOf(1);
            expect(result).to.deep.equal([{
                paymentMethod: 'Venmo',
                amount: 100,
                braintreeVenmoUserId: 'venmo-user-id'
            }]);
        });

        it('If paymentInstrument.paymentMethod equals Credit Card', () => {
            const selectedPaymentInstruments = [{
                paymentMethod: 'Credit Card',
                paymentTransaction: { amount: { value: 100 } },
                creditCardNumberLastDigits: '0000',
                creditCardHolder: 'Harry Potter',
                creditCardExpirationYear: '2222',
                creditCardType: 'Visa',
                maskedCreditCardNumber: '0000',
                creditCardExpirationMonth: '10'
            }];

            const result = getSelectedPaymentInstruments(selectedPaymentInstruments);

            expect(result).to.be.an('array').that.have.lengthOf(1);
            expect(result).to.deep.equal([{
                paymentMethod: 'Credit Card',
                amount: 100,
                lastFour: '0000',
                owner: 'Harry Potter',
                expirationYear: '2222',
                type: 'Visa',
                maskedCreditCardNumber: '0000',
                expirationMonth: '10'
            }]);
        });
    });

    describe('Payment', () => {
        const currentBasket = {
            paymentInstruments: []
        };
        const currentCustomer = {};
        const countryCode = {};

        it('If paymentInstruments are empty', () => {
            payment.call({ selectedPaymentInstruments: { paymentInstruments: [] } }, {}, currentCustomer, countryCode);
            expect(payment).have.been.called;
        });

        it('If paymentInstruments are not empty', () => {
            payment.call({ selectedPaymentInstruments: { paymentInstruments: [] } }, currentBasket, currentCustomer, countryCode);
            expect(payment).have.been.called;
        });
    });
});
