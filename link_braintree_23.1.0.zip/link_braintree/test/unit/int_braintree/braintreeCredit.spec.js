const { stub } = require('sinon');
const { expect } = require('chai');
const { it, describe, before, after } = require('mocha');

// Disables call thru, which determines if keys of original
// modules will be used when they weren't stubbed out.
const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');

require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const { int_braintree: { braintreeCreditPath } } = require('../path.json');

const prefs = {
    creditCardDescriptorName: 'creditCardDescriptorName',
    isFraudToolsEnabled: false,
    paymentMethods: {
        BRAINTREE_CREDIT: {}
    }
};
const checkForPaymentInstruments = stub();

const braintreeCredit = proxyquire(braintreeCreditPath, {
    'dw/web/Resource': dw.web.Resource,
    'dw/order/OrderMgr': dw.order.OrderMgr,
    'dw/order/PaymentMgr': dw.order.PaymentMgr,
    'dw/order/PaymentInstrument': dw.order.PaymentInstrument,
    'dw/system/Transaction': dw.system.Transaction,
    '~/cartridge/config/braintreePreferences': prefs,
    '~/cartridge/scripts/braintree/helpers/paymentHelper': {
        deleteBraintreePaymentInstruments: () => {},
        getNonGiftCertificateAmount: () => {},
        getLogger: () => {
            return { error: (error) => error };
        },
        handleErrorCode: () => {},
        getApplicableCreditCardPaymentInstruments: () => {}
    },
    '~/cartridge/scripts/hooks/payment/processor/processorHelper': {
        saveGeneralTransactionData: () => {},
        createBaseSaleTransactionData: (order, paymentInstrument, _prefs) => {
            return {
                order: order,
                paymentInstrument: paymentInstrument,
                prefs: _prefs
            };
        },
        verifyTransactionStatus: () => {},
        saveCustomerCreditCard: () => {
            return {
                error: false,
                customerPaymentInstrument: {
                    custom: {
                        braintreeCreditCardBillingAddress: 'billing address'
                    }
                }
            };
        },
        isUsedSessionCreditCard: () => false,
        isUsedSavedCardMethod: () => false,
        isSessionCardAlreadyUsed: () => false,
        checkForPaymentInstruments,
        getUsedCreditCardFromForm: () => {
            return {
                creditCardType: 'credit',
                creditCardNumber: '4111 1111 1111 1111',
                creditCardHolder: 'First name Last name',
                creditCardExpirationMonth: '12',
                creditCardExpirationYear: '2025'
            };
        }
    },
    '~/cartridge/scripts/braintree/helpers/customerHelper': {
        clearDefaultProperty: () => {},
        setBraintreeDefaultCard: () => {},
        getCustomerPaymentInstrument: () => {},
        getCustomerPaymentInstrumentByCreditCardToken: () => {
            return {
                custom: {
                    braintreeCreditCardBillingAddress: 'billing address'
                }
            };
        }
    },
    '*/cartridge/models/btGraphQLSdk': () => {
        return {
            createTransaction: () => {
                return {
                    transaction: {
                        paymentMethod: {
                            legacyId: 'id'
                        },
                        customer: {
                            id: 'customerId'
                        }
                    }
                };
            },
            updateCreditCardBillingAddress: () => {}
        };
    }
});

describe('braintreeCredit file', () => {
    describe('createSaleTransactionData', () => {
        const order = {};

        let paymentInstrument = {
            custom: {
                braintreePaymentMethodNonce: 'braintreePaymentMethodNonce'
            },
            creditCardToken: 'creditCardToken'
        };

        const paymentInstrumentRestore = paymentInstrument;

        const createSaleTransactionData = braintreeCredit.__get__('createSaleTransactionData');

        describe('Braintree payment method nonce and credit card token are empty', () => {
            before(() => {
                paymentInstrument = {
                    custom: { braintreePaymentMethodNonce: '' },
                    creditCardToken: ''
                };
            });

            after(() => {
                paymentInstrument = paymentInstrumentRestore;
            });

            it('expects: throw an error with message', () => {
                expect(() => createSaleTransactionData(order, paymentInstrument)).to.throw(Error, /^paymentInstrument.custom.braintreePaymentMethodNonce or paymentInstrument.creditCardToken are empty$/);
            });
        });

        describe('Creating sale transaction data. Fraud tools disabled', () => {
            const val = createSaleTransactionData(order, paymentInstrument);

            it('expects: response type object, object have property descriptor, descriptor include property name - equal => creditCardDescriptorName, object not have property deviceData', () => {
                expect(val).to.be.an('object');
                expect(val).to.have.property('descriptor');
                expect(val.descriptor).to.include({ name: 'creditCardDescriptorName' });
                expect(val).to.not.have.property('deviceData');
            });
        });

        describe('Creating sale transaction data. Fraud tools enabled', () => {
            let val;

            before(() => {
                prefs.isFraudToolsEnabled = true;
                paymentInstrument.custom.braintreeFraudRiskData = 'low';

                val = createSaleTransactionData(order, paymentInstrument);
            });

            after(() => {
                val = undefined;
                prefs.isFraudToolsEnabled = false;
                paymentInstrument = paymentInstrumentRestore;
            });

            it('expects: response type object, object have property descriptor, descriptor include property name - equal => creditCardDescriptorName', () => {
                expect(val).to.be.an('object');
                expect(val).to.have.property('descriptor');
                expect(val.descriptor).to.include({ name: 'creditCardDescriptorName' });
            });

            it('expects: response object have property deviceData with value equal => low', () => {
                expect(val).to.have.property('deviceData');
                expect(val.deviceData).to.equal('low');
            });
        });

        describe('Creating sale transaction data. Descriptor name', () => {
            before(() => {
                prefs.creditCardDescriptorName = '';
            });

            after(() => {
                prefs.creditCardDescriptorName = 'creditCardDescriptorName';
            });

            it('Data descriptor name is empty', () => {
                const val = createSaleTransactionData(order, paymentInstrument);

                expect(val).to.be.an('object');
                expect(val).to.have.property('descriptor');
                expect(val.descriptor).to.have.property('name');
                expect(val.descriptor.name).to.equal('');
            });
        });
    });

    describe('authorizeFailedFlow', () => {
        const authorizeFailedFlow = braintreeCredit.__get__('authorizeFailedFlow');

        const orderRecord = { custom: { isBraintree: null } };
        const paymentInstrumentRecord = {
            custom: {
                braintreeSaveCreditCard: false,
                braintreeDefaultCard: true,
                braintreeFailReason: ''
            }
        };
        const braintreeError = 'Error';

        const val = authorizeFailedFlow(orderRecord, paymentInstrumentRecord, braintreeError);

        it('Authorized flow is failed', () => {
            expect(val).to.be.an('object');
            expect(val).to.have.property('error');
            expect(val.error).to.be.a('boolean');
            expect(val.error).to.equal(true);
        });

        it('Update Order and OrderPaymentInstrument', () => {
            expect(orderRecord.custom.isBraintree).to.equal(true);
            expect(paymentInstrumentRecord.custom.braintreeFailReason).to.equal(braintreeError);
            expect(paymentInstrumentRecord.custom.braintreeSaveCreditCard).to.equal(null);
            expect(paymentInstrumentRecord.custom.braintreeDefaultCard).to.equal(null);
        });
    });

    describe('saveTransactionData', () => {
        const saveTransactionData = braintreeCredit.__get__('saveTransactionData');

        const orderRecord = {};
        const paymentInstrumentRecord = {
            custom: {
                braintree3dSecureStatus: null
            },
            creditCardToken: ''
        };
        const responseTransaction = {
            paymentMethod: {
                legacyId: 'id'
            },
            paymentMethodSnapshot: {
                threeDSecure: {
                    authenticationStatus: 'status'
                }
            }
        };

        const val = saveTransactionData(orderRecord, paymentInstrumentRecord, responseTransaction);

        it('Run function', () => {
            expect(val).to.be.equal(undefined);
        });

        // I'm not shore that it methods below is needed. Please help me with it
        it('Save token for lightning order managment', () => {
            expect(paymentInstrumentRecord.creditCardToken).to.be.equal(responseTransaction.paymentMethod.legacyId);
        });

        it('Does\'t save token for lightning order managment', () => {
            paymentInstrumentRecord.creditCardToken = 'token';

            expect(paymentInstrumentRecord.creditCardToken).to.not.equal(responseTransaction.paymentMethod.legacyId);
        });

        it('Authentication status not empty', () => {
            expect(paymentInstrumentRecord.custom.braintree3dSecureStatus).to.be.equal(responseTransaction.paymentMethodSnapshot.threeDSecure.authenticationStatus);
        });

        it('Authentication status not set', () => {
            responseTransaction.paymentMethodSnapshot.threeDSecure.authenticationStatus = false;

            saveTransactionData(orderRecord, paymentInstrumentRecord, responseTransaction);

            expect(paymentInstrumentRecord.custom.braintree3dSecureStatus).to.be.equal(null);
        });
    });

    describe('Handle', () => {
        const originalRequest = request;
        const originalSession = session;

        const defaultHttpParameterMap = {
            braintreeCreditCardList: { stringValue: 'uuid' },
            braintreePaymentMethodNonce: { stringValue: 'nonce' },
            braintreeCardPaymentMethod: 'CREDIT',
            braintreeSaveCreditCard: { booleanValue: false },
            braintreeIs3dSecureRequired: { booleanValue: false },
            braintreeDeviceData: { stringValue: 'device data' },
            braintreeCardBillingAddress: { stringValue: 'billing address' }
        };

        before(() => {
            request.httpParameterMap = defaultHttpParameterMap;

            session = {
                forms: { billing: { creditCardFields: {} } },
                privacy: { braintree3dSecureNonce: null }
            };

            stub(dw.order.PaymentMgr, 'getPaymentMethod').returns({
                getPaymentProcessor: () => {}
            });
        });

        after(() => {
            request = originalRequest;
            session = originalSession;

            dw.order.PaymentMgr.getPaymentMethod.restore();
        });

        const basket = {
            getPaymentInstruments: () => {
                return [
                    { custom: {} }
                ];
            },
            createPaymentInstrument: () => {
                return {
                    creditCardType: null,
                    creditCardNumber: null,
                    creditCardHolder: null,
                    custom: {
                        braintreePaymentMethodNonce: null,
                        braintreeSaveCreditCard: null,
                        braintreeIs3dSecureRequired: null,
                        braintreeFraudRiskData: null
                    },
                    paymentTransaction: {
                        setPaymentProcessor: () => {}
                    },
                    setCreditCardExpirationMonth: () => {},
                    setCreditCardExpirationYear: () => {}
                };
            },
            createPaymentInstrumentFromWallet: () => {
                return {
                    custom: {},
                    paymentTransaction: { setPaymentProcessor: () => {} }
                };
            }
        };

        const expectClientRequestError = (val) => {
            expect(val).to.be.an('object');
            expect(val).to.have.property('error');
            expect(val.error).to.be.a('boolean');
            expect(val.error).to.equal(true);
            expect(val).to.have.property('fieldErrors');
            expect(val.fieldErrors).to.be.an('array');
            expect(val).to.have.property('serverErrors');
            expect(val.serverErrors).to.be.an('array');
        };

        const expectSuccess = (val) => {
            expect(val).to.be.an('object');
            expect(val).to.have.property('success');
            expect(val.success).to.be.a('boolean');
            expect(val.success).to.equal(true);
        };

        describe('Create Braintree payment instrument', () => {
            it('Success, without cases', () => {
                // eslint-disable-next-line new-cap
                const val = braintreeCredit.Handle(basket);

                expectSuccess(val);
            });

            describe('Case: New/session credit card', () => {
                before(() => {
                    braintreeCredit.__set__('isUsedSessionCreditCard', () => true);
                });

                after(() => {
                    braintreeCredit.__ResetDependency__('isUsedSessionCreditCard');
                });

                it('New/session', () => {
                    // eslint-disable-next-line new-cap
                    const val = braintreeCredit.Handle(basket);

                    expectSuccess(val);
                });

                describe('Check card session', () => {
                    before(() => {
                        braintreeCredit.__set__('isSessionCardAlreadyUsed', () => true);
                    });

                    after(() => {
                        braintreeCredit.__ResetDependency__('isSessionCardAlreadyUsed');
                    });

                    it('Session card already used', () => {
                        // eslint-disable-next-line new-cap
                        const val = braintreeCredit.Handle(basket);

                        expectSuccess(val);
                    });
                });

                describe('Client request error', () => {
                    before(() => {
                        request.httpParameterMap = {
                            braintreeCreditCardList: { stringValue: 'uuid' },
                            braintreeCardPaymentMethod: 'CREDIT',
                            braintreePaymentMethodNonce: { stringValue: '' },
                            braintreeIs3dSecureRequired: { booleanValue: true }
                        };
                    });

                    after(() => {
                        request = originalRequest;
                    });

                    it('New/session credit card fail', () => {
                        // eslint-disable-next-line new-cap
                        const val = braintreeCredit.Handle(basket);

                        expectClientRequestError(val);
                    });
                });

                describe('Log exeption message', () => {
                    before(() => {
                        request.httpParameterMap = defaultHttpParameterMap;

                        braintreeCredit.__set__('isUsedSessionCreditCard', () => true);
                        braintreeCredit.__set__('deleteBraintreePaymentInstruments', () => {
                            throw new Error('Test erro message');
                        });
                    });

                    after(() => {
                        request = originalRequest;

                        braintreeCredit.__set__('isUsedSessionCreditCard', () => false);
                        braintreeCredit.__ResetDependency__('deleteBraintreePaymentInstruments');
                    });

                    it('Catch error', () => {
                        // eslint-disable-next-line new-cap
                        const val = braintreeCredit.Handle(basket);

                        expectClientRequestError(val);
                    });
                });
            });

            describe('Case: Saved card (Credit Card)', () => {
                before(() => {
                    request.httpParameterMap = defaultHttpParameterMap;
                    braintreeCredit.__set__('isUsedSavedCardMethod', () => true);
                });

                after(() => {
                    request = originalRequest;
                    braintreeCredit.__ResetDependency__('isUsedSavedCardMethod');
                });

                it('Credit card is saved', () => {
                    // eslint-disable-next-line new-cap
                    const val = braintreeCredit.Handle(basket);

                    expect(session.privacy.braintree3dSecureNonce).to.be.a('boolean');
                    expect(session.privacy.braintree3dSecureNonce).to.equal(true);

                    expectSuccess(val);
                });

                describe('Client request error', () => {
                    before(() => {
                        request.httpParameterMap = {
                            braintreeCreditCardList: { stringValue: 'uuid' },
                            braintreeCardPaymentMethod: 'CREDIT',
                            braintreePaymentMethodNonce: { stringValue: '' },
                            braintreeIs3dSecureRequired: { booleanValue: true }
                        };
                    });

                    after(() => {
                        request = originalRequest;
                    });

                    it('Credit card is not saved', () => {
                        // eslint-disable-next-line new-cap
                        const val = braintreeCredit.Handle(basket);

                        expectClientRequestError(val);
                    });
                });
            });
        });
    });

    describe('Authorize', () => {
        let isRemovedPaymentInstrument = false;

        before(() => {
            stub(dw.order.OrderMgr, 'getOrder').returns({
                paymentTransaction: { accountID: 'accountID' },
                removePaymentInstrument: () => {
                    isRemovedPaymentInstrument = true;
                }
            });

            braintreeCredit.__set__('createSaleTransactionData', () => {
                return {};
            });

            braintreeCredit.__set__('saveTransactionData', () => {});

            braintreeCredit.__set__('authorizeFailedFlow', () => {
                return { error: true };
            });
            braintreeCredit.__set__('createUpdateCreditCardBaRequestData', () => {});
        });

        after(() => {
            dw.order.OrderMgr.getOrder.restore();

            braintreeCredit.__ResetDependency__('createSaleTransactionData');
            braintreeCredit.__ResetDependency__('saveTransactionData');
            braintreeCredit.__ResetDependency__('authorizeFailedFlow');

            isRemovedPaymentInstrument = false;
            checkForPaymentInstruments.reset();
        });

        let amountValue = 100;
        const orderNumber = '000000001';
        const paymentInstrument = {
            custom: {
                braintreeSaveCreditCard: true
            },
            paymentTransaction: {},
            getPaymentTransaction: () => {
                return {
                    getAmount: () => {
                        return { getValue: () => amountValue };
                    }
                };
            }
        };

        it('If customer is authenticated & there\'re payment instruments in the wallet', () => {
            customer.authenticated = true;
            checkForPaymentInstruments.returns(true);

            // eslint-disable-next-line new-cap
            expect(braintreeCredit.Authorize(orderNumber, paymentInstrument)).to.deep.equal({ authorized: true });
        });

        it('Amount of payment transaction is greater than zero', () => {
            customer.authenticated = false;
            checkForPaymentInstruments.returns(false);
            paymentInstrument.custom.braintreeSaveCreditCard = true;

            // eslint-disable-next-line new-cap
            const val = braintreeCredit.Authorize(orderNumber, paymentInstrument);

            expect(val).to.be.an('object');
            expect(val).to.have.property('authorized');
            expect(val.authorized).to.be.a('boolean');
            expect(val.authorized).to.equal(true);

            expect(isRemovedPaymentInstrument).to.equal(false);
        });

        it('Save credit card', () => {
            // eslint-disable-next-line new-cap
            braintreeCredit.Authorize(orderNumber, paymentInstrument);

            expect(paymentInstrument.custom.braintreeSaveCreditCard).to.equal(null);
        });

        it('Amount of payment transaction is zero', () => {
            amountValue = 0;
            // eslint-disable-next-line new-cap
            const val = braintreeCredit.Authorize(orderNumber, paymentInstrument);

            expect(val).to.be.an('object');
            expect(val).to.have.property('authorized');
            expect(val.authorized).to.be.a('boolean');
            expect(val.authorized).to.equal(true);

            expect(isRemovedPaymentInstrument).to.equal(true);
        });

        describe('Don\'t keep credit card', () => {
            before(() => {
                amountValue = 100;
                paymentInstrument.custom.braintreeSaveCreditCard = false;
            });

            after(() => {
                paymentInstrument.custom.braintreeSaveCreditCard = true;
            });

            it('Credit card has not been saved', () => {
                expect(paymentInstrument.custom.braintreeSaveCreditCard).to.equal(false);
            });
        });

        describe('Authorize failed', () => {
            before(() => {
                amountValue = 100;

                braintreeCredit.__set__('createSaleTransactionData', () => {
                    throw new Error('Error message');
                });
            });

            after(() => {
                braintreeCredit.__ResetDependency__('createSaleTransactionData');
            });

            it('Catch error', () => {
                // eslint-disable-next-line new-cap
                const val = braintreeCredit.Authorize(orderNumber, paymentInstrument);

                expect(val).to.be.an('object');
                expect(val).to.have.property('error');
                expect(val.error).to.be.a('boolean');
                expect(val.error).to.equal(true);
            });
        });
    });
});
