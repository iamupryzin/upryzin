const { int_braintree: { applepay_form_processorPath } } = require('../path.json');
const { expect } = require('chai');
const { stub } = require('sinon');
const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});


const paymentForm = {
    paymentMethod: {
        value: 'BRAINTREE_APPLEPAY'
    }
};

const req = {
    querystring: {
        fromCart: true
    },
    httpParameterMap: {
        braintreeApplePayShippingAddress: { stringValue: '2057 Massachusetts Avenue, Fairfax, Washington DC, United States' },
        braintreeApplePayNonce: { stringValue: 'fsfssw 23wwe3 2Dsw23 wew221' },
        pageFlowCart: { stringValue: true }
    },
    session: {
        privacyCache: {
            set: (key, value) => {
                return { [key]: value };
            }
        }
    }
};

const order = { isShippingAddressUpdated: false };

const applepayFormProcessor = proxyquire(applepay_form_processorPath, {
    '~/cartridge/scripts/hooks/payment/processor/processorHelper': {
        updateShippingAddress: () => Object.assign(order, { isShippingAddressUpdated: true }),
        updateBillingForm: () => true,
        getBillingAddressFromStringValue: address => address
    }
});

describe('applepay_form_processor file', () => {
    describe('processForm', () => {
        const viewFormData = {
            paymentMethod: {
                value: null
            }
        };

        before(() => {
            stub(dw.order.BasketMgr, 'getCurrentBasket');
            dw.order.BasketMgr.getCurrentBasket.returns({
                getDefaultShipment: () => 'defaultShipment'
            });
        });

        after(() => {
            dw.order.BasketMgr.getCurrentBasket.restore();
        });

        it('response should be shipping address not updated if req.querystring is null', () => {
            req.httpParameterMap.pageFlowCart.stringValue = null;
            applepayFormProcessor.processForm(req, paymentForm, viewFormData);

            expect(order).to.have.property('isShippingAddressUpdated', false);
        });
        it('response type should be equal object', () => {
            req.httpParameterMap.pageFlowCart.stringValue = true;

            expect(applepayFormProcessor.processForm(req, paymentForm, viewFormData)).to.be.a('object');
        });
        it('response should consist property error', () => {
            expect(applepayFormProcessor.processForm(req, paymentForm, viewFormData)).has.property('error');
        });
        it('response property error type should be equal boolean', () => {
            expect(applepayFormProcessor.processForm(req, paymentForm, viewFormData).error).to.be.a('boolean');
        });
        it('response property error should be equal false', () => {
            expect(applepayFormProcessor.processForm(req, paymentForm, viewFormData).error).equal(false);
        });
        it('response should consist property viewData', () => {
            expect(applepayFormProcessor.processForm(req, paymentForm, viewFormData)).has.property('viewData');
        });
        it('response property viewData type should be equal boolean', () => {
            expect(applepayFormProcessor.processForm(req, paymentForm, viewFormData).viewData).to.be.a('object');
        });
        it('response property viewData object should consist property paymentMethod', () => {
            expect(applepayFormProcessor.processForm(req, paymentForm, viewFormData).viewData).has.property('paymentMethod');
        });
        it('response property viewData.email object should be deep equal -> { value: "BRAINTREE_APPLEPAY" }', () => {
            expect(applepayFormProcessor.processForm(req, paymentForm, viewFormData).viewData.paymentMethod).deep.equal({ value: 'BRAINTREE_APPLEPAY' });
        });
    });
});
