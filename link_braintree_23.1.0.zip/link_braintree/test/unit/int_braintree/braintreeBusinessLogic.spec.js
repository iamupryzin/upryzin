const { int_braintree: { braintreeBusinessLogicPath } } = require('../path.json');

const { it, describe, before, after, beforeEach } = require('mocha');
const { stub } = require('sinon');
const { expect } = require('chai');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');

const braintreePreferences = {
    tokenizationKey: 'custom-tokenization-key'
};

const createClientToken = stub();
const getMerchantAccountID = stub();
const findCustomer = stub();
const createCustomer = stub();
const vaultPaymentMethod = stub();
const deletePaymentMethodFromVault = stub();
const deletePaymentInstrumentFromDwCustomer = stub();
const searchTransactionsByIds = stub();
const getLastUsedPaypalPmData = stub();

const braintreeBusinessLogic = proxyquire(braintreeBusinessLogicPath, {
    'dw/system/Transaction': dw.system.Transaction,
    '~/cartridge/config/braintreePreferences': braintreePreferences,
    '~/cartridge/scripts/braintree/helpers/paymentHelper': {
        getMerchantAccountID,
        deletePaymentInstrumentFromDwCustomer,
        getLastUsedPaypalPmData,
        getLogger: () => {
            return { error: error => error };
        }
    },
    '~/cartridge/scripts/braintree/helpers/customerHelper': {
        getCustomerId: () => 'some-customer-id',
        getPhoneFromProfile: () => '321321923'
    },
    '~/cartridge/scripts/hooks/payment/processor/processorHelper': {
        createGuestCustomerData: () => {}
    },
    '~/cartridge/config/braintreeConstants': {},
    '*/cartridge/models/btGraphQLSdk': () => {
        return {
            createClientToken,
            createCustomer,
            findCustomer,
            vaultPaymentMethod,
            deletePaymentMethodFromVault,
            searchTransactionsByIds,
            legacyIdConverter: (transactionsId, type) => {
                return `${transactionsId}-test-${type}`;
            }
        };
    }
});

describe('braintreeBusinessLogic file', () => {
    describe('getClientToken', () => {
        const originalCustomer = customer;

        before(() => {
            createClientToken.withArgs({ accId: 'some-merchant-id' }).returns('client-token');
            createClientToken.withArgs({
                accId: 'some-merchant-id',
                btCustomerId: 'some-customer-id'
            }).returns('client-token-auth');

            getMerchantAccountID.returns('some-merchant-id');
        });

        after(() => {
            createClientToken.reset();
            getMerchantAccountID.reset();

            customer = originalCustomer;
        });

        it('If prefs.tokenizationKey exists and not empty string', () => {
            expect(braintreeBusinessLogic.getClientToken()).to.equal('custom-tokenization-key');
        });

        it('If prefs.tokenizationKey does not exist', () => {
            braintreePreferences.tokenizationKey = null;

            expect(braintreeBusinessLogic.getClientToken()).to.equal('client-token');
        });

        it('If customer is authenticated', () => {
            braintreePreferences.tokenizationKey = null;
            customer.authenticated = true;

            expect(braintreeBusinessLogic.getClientToken()).to.equal('client-token-auth');
        });

        it('If customer is not authenticated', () => {
            braintreePreferences.tokenizationKey = null;
            customer.authenticated = false;

            expect(braintreeBusinessLogic.getClientToken()).to.equal('client-token');
        });

        it('If error was thrown', () => {
            braintreePreferences.tokenizationKey = null;
            getMerchantAccountID.throws(Error);

            expect(braintreeBusinessLogic.getClientToken()).to.equal(null);
        });
    });

    describe('getBraintreeCustomer', () => {
        after(() => {
            findCustomer.reset();
        });

        it('If response was returned', () => {
            findCustomer.returns({});

            expect(braintreeBusinessLogic.getBraintreeCustomer()).to.deep.equal({
                error: false,
                customerData: {}
            });
        });

        it('If error was thrown', () => {
            findCustomer.throws(Error);

            expect(braintreeBusinessLogic.getBraintreeCustomer()).to.deep.equal({
                error: true,
                customerData: null
            });
        });
    });

    describe('isCustomerInVault', () => {
        after(() => {
            findCustomer.reset();
        });

        it('If response was returned with empty customer data', () => {
            expect(braintreeBusinessLogic.isCustomerInVault()).to.deep.equal({
                error: true,
                isCustomerInVault: false
            });
        });

        it('If response was returned with some customer data', () => {
            findCustomer.returns({
                firstName: 'first-name',
                lastName: 'last-name',
                email: 'email@email.com',
                company: 'epam'
            });

            expect(braintreeBusinessLogic.isCustomerInVault()).to.deep.equal({
                error: false,
                isCustomerInVault: true
            });
        });
    });

    describe('createCustomerOnBraintreeSide', () => {
        before(() => {
            stub(dw.system.Transaction, 'wrap', (callback) => callback());
            stub(customer, 'getProfile');
            customer.getProfile.returns({
                getFirstName: () => 'first-name',
                getLastName: () => 'last-name',
                getEmail: () => 'email@email.com',
                getCompanyName: () => 'epam',
                custom: {}
            });
        });

        after(() => {
            dw.system.Transaction.wrap.restore();
            customer.getProfile.restore();
            createCustomer.reset();
        });

        it('If customer was successfully created', () => {
            createCustomer.returns('customer-id');

            expect(braintreeBusinessLogic.createCustomerOnBraintreeSide()).to.equal(true);
        });

        it('If error with customMessage was thrown', () => {
            createCustomer.throws({
                customMessage: 'customMessage'
            });

            expect(braintreeBusinessLogic.createCustomerOnBraintreeSide()).to.be.an('object').to.deep.equal({
                error: 'customMessage'
            });
        });

        it('If error with message was thrown', () => {
            createCustomer.throws({
                message: 'message'
            });

            expect(braintreeBusinessLogic.createCustomerOnBraintreeSide()).to.be.an('object').to.deep.equal({
                error: 'message'
            });
        });
    });

    describe('createPaymentMethodOnBraintreeSide', () => {
        after(() => {
            vaultPaymentMethod.reset();
        });

        it('If response data was returned', () => {
            vaultPaymentMethod.returns({});

            expect(braintreeBusinessLogic.createPaymentMethodOnBraintreeSide()).to.deep.equal({});
        });

        it('If error with customMessage was thrown', () => {
            vaultPaymentMethod.throws({
                customMessage: 'customMessage'
            });

            expect(braintreeBusinessLogic.createPaymentMethodOnBraintreeSide()).to.deep.equal({
                error: 'customMessage'
            });
        });

        it('If error with message was thrown', () => {
            vaultPaymentMethod.throws({
                message: 'message'
            });

            expect(braintreeBusinessLogic.createPaymentMethodOnBraintreeSide()).to.deep.equal({
                error: 'message'
            });
        });
    });

    describe('createPaymentMethod', () => {
        before(() => {
            stub(customer, 'isRegistered');
            customer.isRegistered.returns(true);

            vaultPaymentMethod.withArgs({
                customerId: 'some-customer-id',
                paymentMethodNonce: 'braintreePaymentMethodNonce'
            })
            .returns({
                paymentMethod: {
                    legacyId: 'test-legacy-id-for-registered-customer'
                }
            });
            vaultPaymentMethod.withArgs({
                customerId: 'guest-customer-id',
                paymentMethodNonce: 'braintreePaymentMethodNonce'
            })
            .returns({
                paymentMethod: {
                    legacyId: 'test-legacy-id-for-not-registered-customer'
                }
            });

            createCustomer.returns('guest-customer-id');
        });

        after(() => {
            customer.isRegistered.restore();
            createCustomer.reset();
            vaultPaymentMethod.reset();
        });

        it('If customer is registered', () => {
            expect(braintreeBusinessLogic.createPaymentMethod('braintreePaymentMethodNonce', {})).to.equal('test-legacy-id-for-registered-customer');
        });

        it('If customer is not registered', () => {
            customer.isRegistered.returns(false);

            expect(braintreeBusinessLogic.createPaymentMethod('braintreePaymentMethodNonce', {})).to.equal('test-legacy-id-for-not-registered-customer');
        });
    });

    describe('deletePaymentMethod', () => {
        beforeEach(() => {
            deletePaymentMethodFromVault.reset();
            deletePaymentInstrumentFromDwCustomer.reset();
        });

        const paymentToDelete = {
            payment: {
                creditCardToken: 'credit-card-token'
            }
        };

        it('If error was thrown', () => {
            deletePaymentMethodFromVault.throws(Error);
            braintreeBusinessLogic.deletePaymentMethod(paymentToDelete, {});

            expect(deletePaymentInstrumentFromDwCustomer.calledOnce).to.be.false;
        });

        it('If payment method deleted successfully', () => {
            deletePaymentMethodFromVault.returns();
            braintreeBusinessLogic.deletePaymentMethod(paymentToDelete, {});

            expect(deletePaymentMethodFromVault.calledOnce).to.be.true;
            expect(deletePaymentInstrumentFromDwCustomer.calledOnce).to.be.true;
        });
    });

    describe('searchTransactionsByIds', () => {
        const orders = ['first-order', 'second-order'];

        before(() => {
            searchTransactionsByIds.returns({ success: true });
        });

        after(() => {
            searchTransactionsByIds.reset();
        });

        it('If response data returned successfully', () => {
            expect(braintreeBusinessLogic.searchTransactionsByIds(orders)).to.deep.equal({ success: true });
        });

        it('If error was thrown', () => {
            searchTransactionsByIds.throws(Error);

            expect(braintreeBusinessLogic.searchTransactionsByIds(orders)).to.deep.equal({});
        });
    });

    describe('getPaypalCustomerPmDataFromBraintree', () => {
        after(() => {
            findCustomer.reset();
            getLastUsedPaypalPmData.reset();
        });

        it('If braintreeBusinessLogic.getBraintreeCustomer returns data with error property set to true', () => {
            findCustomer.throws(Error);

            expect(braintreeBusinessLogic.getPaypalCustomerPmDataFromBraintree()).to.be.null;
        });

        it('If braintreeBusinessLogic.getBraintreeCustomer returns data with empty customerData property', () => {
            findCustomer.returns();

            expect(braintreeBusinessLogic.getPaypalCustomerPmDataFromBraintree()).to.be.null;
        });

        it('If braintreeBusinessLogic.getBraintreeCustomer returns customer without last PM', () => {
            findCustomer.returns([{
                node: {
                    paymentMethods: {
                        edges: []
                    }
                }
            }]);

            getLastUsedPaypalPmData.returns(null);

            expect(braintreeBusinessLogic.getPaypalCustomerPmDataFromBraintree()).to.be.null;
        });

        it('If braintreeBusinessLogic.getBraintreeCustomer returns customer with last PM', () => {
            findCustomer.returns([{
                node: {
                    paymentMethods: {
                        edges: []
                    }
                }
            }]);

            getLastUsedPaypalPmData.returns({
                node: {}
            });

            expect(braintreeBusinessLogic.getPaypalCustomerPmDataFromBraintree()).to.deep.equal({});
        });
    });
});
