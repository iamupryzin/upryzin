const { stub } = require('sinon');
const { expect } = require('chai');
const { describe, it, before, after } = require('mocha');

const proxyquire = require('proxyquire').noCallThru();
const { int_braintree: { paypal_form_processorPath } } = require('../path.json');

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const isSavedPaypalMethod = stub();
const getAmountPaid = stub();
const updateShippingAddress = stub();
const billingAddressHasBeenChanged = stub();
const isSessionPayPalAccountUsed = stub();
const getSavedPayPalPaymentInstrumentByUUID = stub();

const paypalFormProcessor = proxyquire(paypal_form_processorPath, {
    'dw/order/BasketMgr': dw.order.BasketMgr,
    'dw/web/Resource': dw.web.Resource,
    '~/cartridge/scripts/braintree/helpers/customerHelper': {
        getSavedPayPalPaymentInstrumentByUUID
    },
    '~/cartridge/scripts/hooks/payment/processor/processorHelper': {
        createPreferredAddressObj: (address) => address,
        updateShippingAddress,
        getBillingAddressFromStringValue: (billingAddress) => billingAddress,
        getBillingAddressFromBasket: (basket) => basket.address,
        isSessionPayPalAccountUsed,
        billingAddressHasBeenChanged,
        updateBillingAddressFileds: (address, data) => {
            data.viewData.address = address;
            return data.viewData.address;
        }
    },
    '~/cartridge/scripts/braintree/helpers/paymentHelper': {
        getAmountPaid,
        isSavedPaypalMethod
    }
});

describe('paypal_form_processor file', () => {
    before(() => {
        stub(dw.order.BasketMgr, 'getCurrentBasket');
        dw.order.BasketMgr.getCurrentBasket.returns({
            address: 'address',
            getDefaultShipment: () => 'default' });
    });

    after(() => {
        dw.order.BasketMgr.getCurrentBasket.restore();
    });

    describe('getPreferredShippingAddress', () => {
        const getPreferredShippingAddress = paypalFormProcessor.__get__('getPreferredShippingAddress');

        const req = {
            httpParameterMap: {
                braintreePaypalShippingAddress: { stringValue: '2057 Massachusetts Avenue, Fairfax, Washington DC, United States' }
            }
        };

        describe('If paypal shipping address not empty and customer.authenticated === false', () => {
            before(() => {
                customer.authenticated = false;
            });

            it('response should be equal -> string and equal to paypal shipping address', () => {
                const val = getPreferredShippingAddress(req);

                expect(val).to.be.a('string');
                expect(val).to.equal('2057 Massachusetts Avenue, Fairfax, Washington DC, United States');
            });
        });

        describe('If paypal shipping address is empty and customer.profile.addressBook.preferredAddress !== null', () => {
            before(() => {
                customer = {
                    authenticated: true,
                    profile: {
                        addressBook: {
                            preferredAddress: '4618 Beech Street, Lowndesboro, Alabama, United States'
                        }
                    },
                    getProfile: () => ({
                        getAddressBook: () => {
                            return {
                                preferredAddress: '4618 Beech Street, Lowndesboro, Alabama, United States',
                                getPreferredAddress: function () {
                                    return this.preferredAddress;
                                }
                            };
                        }
                    })
                };

                req.httpParameterMap.braintreePaypalShippingAddress.stringValue = '';
            });

            it('response should be equal -> string and equal to customer prefered address', () => {
                const val = getPreferredShippingAddress(req);
                expect(val).to.be.a('string');
                expect(val).to.equal('4618 Beech Street, Lowndesboro, Alabama, United States');
            });
        });

        describe('If paypal shipping address is empty, customer.authenticated === true and customerPreferredAddress.getPreferredAddress() === null', () => {
            before(() => {
                customer = {
                    authenticated: true,
                    profile: {
                        addressBook: {
                            preferredAddress: ''
                        }
                    },
                    getProfile: () => ({
                        getAddressBook: () => {
                            return {
                                preferredAddress: '',
                                getPreferredAddress: function () {
                                    return this.preferredAddress;
                                }
                            };
                        }
                    })
                };

                req.httpParameterMap.braintreePaypalShippingAddress.stringValue = '';
            });

            it('response should be equal -> string and equal to paypal shipping address', () => {
                const val = getPreferredShippingAddress(req);
                expect(val).to.be.a('string');
                expect(val).to.equal('');
            });
        });
    });

    describe('updateBillingForm', () => {
        const data = {
            req: {
                httpParameterMap: {
                    braintreePaypalNonce: { stringValue: null },
                    braintreePaypalBillingAddress: { stringValue: null },
                    paymentMethod: {
                        custom: {
                            braintreePaypalAccountAddresses: JSON.stringify({ pp1: 'johndoe@gmail.com' })
                        }
                    }
                }
            },
            viewData: { address: null }
        };
        const updateBillingForm = paypalFormProcessor.__get__('updateBillingForm');

        describe('if session account is used', () => {
            before(() => {
                isSessionPayPalAccountUsed.returns(true);
            });

            after(() => {
                isSessionPayPalAccountUsed.returns(false);
            });

            describe('and if billing address is changed', () => {
                before(() => {
                    billingAddressHasBeenChanged.returns(true);
                });

                after(() => {
                    billingAddressHasBeenChanged.reset();
                    data.viewData.address = null;
                });

                it('viewData property address should be equal to a string "address"', () => {
                    updateBillingForm(data);
                    expect(data.viewData).have.property('address').that.equals('address');
                });
            });

            describe('and if billing address isn\'t changed', () => {
                before(() => {
                    billingAddressHasBeenChanged.returns(false);
                });

                after(() => {
                    billingAddressHasBeenChanged.reset();
                });

                it('viewData property address should be null', () => {
                    updateBillingForm(data);
                    expect(data.viewData).have.property('address').that.is.null;
                });
            });
        });

        describe('if session account isn\'t used', () => {
            describe('and if there\'s a customerPaymentInstrument', () => {
                before(() => {
                    getSavedPayPalPaymentInstrumentByUUID.returns(data.req.httpParameterMap.paymentMethod);
                });

                after(() => {
                    getSavedPayPalPaymentInstrumentByUUID.reset();
                    data.viewData.address = null;
                });

                it('viewDate property address should be an object { pp1: "johndoe@gmail.com" }', () => {
                    updateBillingForm(data);
                    expect(data.viewData).have.property('address').that.deep.equals({ pp1: 'johndoe@gmail.com' });
                });
            });

            describe('and if there\'s no customerPaymentInstrument', () => {
                before(() => {
                    getSavedPayPalPaymentInstrumentByUUID.returns(null);
                });

                after(() => {
                    getSavedPayPalPaymentInstrumentByUUID.reset();
                });

                it('viewData property address should be null', () => {
                    updateBillingForm(data);
                    expect(data.viewData).have.property('address').that.is.null;
                });
            });
        });
    });

    describe('processForm', () => {
        const req = {
            httpParameterMap: {
                braintreePaypalNonce: { stringValue: null },
                braintreePaypalShippingAddress: { stringValue: null },
                expressCheckoutFlow: { stringValue: null }
            },
            session: {
                privacyCache: {
                    set: (key, value) => {
                        return { [key]: value };
                    }
                }
            }
        };
        const paymentForm = {
            paymentMethod: { value: 'BRAINTREE_PAYPAL' }
        };
        const viewFormData = {
            paymentMethod: { value: null }
        };

        describe('If currentBasketAmount !== 0', () => {
            before(() => {
                getAmountPaid.returns({ value: 10000 });
                paypalFormProcessor.__set__('updateBillingForm', () => true);
            });

            after(() => {
                getAmountPaid.reset();
                paypalFormProcessor.__ResetDependency__('updateBillingForm');
            });

            it('response type should be an object', () => {
                expect(paypalFormProcessor.processForm(req, paymentForm, viewFormData)).to.be.a('object');
            });

            it('response should include property error', () => {
                expect(paypalFormProcessor.processForm(req, paymentForm, viewFormData)).has.property('error');
            });

            it('response should include property viewData', () => {
                expect(paypalFormProcessor.processForm(req, paymentForm, viewFormData)).has.property('viewData');
            });

            it('response property error type should be equal boolean', () => {
                expect(paypalFormProcessor.processForm(req, paymentForm, viewFormData).error).to.be.a('boolean');
            });

            it('response property viewData type should be equal object', () => {
                expect(paypalFormProcessor.processForm(req, paymentForm, viewFormData).viewData).to.be.a('object');
            });

            it('response property error should be equal false', () => {
                expect(paypalFormProcessor.processForm(req, paymentForm, viewFormData).error).equal(false);
            });
        });

        describe('If currentBasketAmount === 0', () => {
            before(() => {
                getAmountPaid.returns({ value: 0 });
                paypalFormProcessor.__set__('updateBillingForm', () => true);
            });

            after(() => {
                getAmountPaid.reset();
                paypalFormProcessor.__ResetDependency__('updateBillingForm');
            });

            it('response type should be an object', () => {
                expect(paypalFormProcessor.processForm(req, paymentForm, viewFormData)).to.be.a('object');
            });

            it('response should include property error', () => {
                expect(paypalFormProcessor.processForm(req, paymentForm, viewFormData)).has.property('error');
            });

            it('response should include property fieldErrors', () => {
                expect(paypalFormProcessor.processForm(req, paymentForm, viewFormData)).has.property('fieldErrors');
            });

            it('response should include property serverErrors', () => {
                expect(paypalFormProcessor.processForm(req, paymentForm, viewFormData)).has.property('serverErrors');
            });

            it('response property error type should be equal boolean', () => {
                expect(paypalFormProcessor.processForm(req, paymentForm, viewFormData).error).to.be.a('boolean');
            });
        });

        describe('If fromCart value is passed within the request', () => {
            before(() => {
                getAmountPaid.returns({ value: 10 });
                req.querystring = { fromCart: true };
                updateShippingAddress.returns(Object.assign(viewFormData, { shippingAddress: 'preferred' }));
                paypalFormProcessor.__set__('updateBillingForm', () => true);
            });

            after(() => {
                getAmountPaid.reset();
                req.querystring = null;
                updateShippingAddress.reset();
                paypalFormProcessor.__ResetDependency__('updateBillingForm');
            });

            it('response type should contain shipping address in the viewData object', () => {
                expect(paypalFormProcessor.processForm(req, paymentForm, viewFormData).viewData).has.property('shippingAddress');
            });
        });
    });
});
