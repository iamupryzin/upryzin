const { int_braintree: { googlePayButtonConfigsPath } } = require('../path.json');
const { expect } = require('chai');
const { it, describe } = require('mocha');

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const proxyquire = require('proxyquire').noCallThru();

const googlePayButtonConfigs = proxyquire(googlePayButtonConfigsPath, {
    'dw/system/Site': {
        current: {
            getCustomPreferenceValue: () => '{"billing":"billingStyle", "cart":"cartStyle"}'
        }
    }
});

describe('googlePayButtonConfigs file', () => {
    it('object must has GOOGLEPAY_Billing_Button_Config property', () => {
        expect(googlePayButtonConfigs).has.property('GOOGLEPAY_Billing_Button_Config');
    });

    it('styles must be for a billing button', () => {
        expect(googlePayButtonConfigs.GOOGLEPAY_Billing_Button_Config).to.be.equal('billingStyle');
    });

    it('object must has GOOGLEPAY_Cart_Button_Config property', () => {
        expect(googlePayButtonConfigs).has.property('GOOGLEPAY_Cart_Button_Config');
    });

    it('styles must be for a cart button', () => {
        expect(googlePayButtonConfigs.GOOGLEPAY_Cart_Button_Config).to.be.equal('cartStyle');
    });
});
