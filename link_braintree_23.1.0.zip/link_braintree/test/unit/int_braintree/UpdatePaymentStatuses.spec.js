const { expect } = require('chai');
const { int_braintree: { UpdatePaymentStatusesPath } } = require('../path.json');
const { it, describe, before, after, afterEach } = require('mocha');
const { stub } = require('sinon');

const proxyquire = require('proxyquire').noCallThru();


require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const searchTransactionsByIds = stub();
const hasNext = stub();

function Status() {
    this.obj = 'status';
    return this;
}

const transactions = [{
    node: {
        legacyId: 0, status: 'ok'
    }
},
{
    node: {
        legacyId: 5, status: 'ok'
    }
}];

const order = {
    custom: {
        braintreePaymentStatus: ''
    }
};

const UpdatePaymentStatuses = proxyquire(UpdatePaymentStatusesPath, {
    'dw/system': dw.system,
    'dw/order': dw.order,
    'dw/system/Status': Status,
    'dw/system/Transaction': dw.system.Transaction,
    'dw/order/Order': dw.order.Order,
    'dw/object/SystemObjectMgr': dw.object.SystemObjectMgr,
    '~/cartridge/scripts/braintree/braintreeAPI/braintreeBusinessLogic': {
        searchTransactionsByIds: searchTransactionsByIds
    },
    '~/cartridge/scripts/braintree/helpers/paymentHelper': {
        getBraintreePaymentInstrument: () => ({
            getPaymentTransaction: () => ({
                getTransactionID: () => {}
            })
        })
    }
});

describe('int_UpdatePaymentStatuses', () => {
    describe('updateOrders', () => {
        const updateOrders = UpdatePaymentStatuses.__get__('updateOrders');

        before(() => {
            searchTransactionsByIds.returns(transactions);
        });

        afterEach(() => {
            order.custom.braintreePaymentStatus = '';
        });

        after(() => {
            searchTransactionsByIds.reset();
        });

        it('orders statuses must be changed to ok', () => {
            updateOrders([order]);

            expect(order.custom.braintreePaymentStatus).to.be.equal('ok');
        });

        it('if no such order in transaction it`s status must not change', () => {
            updateOrders([{ custom: { braintreePaymentStatus: '' } }, order]);

            expect(order.custom.braintreePaymentStatus).to.be.equal('');
        });

        it('if transactions have an error', () => {
            searchTransactionsByIds.returns({ error: 'error' });

            expect(updateOrders([order])).to.be.undefined;
        });
    });

    describe('execute', () => {
        before(() => {
            stub(dw.object.SystemObjectMgr, 'querySystemObjects');
            dw.object.SystemObjectMgr.querySystemObjects.returns({
                hasNext: hasNext,
                next: () => order
            });
            searchTransactionsByIds.returns(transactions);
        });

        after(() => {
            dw.object.SystemObjectMgr.querySystemObjects.restore();
            searchTransactionsByIds.reset();
        });

        it('it must execute without any errors and return instance of Status object', () => {
            hasNext.onCall(30).returns(false);
            hasNext.returns(true);

            expect(UpdatePaymentStatuses.execute()).to.be.an.instanceOf(Status);
        });
    });
});

