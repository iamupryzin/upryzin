const { expect } = require('chai');
const { int_braintree: { paymentConfigHelperPath } } = require('../path.json');

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const prefs = {
    vaultMode: true,
    paypalOrderIntent: false,
    paymentMethods: {
        BRAINTREE_PAYPAL: { paymentMethodId: 'BRAINTREE_PAYPAL' },
        BRAINTREE_VENMO: { paymentMethodId: 'BRAINTREE_VENMO' }
    }
};

const paymentConfigHelper = require('proxyquire').noCallThru()(paymentConfigHelperPath, {
    '~/cartridge/config/braintreePreferences': prefs,
    '~/cartridge/scripts/braintree/helpers/paymentHelper': {
        getApplicableCreditCardPaymentInstruments: () => {
            return [
                { custom: { braintreeDefaultCard: 'BRAINTREE_CREDITCARD' } }
            ];
        }
    },
    '~/cartridge/scripts/braintree/helpers/customerHelper': {
        getCustomerPaymentInstruments: paymentInstrument => paymentInstrument,
        isBasketPaymentInstrEqualSavedPayPalAccount: () => false
    }
});

describe('paymentConfigHelper file', () => {
    describe('isBraintreeDefaultCard', () => {
        const isBraintreeDefaultCard = paymentConfigHelper.__get__('isBraintreeDefaultCard');
        const customerPaymentInstruments = {
            PI: [],
            iterator: function () {
                return new dw.util.Iterator(this.PI);
            }
        };

        after(() => {
            customer.authenticated = false;
            customerPaymentInstruments.PI = [];
        });

        it('response should be false if customer isn\'t authenticated', () => {
            expect(isBraintreeDefaultCard(customerPaymentInstruments)).be.false;
        });

        it('response should be false if customer is authenticated but no payment intruments', () => {
            customer.authenticated = true;

            expect(isBraintreeDefaultCard(customerPaymentInstruments)).to.be.false;
        });

        it('response should be true if customer is authenticated and there\'s payment intrument', () => {
            customerPaymentInstruments.PI.push({ custom: {} });

            expect(isBraintreeDefaultCard(customerPaymentInstruments)).to.be.false;
        });

        it('response should be true if customer is authenticated and there\'s payment intrument & it has property custom.braintreeDefaultCard', () => {
            customerPaymentInstruments.PI[0].custom = { braintreeDefaultCard: true };

            expect(isBraintreeDefaultCard(customerPaymentInstruments)).to.be.true;
        });
    });

    describe('createGeneralPaymentConfig', () => {
        let paymentMethods;
        const createGeneralPaymentConfig = paymentConfigHelper.__get__('createGeneralPaymentConfig');

        describe('If paymentMethods === null', () => {
            const responseObj = {
                braintreePaymentMethodNonce: '',
                newAccountSelected: true,
                isNeedHideContinueButton: true
            };
            before(() => {
                paymentMethods = [];
            });
            it('response type should be equal -> object', () => {
                expect(createGeneralPaymentConfig(paymentMethods)).to.be.a('object');
            });
            it('response should be deep equal -> responseObj', () => {
                expect(createGeneralPaymentConfig(paymentMethods)).deep.equal(responseObj);
            });
        });

        describe('If paymentMethods !== null', () => {
            const responseObj = {
                braintreePaymentMethodNonce: 'cv3Er4-34eR4r-SD43er-SD3443',
                newAccountSelected: true,
                isNeedHideContinueButton: false
            };
            before(() => {
                paymentMethods = [{ custom: { braintreePaymentMethodNonce: 'cv3Er4-34eR4r-SD43er-SD3443' } }];
            });
            it('response type should be equal -> object', () => {
                expect(createGeneralPaymentConfig(paymentMethods)).to.be.a('object');
            });
            it('response should be deep equal -> responseObj', () => {
                expect(createGeneralPaymentConfig(paymentMethods)).deep.equal(responseObj);
            });
        });
    });

    describe('createGooglepayConfig', () => {
        let paymentMethods;

        describe('If paymentMethods === null', () => {
            const responseObj = {
                braintreeGooglePayCardDescription: '',
                isNeedHideGooglepayButton: false,
                isSaveSessionAccount: false
            };
            before(() => {
                paymentMethods = [];
                paymentConfigHelper.__set__('createGeneralPaymentConfig', () => {
                    return {};
                });
            });
            after(() => {
                paymentConfigHelper.__ResetDependency__('createGeneralPaymentConfig');
            });

            it('response type should be equal -> object', () => {
                expect(paymentConfigHelper.createGooglepayConfig(paymentMethods)).to.be.a('object');
            });
            it('response should be deep equal -> responseObj', () => {
                expect(paymentConfigHelper.createGooglepayConfig(paymentMethods)).deep.equal(responseObj);
            });
        });

        describe('If paymentMethods !== null', () => {
            const responseObj = {
                braintreeGooglePayCardDescription: '4578-3788-1254-1254',
                isNeedHideGooglepayButton: true,
                isSaveSessionAccount: true
            };
            before(() => {
                paymentMethods = [{ custom: { braintreeGooglePayCardDescription: '4578-3788-1254-1254', braintreeSaveCreditCard: true } }];
                paymentConfigHelper.__set__('createGeneralPaymentConfig', () => {
                    return {};
                });
            });
            after(() => {
                paymentConfigHelper.__ResetDependency__('createGeneralPaymentConfig');
            });

            it('response type should be equal -> object', () => {
                expect(paymentConfigHelper.createGooglepayConfig(paymentMethods)).to.be.a('object');
            });
            it('response should be deep equal -> responseObj', () => {
                expect(paymentConfigHelper.createGooglepayConfig(paymentMethods)).deep.equal(responseObj);
            });
        });
    });

    describe('createSrcConfig', () => {
        let paymentMethods;

        describe('', () => {
            before(() => {
                paymentConfigHelper.__set__('createGeneralPaymentConfig', () => {
                    return {};
                });
            });
            after(() => {
                paymentConfigHelper.__ResetDependency__('createGeneralPaymentConfig');
            });

            describe('If paymentMethods === null', () => {
                const responseObj = {
                    braintreeSrcCardDescription: '',
                    isSaveSessionAccount: false,
                    sessionAccount: null
                };
                before(() => {
                    paymentMethods = [];
                });

                it('response type should be equal -> object', () => {
                    expect(paymentConfigHelper.createSrcConfig(paymentMethods)).to.be.a('object');
                });
                it('response should be deep equal -> responseObj', () => {
                    expect(paymentConfigHelper.createSrcConfig(paymentMethods)).deep.equal(responseObj);
                });
            });

            describe('If paymentMethods !== null', () => {
                const responseObj = {
                    braintreeSrcCardDescription: '4578-3788-1254-1254',
                    isSaveSessionAccount: true,
                    sessionAccount: {
                        custom: {
                            braintreeSaveCreditCard: true,
                            braintreeSrcCardDescription: '4578-3788-1254-1254'
                        }
                    }
                };
                before(() => {
                    paymentMethods = [{ custom: { braintreeSrcCardDescription: '4578-3788-1254-1254', braintreeSaveCreditCard: true } }];
                });
                after(() => {
                    paymentMethods = [];
                });

                it('response type should be equal -> object', () => {
                    expect(paymentConfigHelper.createSrcConfig(paymentMethods)).to.be.a('object');
                });
                it('response should be deep equal -> responseObj', () => {
                    expect(paymentConfigHelper.createSrcConfig(paymentMethods)).deep.equal(responseObj);
                });
            });
        });
    });

    describe('createCreditCardConfig', () => {
        let paymentMethods;

        describe('If paymentMethods === null and customer.authenticated === false', () => {
            const responseObj = {
                sessionAccount: null,
                customerSavedCreditCards: [],
                newCardSelected: false,
                braintreePaymentMethodNonce: ''
            };
            before(() => {
                paymentMethods = [];
                customer.authenticated = false;
            });

            it('response type should be equal -> object', () => {
                expect(paymentConfigHelper.createCreditCardConfig(paymentMethods)).to.be.a('object');
            });
            it('response should be deep equal -> responseObj', () => {
                expect(paymentConfigHelper.createCreditCardConfig(paymentMethods)).deep.equal(responseObj);
            });
        });

        describe('If paymentMethods !== null and customer.authenticated === false', () => {
            const responseObj = {
                sessionAccount: { custom: { braintreePaymentMethodNonce: 'cv3Er4-34eR4r-SD43er-SD3443' } },
                customerSavedCreditCards: [],
                newCardSelected: true,
                braintreePaymentMethodNonce: 'cv3Er4-34eR4r-SD43er-SD3443'
            };
            before(() => {
                paymentMethods = [{ custom: { braintreePaymentMethodNonce: 'cv3Er4-34eR4r-SD43er-SD3443' } }];
                customer.authenticated = false;
            });

            it('response type should be equal -> object', () => {
                expect(paymentConfigHelper.createCreditCardConfig(paymentMethods)).to.be.a('object');
            });
            it('response should be deep equal -> responseObj', () => {
                expect(paymentConfigHelper.createCreditCardConfig(paymentMethods)).deep.equal(responseObj);
            });
        });

        describe('If paymentMethods === null and customer.authenticated === true', () => {
            const responseObj = {
                sessionAccount: null,
                customerSavedCreditCards: [{ custom: { braintreeDefaultCard: 'BRAINTREE_CREDITCARD' } }],
                newCardSelected: false,
                braintreePaymentMethodNonce: ''
            };
            before(() => {
                paymentMethods = [];
                customer.authenticated = true;
            });

            it('response type should be equal -> object', () => {
                expect(paymentConfigHelper.createCreditCardConfig(paymentMethods)).to.be.a('object');
            });
            it('response should be deep equal -> responseObj', () => {
                expect(paymentConfigHelper.createCreditCardConfig(paymentMethods)).deep.equal(responseObj);
            });
        });

        describe('If paymentMethods !== null and customer.authenticated === true', () => {
            const responseObj = {
                sessionAccount: { custom: { braintreePaymentMethodNonce: 'cv3Er4-34eR4r-SD43er-SD3443' } },
                customerSavedCreditCards: [{ custom: { braintreeDefaultCard: 'BRAINTREE_CREDITCARD' } }],
                newCardSelected: false,
                braintreePaymentMethodNonce: 'cv3Er4-34eR4r-SD43er-SD3443'
            };
            before(() => {
                paymentMethods = [{ custom: { braintreePaymentMethodNonce: 'cv3Er4-34eR4r-SD43er-SD3443' } }];
                customer.authenticated = true;
            });

            it('response type should be equal -> object', () => {
                expect(paymentConfigHelper.createCreditCardConfig(paymentMethods)).to.be.a('object');
            });
            it('response should be deep equal -> responseObj', () => {
                expect(paymentConfigHelper.createCreditCardConfig(paymentMethods)).deep.equal(responseObj);
            });
        });
    });

    describe('createPaypalConfig', () => {
        let paymentMethods;
        before(() => {
            paymentConfigHelper.__set__('createGeneralPaymentConfig', () => {
                return {
                    isNeedHideContinueButton: true,
                    newAccountSelected: true
                };
            });
        });
        after(() => {
            paymentConfigHelper.__ResetDependency__('createGeneralPaymentConfig');
        });

        describe('If paymentMethods === null, isDefaultCard === false, customer.authenticated === false', () => {
            const responseObj = {
                isNeedHideContinueButton: true,
                newAccountSelected: true,
                isShowCheckbox: false,
                braintreePaypalEmail: '',
                isSaveSessionAccount: false,
                customerPaypalPaymentInstruments: 'BRAINTREE_PAYPAL',
                isBasketPaymentInstrEqualSavedPayPalAccount: false
            };
            before(() => {
                paymentMethods = [];
                customer.authenticated = false;
                paymentConfigHelper.__set__('isBraintreeDefaultCard', () => {
                    return false;
                });
            });
            after(() => {
                paymentConfigHelper.__ResetDependency__('isBraintreeDefaultCard');
            });

            it('response type should be equal -> object', () => {
                expect(paymentConfigHelper.createPaypalConfig(paymentMethods)).to.be.a('object');
            });
            it('response should be deep equal -> responseObj', () => {
                expect(paymentConfigHelper.createPaypalConfig(paymentMethods)).deep.equal(responseObj);
            });
        });

        describe('If paymentMethods !== null, isDefaultCard === false, customer.authenticated === true', () => {
            const responseObj = {
                isNeedHideContinueButton: true,
                newAccountSelected: true,
                isShowCheckbox: true,
                braintreePaypalEmail: 'jj@gmail.com',
                isSaveSessionAccount: true,
                customerPaypalPaymentInstruments: 'BRAINTREE_PAYPAL',
                isBasketPaymentInstrEqualSavedPayPalAccount: false
            };
            before(() => {
                paymentMethods = [{ custom: { braintreePaypalEmail: 'jj@gmail.com', braintreeSaveCreditCard: true } }];
                customer.authenticated = true;
                paymentConfigHelper.__set__('isBraintreeDefaultCard', () => {
                    return false;
                });
            });
            after(() => {
                paymentConfigHelper.__ResetDependency__('isBraintreeDefaultCard');
            });

            it('response type should be equal -> object', () => {
                expect(paymentConfigHelper.createPaypalConfig(paymentMethods)).to.be.a('object');
            });
            it('response should be deep equal -> responseObj', () => {
                expect(paymentConfigHelper.createPaypalConfig(paymentMethods)).deep.equal(responseObj);
            });
        });

        describe('If paymentMethods !== null, isDefaultCard === false, customer.authenticated === true', () => {
            const responseObj = {
                isNeedHideContinueButton: false,
                newAccountSelected: false,
                isShowCheckbox: true,
                braintreePaypalEmail: 'jj@gmail.com',
                isSaveSessionAccount: true,
                customerPaypalPaymentInstruments: 'BRAINTREE_PAYPAL',
                isBasketPaymentInstrEqualSavedPayPalAccount: false
            };
            before(() => {
                paymentMethods = [{ custom: { braintreePaypalEmail: 'jj@gmail.com', braintreeSaveCreditCard: true } }];
                customer.authenticated = true;
                paymentConfigHelper.__set__('isBraintreeDefaultCard', () => {
                    return true;
                });
            });
            after(() => {
                paymentConfigHelper.__ResetDependency__('isBraintreeDefaultCard');
            });

            it('response type should be equal -> object', () => {
                expect(paymentConfigHelper.createPaypalConfig(paymentMethods)).to.be.a('object');
            });
            it('response should be deep equal -> responseObj', () => {
                expect(paymentConfigHelper.createPaypalConfig(paymentMethods)).deep.equal(responseObj);
            });
        });
    });

    describe('createVenmoConfig', () => {
        let paymentMethods;

        before(() => {
            paymentConfigHelper.__set__('createGeneralPaymentConfig', () => {
                return {
                    isNeedHideContinueButton: true,
                    newAccountSelected: true
                };
            });
        });
        after(() => {
            paymentConfigHelper.__ResetDependency__('createGeneralPaymentConfig');
        });

        describe('If paymentMethods === null, isDefaultCard === false, customer.authenticated === false', () => {
            const responseObj = {
                isNeedHideContinueButton: true,
                newAccountSelected: true,
                braintreeVenmoUserId: '',
                isNeedHideVenmoButton: false,
                customerVenmoPaymentInstruments: 'BRAINTREE_VENMO'
            };
            before(() => {
                paymentMethods = [];
                customer.authenticated = false;
                paymentConfigHelper.__set__('isBraintreeDefaultCard', () => {
                    return false;
                });
            });
            after(() => {
                paymentConfigHelper.__ResetDependency__('isBraintreeDefaultCard');
            });

            it('response type should be equal -> object', () => {
                expect(paymentConfigHelper.createVenmoConfig(paymentMethods)).to.be.a('object');
            });
            it('response should be deep equal -> responseObj', () => {
                expect(paymentConfigHelper.createVenmoConfig(paymentMethods)).deep.equal(responseObj);
            });
        });

        describe('If paymentMethods !== null, isDefaultCard === false, customer.authenticated === true', () => {
            const responseObj = {
                isNeedHideContinueButton: true,
                newAccountSelected: true,
                braintreeVenmoUserId: 'jj0821',
                isNeedHideVenmoButton: true,
                customerVenmoPaymentInstruments: 'BRAINTREE_VENMO'
            };
            before(() => {
                paymentMethods = [{ custom: { braintreeVenmoUserId: 'jj0821' } }];
                customer.authenticated = true;
                paymentConfigHelper.__set__('isBraintreeDefaultCard', () => {
                    return false;
                });
            });
            after(() => {
                paymentConfigHelper.__ResetDependency__('isBraintreeDefaultCard');
            });

            it('response type should be equal -> object', () => {
                expect(paymentConfigHelper.createVenmoConfig(paymentMethods)).to.be.a('object');
            });
            it('response should be deep equal -> responseObj', () => {
                expect(paymentConfigHelper.createVenmoConfig(paymentMethods)).deep.equal(responseObj);
            });
        });

        describe('If paymentMethods !== null, isDefaultCard === false, customer.authenticated === true', () => {
            const responseObj = {
                isNeedHideContinueButton: false,
                newAccountSelected: false,
                braintreeVenmoUserId: 'jj0821',
                isNeedHideVenmoButton: true,
                customerVenmoPaymentInstruments: 'BRAINTREE_VENMO'
            };
            before(() => {
                paymentMethods = [{ custom: { braintreeVenmoUserId: 'jj0821' } }];
                customer.authenticated = true;
                paymentConfigHelper.__set__('isBraintreeDefaultCard', () => {
                    return true;
                });
            });
            after(() => {
                paymentConfigHelper.__ResetDependency__('isBraintreeDefaultCard');
            });

            it('response type should be equal -> object', () => {
                expect(paymentConfigHelper.createVenmoConfig(paymentMethods)).to.be.a('object');
            });
            it('response should be deep equal -> responseObj', () => {
                expect(paymentConfigHelper.createVenmoConfig(paymentMethods)).deep.equal(responseObj);
            });
        });
    });
});
