const { expect } = require('chai');
const { int_braintree: { SRCButtonConfigPath } } = require('../path.json');
const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');

const SRCButtonConfig = proxyquire(SRCButtonConfigPath, {});

describe('SRCButtonConfig', () => {
    it('response type should be object', () => {
        expect(SRCButtonConfig).to.be.a('object');
    });
    it('response object should has property -> SRC_Billing_Button_Config', () => {
        expect(SRCButtonConfig).has.property('SRC_Billing_Button_Config');
    });
    it('response object should has property -> SRC_Cart_Button_Config', () => {
        expect(SRCButtonConfig).has.property('SRC_Cart_Button_Config');
    });
    it('response object should has property -> SRC_Account_Button_Config', () => {
        expect(SRCButtonConfig).has.property('SRC_Account_Button_Config');
    });
    it('response should consist property cardBrands and be equal -> VISA,MASTERCARD,AMEX ', () => {
        expect(SRCButtonConfig.SRC_Billing_Button_Config.style.cardBrands).equal('VISA,MASTERCARD,AMEX');
    });
});
