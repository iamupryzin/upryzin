const { describe, it, before, after } = require('mocha');
const { expect } = require('chai');

const { int_braintree: { postAuthorizationHandlingPath } } = require('../path.json');

require('dw-api-mock/demandware-globals');

const postAuthorizationHandling = require('proxyquire').noCallThru()(postAuthorizationHandlingPath, {
    '*/cartridge/models/btGraphQLSdk': function () {
        return this;
    },
    '~/cartridge/scripts/braintree/helpers/paymentHelper': {
        getBraintreePaymentInstrument: () => {}
    }
});

describe('postAuthorizationHandling file', () => {
    const order = {
        customerEmail: null,
        customer: {
            authenticated: true
        },
        paymentTransaction: {
            accountID: null
        },
        shipments: [
            {
                shippingAddress: {
                    firstName: null,
                    lastName: null,
                    phone: null
                }
            }
        ]
    };
    const options = {};

    describe('If result.error !== true', () => {
        const result = {
            error: false
        };

        it('response type should be equal -> object', () => {
            expect(postAuthorizationHandling.postAuthorization(result, order, options)).to.be.a('object').that.is.empty;
        });
    });

    describe('If result.error === true and session.privacy.braintreeErrorMsg === Error message', () => {
        const result = {
            error: true
        };

        before(() => {
            session.privacy = {
                braintreeErrorMsg: 'Error message'
            };
        });

        after(() => {
            session.privacy = {
                braintreeErrorMsg: null
            };
        });

        it('response type should be an object & session.privacy.braintreeErrorMsg should be set to null', () => {
            expect(postAuthorizationHandling.postAuthorization(result, order, options)).to.deep.equal({
                error: true,
                errorStage: {
                    stage: 'payment',
                    step: 'paymentInstrument'
                },
                errorMessage: 'Error message'
            });
            expect(session.privacy.braintreeErrorMsg).to.be.null;
        });
    });
});
