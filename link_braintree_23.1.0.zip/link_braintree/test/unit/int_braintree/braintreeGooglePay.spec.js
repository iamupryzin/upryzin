const { stub } = require('sinon');
const { expect } = require('chai');
const { describe, it, before, after } = require('mocha');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');

require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const { int_braintree: { braintreeGooglePayPath } } = require('../path.json');
const prefs = {
    vaultMode: false,
    paymentMethods: { BRAINTREE_GOOGLEPAY: { paymentMethodId: 'GOOGLEPAY' } }
};

const braintreeGooglePay = proxyquire(braintreeGooglePayPath, {
    'server': {},
    'dw/web/Resource': dw.web.Resource,
    'dw/order/PaymentMgr': dw.order.PaymentMgr,
    'dw/system/Transaction': dw.system.Transaction,
    '~/cartridge/config/braintreePreferences': prefs,
    '~/cartridge/scripts/braintree/helpers/paymentHelper': {
        deleteBraintreePaymentInstruments: () => {},
        getAmountPaid: () => {},
        handleErrorCode: () => {},
        getLogger: () => {
            return { error: (error) => error };
        }
    },
    '~/cartridge/scripts/hooks/payment/processor/processorHelper': {
        saveGeneralTransactionData: () => {},
        createBaseSaleTransactionData: () => {
            return {
                options: {}
            };
        },
        verifyTransactionStatus: () => {},
        getBillingAddressFromStringValue: () => {
            return {};
        },
        createTransactionBillingAddress: () => {
            return {};
        }
    },
    '*/cartridge/models/btGraphQLSdk': () => {
        return {
            createTransaction: () => {
                return {
                    transaction: {
                        paymentMethod: { legacyId: 'token' },
                        customer: { id: 'customerId' }
                    }
                };
            }
        };
    }
});

describe('BraintreeGooglePay File', () => {
    describe('createSaleTransactionData', () => {
        const order = {};
        const paymentInstrument = {
            creditCardToken: '',
            custom: {
                braintreeFraudRiskData: 'FraudRiskData',
                braintreePaymentMethodNonce: ''
            }
        };

        const createSaleTransactionData = braintreeGooglePay.__get__('createSaleTransactionData');

        it('Nonce and token are empty', () => {
            expect(() => createSaleTransactionData(order, paymentInstrument)).to.throw(Error, /^paymentInstrument.custom.braintreePaymentMethodNonce or paymentInstrument.creditCardToken are empty$/);
        });

        it('Sales transaction data created successfully', () => {
            paymentInstrument.creditCardToken = 'token';
            paymentInstrument.custom.braintreePaymentMethodNonce = 'nonce';
            paymentInstrument.custom.braintreePaymentMethodBillingAddress = ' billingAddress';

            const val = createSaleTransactionData(order, paymentInstrument);

            expect(val).to.be.an('object');
            expect(val).to.have.property('deviceData');
            expect(val.deviceData).to.equal(paymentInstrument.custom.braintreeFraudRiskData);
        });
    });

    describe('authorizeFailedFlow', () => {
        const orderRecord = { custom: { isBraintree: null } };
        const paymentInstrumentRecord = { custom: { braintreeFailReason: '' } };

        let braintreeError = '';

        const authorizeFailedFlow = braintreeGooglePay.__get__('authorizeFailedFlow');

        it('Error message not set', () => {
            const val = authorizeFailedFlow(orderRecord, paymentInstrumentRecord, braintreeError);

            expect(val).to.be.an('object');
            expect(val.error).to.be.true;

            expect(orderRecord.custom.isBraintree).to.be.true;
        });

        it('Error message is set', () => {
            braintreeError = 'error';

            const val = authorizeFailedFlow(orderRecord, paymentInstrumentRecord, braintreeError);

            expect(val).to.be.an('object');
            expect(val.error).to.be.true;

            expect(orderRecord.custom.isBraintree).to.be.true;
            expect(paymentInstrumentRecord.custom.braintreeFailReason).to.equal(braintreeError);
        });
    });

    describe('Handle', () => {
        const originalSession = session;
        const originalHttpParameterMap = request.httpParameterMap;

        before(() => {
            session = {
                privacy: { googlepayPaymentType: null },
                forms: { billing: { paymentMethod: { value: 'GooglePay' } } }
            };

            request.httpParameterMap = {
                braintreeGooglePayNonce: { stringValue: 'nonce' },
                braintreeGooglepayPaymentType: { stringValue: 'GooglePay' },
                braintreeGooglePayCardDescription: { stringValue: 'GooglePay description' },
                braintreeGooglePayDeviceDataInput: { stringValue: 'device data' },
                braintreeGooglePayBillingAddress: { stringValue: 'billingAddress' }
            };

            stub(dw.order.PaymentMgr, 'getPaymentMethod').returns({
                getPaymentProcessor: () => { return {}; }
            });
        });

        after(() => {
            session = originalSession;
            request.httpParameterMap = originalHttpParameterMap;

            dw.order.PaymentMgr.getPaymentMethod.restore();
        });

        const basket = {
            createPaymentInstrument: () => {
                return {
                    custom: {
                        braintreeFraudRiskData: '',
                        braintreePaymentMethodNonce: '',
                        braintreeGooglePayCardDescription: '',
                        braintreePaymentMethodBillingAddress: ''
                    },
                    paymentTransaction: { setPaymentProcessor: () => {} }
                };
            }
        };

        it('Create payment instrument', () => {
            // eslint-disable-next-line new-cap
            const val = braintreeGooglePay.Handle(basket);

            expect(val).to.be.an('object');
            expect(val).to.deep.equal({ success: true });

            expect(session.privacy.googlepayPaymentType).to.equal(request.httpParameterMap.braintreeGooglepayPaymentType.stringValue);
        });

        it('Create payment instrument even if there\'s no braintreeGooglePayCardDescription', () => {
            request.httpParameterMap.braintreeGooglePayCardDescription.stringValue = null;

            // eslint-disable-next-line new-cap
            expect(braintreeGooglePay.Handle(basket)).to.have.property('success', true);
        });

        it('Nonce not specified', () => {
            request.httpParameterMap.braintreeGooglePayNonce.stringValue = '';

            // eslint-disable-next-line new-cap
            const val = braintreeGooglePay.Handle(basket);

            expect(val).to.be.an('object');
            expect(val).to.have.all.keys('error', 'fieldErrors', 'serverErrors');
            expect(val.error).to.be.true;
            expect(val.fieldErrors).to.be.an('array').that.is.empty;
            expect(val.serverErrors).to.be.an('array').that.have.lengthOf(1);
        });
    });

    describe('Authorize', () => {
        const orderNumber = '00000001';
        let amountValue = 100;
        const paymentInstrument = {
            creditCardToken: null,
            paymentTransaction: {},
            getPaymentTransaction: () => {
                return {
                    getAmount: () => {
                        return { getValue: () => amountValue };
                    },
                    setPaymentProcessor: () => {}
                };
            },
            custom: {
                braintreePaymentMethodBillingAddress: 'billingAddress'
            }
        };
        const paymentProcessor = {};

        before(() => {
            stub(dw.order.OrderMgr, 'getOrder').returns({
                removePaymentInstrument: (PI) => Object.assign(PI, { isRemoved: true }),
                paymentTransaction: { accountID: 'accountID' }
            });

            braintreeGooglePay.__set__('authorizeFailedFlow', () => {
                return { error: true };
            });

            braintreeGooglePay.__set__('createSaleTransactionData', () => {});
        });

        after(() => {
            dw.order.OrderMgr.getOrder.restore();
            prefs.vaultMode = false;
            braintreeGooglePay.__ResetDependency__('authorizeFailedFlow');
            braintreeGooglePay.__ResetDependency__('createSaleTransactionData');
        });

        it('response object to have property authorized set to true if payment is successfully authorized', () => {
            // eslint-disable-next-line new-cap
            expect(braintreeGooglePay.Authorize(orderNumber, paymentInstrument, paymentProcessor)).to.have.property('authorized', true);
        });

        it('response should be paymentInstrument.custom.braintreePaymentMethodBillingAddress set to null if payment is successfully authorized', () => {
            // eslint-disable-next-line new-cap
            braintreeGooglePay.Authorize(orderNumber, paymentInstrument, paymentProcessor);

            expect(paymentInstrument.custom.braintreePaymentMethodBillingAddress).to.be.null;
        });

        it('response should be paymentInstrument.creditCardToken set to legacyId if prefs.vaultMode is on', () => {
            prefs.vaultMode = true;
            // eslint-disable-next-line new-cap
            braintreeGooglePay.Authorize(orderNumber, paymentInstrument, paymentProcessor);

            expect(paymentInstrument.creditCardToken).to.equal('token');
        });

        it('response should be an error if there\'s an error', () => {
            braintreeGooglePay.__set__('createSaleTransactionData', () => {
                throw Error();
            });

            // eslint-disable-next-line new-cap
            expect(braintreeGooglePay.Authorize(orderNumber, paymentInstrument, paymentProcessor)).to.have.property('error', true);
        });

        it('response should payment instrument deleted if amount value is 0', () => {
            amountValue = 0;
            // eslint-disable-next-line new-cap
            braintreeGooglePay.Authorize(orderNumber, paymentInstrument, paymentProcessor);

            expect(paymentInstrument).to.have.property('isRemoved', true);
        });
    });
});
