const { int_braintree: { btServiceResponseHandlerPath } } = require('../path.json');

const { describe, it } = require('mocha');
const { expect } = require('chai');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const BtServiceResponseHandler = proxyquire(btServiceResponseHandlerPath, {});

describe('int_btServiceResponseHandler file', () => {
    const response = { data: {} };
    const btServiceResponseHandlerModel = new BtServiceResponseHandler();

    describe('generalResponseValidation', () => {
        const generalResponseValidation = BtServiceResponseHandler.__get__('generalResponseValidation');

        after(() => {
            response.error = null;
            response.errorCode = null;
            response.errorMsg = null;
        });

        it('result should be an error if response.error is true', () => {
            response.error = true;
            response.errorCode = 'error code';
            response.errorMsg = 'error msg';

            expect(() => generalResponseValidation(response)).to.throw('error msg');
        });
    });

    describe('validateLegacyIdConverterResponse', () => {
        after(() => {
            response.data.idFromLegacyId = null;
        });

        it('result should be response.data.idFromLegacyId returned', () => {
            response.data.idFromLegacyId = 'idFromLegacyId';

            expect(btServiceResponseHandlerModel.validateLegacyIdConverterResponse(response)).to.equal('idFromLegacyId');
        });
    });

    describe('validateSearchTransactionsByIdsResponse', () => {
        after(() => {
            response.data.search.transactions.edges = null;
        });

        it('result should be response.data.search.transactions.edges returned', () => {
            response.data.search = { transactions: { edges: [] } };

            expect(btServiceResponseHandlerModel.validateSearchTransactionsByIdsResponse(response)).to.deep.equal([]);
        });
    });

    describe('validateCreateClientTokenResponse', () => {
        after(() => {
            response.data.createClientToken.clientToken = null;
        });

        it('result should be response.data.createClientToken.clientToken returned', () => {
            response.data.createClientToken = { clientToken: 'clientToken' };

            expect(btServiceResponseHandlerModel.validateCreateClientTokenResponse(response)).to.equal('clientToken');
        });
    });

    describe('validateVaultPaymentMethodResponse', () => {
        after(() => {
            response.data.vaultPaymentMethod = null;
        });

        it('result should be response.data.vaultPaymentMethod returned', () => {
            response.data.vaultPaymentMethod = 'vaultPaymentMethod';

            expect(btServiceResponseHandlerModel.validateVaultPaymentMethodResponse(response)).to.equal('vaultPaymentMethod');
        });
    });

    describe('validateDeletePaymentMethodFromVaultResponse', () => {
        it('result should be response obj returned', () => {
            expect(btServiceResponseHandlerModel.validateDeletePaymentMethodFromVaultResponse(response)).to.deep.equal(response);
        });
    });

    describe('validateFindCustomerResponse', () => {
        after(() => {
            response.data.search.customers.edges = null;
        });

        it('result should be response.data.search.customers.edges returned', () => {
            response.data.search = { customers: { edges: [] } };

            expect(btServiceResponseHandlerModel.validateFindCustomerResponse(response)).to.deep.equal([]);
        });
    });

    describe('validateCreateCustomerResponse', () => {
        after(() => {
            response.data.createCustomer.customer.legacyId = null;
        });

        it('result should be response.data.createCustomer.customer.legacyId returned', () => {
            response.data.createCustomer = { customer: { legacyId: 'legacyId' } };

            expect(btServiceResponseHandlerModel.validateCreateCustomerResponse(response)).to.equal('legacyId');
        });
    });

    describe('validateCreateTransactionResponse', () => {
        afterEach(() => {
            response.data.chargePaymentMethod = null;
            response.data.authorizePaymentMethod = null;
            response.data.chargePayPalAccount = null;
            response.data.authorizePayPalAccount = null;
            response.data.chargeCreditCard = null;
            response.data.authorizeCreditCard = null;
        });

        it('result should be response.data.chargePaymentMethod returned', () => {
            response.data.chargePaymentMethod = 'chargePaymentMethod';

            expect(btServiceResponseHandlerModel.validateCreateTransactionResponse(response)).to.equal('chargePaymentMethod');
        });

        it('result should be response.data.authorizePaymentMethod returned', () => {
            response.data.authorizePaymentMethod = 'authorizePaymentMethod';

            expect(btServiceResponseHandlerModel.validateCreateTransactionResponse(response)).to.equal('authorizePaymentMethod');
        });

        it('result should be response.data.chargePayPalAccount returned', () => {
            response.data.chargePayPalAccount = 'chargePayPalAccount';

            expect(btServiceResponseHandlerModel.validateCreateTransactionResponse(response)).to.equal('chargePayPalAccount');
        });

        it('result should be response.data.authorizePayPalAccount returned', () => {
            response.data.authorizePayPalAccount = 'authorizePayPalAccount';

            expect(btServiceResponseHandlerModel.validateCreateTransactionResponse(response)).to.equal('authorizePayPalAccount');
        });

        it('result should be response.data.chargeCreditCard returned', () => {
            response.data.chargeCreditCard = 'chargeCreditCard';

            expect(btServiceResponseHandlerModel.validateCreateTransactionResponse(response)).to.equal('chargeCreditCard');
        });

        it('result should be response.data.authorizeCreditCard returned', () => {
            response.data.authorizeCreditCard = 'authorizeCreditCard';

            expect(btServiceResponseHandlerModel.validateCreateTransactionResponse(response)).to.equal('authorizeCreditCard');
        });
    });

    describe('validateUpdateCCBillingAddressResponse', () => {
        it('result should be an error if response.error is true', () => {
            response.error = 'error';

            expect(() => btServiceResponseHandlerModel.validateUpdateCCBillingAddressResponse(response)).to.throw();
        });

        it('result should be undefined if response.error is null', () => {
            response.error = null;

            expect(btServiceResponseHandlerModel.validateUpdateCCBillingAddressResponse(response)).to.be.undefined;
        });
    });
});
