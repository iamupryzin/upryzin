/* eslint-disable no-undef */
const { int_braintree: { xmlHelperPath } } = require('../path.json');

const { it, describe, after } = require('mocha');
const { expect } = require('chai');

const proxyquire = require('proxyquire').noCallThru();

const xmlHelper = proxyquire(xmlHelperPath, {});

describe('xmlHelper file', () => {
    describe('parseXml', () => {
        const originalXML = XML;

        const defineLengthPropery = (obj) => {
            Object.defineProperty(obj, 'length', {
                enumerable: false,
                writable: true
            });

            obj.length = () => 1;
        };

        after(() => {
            XML = originalXML;
        });

        it('If elements length === 0', () => {
            XML = () => {
                return {
                    name: () => ({ toString: () => 'test-string' }),
                    elements: () => {
                        return {
                            length: () => 0
                        };
                    },
                    text: () => ({ toString: () => 'test-text' })
                };
            };

            const result = xmlHelper.parseXml();

            expect(result).to.be.an('object');
            expect(result).to.deep.equal({
                testString: 'test-text'
            });
        });

        it('If elements length > 0 and nodeType === array', () => {
            const elements = {
                0: {
                    hasSimpleContent: () => true,
                    text: () => ({ toString: () => 'element-text' })
                }
            };

            defineLengthPropery(elements);

            XML = () => {
                return {
                    name: () => ({ toString: () => 'test-string' }),
                    elements: () => elements,
                    attribute: () => ({ toString: () => 'array' })
                };
            };

            const result = xmlHelper.parseXml();

            expect(result).to.be.an('object');
            expect(result).to.deep.equal({
                testString: ['element-text']
            });
        });

        it('If elements length > 0 and nodeType === collection', () => {
            const elements = {
                0: {
                    hasSimpleContent: () => true,
                    text: () => ({ toString: () => 'element-text' }),
                    name: () => ({ toString: () => 'element-name' }),
                    elements: () => ({ length: () => 0 })
                }
            };

            defineLengthPropery(elements);

            XML = () => {
                return {
                    name: () => ({ toString: () => 'test-string' }),
                    elements: () => elements,
                    attribute: () => ({ toString: () => 'collection' })
                };
            };


            const result = xmlHelper.parseXml();

            expect(result).to.be.an('object');
            expect(result).to.have.key('testString');
            expect(result.testString).to.be.an('array');
        });

        it('If elements length > 0 and obj instanceof Array', () => {
            const innerElements = {
                0: {
                    attribute: () => ({ toString: () => 'type' }),
                    text: () => ({ toString: () => 'element-text' }),
                    name: () => ({ toString: () => 'element-name' }),
                    elements: () => ({ length: () => 0 })
                }
            };

            defineLengthPropery(innerElements);

            const elements = {
                0: {
                    hasSimpleContent: () => true,
                    attribute: () => ({ toString: () => 'type' }),
                    text: () => ({ toString: () => 'element-text' }),
                    name: () => ({ toString: () => 'element-name' }),
                    elements: () => innerElements
                }
            };

            defineLengthPropery(elements);

            XML = () => {
                return {
                    name: () => ({ toString: () => 'test-string' }),
                    elements: () => elements,
                    attribute: () => ({ toString: () => 'collection' })
                };
            };


            const result = xmlHelper.parseXml();

            expect(result).to.be.an('object');
            expect(result).to.have.key('testString');
            expect(result.testString).to.be.an('array');
            expect(result).to.deep.equal({ testString: [{ elementName: 'element-text' }] });
        });

        it('If elements length > 0 and else section is executed', () => {
            const innerInnerElements = {
                0: {
                    attribute: () => ({ toString: () => 'type' }),
                    text: () => ({ toString: () => 'element-text' }),
                    name: () => ({ toString: () => 'element-name' }),
                    elements: () => ({ length: () => 0 })
                }
            };

            defineLengthPropery(innerInnerElements);

            const innerElements = {
                0: {
                    attribute: () => ({ toString: () => 'type' }),
                    text: () => ({ toString: () => 'element-text' }),
                    name: () => ({ toString: () => 'element-name' }),
                    elements: () => innerInnerElements
                }
            };

            defineLengthPropery(innerElements);

            const elements = {
                0: {
                    hasSimpleContent: () => true,
                    attribute: () => ({ toString: () => 'type' }),
                    text: () => ({ toString: () => 'element-text' }),
                    name: () => ({ toString: () => 'element-name' }),
                    elements: () => innerElements
                }
            };

            defineLengthPropery(elements);

            XML = () => {
                return {
                    name: () => ({ toString: () => 'test-string' }),
                    elements: () => elements,
                    attribute: () => ({ toString: () => 'collection' })
                };
            };


            const result = xmlHelper.parseXml();

            expect(result).to.be.an('object');
            expect(result).to.have.key('testString');
            expect(result.testString).to.be.an('array');
            expect(result).to.deep.equal({ testString: [{ elementName: { elementName: 'element-text' } }] });
        });
    });
});
