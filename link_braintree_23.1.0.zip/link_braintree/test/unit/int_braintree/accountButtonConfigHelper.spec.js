const { expect } = require('chai');
const { describe, it } = require('mocha');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');

require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const { int_braintree: { accountButtonConfigHelperPath } } = require('../path.json');

const prefs = {
    venmoDisplayName: 'VENMO',
    srcDisplayName: 'SRC',
    SRCImageLink: 'https://sandbox.secure.checkout.visa.com/wallet-services-web/xo/button.png',
    SRCAccountButtonConfig: {
        style: {
            size: 213,
            height: 47,
            width: 213,
            legacy: false,
            cardBrands: 'VISA,MASTERCARD,AMEX'
        }
    },
    paypalDisplayName: 'PayPal',
    paypalBillingAgreementDescription: 'Paypal aggreement description',
    paymentMethods: {
        BRAINTREE_SRC: { paymentMethodId: 'SRC' },
        BRAINTREE_VENMO: { paymentMethodId: 'Venmo' },
        BRAINTREE_PAYPAL: { paymentMethodId: 'PayPal' },
        BRAINTREE_GOOGLEPAY: { paymentMethodId: 'GooglePay' }
    }
};

const accountButtonConfigHelper = proxyquire(accountButtonConfigHelperPath, {
    'dw/system/Site': dw.system.Site,
    'dw/web/Resource': dw.web.Resource,
    '~/cartridge/scripts/braintree/braintreeAPI/braintreeBusinessLogic': {
        getClientToken: () => 'client token'
    },
    '~/cartridge/config/braintreePreferences': prefs,
    '~/cartridge/scripts/braintree/helpers/paymentHelper': {
        createSRCImageUrl: () => {
            return prefs.SRCImageLink;
        }
    },
    '~/cartridge/config/braintreeConstants': {
        FLOW_VAULT: 'vault',
        BUTTON_CONFIG_PAYPAL: 'paypal',
        BUTTON_CONFIG_OPTIONS_STYLE_SIZE_SMALL: 'small',
        BUTTON_CONFIG_OPTIONS_STYLE_SHAPE_RECT: 'rect',
        BUTTON_CONFIG_OPTIONS_STYLE_LAYOUT_HORIZONTAL: 'horizontal'
    }
});

describe('AccountButtonConfigHelper File', () => {
    describe('createGeneralButtonConfig', () => {
        let paymentMethodName = 'GooglePay';

        const expectResult = (val) => {
            expect(val).to.be.an('object');
            expect(val.clientToken).to.be.a('string');
            expect(val.paymentMethodName).to.be.a('string');
            expect(val.messages).to.be.an('object').that.have.all.keys('CLIENT_REQUEST_TIMEOUT', 'CLIENT_GATEWAY_NETWORK', 'CLIENT_REQUEST_ERROR', 'CLIENT_MISSING_GATEWAY_CONFIGURATION');
        };

        it('Creates general button config object for all payment methods', () => {
            const val = accountButtonConfigHelper.createGeneralButtonConfig(paymentMethodName);

            expectResult(val);
            expect(val).to.have.all.keys('clientToken', 'paymentMethodName', 'messages', 'options');
            expect(val.options).to.be.an('object').that.have.all.keys('amount', 'isAccount');
            expect(val.options).to.deep.equal({ amount: '0.00', isAccount: true });
        });

        it('Payment method name is not equal to GooglePay or SRC', () => {
            paymentMethodName = 'Other Payment';

            const val = accountButtonConfigHelper.createGeneralButtonConfig(paymentMethodName);

            expectResult(val);
            expect(val).to.have.all.keys('clientToken', 'paymentMethodName', 'messages');
        });
    });

    describe('createPaypalAccountButtonConfig', () => {
        it('Creates config for PayPal button on the Account Page', () => {
            const val = accountButtonConfigHelper.createPaypalAccountButtonConfig();

            expect(val).to.be.an('object');
            expect(val).to.have.all.keys('clientToken', 'paymentMethodName', 'messages', 'options', 'paypalConfig');
            expect(val.clientToken).to.be.a('string');
            expect(val.paymentMethodName).to.be.a('string');
            expect(val.messages).to.be.an('object').that.have.all.keys(
                'CLIENT_REQUEST_TIMEOUT', 'CLIENT_GATEWAY_NETWORK', 'CLIENT_GATEWAY_NETWORK', 'CLIENT_MISSING_GATEWAY_CONFIGURATION',
                'PAYPAL_ACCOUNT_TOKENIZATION_FAILED', 'PAYPAL_INVALID_PAYMENT_OPTION', 'PAYPAL_FLOW_FAILED',
                'PAYPAL_BROWSER_NOT_SUPPORTED', 'PAYPAL_BILLING_ADDRESS_NOT_SUPPORTED'
            );
            expect(val.options).to.be.an('object').that.have.all.keys(
                'flow', 'enableShippingAddress', 'displayName', 'billingAgreementDescription'
            );
            expect(val.paypalConfig).to.be.an('object').that.have.all.keys('fundingSource', 'style');
            expect(val.paypalConfig.style).to.be.an('object');
        });
    });

    describe('createAccountSrcButtonConfig', () => {
        it('Creates config for SRC button on the Account Page', () => {
            const val = accountButtonConfigHelper.createAccountSrcButtonConfig();

            expect(val).to.be.an('object');
            expect(val).to.have.all.keys('clientToken', 'paymentMethodName', 'messages', 'options', 'SRCImageUrl', 'settings');
            expect(val.clientToken).to.be.a('string');
            expect(val.paymentMethodName).to.be.a('string');
            expect(val.messages).to.be.an('object').that.have.all.keys('CLIENT_REQUEST_TIMEOUT', 'CLIENT_GATEWAY_NETWORK', 'CLIENT_GATEWAY_NETWORK', 'CLIENT_MISSING_GATEWAY_CONFIGURATION', 'CARD_ALREADY_EXIST_ERROR_MESSAGE');
            expect(val.options).to.be.an('object');
            expect(val.SRCImageUrl).to.be.a('string').that.not.empty;
            expect(val.settings).to.be.an('object').that.have.all.keys('style');
            expect(val.settings.style).to.be.an('object');
        });
    });

    describe('createAccountVenmoButtonConfig', () => {
        it('Creates config for Venmo button on the Account Page', () => {
            const val = accountButtonConfigHelper.createAccountVenmoButtonConfig();

            expect(val).to.be.an('object');
            expect(val).to.have.all.keys('clientToken', 'paymentMethodName', 'messages', 'venmoAccountPage', 'options');
            expect(val.clientToken).to.be.a('string');
            expect(val.paymentMethodName).to.be.a('string');
            expect(val.messages).to.be.an('object').that.have.all.keys('CLIENT_REQUEST_TIMEOUT', 'CLIENT_GATEWAY_NETWORK', 'CLIENT_GATEWAY_NETWORK', 'CLIENT_MISSING_GATEWAY_CONFIGURATION', 'VENMO_ACCOUNT_TOKENIZATION_FAILED', 'VENMO_BROWSER_NOT_SUPPORTED');
            expect(val.venmoAccountPage).to.be.true;
            expect(val.options).to.be.an('object').that.have.all.keys('flow', 'displayName');
        });

        it('Braintree Preferences: venmoDisplayName not set', () => {
            prefs.venmoDisplayName = null;

            const val = accountButtonConfigHelper.createAccountVenmoButtonConfig();

            expect(val).to.be.an('object');
            expect(val.options).to.be.an('object').that.have.all.keys('flow', 'displayName');
            expect(val.options.displayName).to.equal('');
        });
    });
});
