const { expect } = require('chai');
const { describe, it } = require('mocha');

const { int_braintree: { SDKEnableFundingHelperPath } } = require('../path.json');

const SDKEnableFundingHelper = require('proxyquire').noCallThru()(SDKEnableFundingHelperPath, {});

describe('SDKEnableFundingHelper File', () => {
    describe('filterEnableFundingList', () => {
        it('Returns enableFundingArray witch not consist prohibitedMethodsList elements', () => {
            const enableFundingArray = [
                'venmo', 'sepa', 'bancontact', 'eps',
                'giropay', 'ideal', 'mybank', 'p24', 'sofort',
                'paylater', 'credit', 'mercadopago'
            ];

            const val = SDKEnableFundingHelper.filterEnableFundingList(enableFundingArray);

            expect(val).to.be.an('array').that.have.lengthOf(3);
            expect(val).to.deep.equal(['paylater', 'credit', 'mercadopago']);
        });
    });
});
