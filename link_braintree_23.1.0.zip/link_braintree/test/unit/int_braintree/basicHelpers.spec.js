const { int_braintree: { basicHelpersPath } } = require('../path.json');

const { expect } = require('chai');
const { it, describe } = require('mocha');

const proxyquire = require('proxyquire').noCallThru();

const basicHelpers = proxyquire(basicHelpersPath, {});

describe('basicHelpers file', () => {
    describe('getValueOr', () => {
        const defaultValue = '';
        const value = 'test-str';

        it('getValueOr should be a function', () => {
            expect(basicHelpers.getValueOr).to.be.a('function');
        });

        it('should return default value', () => {
            expect(basicHelpers.getValueOr(null, defaultValue)).to.equal(defaultValue);
        });

        it('should return passed value', () => {
            expect(basicHelpers.getValueOr(value, defaultValue)).to.equal(value);
        });
    });

    describe('getValueByKey', () => {
        const key = 'customer.email.value';
        const fakeKey = 'customer.firstName.value';
        const obj = {
            customer: {
                email: { value: 'test@email.com' }
            }
        };
        const defaultValue = null;

        it('should return email value', () => {
            expect(basicHelpers.getValueByKey(obj, key, defaultValue)).to.equal('test@email.com');
        });

        it('should return default value', () => {
            expect(basicHelpers.getValueByKey(obj, fakeKey, defaultValue)).to.equal(defaultValue);
        });
    });
});
