const { expect } = require('chai');
const { int_braintree: { googlepay_form_processorPath } } = require('../path.json');
const { stub } = require('sinon');
const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const req = {
    httpParameterMap: {
        accountUUID: {
            stringValue: null
        },
        braintreeGooglePayNonce: {
            stringValue: null
        },
        pageFlowCart: {
            stringValue: null
        },
        braintreeGooglePayShippingAddress: { stringValue: '2057 Massachusetts Avenue, Fairfax, Washington DC, United States' }
    },
    session: {
        privacyCache: {
            set: (key, value) => {
                return { [key]: value };
            }
        }
    }
};
const order = { isShippingAddressUpdated: false };

const googlepayFormProcessor = proxyquire(googlepay_form_processorPath, {
    'dw/order/BasketMgr': dw.order.BasketMgr,
    '~/cartridge/scripts/hooks/payment/processor/processorHelper': {
        updateShippingAddress: () => Object.assign(order, { isShippingAddressUpdated: true }),
        getBillingAddressFromStringValue: billingAddress => billingAddress
    }
});

describe('googlepay_form_processor file', () => {
    describe('processForm', () => {
        const paymentForm = {
            paymentMethod: {
                value: 'BRAINTREE_GOOGLE_PAY'
            },
            contactInfoFields: {
                email: { value: 'johnSmith@gmail.com' }
            }
        };
        const viewFormData = {
            paymentMethod: {
                value: null
            }
        };

        before(() => {
            stub(dw.order.BasketMgr, 'getCurrentBasket');
            dw.order.BasketMgr.getCurrentBasket.returns({
                getDefaultShipment: () => 'defaultShipment'
            });
            googlepayFormProcessor.__set__('updateBillingForm', () => {
                return true;
            });
        });
        after(() => {
            dw.order.BasketMgr.getCurrentBasket.restore();
            googlepayFormProcessor.__ResetDependency__('updateBillingForm');
        });

        describe('If httpParameterMap.braintreeGooglePayNonce.stringValue === null and httpParameterMap.accountUUID.stringValue === null', () => {
            after(() => {
                order.isShippingAddressUpdated = false;
                req.httpParameterMap.pageFlowCart.stringValue = null;
            });

            it('response type should be equal object', () => {
                expect(googlepayFormProcessor.processForm(req, paymentForm, viewFormData)).to.be.a('object');
            });
            it('response should consist property error', () => {
                expect(googlepayFormProcessor.processForm(req, paymentForm, viewFormData)).has.property('error');
            });
            it('response property error type should be equal boolean', () => {
                expect(googlepayFormProcessor.processForm(req, paymentForm, viewFormData).error).to.be.a('boolean');
            });
            it('response property error should be equal false', () => {
                expect(googlepayFormProcessor.processForm(req, paymentForm, viewFormData).error).equal(false);
            });
            it('response should be shipping address updated if req.querystring isn\'t empty', () => {
                req.httpParameterMap.pageFlowCart.stringValue = true;
                googlepayFormProcessor.processForm(req, paymentForm, viewFormData);

                expect(order).to.have.property('isShippingAddressUpdated', true);
            });
        });

        describe('If httpParameterMap.braintreeGooglePayNonce.stringValue !== null and httpParameterMap.accountUUID.stringValue !== null', () => {
            before(() => {
                req.httpParameterMap.accountUUID.stringValue = 'DDas2-sdsd-ds34-332w';
                req.httpParameterMap.braintreeGooglePayNonce.stringValue = 'dd887s-sdu876-ds87s8-sddf9S';
            });
            it('response type should be equal object', () => {
                expect(googlepayFormProcessor.processForm(req, paymentForm, viewFormData)).to.be.a('object');
            });
            it('response should consist property error', () => {
                expect(googlepayFormProcessor.processForm(req, paymentForm, viewFormData)).has.property('error');
            });
            it('response should consist property viewData', () => {
                expect(googlepayFormProcessor.processForm(req, paymentForm, viewFormData)).has.property('viewData');
            });
            it('response property error type should be equal boolean', () => {
                expect(googlepayFormProcessor.processForm(req, paymentForm, viewFormData).error).to.be.a('boolean');
            });
            it('response property viewData type should be equal object', () => {
                expect(googlepayFormProcessor.processForm(req, paymentForm, viewFormData).viewData).to.be.a('object');
            });
            it('response property error should be equal false', () => {
                expect(googlepayFormProcessor.processForm(req, paymentForm, viewFormData).error).equal(false);
            });
        });
    });
});
