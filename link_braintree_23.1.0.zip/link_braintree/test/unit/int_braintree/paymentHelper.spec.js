const { expect } = require('chai');
const { stub, assert } = require('sinon');

const { int_braintree: { paymentHelperPath } } = require('../path.json');

require('dw-api-mock/demandware-globals');

require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const deleteBillingAddress = stub();
const getCustomerPaymentInstruments = stub();

let errorStatus;
let currencyCode;
let httpParameterMap;
let baseUrl;
let params;

const prefs = {
    creditCardDescriptorName: 'Descriptor_Name',
    creditCardDescriptorPhone: 'Descriptor_Phone',
    creditCardDescriptorUrl: 'Descriptor_Url',
    isFraudToolsEnabled: false,
    isSettle: true,
    vaultMode: true,
    isL2L3: false,
    creditCardMethodName: 'creditCard',
    merchantAccountIDs: {
        'test merchant ID': 'USD: dhr1 32d4 fg45 dfr4'
    },
    paymentMethods: {
        BRAINTREE_GOOGLEPAY: {
            paymentMethodId: 'BRAINTREE_GOOGLEPAY'
        },
        BRAINTREE_SRC: {
            paymentMethodId: 'BRAINTREE_SRC'
        }
    }
};
const service = {
    configuration: {
        credential: {
            custom: {
                BRAINTREE_Client_Id: 'g12345D'
            }
        }
    }
};
const server = {
    forms: {
        getForm: (name) => {
            const forms = {
                coCustomer: {
                    htmlName: 'dwfrm_coCustomer',
                    email: { htmlName: 'dwfrm_coCustomer_email', value: '' }
                },
                billing: {
                    addressFields: {
                        htmlName: 'dwfrm_billing_addressFields',
                        value: '',
                        firstName: { htmlName: 'dwfrm_billing_addressFields_firstName', value: '' },
                        lastName: { htmlName: 'dwfrm_billing_addressFields_lastName', value: '' },
                        address1: { htmlName: 'dwfrm_billing_addressFields_address1', value: '' },
                        address2: { htmlName: 'dwfrm_billing_addressFields_address2', value: '' },
                        city: { htmlName: 'dwfrm_billing_addressFields_city', value: '' },
                        postalCode: { htmlName: 'dwfrm_billing_addressFields_postalCode', value: '' },
                        stateCode: { htmlName: 'dwfrm_billing_addressFields_stateCode', value: '' },
                        country: { htmlName: 'dwfrm_billing_addressFields_country', value: '' },
                        phone: { htmlName: 'dwfrm_billing_addressFields_phone', value: '' },
                        paymentMethod: { htmlName: 'dwfrm_billing_addressFields_paymentMethod', value: '' },
                        states: { htmlName: 'dwfrm_billing_addressFields_states', value: '', stateCode: { htmlName: 'dwfrm_billing_addressFields_states_stateCode', value: '' } }
                    },
                    contactInfoFields: {
                        htmlName: 'dwfrm_billing_contactInfoFields',
                        value: '',
                        phone: { htmlName: 'dwfrm_billing_contactInfoFields_phone', value: '' }
                    }
                }
            };

            let form = forms[name];
            form.clear = () => {};

            return form;
        }
    }
};

const paymentHelper = require('proxyquire').noCallThru()(paymentHelperPath, {
    'dw/svc': {},
    'dw/system': dw.system,
    'dw/value/Money': dw.value.Money,
    'dw/order': dw.order,
    'dw/customer': dw.customer,
    'dw/web/Resource': dw.web.Resource,
    'dw/order/PaymentInstrument': dw.order.PaymentInstrument,
    'server': server,
    '~/cartridge/config/braintreePreferences': prefs,
    '~/cartridge/scripts/braintree/braintreeAPI/braintreeApi': {},
    '~/cartridge/scripts/braintree/braintreeAPI/braintreeApiCalls': {
        deleteBillingAddress
    },
    '~/cartridge/scripts/braintree/helpers/customerHelper': {
        getCustomerPaymentInstruments
    },
    'dw/svc/LocalServiceRegistry': {
        createService: () => { return service; }
    },
    '*/cartridge/scripts/util/array': {
        find: (array, matcher) => array.find((item) => matcher(item))
    },
    '~/cartridge/config/braintreeConstants': {
        PAYMENT_PROCCESSOR_ID_BRAINTREE_CREDIT: 'BRAINTREE_CREDIT',
        PAYMENT_PROCCESSOR_ID_BRAINTREE_PAYPAL: 'BRAINTREE_PAYPAL',
        PAYMENT_PROCCESSOR_ID_BRAINTREE_APPLEPAY: 'BRAINTREE_APPLEPAY',
        PAYMENT_PROCCESSOR_ID_BRAINTREE_VENMO: 'BRAINTREE_VENMO',
        PAYMENT_PROCCESSOR_ID_BRAINTREE_SRC: 'BRAINTREE_SRC',
        PAYMENT_PROCCESSOR_ID_BRAINTREE_LOCAL: 'BRAINTREE_LOCAL',
        PAYMENT_PROCCESSOR_ID_BRAINTREE_GOOGLEPAY: 'BRAINTREE_GOOGLEPAY',
        PAYPAL_ACCOUNT_DETAILS_TYPE: 'PayPalAccountDetails',
        QUERY_NAME_PAYPAL_SALE: 'chargePaypal',
        QUERY_NAME_PAYPAL_AUTHORIZATION: 'authorizePaypal',
        QUERY_NAME_CHARGE_CREDIT_CARD: 'chargeCreditCard',
        QUERY_NAME_AUTHORIZE_CREDIT_CARD: 'authorizeCreditCard',
        QUERY_NAME_SALE: 'sale',
        QUERY_NAME_AUTHORIZATION: 'authorization',
        LINE_ITEMS_KIND: 'DEBIT',
        NEW_ACCOUNT: 'newaccount'
    }
});

describe('paymentHelper file', () => {
    describe('getLogger check error mode', () => {
        before(() => {
            stub(dw.system.Logger, 'getLogger');
            stub(dw.system.Logger, 'error');
            stub(dw.system.Logger, 'info');
            stub(dw.system.Logger, 'warn');
            dw.system.Logger.getLogger.withArgs('Braintree', 'Braintree_General').returns(dw.system.Logger);
        });

        after(() => {
            dw.system.Logger.getLogger.restore();
            dw.system.Logger.error.restore();
            dw.system.Logger.info.restore();
            dw.system.Logger.warn.restore();
        });

        afterEach(() => {
            dw.system.Logger.error.reset();
            dw.system.Logger.info.reset();
            dw.system.Logger.warn.reset();
        });

        describe('if prefs.loggingMode = "none"', () => {
            before(() => {
                prefs.loggingMode = 'none';
            });
            it('should not log error', () => {
                paymentHelper.getLogger().error('test');
                assert.notCalled(dw.system.Logger.error);
            });
            it('should not log info', () => {
                paymentHelper.getLogger().warn('test');
                assert.notCalled(dw.system.Logger.warn);
            });
            it('should not log warn', () => {
                paymentHelper.getLogger().info('test');
                assert.notCalled(dw.system.Logger.info);
            });
        });

        describe('if prefs.loggingMode = "none"', () => {
            before(() => {
                prefs.loggingMode = 'errors';
            });
            it('should log error', () => {
                paymentHelper.getLogger().error('test');
                assert.calledOnce(dw.system.Logger.error);
            });
            it('should not log info', () => {
                paymentHelper.getLogger().warn('test');
                assert.notCalled(dw.system.Logger.warn);
            });
            it('should not log warn', () => {
                paymentHelper.getLogger().info('test');
                assert.notCalled(dw.system.Logger.info);
            });
        });

        describe('if prefs.loggingMode = "none"', () => {
            before(() => {
                prefs.loggingMode = 'all';
            });
            it('should log error', () => {
                paymentHelper.getLogger().error('test');
                assert.calledOnce(dw.system.Logger.error);
            });
            it('should log info', () => {
                paymentHelper.getLogger().warn('test');
                assert.calledOnce(dw.system.Logger.warn);
            });
            it('should not warn', () => {
                paymentHelper.getLogger().info('test');
                assert.calledOnce(dw.system.Logger.info);
            });
        });
    });

    describe('createErrorMessage', () => {
        const error = stub();
        before(() => {
            stub(paymentHelper, 'getLogger').returns({
                error
            });
        });

        after(() => {
            paymentHelper.getLogger.restore();
        });
    });

    describe('getBraintreePaymentInstrument iterate over paymentInstrumentList', () => {
        let paymentProcessorId;
        const lineItemContainer = {
            getPaymentInstruments: () => ({
                iterator: () => {
                    return new dw.util.Iterator([{
                        getPaymentTransaction: () => ({
                            getPaymentProcessor: () => ({
                                ID: paymentProcessorId
                            })
                        })
                    }]);
                }
            })
        };

        describe('if paymentProcessorId is BRAINTREE_CREDIT', () => {
            it('return paymentInstrument form the list', () => {
                paymentProcessorId = 'BRAINTREE_CREDIT';
                expect(paymentHelper.getBraintreePaymentInstrument(lineItemContainer)).to.be.a('object');
            });
        });
        describe('if paymentProcessorId is BRAINTREE_PAYPAL', () => {
            it('return paymentInstrument form the list', () => {
                paymentProcessorId = 'BRAINTREE_PAYPAL';
                expect(paymentHelper.getBraintreePaymentInstrument(lineItemContainer)).to.be.a('object');
            });
        });
        describe('if paymentProcessorId is BRAINTREE_PAYPAL', () => {
            it('return paymentInstrument form the list', () => {
                paymentProcessorId = 'BRAINTREE_APPLEPAY';
                expect(paymentHelper.getBraintreePaymentInstrument(lineItemContainer)).to.be.a('object');
            });
        });
        describe('if paymentProcessorId is something else', () => {
            it('return paymentInstrument form the list', () => {
                paymentProcessorId = 'MASTERPASS';
                expect(paymentHelper.getBraintreePaymentInstrument(lineItemContainer)).to.be.null;
            });
        });
    });

    describe('addDefaultShipping', () => {
        let basket = {
            getDefaultShipment: () => ({
                shippingMethod: '',
                setShippingMethod: stub()
            })
        };

        before(() => {
            stub(dw.order.ShippingMgr, 'getDefaultShippingMethod');
            stub(dw.order.ShippingMgr, 'applyShippingCost');
            stub(dw.system.HookMgr, 'callHook');
        });
        after(() => {
            dw.order.ShippingMgr.getDefaultShippingMethod.restore();
            dw.order.ShippingMgr.applyShippingCost.restore();
            dw.system.HookMgr.callHook.restore();
        });

        describe('If default shipping method does not exist', () => {
            it('add default shipping method for current cart', () => {
                paymentHelper.addDefaultShipping(basket);
                assert.calledWith(dw.system.HookMgr.callHook, 'dw.order.calculate', 'calculate', basket);
            });
        });

        describe('If default shipping method exist', () => {
            before(() => {
                basket = {
                    getDefaultShipment: () => ({
                        shippingMethod: 'groundShippingMethod'
                    })
                };
            });

            it('do not add a default shipping method for the current cart', () => {
                expect(paymentHelper.addDefaultShipping(basket)).equal(undefined);
            });
        });
    });

    describe('getNonGiftCertificateAmount', () => {
        let Decimal = function (value) {
            this.value = value;
        };
        Decimal.prototype.subtract = function (money) {
            return new Decimal(this.value - money.value);
        };
        Decimal.prototype.value = null;

        let getAmountPaid = new dw.value.Money(20);
        const gcPaymentInstrs = {
            iterator: () => {
                return new dw.util.Iterator([{
                    getPaymentTransaction: () => ({
                        getAmount: () => {
                            return getAmountPaid;
                        }
                    })
                }]);
            }
        };

        let basket = {
            getCurrencyCode: () => {
                return 'Us';
            },
            getGiftCertificatePaymentInstruments: () => {
                return gcPaymentInstrs;
            },
            getTotalGrossPrice: () => {
                return new dw.value.Money(100);
            }
        };

        it('Returns the open amount to be paid.', () => {
            expect(paymentHelper.getNonGiftCertificateAmount(basket).value).to.be.equal(80);
        });
    });

    describe('getOrderLevelDiscountTotal function', () => {
        describe("subtracting the basket's total including the discount from the basket's total excluding the order discount", () => {
            const lineItemContainer1 = {
                getAdjustedMerchandizeTotalPrice: () => {
                    return {
                        subtract: () => {
                            return {
                                getDecimalValue: () => 154.32
                            };
                        }
                    };
                }
            };
            it('should return the order discount amount as a string', () => {
                expect(paymentHelper.getOrderLevelDiscountTotal(lineItemContainer1)).to.be.equal('154.32');
            });
        });
    });

    describe('getLineItems function', () => {
        describe('If productLineItems is not empty and input argument is equal dataLineItems1', () => {
            it('should return object with value details', () => {
                const dataLineItems1 = {
                    productLineItems: {
                        toArray: () => ([{
                            getProductName: () => 'product123',
                            getQuantityValue: () => 5,
                            getProratedPrice: () => 11,
                            getPrice: () => ({
                                subtract: () => ({
                                    getDecimalValue: () => '17.8'
                                }),
                                toNumberString: () => '124.7'
                            }),
                            getTax: () => ({
                                toNumberString: () => '2.8'
                            }),
                            getProduct: () => ({
                                custom: {
                                    unitOfMeasure: 'kg',
                                    commodityCode: '12'
                                },
                                getUPC: () => 'UM332',
                                getPriceModel: () => ({
                                    getPrice: () => ({
                                        toNumberString: () => '123.7'
                                    })
                                })
                            })
                        }])
                    }
                };
                expect(paymentHelper.getLineItems(dataLineItems1)).to.deep.equal([
                    {
                        name: 'product123',
                        kind: 'DEBIT',
                        quantity: 5,
                        unitAmount: '123.7',
                        unitOfMeasure: 'kg',
                        totalAmount: '124.7',
                        taxAmount: '2.8',
                        discountAmount: '17.8',
                        productCode: 'UM332',
                        commodityCode: '12'
                    }
                ]);
            });
        });

        describe('If productLineItems is not empty and input argument is equal dataLineItems2', () => {
            it('should return object with value details', () => {
                const dataLineItems2 = {
                    productLineItems: {
                        toArray: () => ([{
                            getProductName: () => 'product123',
                            getQuantityValue: () => 5,
                            getProratedPrice: () => 11,
                            getPrice: () => ({
                                subtract: () => ({
                                    getDecimalValue: () => '17.8'
                                }),
                                toNumberString: () => '124.7'
                            }),
                            getTax: () => ({
                                toNumberString: () => '2.8'
                            }),
                            getProduct: () => ({
                                custom: {
                                    unitOfMeasure: null,
                                    commodityCode: null
                                },
                                getUPC: () => 'UM332',
                                getPriceModel: () => ({
                                    getPrice: () => ({
                                        toNumberString: () => '123.7'
                                    })
                                })
                            })
                        }])
                    }
                };
                expect(paymentHelper.getLineItems(dataLineItems2)).to.deep.equal([
                    {
                        name: 'product123',
                        kind: 'DEBIT',
                        quantity: 5,
                        unitAmount: '123.7',
                        unitOfMeasure: '',
                        totalAmount: '124.7',
                        taxAmount: '2.8',
                        discountAmount: '17.8',
                        productCode: 'UM332',
                        commodityCode: ''
                    }
                ]);
            });
        });

        describe('If productLineItems is empty, gcLineItems is not empty and input argument is equal dataLineItems4', () => {
            const dataLineItems3 = {
                productLineItems: null,
                giftCertificateLineItems: {
                    toArray: () => ([{
                        recipientEmail: 'johnSmith@gmail.com',
                        getPrice: () => ({
                            toNumberString: () => '255.7'
                        }),
                        getTax: () => ({
                            toNumberString: () => '55.7'
                        })
                    }])
                }
            };

            it('should return object with value details', () => {
                expect(paymentHelper.getLineItems(dataLineItems3)).to.deep.equal([
                    {
                        name: 'Gift - johnSmith@gmail.com',
                        kind: 'DEBIT',
                        quantity: 1,
                        unitAmount: '255.7',
                        unitOfMeasure: '',
                        totalAmount: '255.7',
                        taxAmount: '55.7',
                        discountAmount: '',
                        productCode: '',
                        commodityCode: ''
                    }
                ]);
            });
        });

        describe('If productLineItems is not empty, gcLineItems is not empty and input argument is equal dataLineItems4', () => {
            const dataLineItems4 = {
                productLineItems: {
                    toArray: () => ([{
                        getProductName: () => 'product123',
                        getQuantityValue: () => 5,
                        getProratedPrice: () => 11,
                        getPrice: () => ({
                            subtract: () => ({
                                getDecimalValue: () => '17.8'
                            }),
                            toNumberString: () => '124.7'
                        }),
                        getTax: () => ({
                            toNumberString: () => '2.8'
                        }),
                        getProduct: () => ({
                            custom: {
                                unitOfMeasure: null,
                                commodityCode: null
                            },
                            getUPC: () => 'UM332',
                            getPriceModel: () => ({
                                getPrice: () => ({
                                    toNumberString: () => '123.7'
                                })
                            })
                        })
                    }])
                },
                giftCertificateLineItems: {
                    toArray: () => ([{
                        recipientEmail: 'johnSmith@gmail.com',
                        getPrice: () => ({
                            toNumberString: () => '255.7'
                        }),
                        getTax: () => ({
                            toNumberString: () => '55.7'
                        })
                    }])
                }
            };

            it('should return object with value details', () => {
                expect(paymentHelper.getLineItems(dataLineItems4)).to.deep.equal([
                    {
                        name: 'product123',
                        kind: 'DEBIT',
                        quantity: 5,
                        unitAmount: '123.7',
                        unitOfMeasure: '',
                        totalAmount: '124.7',
                        taxAmount: '2.8',
                        discountAmount: '17.8',
                        productCode: 'UM332',
                        commodityCode: ''
                    },
                    {
                        name: 'Gift - johnSmith@gmail.com',
                        kind: 'DEBIT',
                        quantity: 1,
                        unitAmount: '255.7',
                        unitOfMeasure: '',
                        totalAmount: '255.7',
                        taxAmount: '55.7',
                        discountAmount: '',
                        productCode: '',
                        commodityCode: ''
                    }
                ]);
            });
        });
    });

    describe('isPaypalButtonEnabled', () => {
        let targetPage;
        describe('if prefs.paypalButtonLocation.toLowerCase() == "none"', () => {
            before(() => {
                prefs.paypalButtonLocation = 'none';
            });

            it('displayPages == null', () => {
                expect(paymentHelper.isPaypalButtonEnabled()).to.be.false;
            });
        });

        describe('if prefs.paypalButtonLocation.toLowerCase() != "none"', () => {
            before(() => {
                prefs.paypalButtonLocation = 'cart';
            });

            it('targetPage != null', () => {
                expect(paymentHelper.isPaypalButtonEnabled(targetPage)).to.be.false;
            });
        });

        describe('if prefs.paypalButtonLocation.toLowerCase() !== "none"', () => {
            before(() => {
                prefs.paypalButtonLocation = 'cart';
                targetPage = 'cart';
            });

            it('targetPage != null', () => {
                expect(paymentHelper.isPaypalButtonEnabled(targetPage)).to.be.true;
            });
        });

        describe('if prefs.paypalButtonLocation.toLowerCase() !== "none"', () => {
            before(() => {
                prefs.paypalButtonLocation = 'cart';
                targetPage = 'pdp';
            });

            it('targetPage != null', () => {
                expect(paymentHelper.isPaypalButtonEnabled(targetPage)).to.be.false;
            });
        });
    });

    describe('calculateAppliedGiftCertificatesAmount Calculate amount of gift certificates in the order', () => {
        const amount = 123;
        const order = {
            getGiftCertificatePaymentInstruments: () => ({
                iterator: () => {
                    return new dw.util.Iterator([{
                        getPaymentTransaction: () => ({
                            getAmount: () => (amount)
                        })
                    }]);
                }
            }),
            getCurrencyCode: stub()
        };

        describe('Calculate amount', () => {
            it('return amount', () => {
                expect(paymentHelper.calculateAppliedGiftCertificatesAmount(order)).to.be.a('object');
            });
        });
    });

    describe('updateOrderBillingAddress', () => {
        const order = {
            getBillingAddress: stub(),
            createBillingAddress: stub(),
            setCustomerEmail: stub()
        };
        const billingDetails = {
            countryCode: 'CO',
            phone: 'testPhone',
            firstName: 'John',
            lastName: 'Doe',
            email: 'newEmail'
        };
        const billingAddress = {
            firstName: 'Pam',
            lastName: 'Di',
            countryCode: { value: 'UA' },
            phone: null,
            setFirstName: stub(),
            setLastName: stub(),
            setCountryCode: stub(),
            setPhone: stub()
        };

        describe('if billing data is taken from billingDetails', () => {
            before(() => {
                order.getBillingAddress.returns(billingAddress);
                paymentHelper.updateOrderBillingAddress(order, billingDetails);
            });

            afterEach(() => {
                order.getBillingAddress.reset();
            });

            it('should set country code into billing address', () => {
                assert.calledWith(billingAddress.setCountryCode, 'CO');
            });

            it('should set phone into billing address', () => {
                assert.calledWith(billingAddress.setPhone, 'testPhone');
            });

            it('should set first name into billing address', () => {
                assert.calledWith(billingAddress.setFirstName, 'John');
            });

            it('should set last name into billing address', () => {
                assert.calledWith(billingAddress.setLastName, 'Doe');
            });
        });

        describe('if billing data is taken from billingAddress & phone number isn\'t provided', () => {
            before(() => {
                billingDetails.countryCode = null;
                billingDetails.firstName = null;
                billingDetails.lastName = null;
                billingDetails.phone = null;
                order.getBillingAddress.returns(null);
                order.createBillingAddress.returns(billingAddress);
                paymentHelper.updateOrderBillingAddress(order, billingDetails);
            });

            after(() => {
                order.createBillingAddress.reset();
                order.getBillingAddress.reset();
                billingDetails.countryCode = 'CO';
                billingDetails.firstName = 'John';
                billingDetails.lastName = 'Doe';
                billingDetails.phone = 'testPhone';
            });

            it('should set country code into billing address from billingAddress', () => {
                assert.calledWith(billingAddress.setCountryCode, 'UA');
            });

            it('should set first name into billing address from billingAddress', () => {
                assert.calledWith(billingAddress.setFirstName, 'Pam');
            });

            it('should set last name into billing address from billingAddress & skip setting phone if value for it is provided', () => {
                assert.calledWith(billingAddress.setLastName, 'Di');
            });

            it('should set phone value as null into billing address from billingAddress', () => {
                assert.calledWith(billingAddress.setPhone, null);
            });
        });

        describe('if billing data is taken from billingAddress & phone number is provided', () => {
            before(() => {
                billingAddress.phone = 'phone';
            });

            after(() => {
                billingAddress.phone = null;
            });

            it('should return undefined & skip setting a phone number', () => {
                expect(paymentHelper.updateOrderBillingAddress(order, billingDetails)).to.be.undefined;
            });
        });
    });

    describe('getActiveLocalPaymentMethod', () => {
        let paymentProcessorId;
        const paymentMethod = 'p24';
        const order = {
            getPaymentInstruments: () => ({
                iterator: () => {
                    return new dw.util.Iterator([{
                        getPaymentTransaction: () => ({
                            getPaymentProcessor: () => ({
                                ID: paymentProcessorId
                            })
                        }),
                        getPaymentMethod: () => paymentMethod
                    }]);
                }
            })
        };

        describe('If paymentProcessorId === BRAINTREE_LOCAL', () => {
            before(() => {
                paymentProcessorId = 'BRAINTREE_LOCAL';
            });
            it('should return the payment method name', () => {
                expect(paymentHelper.getActiveLocalPaymentMethod(order)).to.be.equal('p24');
            });
        });

        describe('If paymentProcessorId is not braintree local', () => {
            before(() => {
                paymentProcessorId = 'BRAINTREE_CREDIT';
            });
            it('should return null', () => {
                expect(paymentHelper.getActiveLocalPaymentMethod(order)).to.be.null;
            });
        });
    });

    describe('getActivePaymentMethods', () => {
        let activePaymentMethods = [
            {
                active: true,
                ID: 'ApplePay',
                paymentProcessor: {
                    ID: 'BRAINTREE_APPLEPAY'
                }
            },
            {
                active: true,
                ID: 'p24',
                paymentProcessor: {
                    ID: 'BRAINTREE_LOCAL'
                }
            },
            {
                active: true,
                ID: 'local',
                paymentProcessor: {
                    ID: 'BRAINTREE_LOCAL'
                }
            },
            {
                active: true,
                ID: 'CREDIT_CARD',
                paymentProcessor: {
                    ID: 'BRAINTREE_CREDIT'
                }
            }
        ];
        before(() => {
            Array.filter = function (a, b) {
                return Array.prototype.filter.call(a, b);
            };
            Array.forEach = function (a, b) {
                return Array.prototype.forEach.call(a, b);
            };
            stub(dw.order.PaymentMgr, 'getActivePaymentMethods');
            dw.order.PaymentMgr.getActivePaymentMethods.returns(activePaymentMethods);
        });

        describe('if payment methods braintree_applepay and braintree_local are active', () => {
            let paymentMethods = {
                BRAINTREE_APPLEPAY: {
                    isActive: true,
                    paymentMethodId: 'ApplePay'
                },
                BRAINTREE_CREDIT: {
                    isActive: true,
                    paymentMethodId: 'CREDIT_CARD'
                },
                BRAINTREE_PAYPAL: {},
                BRAINTREE_VENMO: {},
                BRAINTREE_LOCAL: {
                    isActive: true,
                    paymentMethodIds: ['p24', 'local']
                },
                BRAINTREE_GOOGLEPAY: {},
                BRAINTREE_SRC: {}
            };
            it('should return object with active payment methods id and active status', () => {
                expect(paymentHelper.getActivePaymentMethods()).to.deep.equal(paymentMethods);
            });
        });
    });

    describe('getApplicableLocalPaymentMethods', () => {
        let parameters = {
            applicablePaymentMethods: [
                { ID: 'ApplePay', name: 'ApplePay' },
                { ID: 'p24', name: 'p24' }
            ],
            paymentMethodIds: ['p24']
        };
        let lpmPaymentOptions = ['p24'];

        it('should return object with applicable local payment methods', () => {
            expect(paymentHelper.getApplicableLocalPaymentMethods(parameters)).to.deep.equal(lpmPaymentOptions);
        });
    });

    describe('getWalletPaymentInstrument', () => {
        const paymentInstruments = ['PayPal', 'CREDIT_CARD', 'GooglePay', 'Venmo', 'ApplePay'].map(methodID => ({
            paymentMethod: methodID,
            getPaymentMethod: () => methodID
        }));

        const notAvailableMethodID = 'fake';

        describe('should return empty array if payment method was\'t provided or did\'t find at the payment instruments', () => {
            it('should return empty array', () => {
                expect(paymentHelper.getWalletPaymentInstrument(paymentInstruments)).to.deep.equal([]);
            });

            it('should return empty array', () => {
                expect(paymentHelper.getWalletPaymentInstrument(paymentInstruments, notAvailableMethodID)).to.deep.equal([]);
            });
        });

        describe('should return payment instrument by method', () => {
            paymentInstruments.forEach(instrument => {
                it(`should return payment instrument by method id ${instrument.paymentMethod}`, () => {
                    expect(paymentHelper.getWalletPaymentInstrument(paymentInstruments, instrument.paymentMethod).length === 1).to.equal(true);
                });
            });
        });
    });

    describe('getApplicableCreditCardPaymentInstruments', () => {
        const paymentInstruments = ['CREDIT_CARD', 'GooglePay', 'PayPal', 'Venmo', 'ApplePay', 'SRC']
            .map((paymentMethod) => ({ paymentMethod }));

        before(() => {
            stub(customer, 'getProfile').returns({
                getWallet: () => ({
                    getPaymentInstruments: () => paymentInstruments
                })
            });
        });

        after(() => {
            customer.getProfile.restore();
            customer.authenticated = () => {};
        });

        it('should return emty array if customer is authenticated', () => {
            customer.authenticated = true;

            expect(paymentHelper.getApplicableCreditCardPaymentInstruments()).to.deep.equal([{ paymentMethod: 'CREDIT_CARD' }]);
        });

        it('should return emty array if customer is not authenticated', () => {
            customer.authenticated = false;

            expect(paymentHelper.getApplicableCreditCardPaymentInstruments()).to.deep.equal([]);
        });
    });

    describe('getAmountPaid', () => {
        const appliedGiftCertificatesAmount = 123;
        const orderAmount = 823;
        let order = {
            getTotalGrossPrice: () => {
                return {
                    subtract: () => {
                        return orderAmount - appliedGiftCertificatesAmount;
                    }
                };
            }
        };

        before(() => {
            stub(paymentHelper, 'calculateAppliedGiftCertificatesAmount');
            paymentHelper.calculateAppliedGiftCertificatesAmount.returns(appliedGiftCertificatesAmount);
        });

        after(() => {
            paymentHelper.calculateAppliedGiftCertificatesAmount.restore();
        });

        describe('If all input amounts were correct', () => {
            it('response type should be number', () => {
                expect(paymentHelper.getAmountPaid(order)).to.be.a('number');
            });
            it('response should be equal to 700', () => {
                expect(paymentHelper.getAmountPaid(order)).equal(700);
            });
        });
    });

    describe('createAddressData', () => {
        let address = {
            getCompanyName: () => 'Paypal',
            getCountryCode: () => {
                return {
                    getValue: () => 'us',
                    getDisplayValue: () => 'United States of America'
                };
            },
            getFirstName: () => 'John',
            getLastName: () => 'Smith',
            getCity: () => 'New York',
            getPostalCode: () => '11256',
            getStateCode: () => '10001',
            getAddress1: () => '1050 Forbell St, Brooklyn',
            getAddress2: () => '1050 Forbell St, Brooklyn, New York, United State of America',
            getPhone: () => '+1 718-843-6776'
        };

        describe('If all input data are correct', () => {
            it('response type should be object', () => {
                expect(paymentHelper.createAddressData(address)).to.be.a('object');
            });
            it('response should has property company', () => {
                expect(paymentHelper.createAddressData(address)).has.property('company');
            });
            it('response property company should be equal Paypal', () => {
                expect(paymentHelper.createAddressData(address).company).equal('Paypal');
            });
            it('response should has property countryCodeAlpha2', () => {
                expect(paymentHelper.createAddressData(address)).has.property('countryCodeAlpha2');
            });
            it('response property countryCodeAlpha2 should be equal US', () => {
                expect(paymentHelper.createAddressData(address).countryCodeAlpha2).equal('US');
            });
            it('response should has property countryName', () => {
                expect(paymentHelper.createAddressData(address)).has.property('countryName');
            });
            it('response property countryName should be equal United States of America', () => {
                expect(paymentHelper.createAddressData(address).countryName).equal('United States of America');
            });
            it('response should has property firstName', () => {
                expect(paymentHelper.createAddressData(address)).has.property('firstName');
            });
            it('response property firstName should be equal John', () => {
                expect(paymentHelper.createAddressData(address).firstName).equal('John');
            });
            it('response should has property lastName', () => {
                expect(paymentHelper.createAddressData(address)).has.property('lastName');
            });
            it('response property lastName should be equal Smith', () => {
                expect(paymentHelper.createAddressData(address).lastName).equal('Smith');
            });
            it('response should has property locality', () => {
                expect(paymentHelper.createAddressData(address)).has.property('locality');
            });
            it('response property locality should be equal New York', () => {
                expect(paymentHelper.createAddressData(address).locality).equal('New York');
            });
            it('response should has property postalCode', () => {
                expect(paymentHelper.createAddressData(address)).has.property('postalCode');
            });
            it('response property postalCode should be equal 11256', () => {
                expect(paymentHelper.createAddressData(address).postalCode).equal('11256');
            });
            it('response should has property region', () => {
                expect(paymentHelper.createAddressData(address)).has.property('region');
            });
            it('response property region should be equal 10001', () => {
                expect(paymentHelper.createAddressData(address).region).equal('10001');
            });
            it('response should has property streetAddress', () => {
                expect(paymentHelper.createAddressData(address)).has.property('streetAddress');
            });
            it('response property streetAddress should be equal 1050 Forbell St, Brooklyn', () => {
                expect(paymentHelper.createAddressData(address).streetAddress).equal('1050 Forbell St, Brooklyn');
            });
            it('response should has property extendedAddress', () => {
                expect(paymentHelper.createAddressData(address)).has.property('extendedAddress');
            });
            it('response property extendedAddress should be equal 1050 Forbell St, Brooklyn, New York, United State of America', () => {
                expect(paymentHelper.createAddressData(address).extendedAddress).equal('1050 Forbell St, Brooklyn, New York, United State of America');
            });
            it('response should has property phoneNumber', () => {
                expect(paymentHelper.createAddressData(address)).has.property('phoneNumber');
            });
            it('response property phoneNumber should be equal +1 718-843-6776', () => {
                expect(paymentHelper.createAddressData(address).phoneNumber).equal('+1 718-843-6776');
            });
        });
    });

    describe('createShippingAddressData', () => {
        let address = {
            getCompanyName: () => 'Paypal',
            getCountryCode: () => {
                return {
                    getValue: () => 'us',
                    getDisplayValue: () => 'United States of America'
                };
            },
            getFirstName: () => 'John',
            getLastName: () => 'Smith',
            getCity: () => 'New York',
            getPostalCode: () => '11256',
            getStateCode: () => '10001',
            getAddress1: () => '1050 Forbell St, Brooklyn',
            getAddress2: () => '1050 Forbell St, Brooklyn, New York, United State of America'
        };

        describe('If all input data are correct', () => {
            it('response type should be object', () => {
                expect(paymentHelper.createShippingAddressData(address)).to.be.a('object');
            });
            it('response should has property company', () => {
                expect(paymentHelper.createShippingAddressData(address)).has.property('company');
            });
            it('response property company should be equal Paypal', () => {
                expect(paymentHelper.createShippingAddressData(address).company).equal('Paypal');
            });
            it('response should has property countryCode', () => {
                expect(paymentHelper.createShippingAddressData(address)).has.property('countryCode');
            });
            it('response property countryCode should be equal US', () => {
                expect(paymentHelper.createShippingAddressData(address).countryCode).equal('US');
            });
            it('response should has property countryName', () => {
                expect(paymentHelper.createShippingAddressData(address)).has.property('countryName');
            });
            it('response property countryName should be equal United States of America', () => {
                expect(paymentHelper.createShippingAddressData(address).countryName).equal('United States of America');
            });
            it('response should has property firstName', () => {
                expect(paymentHelper.createShippingAddressData(address)).has.property('firstName');
            });
            it('response property firstName should be equal John', () => {
                expect(paymentHelper.createShippingAddressData(address).firstName).equal('John');
            });
            it('response should has property lastName', () => {
                expect(paymentHelper.createShippingAddressData(address)).has.property('lastName');
            });
            it('response property lastName should be equal Smith', () => {
                expect(paymentHelper.createShippingAddressData(address).lastName).equal('Smith');
            });
            it('response should has property locality', () => {
                expect(paymentHelper.createShippingAddressData(address)).has.property('locality');
            });
            it('response property locality should be equal New York', () => {
                expect(paymentHelper.createShippingAddressData(address).locality).equal('New York');
            });
            it('response should has property postalCode', () => {
                expect(paymentHelper.createShippingAddressData(address)).has.property('postalCode');
            });
            it('response property postalCode should be equal 11256', () => {
                expect(paymentHelper.createShippingAddressData(address).postalCode).equal('11256');
            });
            it('response should has property region', () => {
                expect(paymentHelper.createShippingAddressData(address)).has.property('region');
            });
            it('response property region should be equal 10001', () => {
                expect(paymentHelper.createShippingAddressData(address).region).equal('10001');
            });
            it('response should has property streetAddress', () => {
                expect(paymentHelper.createShippingAddressData(address)).has.property('streetAddress');
            });
            it('response property streetAddress should be equal 1050 Forbell St, Brooklyn', () => {
                expect(paymentHelper.createShippingAddressData(address).streetAddress).equal('1050 Forbell St, Brooklyn');
            });
            it('response should has property extendedAddress', () => {
                expect(paymentHelper.createShippingAddressData(address)).has.property('extendedAddress');
            });
            it('response property extendedAddress should be equal 1050 Forbell St, Brooklyn, New York, United State of America', () => {
                expect(paymentHelper.createShippingAddressData(address).extendedAddress).equal('1050 Forbell St, Brooklyn, New York, United State of America');
            });
        });
    });

    describe('deleteBraintreePaymentInstruments', () => {
        const braintreePaymentInstrument = 'braintreePaymentInstrument';
        const creditCardPaymentInstrument = 'creditCardPaymentInstrument';
        let lineItemContainer = {
            paymentInstruments: [
                braintreePaymentInstrument,
                creditCardPaymentInstrument
            ],
            removePaymentInstrument: function (value) {
                this.paymentInstruments = this.paymentInstruments.filter(item => item !== value);
            }
        };

        describe('If braintreePaymentInstrument does not exist', () => {
            before(() => {
                stub(paymentHelper, 'getBraintreePaymentInstrument');
                paymentHelper.getBraintreePaymentInstrument.returns(undefined);
            });
            after(() => {
                paymentHelper.getBraintreePaymentInstrument.restore();
            });
            it('response should be undefined', () => {
                expect(paymentHelper.deleteBraintreePaymentInstruments(lineItemContainer)).equal(undefined);
            });
        });

        describe('If braintreePaymentInstrument exist', () => {
            before(() => {
                stub(paymentHelper, 'getBraintreePaymentInstrument');
                paymentHelper.getBraintreePaymentInstrument.returns(braintreePaymentInstrument);
            });
            after(() => {
                paymentHelper.getBraintreePaymentInstrument.restore();
            });
            it('braintreePaymentInstrument shold be deleted from paymentInstruments', () => {
                expect(lineItemContainer.paymentInstruments.length).equal(2);
                paymentHelper.deleteBraintreePaymentInstruments(lineItemContainer);
                expect(lineItemContainer.paymentInstruments.length).equal(1);
            });
        });
    });

    describe('deletePaymentInstrumentFromDwCustomer', () => {
        const customerProfile = { wallet: { getPaymentInstruments: () => null } };
        const creditCardToken = 'token #1';

        afterEach(() => {
            customer.profile = null;
        });

        it('result should return undefined if customerPaymentInstruments is empty', () => {
            expect(paymentHelper.deletePaymentInstrumentFromDwCustomer(creditCardToken, customerProfile)).to.equal(undefined);
        });

        it('result should be payment instrument with property creditCardToken:"token #1" deleted from customer.profile.paymentInstruments', () => {
            customer.profile = {
                paymentInstruments: [{ creditCardToken: 'token #0' }, { creditCardToken: 'token #1' }, { creditCardToken: 'token #2' }],
                wallet: {
                    getPaymentInstruments: function () {
                        return customer.profile.paymentInstruments;
                    }
                },
                getWallet: () => ({
                    removePaymentInstrument: function (paymentInstrument) {
                        const index = customer.profile.paymentInstruments.findIndex((item) => item.creditCardToken.includes(paymentInstrument.creditCardToken));
                        customer.profile.paymentInstruments.splice(index, 1);
                    }
                })
            };
            paymentHelper.deletePaymentInstrumentFromDwCustomer(creditCardToken, customerProfile);

            expect(customer.profile.paymentInstruments).to.deep.equal([{ creditCardToken: 'token #0' }, { creditCardToken: 'token #2' }]);
        });

        it('result should be an error if customer.profile.getWallet() throws an error', () => {
            customer.profile = {
                wallet: {
                    getPaymentInstruments: () => [{ creditCardToken: 'token #0' }, { creditCardToken: 'token #1' }, { creditCardToken: 'token #2' }]
                },
                getWallet: () => {
                    throw Error();
                }
            };

            expect(() => paymentHelper.deletePaymentInstrumentFromDwCustomer(creditCardToken, customerProfile)).to.throw();
        });
    });

    describe('getGooglepayCardDescriprionFromOrder', () => {
        let paymentProcessorId;
        const order = {
            getPaymentInstruments: () => ({
                iterator: () => {
                    return new dw.util.Iterator([{
                        getPaymentTransaction: () => ({
                            getPaymentProcessor: () => ({
                                ID: paymentProcessorId
                            })
                        }),
                        custom: {
                            braintreeGooglePayCardDescription: '5268 2547'
                        }
                    }]);
                }
            })
        };

        describe('If payment proccessor is PAYMENT_PROCCESSOR_ID_BRAINTREE_GOOGLEPAY', () => {
            before(() => {
                paymentProcessorId = 'BRAINTREE_GOOGLEPAY';
            });
            it('response type should be string', () => {
                expect(paymentHelper.getGooglepayCardDescriprionFromOrder(order)).to.be.a('string');
            });
            it('should return 5268....2547', () => {
                expect(paymentHelper.getGooglepayCardDescriprionFromOrder(order)).equal('5268....2547');
            });
        });

        describe('If payment proccessor is not PAYMENT_PROCCESSOR_ID_BRAINTREE_GOOGLEPAY', () => {
            before(() => {
                paymentProcessorId = 'BRAINTREE_APPLEPAY';
            });
            it('response type should not be string', () => {
                expect(paymentHelper.getGooglepayCardDescriprionFromOrder(order)).to.be.not.a('string');
            });
            it('should return null', () => {
                expect(paymentHelper.getGooglepayCardDescriprionFromOrder(order)).equal(null);
            });
        });
    });

    describe('handleErrorCode', () => {
        before(() => {
            stub(dw.web.Resource, 'msg');
            dw.web.Resource.msg.withArgs('braintree.error.2000', 'locale', null).returns('There was a problem processing your payment. Please verify your payment information and try again.');
            dw.web.Resource.msg.withArgs('braintree.error.3000', 'locale', null).returns('Network error, please try again later.');
            dw.web.Resource.msg.withArgs('braintree.error.91564', 'locale', null).returns('There was a problem processing your payment. Please re-enter your payment information and try again.');
        });
        after(() => {
            dw.web.Resource.msg.restore();
        });

        describe('If errorStatus was not provided and braintreeErrorCode first number equal 2', () => {
            before(() => {
                session = {
                    privacy: {
                        braintreeErrorMsg: 'No errors have been detected yet',
                        braintreeErrorCode: '23244'
                    }
                };
                errorStatus = null;
                paymentHelper.handleErrorCode(errorStatus);
            });

            it('session.privacy.braintreeErrorMsg should change and not be equal to default - No errors have been detected yet', () => {
                expect(session.privacy.braintreeErrorMsg).not.equal('No errors have been detected yet');
            });

            it('session.privacy.braintreeErrorMsg should change and be equal to - There was a problem processing your payment. Please verify your payment information and try again.', () => {
                expect(session.privacy.braintreeErrorMsg).equal('There was a problem processing your payment. Please verify your payment information and try again.');
            });

            it('session.privacy.braintreeErrorCode should change and be equal to null', () => {
                expect(session.privacy.braintreeErrorCode).equal(null);
            });
        });

        describe('If errorStatus was not provided and braintreeErrorCode first number equal 3', () => {
            before(() => {
                session = {
                    privacy: {
                        braintreeErrorMsg: 'No errors have been detected yet',
                        braintreeErrorCode: '33244'
                    }
                };
                errorStatus = null;
                paymentHelper.handleErrorCode(errorStatus);
            });

            it('session.privacy.braintreeErrorMsg should change and not be equal to default - No errors have been detected yet', () => {
                expect(session.privacy.braintreeErrorMsg).not.equal('No errors have been detected yet');
            });

            it('session.privacy.braintreeErrorMsg should change and be equal to - Network error, please try again later.', () => {
                expect(session.privacy.braintreeErrorMsg).equal('Network error, please try again later.');
            });

            it('session.privacy.braintreeErrorCode should change and be equal to null', () => {
                expect(session.privacy.braintreeErrorCode).equal(null);
            });
        });

        describe('If errorStatus was not provided and braintreeErrorCode is equal 91564', () => {
            before(() => {
                session = {
                    privacy: {
                        braintreeErrorMsg: 'No errors have been detected yet',
                        braintreeErrorCode: '91564'
                    }
                };
                errorStatus = null;
                paymentHelper.handleErrorCode(errorStatus);
            });

            it('session.privacy.braintreeErrorMsg should change and not be equal to default - No errors have been detected yet', () => {
                expect(session.privacy.braintreeErrorMsg).not.equal('No errors have been detected yet');
            });

            it('session.privacy.braintreeErrorMsg should change and be equal to - There was a problem processing your payment. Please re-enter your payment information and try again.', () => {
                expect(session.privacy.braintreeErrorMsg).equal('There was a problem processing your payment. Please re-enter your payment information and try again.');
            });

            it('session.privacy.braintreeErrorCode should change and be equal to null', () => {
                expect(session.privacy.braintreeErrorCode).equal(null);
            });
        });

        describe('If errorStatus is equal PROCESSOR_DECLINED and braintreeErrorCode isn\'t provided', () => {
            before(() => {
                session = {
                    privacy: {
                        braintreeErrorMsg: 'No errors have been detected yet',
                        braintreeErrorCode: null }
                };
                errorStatus = 'PROCESSOR_DECLINED';
                paymentHelper.handleErrorCode(errorStatus);
            });

            it('session.privacy.braintreeErrorMsg should change and not be equal to default - No errors have been detected yet', () => {
                expect(session.privacy.braintreeErrorMsg).not.equal('No errors have been detected yet');
            });

            it('session.privacy.braintreeErrorMsg should change and be equal to - There was a problem processing your payment. Please verify your payment information and try again.', () => {
                expect(session.privacy.braintreeErrorMsg).equal('There was a problem processing your payment. Please verify your payment information and try again.');
            });

            it('session.privacy.braintreeErrorCode should change and be equal to null', () => {
                expect(session.privacy.braintreeErrorCode).equal(null);
            });
        });

        describe('If errorStatus is equal ERROR and braintreeErrorCode first number isn\'t 2 or 3 or it doesn\'t equal 91564', () => {
            before(() => {
                session = {
                    privacy: {
                        braintreeErrorMsg: 'No errors have been detected yet',
                        braintreeErrorCode: '5000'
                    }
                };
                errorStatus = 'ERROR';
                paymentHelper.handleErrorCode(errorStatus);
            });

            it('session.privacy.braintreeErrorMsg should be equal to default - No errors have been detected yet', () => {
                expect(session.privacy.braintreeErrorMsg).to.equal('No errors have been detected yet');
            });

            it('session.privacy.braintreeErrorCode should change and be equal to null', () => {
                expect(session.privacy.braintreeErrorCode).equal(null);
            });
        });
    });

    describe('createSRCImageUrl', () => {
        describe('If params is empty', () => {
            before(() => {
                baseUrl = 'https://paypal.com/';
                params = null;
            });
            it('response type should be string', () => {
                expect(paymentHelper.createSRCImageUrl(baseUrl, params)).to.be.a('string');
            });
            it('response should be equal baseUrl', () => {
                expect(paymentHelper.createSRCImageUrl(baseUrl, params)).equal(baseUrl);
            });
        });

        describe('If params is not empty', () => {
            before(() => {
                baseUrl = 'https://paypal.com/';
                params = { location: 'USA', city: 'Boston' };
            });
            it('response type should be string', () => {
                expect(paymentHelper.createSRCImageUrl(baseUrl, params)).to.be.a('string');
            });
            it('response should be equal baseUrl', () => {
                expect(paymentHelper.createSRCImageUrl(baseUrl, params)).equal('https://paypal.com/?location=USA&city=Boston');
            });
        });
    });

    describe('isSavedPaypalMethod', () => {
        describe('If customer is not authenticated', () => {
            before(() => {
                customer.authenticated = false;
                httpParameterMap = {};
            });
            it('response should be equal false', () => {
                expect(paymentHelper.isSavedPaypalMethod(httpParameterMap)).equal(false);
            });
        });

        describe('If customer is authenticated and httpParameterMap.braintreePaypalNonce.stringValue is not empty', () => {
            before(() => {
                customer.authenticated = true;
                httpParameterMap = {
                    braintreePaypalAccountList: {
                        value: 'john_smith'
                    },
                    paymentMethodUUID: {
                        stringValue: 'a737aaee-f9b2-4241-a17e-1344649bb851'
                    },
                    braintreePaypalNonce: {
                        stringValue: 'ce0210ba-cec7-49c4-b02f-c27ade516a82'
                    }
                };
            });
            it('response should be equal false', () => {
                expect(paymentHelper.isSavedPaypalMethod(httpParameterMap)).equal(false);
            });
        });

        describe('If customer is authenticated and httpParameterMap.braintreePaypalNonce.stringValue & httpParameterMap.braintreePaypalAccountList.value are empty', () => {
            before(() => {
                customer.authenticated = true;
                httpParameterMap = {
                    braintreePaypalAccountList: {
                        value: ''
                    },
                    paymentMethodUUID: {
                        stringValue: 'a737aaee-f9b2-4241-a17e-1344649bb851'
                    },
                    braintreePaypalNonce: {
                        stringValue: ''
                    }
                };
            });
            it('response should be equal true', () => {
                expect(paymentHelper.isSavedPaypalMethod(httpParameterMap)).equal(true);
            });
        });
    });

    describe('getMerchantAccountID', () => {
        describe('If currency code is correct and provided in lower case', () => {
            before(() => {
                currencyCode = 'usd';
            });
            it('responce type shoul be string', () => {
                expect(paymentHelper.getMerchantAccountID(currencyCode)).to.be.a('string');
            });
            it('responce length shoul be equal 16', () => {
                expect(paymentHelper.getMerchantAccountID(currencyCode).length).equal(16);
            });
            it('responce shoul be equal dhr132d4fg45dfr4', () => {
                expect(paymentHelper.getMerchantAccountID(currencyCode)).equal('dhr132d4fg45dfr4');
            });
        });

        describe('If currency code is correct and provided in upper case', () => {
            before(() => {
                currencyCode = 'USD';
            });
            it('responce type shoul be string', () => {
                expect(paymentHelper.getMerchantAccountID(currencyCode)).to.be.a('string');
            });
            it('responce length shoul be equal 16', () => {
                expect(paymentHelper.getMerchantAccountID(currencyCode).length).equal(16);
            });
            it('responce shoul be equal dhr132d4fg45dfr4', () => {
                expect(paymentHelper.getMerchantAccountID(currencyCode)).equal('dhr132d4fg45dfr4');
            });
        });
    });

    describe('setAndReturnNewDefaultCard', () => {
        const customerProfile = {
            paymentInstruments: [{
                paymentMethod: 'BRAINTREE_CREDIT',
                custom: {}
            }, {
                paymentMethod: 'DISCOVER',
                custom: {}
            }],
            getWallet: () => ({
                getPaymentInstruments: function (paymentInstrument) {
                    return customerProfile.paymentInstruments.filter((item) => item.paymentMethod.includes(paymentInstrument));
                }
            })
        };
        const paymentMethod = 'BRAINTREE_CREDIT';
        const responseArray = [{
            custom: {
                braintreeDefaultCard: false
            }
        }];
        dw.order.PaymentInstrument.METHOD_CREDIT_CARD = 'BRAINTREE_CREDIT';

        describe('If customer.profile exist and paymentInstrument is allowed', () => {
            before(() => {
                customer = {
                    profile: {
                        paymentInstruments: ['BRAINTREE_CREDIT', 'BRAINTREE_GOOGLEPAY', 'BRAINTREE_SRC'],
                        getWallet: () => ({
                            getPaymentInstruments: function (paymentInstrument) {
                                const index = customer.profile.paymentInstruments.indexOf(paymentInstrument);
                                return customer.profile.paymentInstruments[index];
                            }
                        })
                    }
                };
                stub(paymentHelper, 'getApplicableCreditCardPaymentInstruments');
                paymentHelper.getApplicableCreditCardPaymentInstruments.returns(responseArray);
            });

            after(() => {
                paymentHelper.getApplicableCreditCardPaymentInstruments.restore();
            });

            it('response type should be an array', () => {
                expect(paymentHelper.setAndReturnNewDefaultCard(paymentMethod, customerProfile)).to.be.a('array');
            });
            it('response type deeply should be object', () => {
                expect(paymentHelper.setAndReturnNewDefaultCard(paymentMethod, customerProfile)[0]).to.be.a('object');
            });
            it('response property custom.braintreeDefaultCard should change from false to true', () => {
                expect(paymentHelper.setAndReturnNewDefaultCard(paymentMethod, customerProfile)[0].custom.braintreeDefaultCard).equal(true);
            });
        });

        describe('If customer.profile does not exist and paymentInstrument is allowed', () => {
            before(() => {
                customer = {
                    profile: null
                };
                stub(paymentHelper, 'getApplicableCreditCardPaymentInstruments');
                paymentHelper.getApplicableCreditCardPaymentInstruments.returns(responseArray);
            });

            after(() => {
                paymentHelper.getApplicableCreditCardPaymentInstruments.restore();
            });

            it('response type should be an array', () => {
                expect(paymentHelper.setAndReturnNewDefaultCard(paymentMethod, customerProfile)).to.be.a('array');
            });
            it('response type deeply should be object', () => {
                expect(paymentHelper.setAndReturnNewDefaultCard(paymentMethod, customerProfile)[0]).to.be.a('object');
            });
            it('response property custom.braintreeDefaultCard should change from false to true', () => {
                expect(paymentHelper.setAndReturnNewDefaultCard(paymentMethod, customerProfile)[0].custom.braintreeDefaultCard).equal(true);
            });
            it('response property custom.braintreeDefaultCard should change from false to true if paymentMethod isn\'t among allowed payment processors ids', () => {
                expect(paymentHelper.setAndReturnNewDefaultCard('DISCOVER', customerProfile)).to.deep.equal([{
                    paymentMethod: 'DISCOVER',
                    custom: {
                        braintreeDefaultCard: true
                    }
                }]);
            });
        });
    });

    describe('defineCreateTransactionQueryName', () => {
        const data = { options: {} };

        afterEach(() => {
            data.isPaypal = false;
            data.isCreditCard = false;
            data.options.submitForSettlement = false;
        });

        it('response should be equal chargePaypal if if data.isPaypal === true && data.options.submitForSettlement === true', () => {
            data.isPaypal = true;
            data.options.submitForSettlement = true;

            expect(paymentHelper.defineCreateTransactionQueryName(data)).to.equal('chargePaypal');
        });

        it('response should be equal authorizePaypal if data.isPaypal === true && data.options.submitForSettlement === false', () => {
            data.isPaypal = true;
            data.options.submitForSettlement = false;

            expect(paymentHelper.defineCreateTransactionQueryName(data)).to.equal('authorizePaypal');
        });

        it('response should be equal sale if data.isPaypal === false && data.options.submitForSettlement === true', () => {
            data.isPaypal = false;
            data.options.submitForSettlement = true;

            expect(paymentHelper.defineCreateTransactionQueryName(data)).equal('sale');
        });

        it('response should be equal authorization if data.isPaypal === false && data.options.submitForSettlement === false', () => {
            data.isPaypal = false;
            data.options.submitForSettlement = false;

            expect(paymentHelper.defineCreateTransactionQueryName(data)).equal('authorization');
        });

        it('response should be equal chargeCreditCard if data.isCreditCard === true && data.options.submitForSettlement === true', () => {
            data.isCreditCard = true;
            data.options.submitForSettlement = true;

            expect(paymentHelper.defineCreateTransactionQueryName(data)).equal('chargeCreditCard');
        });

        it('response should be equal authorizeCreditCard if data.isCreditCard === true && data.options.submitForSettlement === false', () => {
            data.isCreditCard = true;
            data.options.submitForSettlement = false;

            expect(paymentHelper.defineCreateTransactionQueryName(data)).equal('authorizeCreditCard');
        });
    });

    describe('getSessionPaymentMethodId', () => {
        before(() => {
            stub(paymentHelper, 'getBraintreePaymentInstrument');
        });

        after(() => {
            paymentHelper.getBraintreePaymentInstrument.restore();
        });

        const lineItemContainer = {};

        it('Return sesison payment method ID', () => {
            paymentHelper.getBraintreePaymentInstrument.returns({
                getPaymentMethod: () => 'PayPal'
            });

            const val = paymentHelper.getSessionPaymentMethodId(lineItemContainer);

            expect(val).to.be.a('string').that.equal('PayPal');
        });

        it('Return null, session payment method ID', () => {
            paymentHelper.getBraintreePaymentInstrument.returns(undefined);

            expect(paymentHelper.getSessionPaymentMethodId(lineItemContainer)).to.be.null;
        });
    });

    describe('getAccountFormFields', () => {
        let formKeys = { email: '' };
        let paymentForm = server.forms.getForm('coCustomer');

        Array.reduce = (a, b, c) => {
            return Array.prototype.reduce.call(a, b, c);
        };

        it('Get Account Form Fields (coCustomer)', () => {
            paymentForm.email = { htmlName: 'dwfrm_coCustomer_email', value: '' };

            const val = paymentHelper.getAccountFormFields(paymentForm, formKeys);

            expect(val).to.be.an('object').that.have.property('email');
            expect(val.email).to.have.all.keys('name', 'value');
        });

        it('Get Account Form Fields (billing)', () => {
            formKeys = {
                firstName: '',
                lastName: '',
                address1: '',
                address2: '',
                city: '',
                postalCode: '',
                stateCode: '',
                country: '',
                phone: '',
                paymentMethod: '',
                addInfo: null,
                newsletterSubscription: null
            };

            paymentForm = server.forms.getForm('billing');

            paymentForm.firstName = { htmlName: 'dwfrm_billing_addressFields_firstName', value: '' };
            paymentForm.lastName = { htmlName: 'dwfrm_billing_addressFields_lastName', value: '' };
            paymentForm.address1 = { htmlName: 'dwfrm_billing_addressFields_address1', value: '' };
            paymentForm.address2 = { htmlName: 'dwfrm_billing_addressFields_address2', value: '' };
            paymentForm.city = { htmlName: 'dwfrm_billing_addressFields_city', value: '' };
            paymentForm.postalCode = { htmlName: 'dwfrm_billing_addressFields_postalCode', value: '' };
            paymentForm.stateCode = { htmlName: 'dwfrm_billing_addressFields_stateCode', value: '' };
            paymentForm.country = { htmlName: 'dwfrm_billing_addressFields_country', value: '' };
            paymentForm.phone = { htmlName: 'dwfrm_billing_addressFields_phone', value: '' };
            paymentForm.paymentMethod = { htmlName: 'dwfrm_billing_addressFields_paymentMethod', value: '' };
            paymentForm.newsletterSubscription = { htmlName: 'dwfrm_billing_addressFields_states_newsletterSubscription', value: '' };

            const val = paymentHelper.getAccountFormFields(paymentForm, formKeys);

            expect(val)
                .to.be.an('object')
                .that.include.keys('firstName', 'lastName', 'address1', 'address2', 'city', 'postalCode', 'stateCode', 'country', 'phone', 'paymentMethod', 'newsletterSubscription');
        });
    });

    describe('createBillingFormFields', () => {
        it('Creates Checkout Billing Form fields object', () => {
            expect(paymentHelper.createBillingFormFields())
                .to.be.an('object')
                .that.include.keys('firstName', 'lastName', 'address1', 'address2', 'city', 'postalCode', 'stateCode', 'country', 'phone', 'paymentMethod');
        });
    });

    describe('createCustomerFormFields', () => {
        it('Creates Customer Form fields object (email)', () => {
            expect(paymentHelper.createCustomerFormFields()).to.be.an('object').that.include.keys('value', 'htmlName');
        });
    });

    describe('getAccountNameFields', () => {
        const paymentForm = {
            key_0: { htmlName: 'name_0' },
            key_1: { htmlName: 'name_1' },
            clear: () => {}
        };
        const data = { key_0: {}, key_1: {}, key_2: {} };

        it('result should be an object with account name fields', () => {
            expect(paymentHelper.getAccountNameFields(paymentForm, data)).to.deep.equal({ name_0: '', name_1: '' });
        });
    });

    describe('findCurrentSiteCurrency', () => {
        const allowedCurrenciesCodes = ['USD', 'EUR', 'JPY', 'CNY'];

        it('Return current site currency code', () => {
            const val = paymentHelper.findCurrentSiteCurrency(allowedCurrenciesCodes);

            expect(val).to.be.a('string').that.equal('USD');
        });

        it('Current site currency code not founded', () => {
            allowedCurrenciesCodes.shift();

            expect(paymentHelper.findCurrentSiteCurrency(allowedCurrenciesCodes)).to.be.null;
        });
    });

    describe('getSFRACheckoutFormFields', () => {
        it('Gets object with SFRA Checkout Form Fields', () => {
            expect(paymentHelper.getSFRACheckoutFormFields())
                .to.be.an('object')
                .that.include.keys('firstName', 'lastName', 'address1', 'address2', 'city', 'postalCode', 'stateCode', 'country', 'phone', 'paymentMethod');
        });
    });

    describe('getSFRACustomerFormFields', () => {
        it('Gets object with SFRA Customer Form Fields', () => {
            stub(paymentHelper, 'createCustomerFormFields').returns(server.forms.getForm('coCustomer'));

            const val = paymentHelper.getSFRACustomerFormFields();

            expect(val).to.be.an('object').that.have.property('email');
            expect(val.email).to.have.all.keys('name', 'value');

            paymentHelper.createCustomerFormFields.restore();
        });
    });

    describe('getLastUsedPaypalPmData', () => {
        const paymentMethods = [
            { node: { details: { __typename: 'CreditCardDetails' } } },
            { node: { details: { __typename: 'PayPalAccountDetails' } } }
        ];

        it('The last used payment method was got', () => {
            expect(paymentHelper.getLastUsedPaypalPmData(paymentMethods)).to.be.an('object').has.property('node');
        });

        it('No match found, returns null', () => {
            paymentMethods.pop();

            expect(paymentHelper.getLastUsedPaypalPmData(paymentMethods)).to.be.null;
        });
    });
});
