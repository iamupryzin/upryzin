const { int_braintree: { braintreeApiCallsPath } } = require('../path.json');

const { it, describe, before, after } = require('mocha');
const { stub } = require('sinon');
const { expect } = require('chai');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');

const createGQService = stub();

const braintreeApiCalls = proxyquire(braintreeApiCallsPath, {
    'dw/web/Resource': dw.web.Resource,
    '~/cartridge/scripts/braintree/helpers/paymentHelper': {
        getLogger: () => {
            return { error: error => error };
        }
    },
    '*/cartridge/scripts/service/braintreeGraphQLService': createGQService
});


describe('braintreeApiCalls file', () => {
    describe('call', () => {
        before(() => {
            stub(dw.web.Resource, 'msg');

            dw.web.Resource.msg.withArgs('braintree.service.noconfigurations', 'locale', null).returns('Service int_braintree.http.graphql.payment.Braintree is undefined. Need to add this service in Administration > Operations > Services');
            dw.web.Resource.msg.withArgs('braintree.server.error.parse', 'locale', null).returns('An error occurred. Check Braintree log file for more details.');
            dw.web.Resource.msg.withArgs('braintree.server.error', 'locale', null).returns('Internal server error. Please, try later...');
        });

        after(() => {
            dw.web.Resource.msg.restore();
        });

        it('If createGQService throw an error', () => {
            createGQService.throws(Error);
            expect(() => braintreeApiCalls.call()).to.throw(Error, 'Service int_braintree.http.graphql.payment.Braintree is undefined');
        });

        it('If service.call() throw an error', () => {
            createGQService.returns({
                call: () => {
                    throw new Error();
                }
            });
            expect(() => braintreeApiCalls.call()).to.throw(Object).with.property('customMessage');
        });

        it('If result.isOk() === false', () => {
            createGQService.returns({
                call: () => {
                    return {
                        isOk: () => false
                    };
                }
            });
            expect(() => braintreeApiCalls.call()).to.throw(Error, 'Internal server error. Please, try later...');
        });

        it('If method returns service.getResponse() successfully', () => {
            createGQService.returns({
                call: () => {
                    return {
                        isOk: () => true
                    };
                },
                getResponse: () => { return {}; }
            });
            expect(braintreeApiCalls.call()).to.deep.equal({});
        });
    });
});
