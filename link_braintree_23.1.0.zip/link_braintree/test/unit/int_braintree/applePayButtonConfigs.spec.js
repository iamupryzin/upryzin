const { int_braintree: { applePayButtonConfigsPath } } = require('../path.json');
const { expect } = require('chai');
const { it, describe } = require('mocha');

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const proxyquire = require('proxyquire').noCallThru();

const applePayButtonConfigs = proxyquire(applePayButtonConfigsPath, {
    'dw/system/Site': {
        current: {
            getCustomPreferenceValue: () => '{"billing":"billingStyle", "cart":"cartStyle"}'
        }
    }
});

describe('applePayButtonConfigs file', () => {
    it('object must has APPLEPAY_Billing_Button_Config property', () => {
        expect(applePayButtonConfigs).has.property('APPLEPAY_Billing_Button_Config');
    });

    it('styles must be for a billing button', () => {
        expect(applePayButtonConfigs.APPLEPAY_Billing_Button_Config).to.be.deep.equal({ style: 'billingStyle' });
    });

    it('object must has APPLEPAY_Cart_Button_Config property', () => {
        expect(applePayButtonConfigs).has.property('APPLEPAY_Cart_Button_Config');
    });

    it('styles must be for a cart button', () => {
        expect(applePayButtonConfigs.APPLEPAY_Cart_Button_Config).to.be.deep.equal({ style: 'cartStyle' });
    });
});
