/* eslint-disable new-cap */
const { int_braintree: { braintreeVenmoPath } } = require('../path.json');

const { it, describe, before, after, beforeEach, afterEach } = require('mocha');
const { stub } = require('sinon');
const { expect } = require('chai');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');

require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const getCustomerPaymentInstrument = stub();
const verifyTransactionStatus = stub();
const checkForPaymentInstruments = stub();

const braintreeVenmo = proxyquire(braintreeVenmoPath, {
    'dw/order/OrderMgr': {
        getOrder: () => ({ removePaymentInstrument: () => {} })
    },
    'dw/order/PaymentMgr': {
        getPaymentMethod: () => {
            return { getPaymentProcessor: () => {} };
        }
    },
    'dw/system/Transaction': dw.system.Transaction,
    'dw/web/Resource': dw.web.Resource,
    '~/cartridge/scripts/braintree/helpers/customerHelper': {
        getVenmoCustomerPaymentInstrumentByUserID: () => {},
        getCustomerPaymentInstrument,
        setBraintreeDefaultCard: () => {},
        clearDefaultProperty: () => {},
        getCustomerPaymentInstruments: () => {}
    },
    '~/cartridge/scripts/hooks/payment/processor/processorHelper': {
        createBaseSaleTransactionData: () => ({}),
        saveGeneralTransactionData: () => {},
        checkForPaymentInstruments,
        verifyTransactionStatus
    },
    '~/cartridge/scripts/braintree/helpers/paymentHelper': {
        deleteBraintreePaymentInstruments: () => {},
        getAmountPaid: () => {},
        handleErrorCode: () => {},
        getLogger: () => ({ error: () => {} })
    },
    '~/cartridge/config/braintreePreferences': {
        paymentMethods: {
            BRAINTREE_VENMO: {
                paymentMethodId: 'venmo-id'
            }
        }
    },
    '~/cartridge/config/braintreeConstants': {
        NEW_ACCOUNT: 'new-account'
    },
    '*/cartridge/models/btGraphQLSdk': function () {
        this.createTransaction = () => {
            return {
                transaction: {
                    paymentMethodSnapshot: { venmoUserId: 'venmo-user-id' },
                    paymentMethod: { legacyId: 'legacy-id' }
                }
            };
        };
    }
});

describe('braintreeVenmo file', () => {
    describe('createSaleTransactionData', () => {
        const order = {};
        const paymentInstrument = {
            custom: {
                braintreePaymentMethodNonce: '',
                braintreeFraudRiskData: 'super-secure-data'
            },
            creditCardToken: ''
        };

        const createSaleTransactionData = braintreeVenmo.__get__('createSaleTransactionData');

        it('If paymentInstrument.custom.braintreePaymentMethodNonce && paymentInstrument.creditCardToken are empty', () => {
            expect(() => createSaleTransactionData(order, paymentInstrument)).to.throw(Error, 'paymentInstrument.custom.braintreePaymentMethodNonce or paymentInstrument.creditCardToken are empty');
        });

        it('If response data returned successfully', () => {
            paymentInstrument.custom.braintreePaymentMethodNonce = 'test-nonce';
            paymentInstrument.creditCardToken = 'test-token';

            const result = createSaleTransactionData(order, paymentInstrument);

            expect(result).to.be.an('object');
            expect(result).to.have.all.keys('descriptor', 'deviceData');
            expect(result).to.deep.equal({
                descriptor: {
                    name: ''
                },
                deviceData: 'super-secure-data'
            });
        });
    });

    describe('authorizeFailedFlow', () => {
        const order = { custom: {} };
        const paymentInstrument = {
            getPaymentTransaction: () => {
                return {
                    setPaymentProcessor: () => {}
                };
            },
            custom: {}
        };
        const braintreeError = 'braintree-error-text';

        const authorizeFailedFlow = braintreeVenmo.__get__('authorizeFailedFlow');

        before(() => {
            stub(dw.system.Transaction, 'wrap', (callback) => callback());
        });

        after(() => {
            dw.system.Transaction.wrap.restore();
        });

        it('If failed flow authorized and object with error returned', () => {
            const result = authorizeFailedFlow(order, paymentInstrument, braintreeError);

            expect(result).to.be.an('object');
            expect(result).to.have.key('error');
            expect(result).to.deep.equal({ error: true });

            expect(dw.system.Transaction.wrap.calledOnce).to.be.true;
        });
    });

    describe('saveTransactionData', () => {
        const setPaymentProcessor = stub();

        const order = {};
        const paymentInstrument = {
            getPaymentTransaction: () => {
                return { setPaymentProcessor };
            },
            creditCardToken: ''
        };
        const saleTransactionResponseData = {};
        const saleTransactionRequestData = {};

        const saveTransactionData = braintreeVenmo.__get__('saveTransactionData');

        before(() => {
            stub(dw.system.Transaction, 'wrap', (callback) => callback());
        });

        after(() => {
            dw.system.Transaction.wrap.restore();
        });

        afterEach(() => {
            dw.system.Transaction.wrap.reset();
            setPaymentProcessor.reset();
        });

        it('If general transaction data was saved', () => {
            saveTransactionData(order, paymentInstrument, saleTransactionResponseData, saleTransactionRequestData);

            expect(dw.system.Transaction.wrap.calledOnce).to.be.true;
            expect(setPaymentProcessor.calledOnce).to.be.true;
        });

        it('If creditCardToken and general transaction data were saved', () => {
            saleTransactionResponseData.paymentMethod = { legacyId: 'venmo-id' };

            saveTransactionData(order, paymentInstrument, saleTransactionResponseData, saleTransactionRequestData);

            expect(dw.system.Transaction.wrap.calledOnce).to.be.true;
            expect(setPaymentProcessor.calledOnce).to.be.true;
            expect(paymentInstrument.creditCardToken).to.equal('venmo-id');
        });
    });

    describe('saveVenmoAccount', () => {
        const transactionResponseData = {
            paymentMethod: { legacyId: 'venmo-id' },
            paymentMethodSnapshot: { venmoUserId: 'venmo-user-id' }
        };
        const venmoUserId = '';
        const originalCustomer = customer;
        const setCreditCardType = stub();

        const saveVenmoAccount = braintreeVenmo.__get__('saveVenmoAccount');

        before(() => {
            customer = {
                getProfile: () => {
                    return {
                        getWallet: () => {
                            return {
                                createPaymentInstrument: () => {
                                    return {
                                        setCreditCardType,
                                        custom: {}
                                    };
                                }
                            };
                        }
                    };
                }
            };
            stub(dw.system.Transaction, 'rollback');
            stub(dw.system.Transaction, 'commit');
        });

        after(() => {
            customer = originalCustomer;

            dw.system.Transaction.rollback.restore();
            dw.system.Transaction.commit.restore();
        });

        it('If error was thrown and transaction rolled back', () => {
            setCreditCardType.throws({ message: 'Venmo error' });

            const result = saveVenmoAccount(transactionResponseData, venmoUserId);

            expect(result).to.be.an('object');
            expect(result).to.have.key('error');
            expect(result).to.deep.equal({ error: 'Venmo error' });

            expect(dw.system.Transaction.rollback.calledOnce).to.be.true;
        });

        it('If token was returned and transaction commited', () => {
            setCreditCardType.returns();

            const result = saveVenmoAccount(transactionResponseData, venmoUserId);

            expect(result).to.be.an('object');
            expect(result).to.have.key('token');
            expect(result).to.deep.equal({ token: 'venmo-id' });

            expect(dw.system.Transaction.commit.calledOnce).to.be.true;
        });
    });

    describe('Handle', () => {
        const originalHttpParameterMap = request.httpParameterMap;

        const basket = {
            createPaymentInstrument: () => {
                return {
                    custom: {
                        braintreeFraudRiskData: '',
                        braintreePaymentMethodNonce: ''
                    },
                    paymentTransaction: { setPaymentProcessor: () => {} }
                };
            }
        };

        before(() => {
            request.httpParameterMap = {
                braintreeVenmoNonce: { stringValue: 'nonce' },
                braintreeVenmoAccountList: { stringValue: 'account' },
                braintreeVenmoAccountMakeDefault: { booleanValue: true },
                braintreeVenmoRiskData: { stringValue: 'risk-data' },
                braintreeSaveVenmoAccount: { booleanValue: true },
                braintreeVenmoUserId: { stringValue: 'user-id' }
            };

            stub(dw.web.Resource, 'msg').returns('Error occurred while attempting to process payment.');
            stub(dw.order.PaymentMgr, 'getPaymentMethod').returns({ getPaymentProcessor: () => {} });
        });

        after(() => {
            request.httpParameterMap = originalHttpParameterMap;

            dw.order.PaymentMgr.getPaymentMethod.restore();
            dw.web.Resource.msg.restore();
        });

        beforeEach(() => {
            dw.order.PaymentMgr.getPaymentMethod.reset();
        });

        it('If braintree payment instrument successfully created', () => {
            const result = braintreeVenmo.Handle(basket);

            expect(result).to.be.an('object');
            expect(result).to.have.key('success');
            expect(result).to.deep.equal({ success: true });
        });

        it('If no payment instruments were found and error returned', () => {
            request.httpParameterMap.braintreeVenmoNonce.empty = true;

            const result = braintreeVenmo.Handle(basket);

            expect(result).to.be.an('object');
            expect(result).to.have.property('error');
            expect(result).to.deep.equal({
                error: true,
                fieldErrors: [],
                serverErrors: [
                    'Error occurred while attempting to process payment.'
                ]
            });
        });

        it('If payment instruments were found and new one was created', () => {
            getCustomerPaymentInstrument.returns({ custom: { braintreeVenmoUserId: 'venmo-user-id' } });
            request.httpParameterMap.braintreeVenmoNonce.empty = true;

            const result = braintreeVenmo.Handle(basket);

            expect(result).to.be.an('object');
            expect(result).to.have.property('success');
            expect(result).to.deep.equal({ success: true });
        });

        it('If no nonce were found and error returned', () => {
            request.httpParameterMap.braintreeVenmoNonce.empty = false;
            request.httpParameterMap.braintreeVenmoNonce.stringValue = '';

            const result = braintreeVenmo.Handle(basket);

            expect(result).to.be.an('object');
            expect(result).to.have.property('error');
            expect(result).to.deep.equal({
                error: true,
                fieldErrors: [],
                serverErrors: [
                    'Error occurred while attempting to process payment.'
                ]
            });
        });
    });

    describe('Authorize', () => {
        const getValue = stub();

        const orderNo = '00000';
        const paymentInstrument = {
            getPaymentTransaction: () => {
                return {
                    getAmount: () => {
                        return {
                            getValue
                        };
                    }
                };
            },
            custom: {
                braintreeSaveCreditCard: true
            }
        };
        const originalCustomer = customer;
        checkForPaymentInstruments.returns(false);

        before(() => {
            braintreeVenmo.__set__('createSaleTransactionData', () => {});
            braintreeVenmo.__set__('saveTransactionData', () => {});
            braintreeVenmo.__set__('authorizeFailedFlow', () => ({ error: true }));

            stub(dw.system.Transaction, 'wrap', (callback) => callback());

            customer.authenticated = true;
        });

        after(() => {
            braintreeVenmo.__ResetDependency__('createSaleTransactionData');
            braintreeVenmo.__ResetDependency__('saveTransactionData');
            braintreeVenmo.__ResetDependency__('authorizeFailedFlow');

            dw.system.Transaction.wrap.restore();

            customer = originalCustomer;

            checkForPaymentInstruments.reset();
        });

        afterEach(() => {
            dw.system.Transaction.wrap.reset();
        });

        it('If payment instrument amount is less than 0', () => {
            getValue.returns(-1);

            const result = braintreeVenmo.Authorize(orderNo, paymentInstrument);

            expect(result).to.be.an('object');
            expect(result).to.have.property('authorized');
            expect(result).to.deep.equal({ authorized: true });

            expect(dw.system.Transaction.wrap.calledOnce).to.be.true;
        });

        it('If payment instrument amount is more than 0 and transaction status was not verified', () => {
            getValue.returns(1);
            verifyTransactionStatus.throws({ message: 'Error' });

            const result = braintreeVenmo.Authorize(orderNo, paymentInstrument);

            expect(result).to.be.an('object');
            expect(result).to.have.property('error');
            expect(result).to.deep.equal({ error: true });

            expect(dw.system.Transaction.wrap.calledOnce).to.be.false;
        });

        it('If payment instrument amount is more than 0, transaction status was verified and customer is authenticated', () => {
            getValue.returns(1);
            verifyTransactionStatus.returns();

            const result = braintreeVenmo.Authorize(orderNo, paymentInstrument);

            expect(result).to.be.an('object');
            expect(result).to.have.property('authorized');
            expect(result).to.deep.equal({ authorized: true });

            expect(dw.system.Transaction.wrap.calledOnce).to.be.true;
        });

        it('If payment instrument amount is more than 0, transaction status was verified and customer is authenticated, but it\'s not first payment intrument', () => {
            paymentInstrument.custom.braintreeSaveCreditCard = true;
            checkForPaymentInstruments.returns(true);

            expect(braintreeVenmo.Authorize(orderNo, paymentInstrument)).to.deep.equal({ authorized: true });
        });

        it('If payment instrument amount is more than 0, transaction status was verified and customer is not authenticated', () => {
            getValue.returns(1);
            verifyTransactionStatus.returns();
            customer.authenticated = false;

            const result = braintreeVenmo.Authorize(orderNo, paymentInstrument);

            expect(result).to.be.an('object');
            expect(result).to.have.property('authorized');
            expect(result).to.deep.equal({ authorized: true });

            expect(dw.system.Transaction.wrap.calledOnce).to.be.false;
        });
    });
});
