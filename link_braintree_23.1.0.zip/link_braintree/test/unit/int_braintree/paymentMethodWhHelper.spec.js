const { expect } = require('chai');
const { int_braintree: { paymentMethodWhHelperPath } } = require('../path.json');
const { stub } = require('sinon');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

dw.crypto.WeakMessageDigest = stub();
dw.crypto.WeakMac = stub();
dw.util.Bytes = stub();

const paymentMethodWhHelper = proxyquire(paymentMethodWhHelperPath, {
    'dw/util/Bytes': dw.util.Bytes,
    'dw/crypto/Encoding': dw.crypto.Encoding,
    'dw/crypto/WeakMessageDigest': dw.crypto.WeakMessageDigest,
    'dw/crypto/WeakMac': dw.crypto.WeakMac,
    '*/cartridge/scripts/service/braintreeGraphQLService': () => {
        return {
            configuration: {
                credential: 'BRAINTREE_CREDENTIALS'
            }
        };
    }
});

describe('paymentMethodWhHelper', () => {
    it('response type should be object', () => {
        expect(paymentMethodWhHelper).to.be.a('object');
    });
    it('response should contain property getBtServiceCredentials', () => {
        expect(paymentMethodWhHelper).has.property('getBtServiceCredentials');
    });
    it('response property getBtServiceCredentials type should be function', () => {
        expect(paymentMethodWhHelper.getBtServiceCredentials).to.be.a('function');
    });
    it('response should contain property signatureWithPayloadComparizon', () => {
        expect(paymentMethodWhHelper).has.property('signatureWithPayloadComparizon');
    });
    it('response property signatureWithPayloadComparizon type should be function', () => {
        expect(paymentMethodWhHelper.signatureWithPayloadComparizon).to.be.a('function');
    });
    it('response should contain property getSha1HexDigestValue', () => {
        expect(paymentMethodWhHelper).has.property('getSha1HexDigestValue');
    });
    it('response property getSha1HexDigestValue type should be function', () => {
        expect(paymentMethodWhHelper.getSha1HexDigestValue).to.be.a('function');
    });

    describe('getSha1HashValue', () => {
        const key = 'some_key';
        const getSha1HashValue = paymentMethodWhHelper.__get__('getSha1HashValue');
        before(() => {
            dw.util.Bytes.returns({
                key: key
            });
            dw.crypto.WeakMessageDigest.returns({
                digestBytes: privateKeyToBytes => privateKeyToBytes
            });
        });
        after(() => {
            dw.util.Bytes.reset();
            dw.crypto.WeakMessageDigest.reset();
        });
        it('response type should be object', () => {
            expect(getSha1HashValue(key)).to.be.a('object');
        });
        it('response should has property key', () => {
            expect(getSha1HashValue(key)).has.property('key');
        });
        it('response property key type should be string', () => {
            expect(getSha1HashValue(key).key).to.be.a('string');
        });
        it('response property key type should be equal -> some_key', () => {
            expect(getSha1HashValue(key).key).equal('some_key');
        });
    });

    describe('getHmacSha1HashValue', () => {
        const key = 'some_key';
        const data = 'some_data';
        const getHmacSha1HashValue = paymentMethodWhHelper.__get__('getHmacSha1HashValue');
        before(() => {
            dw.util.Bytes.returns({
                data: data
            });
            dw.crypto.WeakMac.returns({
                digest: (payloadToBytes, getSha1HashValue) => {
                    return {
                        payloadToBytes: payloadToBytes,
                        getSha1HashValue: getSha1HashValue
                    };
                }
            });
            paymentMethodWhHelper.__set__('getSha1HashValue', _key => {
                return _key;
            });
        });
        after(() => {
            dw.util.Bytes.reset();
            dw.crypto.WeakMac.reset();
            paymentMethodWhHelper.__ResetDependency__('getSha1HashValue', () => {
                return undefined;
            });
        });
        it('response type should be object', () => {
            expect(getHmacSha1HashValue(key, data)).to.be.a('object');
        });
        it('response should have property -> payloadToBytes', () => {
            expect(getHmacSha1HashValue(key, data)).has.property('payloadToBytes');
        });
        it('response property payloadToBytes should be deep equal -> { data: "some_data" }', () => {
            expect(getHmacSha1HashValue(key, data).payloadToBytes).deep.equal({ data: 'some_data' });
        });
        it('response type should have property -> getSha1HashValue', () => {
            expect(getHmacSha1HashValue(key, data)).has.property('getSha1HashValue');
        });
        it('response property getHmacSha1HashValue should be equal -> "some_key" ', () => {
            expect(getHmacSha1HashValue(key, data).getSha1HashValue).equal('some_key');
        });
    });

    describe('getBytesFromString', () => {
        const string = 'hello';
        const getBytesFromString = paymentMethodWhHelper.__get__('getBytesFromString');
        describe('If argument string === hello', () => {
            it('response type should be Array', () => {
                expect(getBytesFromString(string)).to.be.a('array');
            });
            it('respons.length should be equal argument.length', () => {
                expect(getBytesFromString(string).length).equal(string.length);
            });
            it('response should be equal [ 104, 101, 108, 108, 111 ]', () => {
                expect(getBytesFromString(string)).deep.equal([104, 101, 108, 108, 111]);
            });
            it('response element type should be number', () => {
                expect(getBytesFromString(string)[0]).to.be.a('number');
            });
        });
    });

    describe('getZipArray', () => {
        let arrays = [['1', '2', '3', '4'], ['a', 'b', 'c', 'd']];
        const getZipArray = paymentMethodWhHelper.__get__('getZipArray');
        it('response type should be -> array', () => {
            expect(getZipArray(arrays)).to.be.a('array');
        });
        it('response array.length should be equal -> 4', () => {
            expect(getZipArray(arrays).length).equal(4);
        });
        it('response array element type should be -> array', () => {
            expect(getZipArray(arrays)[0]).to.be.a('array');
        });
        it('response array element length should be -> 2', () => {
            expect(getZipArray(arrays)[0].length).equal(2);
        });
    });

    describe('getBtServiceCredentials', () => {
        it('response type should be equal string', () => {
            expect(paymentMethodWhHelper.getBtServiceCredentials()).to.be.a('string');
        });
        it('response should be equal -> BRAINTREE_CREDENTIALS', () => {
            expect(paymentMethodWhHelper.getBtServiceCredentials()).equal('BRAINTREE_CREDENTIALS');
        });
    });

    describe('signatureWithPayloadComparizon', () => {
        let signature;
        let payload;
        describe('If signature == null || payload == null', () => {
            it('response type should be -> boolean', () => {
                expect(paymentMethodWhHelper.signatureWithPayloadComparizon(signature, payload)).to.be.a('boolean');
            });
            it('response should be equal false', () => {
                expect(paymentMethodWhHelper.signatureWithPayloadComparizon(signature, payload)).equal(false);
            });
        });
        describe('If signature != null || payload != null', () => {
            before(() => {
                signature = 'JohnDowSignature';
                payload = true;
            });
            it('response type should be -> boolean', () => {
                expect(paymentMethodWhHelper.signatureWithPayloadComparizon(signature, payload)).to.be.a('boolean');
            });
            it('response should be equal false', () => {
                expect(paymentMethodWhHelper.signatureWithPayloadComparizon(signature, payload)).equal(false);
            });
        });
    });
});
