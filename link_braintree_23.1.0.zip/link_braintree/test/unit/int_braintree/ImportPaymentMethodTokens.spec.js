const { int_braintree: { ImportPaymentMethodTokensPath } } = require('../path.json');
const { expect } = require('chai');
const { it, describe } = require('mocha');
const { stub } = require('sinon');

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const proxyquire = require('proxyquire').noCallThru();

const hasNext = stub();
const getCustomerByCustomerNumber = stub();
const info = stub();
const warn = stub();
const error = stub();
const close = stub();
const called = stub();

const tokenizedMethodDetailsData = {
    creditCardType: '',
    prefix: '',
    braintreePaymentMethodToken: '',
    creditCardExpMonth: '',
    creditCardExpYear: '',
    customerId: ''
};

const instrument = {
    creditCardToken: null
};

function Status() {
    return this;
}

const wallet = {
    getPaymentInstruments: () => ({
        iterator: () => ({
            hasNext: hasNext,
            next: () => instrument
        })
    }),
    createPaymentInstrument: () => ({
        setCreditCardHolder: () => {},
        setCreditCardNumber: () => {},
        setCreditCardExpirationMonth: () => {},
        setCreditCardExpirationYear: () => {},
        setCreditCardType: () => {},
        creditCardToken: () => {}
    }),
    removePaymentInstrument: () => {}
};

const customer = {
    getProfile: () => ({
        getWallet: () => wallet,
        getFirstName: () => {},
        getLastName: () => {}
    })
};

const ImportPaymentMethodTokens = proxyquire(ImportPaymentMethodTokensPath, {
    'dw/customer': {
        CustomerMgr: {
            getCustomerByCustomerNumber: getCustomerByCustomerNumber
        }
    },
    'dw/io': {
        File: function () {
            this.remove = called;
            this.IMPEX = 'IMPEX';
            this.SEPARATOR = 'SEPARATOR';
            return this;
        },
        CSVStreamReader: function () {
            this.close = close;
            this.readNext = hasNext;
            return this;
        },
        FileReader: function () {
            this.close = close;
            return this;
        }
    },
    'dw/system/Status': Status,
    'dw/system/Transaction': dw.system.Transaction,
    'dw/order/PaymentInstrument': dw.order.PaymentInstrument,
    '~/cartridge/scripts/braintree/helpers/paymentHelper': {
        getLogger: () => ({
            info: info,
            warn: warn,
            error: error
        })
    }
});

describe('name file', () => {
    describe('isPaymentInstrumentExistsInWallet', () => {
        const isPaymentInstrumentExistsInWallet = ImportPaymentMethodTokens.__get__('isPaymentInstrumentExistsInWallet');
        const paymentMethodToken = 'paymentMethodToken';

        beforeEach(() => {
            hasNext.onFirstCall().returns(true).onSecondCall().returns(false);
        });

        afterEach(() => {
            hasNext.reset();
        });

        after(() => {
            instrument.creditCardToken = null;
        });

        it('if payment instrument exists in wallet', () => {
            instrument.creditCardToken = 'paymentMethodToken';

            expect(isPaymentInstrumentExistsInWallet(wallet, paymentMethodToken)).to.be.true;
        });

        it('if payment instrument does not exist in wallet', () => {
            instrument.creditCardToken = null;

            expect(isPaymentInstrumentExistsInWallet(wallet, paymentMethodToken)).to.be.false;
        });
    });

    describe('createFakeCardNumber', () => {
        const createFakeCardNumber = ImportPaymentMethodTokens.__get__('createFakeCardNumber');

        it('must return fake card number', () => {
            const tokenizedMethodDetails = {
                prefix: 'prefix',
                midPart: 'midPart',
                creditCardLastFour: 'creditCardLastFour'
            };

            expect(createFakeCardNumber(tokenizedMethodDetails)).to.be.equal(['prefix', 'midPart', 'creditCardLastFour'].join(''));
        });
    });

    describe('decorateDetailsByType', () => {
        const decorateDetailsByType = ImportPaymentMethodTokens.__get__('decorateDetailsByType');

        const time = String(Date.now().toString().substr(0, 8));

        after(() => {
            tokenizedMethodDetailsData.creditCardType = null;
            tokenizedMethodDetailsData.prefix = null;
            tokenizedMethodDetailsData.midPart = null;
        });

        it('if credit card type is mastercard', () => {
            tokenizedMethodDetailsData.creditCardType = 'mastercard';

            expect(decorateDetailsByType(tokenizedMethodDetailsData)).to.be.deep.equal(Object.assign(tokenizedMethodDetailsData, {
                creditCardType: 'MasterCard',
                prefix: '5444',
                midPart: time
            }));
        });

        it('if credit card type is americanexpress', () => {
            tokenizedMethodDetailsData.creditCardType = 'americanexpress';

            expect(decorateDetailsByType(tokenizedMethodDetailsData)).to.be.deep.equal(Object.assign(tokenizedMethodDetailsData, {
                creditCardType: 'Amex',
                prefix: '3782',
                midPart: time
            }));
        });

        it('if credit card type is discover', () => {
            tokenizedMethodDetailsData.creditCardType = 'discover';

            expect(decorateDetailsByType(tokenizedMethodDetailsData)).to.be.deep.equal(Object.assign(tokenizedMethodDetailsData, {
                creditCardType: 'Discover',
                prefix: '6011',
                midPart: time
            }));
        });

        it('if credit card type is unknown', () => {
            tokenizedMethodDetailsData.creditCardType = 'unknown';

            expect(decorateDetailsByType(tokenizedMethodDetailsData)).to.be.deep.equal(Object.assign(tokenizedMethodDetailsData, {
                creditCardType: 'Visa',
                prefix: '4111',
                midPart: time
            }));
        });
    });

    describe('createCustomerPaymentInstrument', () => {
        const createCustomerPaymentInstrument = ImportPaymentMethodTokens.__get__('createCustomerPaymentInstrument');

        after(() => {
            warn.reset();
            error.reset();
            getCustomerByCustomerNumber.reset();
            info.reset();
            ImportPaymentMethodTokens.__ResetDependency__('isPaymentInstrumentExistsInWallet');
            ImportPaymentMethodTokens.__ResetDependency__('decorateDetailsByType');
            tokenizedMethodDetailsData.customerId = '';
        });

        it('must throw an error', () => {
            expect(() => createCustomerPaymentInstrument(tokenizedMethodDetailsData)).to.throw(Error, 'No customer with ID given: 00000000');
        });

        it('must log info if isPaymentInstrumentAlreadyExists', () => {
            ImportPaymentMethodTokens.__set__('isPaymentInstrumentExistsInWallet', () => true);
            getCustomerByCustomerNumber.returns(customer);

            createCustomerPaymentInstrument(tokenizedMethodDetailsData);

            expect(info.calledOnce).to.be.true;
        });

        it('must execute without problems', () => {
            ImportPaymentMethodTokens.__set__('isPaymentInstrumentExistsInWallet', () => false);
            getCustomerByCustomerNumber.returns(customer);
            tokenizedMethodDetailsData.customerId = '1234567';

            expect(createCustomerPaymentInstrument(tokenizedMethodDetailsData, true)).to.be.undefined;
        });

        it('must log warn and error', () => {
            ImportPaymentMethodTokens.__set__('isPaymentInstrumentExistsInWallet', () => false);
            ImportPaymentMethodTokens.__set__('decorateDetailsByType', () => {
                throw new Error();
            });
            getCustomerByCustomerNumber.returns(customer);

            createCustomerPaymentInstrument(tokenizedMethodDetailsData, false);

            expect(warn.calledOnce).to.be.true;
            expect(error.calledOnce).to.be.true;
        });
    });

    describe('removeAllInstruments', () => {
        const removeAllInstruments = ImportPaymentMethodTokens.__get__('removeAllInstruments');

        before(() => {
            hasNext.onFirstCall().returns(true).onSecondCall().returns(true);
            hasNext.returns(false);
        });

        after(() => {
            hasNext.reset();
            close.reset();
            getCustomerByCustomerNumber.reset();
        });

        it('must remove all instruments', () => {
            getCustomerByCustomerNumber.returns(customer);

            removeAllInstruments();
            expect(close.calledTwice).to.be.true;
        });
    });

    describe('importTokensJob', () => {
        const importTokensJob = ImportPaymentMethodTokens.__get__('importTokensJob');

        const opts = {
            fileShortName: 'fileShortName',
            cleanUpCustomersWallet: null,
            removeInputFileAfterImport: null
        };

        beforeEach(() => {
            hasNext.onFirstCall(0).returns(true).onSecondCall(1).returns(true);
            hasNext.returns(false);
        });

        before(() => {
            ImportPaymentMethodTokens.__set__('removeAllInstruments', called);
        });

        afterEach(() => {
            hasNext.reset();
            called.reset();
        });

        after(() => {
            ImportPaymentMethodTokens.__ResetDependency__('removeAllInstruments');
        });

        it('if there is cleanUpCustomersWallet', () => {
            opts.cleanUpCustomersWallet = 'cleanUpCustomersWallet';

            importTokensJob(opts);
            expect(called.calledOnce).to.be.true;
        });

        it('if there is not cleanUpCustomersWallet', () => {
            opts.cleanUpCustomersWallet = null;

            expect(importTokensJob(opts)).to.be.undefined;
        });

        it('if removeInputFileAfterImport is true', () => {
            opts.removeInputFileAfterImport = true;

            importTokensJob(opts);
            expect(called.called).to.be.true;
        });
    });

    describe('removeAllInstruments', () => {
        const parameters = {
            file_name: null,
            ignore_exist_tokens: null,
            remove_file: null,
            clean_walle: null
        };

        after(() => {
            ImportPaymentMethodTokens.__ResetDependency__('importTokensJob');
        });

        it('must execute without errors', () => {
            ImportPaymentMethodTokens.__set__('importTokensJob', () => {});

            expect(ImportPaymentMethodTokens.execute(parameters)).to.be.instanceOf(Status);
        });

        it('if there is an errors', () => {
            ImportPaymentMethodTokens.__set__('importTokensJob', () => {
                throw new Error();
            });

            expect(ImportPaymentMethodTokens.execute(parameters)).to.be.instanceOf(Status);
            expect(error.called).to.be.true;
        });
    });
});
