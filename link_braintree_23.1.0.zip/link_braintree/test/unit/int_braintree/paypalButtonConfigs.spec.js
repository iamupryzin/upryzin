const { expect } = require('chai');
const { int_braintree: { paypalButtonConfigsPath } } = require('../path.json');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');

const current = {
    getCustomPreferenceValue: () => {
        return JSON.stringify({
            billing: 'billingStyle',
            cart: 'cartStyle',
            minicart: 'minicartStyle',
            pdp: 'pdpStyle'
        });
    }
};

const paypalButtonConfigs = proxyquire(paypalButtonConfigsPath, {
    'dw/system/Site': {
        current
    }
});

describe('paypalButtonConfigs file', () => {
    it('response type should be equal -> object', () => {
        expect(paypalButtonConfigs).to.be.a('object');
    });
    it('response type should consist property -> PAYPAL_Billing_Button_Config', () => {
        expect(paypalButtonConfigs).has.property('PAYPAL_Billing_Button_Config');
    });
    it('response property PAYPAL_Billing_Button_Config type should be equal -> object', () => {
        expect(paypalButtonConfigs.PAYPAL_Billing_Button_Config).to.be.a('object');
    });
    it('response type should consist property -> PAYPAL_Cart_Button_Config', () => {
        expect(paypalButtonConfigs).has.property('PAYPAL_Cart_Button_Config');
    });
    it('response property PAYPAL_Cart_Button_Config type should be equal -> object', () => {
        expect(paypalButtonConfigs.PAYPAL_Cart_Button_Config).to.be.a('object');
    });
    it('response type should consist property -> PAYPAL_MiniCart_Button_Config', () => {
        expect(paypalButtonConfigs).has.property('PAYPAL_MiniCart_Button_Config');
    });
    it('response property PAYPAL_MiniCart_Button_Config type should be equal -> object', () => {
        expect(paypalButtonConfigs.PAYPAL_MiniCart_Button_Config).to.be.a('object');
    });
    it('response type should consist property -> PAYPAL_PDP_Button_Config', () => {
        expect(paypalButtonConfigs).has.property('PAYPAL_PDP_Button_Config');
    });
    it('response property PAYPAL_PDP_Button_Config type should be equal -> object', () => {
        expect(paypalButtonConfigs.PAYPAL_PDP_Button_Config).to.be.a('object');
    });
});
