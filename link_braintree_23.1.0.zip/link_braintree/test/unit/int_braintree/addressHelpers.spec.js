const { int_braintree: { addressHelpersPath } } = require('../path.json');

const { stub } = require('sinon');
const { expect } = require('chai');
const { describe, it } = require('mocha');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');

require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const clear = stub();
const copyFrom = stub();
const addressValidatorModel = stub();

const addressHelpers = proxyquire(addressHelpersPath, {
    '*/cartridge/models/addressValidator': addressValidatorModel,
    '~/cartridge/config/braintreeConstants': {
        BILLING_ADDRESS_ID: 'Billing address',
        SHIPPING_ADDRESS_ID: 'Shipping address'
    }
});

describe('addressHelpers file', () => {
    describe('validateAddressForm', () => {
        const form = {
            clear: clear,
            copyFrom: copyFrom,
            addressId: { value: '' },
            firstName: { value: '' },
            lastName: { value: '' },
            address1: { value: '' },
            address2: { value: '' },
            city: { value: '' },
            phone: { value: '' },
            country: { value: '' },
            states: { stateCode: { value: '' } }
        };

        const data = {
            addressId: 'Test address',
            firstName: 'John',
            lastName: 'Doe',
            address1: '473 Wiseman Street',
            address2: '',
            city: 'Sevierville',
            postalCode: decodeURIComponent('37862'),
            countryCode: 'US',
            stateCode: 'TN',
            phone: '9234567890'
        };

        afterEach(() => {
            clear.reset();
            copyFrom.reset();
            addressValidatorModel.reset();
        });

        it('validation without errors', () => {
            addressValidatorModel.returns({ validate: () => ({}) });

            const val = addressHelpers.validateAddressForm(form, data);

            expect(val).to.be.an.object;
            expect(val).to.be.empty;

            expect(clear.calledOnce).to.be.true;
            expect(copyFrom.calledOnce).to.be.true;
            expect(addressValidatorModel.calledOnce).to.be.true;
        });

        it('validation with errors', () => {
            data.postalCode = '';

            addressValidatorModel.returns({ validate: () => ({ postalCode: 'Invalid field.' }) });

            const val = addressHelpers.validateAddressForm(form, data);

            expect(val).to.be.an.object;
            expect(val).to.be.not.empty;

            expect(clear.calledOnce).to.be.true;
            expect(copyFrom.calledOnce).to.be.true;
            expect(addressValidatorModel.calledOnce).to.be.true;
        });

        it('required fields are missing', () => {
            delete form.country;
            delete form.states;

            expect(() => addressHelpers.validateAddressForm(form, data)).to.throw(TypeError);

            expect(clear.calledOnce).to.be.true;
            expect(copyFrom.calledOnce).to.be.true;
            expect(addressValidatorModel.notCalled).to.be.true;
        });
    });

    describe('prepareAddressData', () => {
        it('return an address object with required keys', () => {
            const prepareAddressData = addressHelpers.__get__('prepareAddressData');

            const val = prepareAddressData({
                addressId: 'Test address',
                firstName: 'John',
                lastName: 'Doe',
                address1: '473 Wiseman Street',
                address2: '',
                city: 'Sevierville',
                postalCode: decodeURIComponent('37862'),
                countryCode: 'US',
                stateCode: 'TN',
                phone: '9234567890'
            });

            expect(val).to.be.an.object;
            expect(val).be.not.empty;
            expect(val).to.have.all.keys([
                'firstName', 'lastName', 'phone', 'addressId', 'address1',
                'address2', 'city', 'postalCode', 'stateCode', 'countryCode'
            ]);
        });
    });

    describe('prepareBillingAddressData', () => {
        it('return a billing address object with required keys', () => {
            const data = {
                billingAddress: {
                    firstName: 'John',
                    lastName: 'Doe',
                    phone: '9234567890',
                    line1: '473 Wiseman Street',
                    locality: 'Sevierville',
                    postalCode: decodeURIComponent('37862'),
                    countryCodeAlpha2: 'US',
                    region: 'TN'
                }
            };

            const val = addressHelpers.prepareBillingAddressData(data);

            expect(val).to.be.an.object;
            expect(val).be.not.empty;
            expect(val).to.have.all.keys([
                'firstName', 'lastName', 'phone', 'addressId', 'address1',
                'address2', 'city', 'postalCode', 'stateCode', 'countryCode'
            ]);
        });
    });

    describe('prepareShippingAddressData', () => {
        it('return a shipping address object with required keys', () => {
            const data = {
                firstName: 'John',
                lastName: 'Doe',
                phone: '9234567890',
                shippingAddress: {
                    line1: '473 Wiseman Street',
                    city: 'Sevierville',
                    postalCode: decodeURIComponent('37862'),
                    countryCode: 'US',
                    state: 'TN'
                }
            };

            const val = addressHelpers.prepareShippingAddressData(data);

            expect(val).to.be.an.object;
            expect(val).be.not.empty;
            expect(val).to.have.all.keys([
                'firstName', 'lastName', 'phone', 'addressId', 'address1',
                'address2', 'city', 'postalCode', 'stateCode', 'countryCode'
            ]);
        });
    });
});
