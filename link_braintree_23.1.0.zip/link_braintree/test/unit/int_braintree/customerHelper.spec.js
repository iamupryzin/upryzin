const { expect } = require('chai');
const { assert, stub } = require('sinon');
const { describe, it, before, after, beforeEach, afterEach } = require('mocha');
const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');

require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const { int_braintree: { customerHelperPath } } = require('../path.json');

const find = stub();
const updateAddressFields = stub();
let customerId;

const prefs = {
    paymentMethods: {
        BRAINTREE_SRC: {
            paymentMethodId: 'BRAINTREE_SRC'
        },
        BRAINTREE_PAYPAL: {
            paymentMethodId: 'BRAINTREE_PAYPAL'
        },
        BRAINTREE_CREDIT: {
            paymentMethodId: 'BRAINTREE_CREDIT'
        },
        BRAINTREE_APPLEPAY: {
            paymentMethodId: 'BRAINTREE_APPLEPAY'
        },
        BRAINTREE_VENMO: {
            paymentMethodId: 'BRAINTREE_VENMO'
        }
    }
};

const customerHelper = proxyquire(customerHelperPath, {
    'dw/svc': {},
    'dw/system/Transaction': dw.system.Transaction,
    'dw/system': dw.system,
    'dw/order': dw.order,
    'dw/customer': dw.customer,
    'dw/object/SystemObjectMgr': dw.object.SystemObjectMgr,
    '~/cartridge/config/braintreePreferences': prefs,
    '*/cartridge/scripts/util/array': { find },
    '*/cartridge/scripts/helpers/addressHelpers': { updateAddressFields },
    '~/cartridge/config/braintreeConstants': {
        TRANSACTION_STATUS_AUTHORIZED: 'AUTHORIZED'
    },
    '~/cartridge/scripts/braintree/helpers/paymentHelper': {
        getBraintreePaymentInstrument: () => {
            return {
                creditCardNumberLastDigits: '1111',
                creditCardExpirationMonth: '07',
                creditCardExpirationYear: '2025',
                custom: { braintreeVenmoUserId: 'venmo-user-id' }
            };
        }
    }
});

describe('customerHelper file', () => {
    describe('getCustomerPaymentInstruments', () => {
        const getPaymentInstruments = stub();
        before(() => {
            stub(customer, 'getProfile');
            customer.getProfile.returns({
                getWallet: () => {
                    return {
                        getPaymentInstruments
                    };
                }
            });

            stub(dw.customer.CustomerMgr, 'getProfile');
            dw.customer.CustomerMgr.getProfile.withArgs(prefs.paymentMethods.BRAINTREE_PAYPAL.paymentMethodId).returns({
                getWallet: () => {
                    return {
                        getPaymentInstruments
                    };
                }
            });
        });
        after(() => {
            dw.customer.CustomerMgr.getProfile.restore();
            customer.getProfile.restore();
        });

        describe('Payment method from customers payment methods list customerId == false', () => {
            before(() => {
                customer.authenticated = true;
            });

            it('customer.authenticated == true', () => {
                customerHelper.getCustomerPaymentInstruments(prefs.paymentMethods.BRAINTREE_PAYPAL.paymentMethodId);
                assert.calledWith(getPaymentInstruments, prefs.paymentMethods.BRAINTREE_PAYPAL.paymentMethodId);
            });
        });

        describe('Returns null', () => {
            before(() => {
                customer.authenticated = undefined;
            });

            it('payment instrument == null', () => {
                expect(customerHelper.getDefaultCustomerPaypalPaymentInstrument()).to.be.null;
            });
        });
    });

    describe('getCustomerPaymentInstrument', () => {
        let uuid = '11111';
        let paymentInstrument = {
            UUID: uuid,
            custom: {
                braintreePaypalAccountEmail: '11111'
            }
        };
        let iter = () => {
            return new dw.util.Iterator([paymentInstrument]);
        };
        let getPaymentInstruments = () => ({
            size: stub(),
            iterator: iter
        });

        describe('Return customerId', () => {
            before(() => {
                customerId = true;
            });
            after(() => {
                customerId = null;
            });
            it('customerId == true', () => {
                expect(customerHelper.getCustomerPaymentInstrument()).to.be.getPaymentInstruments;
            });
        });

        describe('Returns false', () => {
            before(() => {
                customer.authenticated = false;
            });
            after(() => {
                customer.authenticated = undefined;
            });

            it('!customer.authenticated', () => {
                uuid = '11111';
                expect(customerHelper.getCustomerPaymentInstrument(uuid)).to.be.false;
            });
        });

        describe('customer payment indstrument', () => {
            let paymentInstruments = null;
            before(() => {
                customer.authenticated = true;
                stub(customer, 'getProfile');
                customer.getProfile.returns({
                    getWallet: () => {
                        return {
                            getPaymentInstruments: () => paymentInstruments
                        };
                    }
                });
            });
            after(() => {
                customer.authenticated = undefined;
                customer.getProfile.restore();
            });

            it('uuid === null', () => {
                uuid = '55555';
                expect(customerHelper.getCustomerPaymentInstrument(uuid)).to.be.false;
            });
            it('customerPaymentInstruments === null', () => {
                uuid = '11111';
                expect(customerHelper.getCustomerPaymentInstrument(uuid)).to.be.false;
            });
            it('customerPaymentInstruments.size() < 1', () => {
                uuid = '11111';
                paymentInstruments = {};
                paymentInstruments.size = () => 0;
                expect(customerHelper.getCustomerPaymentInstrument(uuid)).to.be.false;
            });
        });

        describe('customer payment indstrument', () => {
            before(() => {
                customer.authenticated = true;
                stub(customer, 'getProfile');
                customer.getProfile.returns({
                    getWallet: () => {
                        return {
                            getPaymentInstruments: getPaymentInstruments
                        };
                    }
                });
            });
            after(() => {
                customer.authenticated = undefined;
                customer.getProfile.restore();
            });

            it('return instrument', () => {
                uuid = '11111';
                expect(customerHelper.getCustomerPaymentInstrument(uuid)).to.deep.equal(paymentInstrument);
            });
        });

        describe('return false', () => {
            before(() => {
                customer.authenticated = true;
                stub(customer, 'getProfile');
                customer.getProfile.returns({
                    getWallet: () => {
                        return {
                            getPaymentInstruments: getPaymentInstruments
                        };
                    }
                });
            });
            after(() => {
                customer.authenticated = undefined;
                customer.getProfile.restore();
            });

            it('return instrument', () => {
                uuid = '55555';
                expect(customerHelper.getCustomerPaymentInstrument(uuid)).to.be.false;
            });
        });
    });

    describe('getDefaultCustomerPaypalPaymentInstrument', () => {
        const paymentInstrument = {
            custom: {
                braintreeDefaultCard: true
            }
        };
        customerId = '11111';
        const instruments = [paymentInstrument];
        instruments.iterator = () => {
            return new dw.util.Iterator([paymentInstrument]);
        };

        describe('Returns the payment instruments', () => {
            it('customerPaymentInstruments != null', () => {
                expect(customerHelper.getDefaultCustomerPaypalPaymentInstrument(customerId)).to.deep.equal(paymentInstrument);
            });
        });

        describe('Returns the payment instruments', () => {
            it('customerPaymentInstruments != null but no braintreeDefaultCard', () => {
                paymentInstrument.custom.braintreeDefaultCard = false;
                expect(customerHelper.getDefaultCustomerPaypalPaymentInstrument(customerId)).to.deep.equal(paymentInstrument);
            });
        });

        describe('Returns null', () => {
            before(() => {
                customerHelper.getCustomerPaymentInstruments.returns(null);
            });
            it('payment instrument == null', () => {
                expect(customerHelper.getDefaultCustomerPaypalPaymentInstrument(customerId)).to.be.null;
            });
        });

        before(() => {
            stub(customerHelper, 'getCustomerPaymentInstruments').returns(
                instruments
            );
        });
        after(() => {
            customerHelper.getCustomerPaymentInstruments.restore();
        });
    });

    describe('getPaypalCustomerPaymentInstrumentByEmail', () => {
        let email = 'a@a.com';
        const braintreePaypalAccountEmail = email;
        const paymentInstrument = {
            custom: {
                braintreePaypalAccountEmail
            }
        };

        const customerPaymentInstruments = {
            iterator: () => {
                return new dw.util.Iterator([paymentInstrument]);
            }
        };

        before(() => {
            stub(customerHelper, 'getCustomerPaymentInstruments').returns(
                customerPaymentInstruments
            );
        });
        after(() => {
            customerHelper.getCustomerPaymentInstruments.restore();
        });

        describe('Returns the payment instruments', () => {
            it('customerPaymentInstruments != null', () => {
                expect(customerHelper.getPaypalCustomerPaymentInstrumentByEmail(email)).to.deep.equal(paymentInstrument);
            });
        });

        describe('Returns null', () => {
            before(() => {
                customerHelper.getCustomerPaymentInstruments.returns(
                    null
                );
            });
            it('customerPaymentInstruments == null', () => {
                expect(customerHelper.getPaypalCustomerPaymentInstrumentByEmail(email)).to.be.null;
            });
        });

        describe('Returns null', () => {
            before(() => {
                email = 'other@mail.com';
            });
            it('paymentInst.custom.braintreePaypalAccountEmail !== email', () => {
                expect(customerHelper.getPaypalCustomerPaymentInstrumentByEmail(email)).to.be.null;
            });
        });
    });

    describe('createCustomerId function', () => {
        const siteName = 'SiteGenesis';

        describe('if customer was registered', () => {
            after(() => {
                dw.system.Site.current = null;
            });

            afterEach(function () {
                session.privacy.customerId = null;
            });

            const customer = {
                profile: { customerNo: '123' },
                isRegistered: () => true
            };

            describe('If session.privacy.customerId exist', () => {
                before(() => {
                    session.privacy.customerId = 'this_is_customer_id';
                });
                it('should return session.privacy.customerId', () => {
                    expect(customerHelper.createCustomerId(customer)).to.be.equal('this_is_customer_id');
                });
            });

            it('should return site name_customer id', () => {
                dw.system.Site.current = { ID: siteName };

                expect(customerHelper.createCustomerId(customer)).to.be.equal('sitegenesis_123');
            });

            describe('if site name has more than allowed', () => {
                it('should cut string to allowed length', () => {
                    dw.system.Site.current.ID = 'SiteGenesisWithVeryLongTestStringName';

                    expect(customerHelper.createCustomerId(customer)).to.be.equal('sitegenesiswithverylongtests_123');
                });
            });
        });
    });

    describe('getVenmoCustomerPaymentInstrumentByUserID', () => {
        const userId = '23523gergs';
        const paymentInstrument = {
            custom: {
                braintreeVenmoUserId: userId
            }
        };

        const customerPaymentInstruments = {
            iterator: () => {
                return new dw.util.Iterator([paymentInstrument]);
            }
        };

        before(() => {
            stub(customerHelper, 'getCustomerPaymentInstruments').returns(
                customerPaymentInstruments
            );
        });
        after(() => {
            customerHelper.getCustomerPaymentInstruments.restore();
        });

        describe('If customerPaymentInstruments exists', () => {
            it('should return the payment instrument', () => {
                expect(customerHelper.getVenmoCustomerPaymentInstrumentByUserID(userId)).to.deep.equal(paymentInstrument);
            });
        });

        describe('If there is no customerPaymentInstruments', () => {
            before(() => {
                customerHelper.getCustomerPaymentInstruments.returns(
                    null
                );
            });
            it('should return null', () => {
                expect(customerHelper.getVenmoCustomerPaymentInstrumentByUserID(userId)).to.be.null;
            });
        });
    });

    describe('getPhoneFromProfile', () => {
        let phone = '4084607119';
        const profile = {
            getPhoneMobile: () => phone,
            getPhoneHome: () => phone,
            getPhoneBusiness: () => phone
        };

        describe('if phone number is provided', () => {
            it('should return phone number', () => {
                expect(customerHelper.getPhoneFromProfile(profile)).to.equal(phone);
            });
            it('should return string', () => {
                expect(customerHelper.getPhoneFromProfile(profile)).to.be.a('string');
            });
        });

        describe('if number not provided at the profile', () => {
            before(() => {
                phone = null;
            });
            it('should return null', () => {
                expect(customerHelper.getPhoneFromProfile(profile)).to.be.null;
            });
        });
    });

    describe('getSavedPayPalPaymentInstrumentByUUID', () => {
        const customerPaymentInstruments = 'paymentMethodFromCart';
        const httpParameterMap = {
            paymentMethodUUID: {
                stringValue: 'paymentMethodFromCart'
            },
            paymentMethodFromBillingPage: {
                stringValue: 'paymentMethodFromBillingPage'
            }
        };

        describe('Returns paymentMethodFromCart', () => {
            before(() => {
                customer.authenticated = true;
                stub(customerHelper, 'getSavedPayPalPaymentInstrumentByUUID').returns(
                    customerPaymentInstruments
                );
            });
            after(() => {
                customerHelper.getSavedPayPalPaymentInstrumentByUUID.restore();
            });
            it('customer.authenticated == true', () => {
                expect(customerHelper.getSavedPayPalPaymentInstrumentByUUID(httpParameterMap)).to.be.customerPaymentInstruments;
            });
        });

        describe('Returns false', () => {
            before(() => {
                customer.authenticated = undefined;
            });

            it('customer.authenticated == undefined', () => {
                expect(customerHelper.getSavedPayPalPaymentInstrumentByUUID(httpParameterMap)).to.be.false;
            });
        });
    });

    describe('clearDefaultProperty', () => {
        let pi = {
            custom: {
                braintreeDefaultCard: 'defaultCard'
            }
        };

        let applicableCCPI = [pi];

        describe('if applicable Credit Card Payment Instruments was not provided', () => {
            before(() => {
                applicableCCPI = [];
            });
            it('should return object type', () => {
                expect(customerHelper.clearDefaultProperty(applicableCCPI)).to.be.a('object');
            });
            it('should return empty object', () => {
                expect(customerHelper.clearDefaultProperty()).to.deep.equal({});
            });
        });

        describe('if applicable Credit Card Payment Instruments was empty', () => {
            before(() => {
                applicableCCPI = null;
            });
            it('should return object type', () => {
                expect(customerHelper.clearDefaultProperty(applicableCCPI)).to.be.a('object');
            });
            it('should return empty object', () => {
                expect(customerHelper.clearDefaultProperty()).to.deep.equal({});
            });
        });

        describe('if applicable Credit Card Payment Instruments was not empty', () => {
            before(() => {
                applicableCCPI = [pi];
            });
            it('should return object type', () => {
                expect(customerHelper.clearDefaultProperty(applicableCCPI)).to.be.a('object');
            });
            it('should return empty object', () => {
                expect(customerHelper.clearDefaultProperty()).to.deep.equal({});
            });
        });
    });

    describe('setBraintreeDefaultCard', () => {
        let paymentMethodToken = '122332dss332323ww';
        const result = { braintreeDefaultCard: true };
        before(() => {
            stub(customerHelper, 'setBraintreeDefaultCard');
            customerHelper.setBraintreeDefaultCard.withArgs(paymentMethodToken).returns(result);
        });
        after(() => {
            customerHelper.setBraintreeDefaultCard.restore();
        });

        describe('If paymentMethodToken is correct', () => {
            it('the value in braintreeDefaultCard should be equal to result', () => {
                expect(customerHelper.setBraintreeDefaultCard('122332dss332323ww')).equal(result);
            });
            it('the type of braintreeDefaultCard should be object', () => {
                expect(customerHelper.setBraintreeDefaultCard('122332dss332323ww')).to.be.a('object');
            });
        });

        describe('If paymentMethodToken is incorrect', () => {
            it('the value in braintreeDefaultCard should not be equal to result', () => {
                expect(customerHelper.setBraintreeDefaultCard('Some other string TOKEN')).is.not.equal(result);
            });
            it('the type of braintreeDefaultCard should not be object', () => {
                expect(customerHelper.setBraintreeDefaultCard('Some other string TOKEN')).to.not.be.a('object');
            });
        });
    });

    describe('createPreferredAddress', () => {
        const payerInfo = {
            firstName: 'John',
            lastName: 'Smith',
            phoneNumber: '5555551234'
        };

        const shippingDataString = JSON.stringify({
            line1: 'Some first address',
            line2: 'Some second address',
            countryCode: 12456,
            state: 321
        });

        before(() => {
            stub(customer, 'getProfile');
            customer.getProfile.returns({
                getAddressBook: () => {
                    return {
                        addressArray: [],
                        setPreferredAddress: function (address) {
                            this.addressArray.push(address);
                        },
                        createAddress: function (address) {
                            return address;
                        }
                    };
                }
            });
        });

        after(() => {
            customer.getProfile.restore();
        });

        describe('If arguments are correct', () => {
            it('no object should be returned from the function', () => {
                expect(customerHelper.createPreferredAddress(payerInfo, shippingDataString)).to.not.be.a('object');
            });
            it('response type should be undefined', () => {
                expect(customerHelper.createPreferredAddress(payerInfo, shippingDataString)).to.be.a('undefined');
            });
        });
    });

    describe('getCustomerId', () => {
        let user = {
            profile: {
                custom: {
                    braintreeCustomerId: null
                }
            }
        };

        before(() => {
            stub(customerHelper, 'createCustomerId');
            customerHelper.createCustomerId.returns('Some new customer Id');
        });

        after(() => {
            customerHelper.createCustomerId.restore();
        });

        describe('If customer.profile.custom.braintreeCustomerId does not exist', () => {
            it('response should be Some new customer Id', () => {
                expect(customerHelper.getCustomerId(user)).equal('Some new customer Id');
            });
            it('response type should be string', () => {
                expect(customerHelper.getCustomerId(user)).to.be.a('string');
            });
        });

        describe('If customer.profile.custom.braintreeCustomerId exist', () => {
            before(() => {
                user.profile.custom.braintreeCustomerId = 'Some customer id from customer.profile';
            });
            it('response should be Some customer id from customer.profile', () => {
                expect(customerHelper.getCustomerId(user)).equal('Some customer id from customer.profile');
            });
            it('response type should be string', () => {
                expect(customerHelper.getCustomerId(user)).to.be.a('string');
            });
        });
    });

    describe('getAssociatedAddress', () => {
        let isEquivalentAddress = true;
        let isEquivalentShippingAddress = true;

        const shipmentUUID = '4f268b44ba97d2f5d3a369c4a3-basket-shipments';
        const customerAddressID = '4f268b44ba97d2f5d3a369c4a3-customer-address';

        const basket = {
            billingAddress: '2348 Rardin Drive San Bruno CA 94066 6505895223',
            shipments: {
                toArray: () => {
                    return [{
                        UUID: shipmentUUID,
                        shippingAddress: {
                            isEquivalentAddress: () => isEquivalentShippingAddress
                        }
                    }];
                }
            }
        };
        const customer = {
            addressBook: {
                addresses: {
                    toArray: () => {
                        return [{
                            ID: customerAddressID,
                            isEquivalentAddress: () => isEquivalentAddress
                        }];
                    }
                }
            }
        };

        it('Return the matching shipment UUID for a billing address', () => {
            const val = customerHelper.getAssociatedAddress(basket, customer);

            expect(val).to.be.a('string').and.not.empty;
            expect(val).to.be.equal(shipmentUUID);
        });

        it('Return the matching customer address ID for a billing address', () => {
            isEquivalentShippingAddress = false;

            const val = customerHelper.getAssociatedAddress(basket, customer);

            expect(val).to.be.a('string').and.not.empty;
            expect(val).to.be.equal(customerAddressID);
        });

        it('Did not find a match of address ID or UUID for a billing address', () => {
            isEquivalentAddress = false;

            const val = customerHelper.getAssociatedAddress(basket, customer);

            expect(val).to.be.undefined;
        });

        it('Billing address not specified', () => {
            basket.billingAddress = '';

            expect(customerHelper.getAssociatedAddress(basket, customer)).to.be.false;
        });
    });

    describe('getDefaultCustomerShippingAddress', () => {
        let defaultAddress = {
            address1: '',
            address2: '' || '',
            city: '',
            stateCode: '',
            postalCode: '',
            countryCode: { value: '' },
            phone: '',
            fullName: ''
        };

        it('Return customer shipping address for createPayment method of Braintree SDK', () => {
            const val = customerHelper.getDefaultCustomerShippingAddress(defaultAddress);

            expect(val).to.be.an('object').that.have.all.keys('line1', 'line2', 'city', 'state', 'postalCode', 'countryCode', 'phone', 'recipientName');
            expect(val.line2).to.be.equal(defaultAddress.address2);
        });

        it('If CustomerAddress.address2 is not set', () => {
            defaultAddress.address2 = null;

            const val = customerHelper.getDefaultCustomerShippingAddress(defaultAddress);

            expect(val).to.be.an('object').that.have.all.keys('line1', 'line2', 'city', 'state', 'postalCode', 'countryCode', 'phone', 'recipientName');
            expect(val.line2).to.be.empty;
        });
    });

    describe('isBasketPaymentInstrEqualSavedPayPalAccount', () => {
        before(() => {
            stub(customerHelper, 'getCustomerPaymentInstruments');

            dw.order.BasketMgr.currentBasket = {
                getPaymentInstruments: () => [{ creditCardToken: 'token' }]
            };
        });

        after(() => {
            dw.order.BasketMgr.currentBasket = null;
            customerHelper.getCustomerPaymentInstruments.restore();
        });

        it('Paypal basket payment instrument equal a saved paypal account', () => {
            customerHelper.getCustomerPaymentInstruments.returns({
                iterator: () => new dw.util.Iterator([{ creditCardToken: 'token' }])
            });

            const val = customerHelper.isBasketPaymentInstrEqualSavedPayPalAccount();

            expect(val).to.be.true;
        });

        it('Paypal basket payment instrument not equal a saved paypal account', () => {
            customerHelper.getCustomerPaymentInstruments.returns({
                iterator: () => new dw.util.Iterator([])
            });

            const val = customerHelper.isBasketPaymentInstrEqualSavedPayPalAccount();

            expect(val).to.be.false;
        });

        it('Return false if customer Paypal payment instruments is empty', () => {
            customerHelper.getCustomerPaymentInstruments.returns([]);

            const val = customerHelper.isBasketPaymentInstrEqualSavedPayPalAccount();

            expect(val).to.be.false;
        });

        it('Return false if paypal basket payment instrument is empty', () => {
            customerHelper.getCustomerPaymentInstruments.returns({ 'fake data': 'for test case' });
            dw.order.BasketMgr.currentBasket = { getPaymentInstruments: () => [] };

            const val = customerHelper.isBasketPaymentInstrEqualSavedPayPalAccount();

            expect(val).to.be.false;
        });
    });

    describe('isPaymentMethodRemoveAllowed', () => {
        after(() => {
            customerHelper.__ResetDependency__('getAuthorizedAndPartiallyCapturedOrders');
        });

        let paymentInstrument = {};

        beforeEach(() => {
            customerHelper.__set__('getAuthorizedAndPartiallyCapturedOrders', () => {
                return [{ custom: { braintreePaymentStatus: 'SETTLED' } }];
            });

            paymentInstrument = {
                creditCardNumberLastDigits: '1111',
                creditCardExpirationMonth: '07',
                creditCardExpirationYear: '2025',
                custom: {
                    braintreeVenmoUserId: 'venmo-user-id'
                }
            };
        });

        const expectTrue = () => {
            expect(customerHelper.isPaymentMethodRemoveAllowed(paymentInstrument)).to.be.true;
        };

        describe('Payment instrument has braintreeVenmoUserId value', () => {
            it('empty(venmoOrders)', () => {
                customerHelper.__set__('getAuthorizedAndPartiallyCapturedOrders', () => []);

                expectTrue();
            });

            it('empty(venmoOrdersSortedByPaymentAccount)', () => {
                paymentInstrument.custom.braintreeVenmoUserId = 'other-user-id';

                expectTrue();
            });

            it('Response equal to true when set braintreeVenmoUserId value', () => {
                expectTrue();
            });
        });

        describe('Payment instrument custom does\'t have braintreeVenmoUserId value', () => {
            it('SRC or Credit Card Orders are empty', () => {
                paymentInstrument.custom.braintreeVenmoUserId = null;

                customerHelper.__set__('getAuthorizedAndPartiallyCapturedOrders', () => []);

                expectTrue();
            });

            it('Card orders sorted by payment account are empty', () => {
                paymentInstrument.custom.braintreeVenmoUserId = null;
                paymentInstrument.creditCardNumberLastDigits = '2024';

                expectTrue();
            });

            it('Other payment instrument', () => {
                paymentInstrument.custom.braintreeVenmoUserId = null;

                expectTrue();
            });
        });
    });

    describe('formatCustomerName', () => {
        let shipping = { 0: {
            shippingAddress: {
                firstName: 'John',
                secondName: 'Test',
                lastName: 'Doe'
            }
        } };

        let shippingAddress = shipping[0].shippingAddress;

        afterEach(() => {
            shipping[0].shippingAddress = {
                firstName: 'John',
                secondName: 'Test',
                lastName: 'Doe'
            };

            shippingAddress = shipping[0].shippingAddress;
        });

        it('Second name contains only one word', () => {
            const val = customerHelper.formatCustomerName(shipping);

            expect(val).to.be.undefined;
            expect(shippingAddress.firstName).to.equal('John Test');
        });

        it('Second name contains two words', () => {
            shipping[0].shippingAddress.secondName = 'First Last';

            const val = customerHelper.formatCustomerName(shipping);

            expect(val).to.be.undefined;
            expect(shippingAddress.firstName).to.equal('John First');
            expect(shippingAddress.lastName).to.equal('Last Doe');
        });

        it('Second name not set', () => {
            shipping[0].shippingAddress.secondName = '';

            expect(customerHelper.formatCustomerName(shipping)).to.be.undefined;
        });

        it('Shipping address not set', () => {
            shipping[0].shippingAddress = {};

            expect(customerHelper.formatCustomerName(shipping)).to.be.undefined;
        });
    });
});
