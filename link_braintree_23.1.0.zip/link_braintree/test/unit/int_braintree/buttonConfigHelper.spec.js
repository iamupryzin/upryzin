const { expect } = require('chai');
const { int_braintree: { buttonConfigHelperPath } } = require('../path.json');
const { stub } = require('sinon');

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const prefs = {
    paypalDisplayName: null,
    paypalBillingAgreementDescription: null,
    vaultMode: false,
    paymentMethods: {
        BRAINTREE_PAYPAL: { paymentMethodId: 'BRAINTREE_PAYPAL' },
        BRAINTREE_APPLEPAY: { paymentMethodId: 'BRAINTREE_APPLEPAY' },
        BRAINTREE_VENMO: { paymentMethodId: 'BRAINTREE_VENMO' },
        BRAINTREE_LOCAL: { paymentMethodIds: 'BRAINTREE_LOCAL' },
        BRAINTREE_GOOGLEPAY: { paymentMethodId: 'BRAINTREE_GOOGLEPAY' },
        BRAINTREE_SRC: { paymentMethodId: 'BRAINTREE_SRC' }
    },
    isPaypalFraudToolsEnabled: false,
    isFraudToolsEnabled: true,
    paypalIntent: 'ready',
    paypalOrderIntent: 'ready',
    venmoDisplayName: 'BRAINTREE_VENMO',
    srcDisplayName: 'BRAINTREE_SRC',
    SRCBillingButtonConfig: {},
    googlepayDisplayName: 'BRAINTREE_GOOGLEPAY',
    googleMerchantId: 'your-merchant-id-from-google',
    applePayBtnSdk: 'applePayButtonSdk',
    changePMButtonEnabled: true,
    paypalPdpButtonConfig: { style: 'PdpButtonConfig' },
    paypalCartButtonConfig: { style: 'CartButtonConfig' },
    paypalMiniCartButtonConfig: { style: 'MiniCartButtonConfig' },
    paypalBillingButtonConfig: { style: 'BillingButtonConfig' }
};

const braintreeConstants = {
    FLOW_CHECKOUT: 'FLOW_CHECKOUT',
    FLOW_VAULT: 'FLOW_VAULT',
    INTENT_TYPE_ORDER: 'INTENT_TYPE_ORDER',
    BUTTON_CONFIG_OPTIONS_USERACTION_COMMIT: 'BUTTON_CONFIG_OPTIONS_USERACTION_COMMIT',
    PAGE_FLOW_CHECKOUT: 'PAGE_FLOW_CHECKOUT',
    PAGE_FLOW_CART: 'PAGE_FLOW_CART',
    PAGE_FLOW_PDP: 'PAGE_FLOW_PDP',
    PAGE_FLOW_MINICART: 'PAGE_FLOW_MINICART',
    PRODUCTION_SYSTEM_TYPE: 0,
    DEVELOPMENT_SYSTEM_TYPE: 1
};
const getAmountPaid = stub();
const getCurrent = stub();
const toArray = stub();

const buttonConfigHelper = require('proxyquire').noCallThru()(buttonConfigHelperPath, {
    'dw/system/System': dw.system.System,
    'dw/system/Site': {
        current: {
            getAllowedLocales: () => ({
                toArray: toArray
            })
        },
        getCurrent: getCurrent
    },
    'dw/web/URLUtils': dw.web.URLUtils,
    'dw/web/Resource': dw.web.Resource,
    '~/cartridge/config/braintreeUrls': {},
    '*/cartridge/config/braintreeSDK': {
        applePayBtnSdk: 'applePayButtonSdk'
    },
    '~/cartridge/config/braintreePreferences': prefs,
    '~/cartridge/scripts/braintree/helpers/customerHelper': {
        getCustomerPaymentInstruments: () => 'CustomerPaymentInstruments'
    },
    '~/cartridge/scripts/braintree/helpers/paymentHelper': {
        addDefaultShipping: () => {},
        getAmountPaid: getAmountPaid,
        createSRCImageUrl: () => 'https://SRCImageUrl',
        getSessionPaymentMethodId: () => 'defaultMethod'
    },
    '~/cartridge/config/braintreeConstants': braintreeConstants,
    '~/cartridge/scripts/braintree/braintreeAPI/braintreeBusinessLogic': {
        getPaypalCustomerPmDataFromBraintree: () => 'CustomerPmDataFromBraintree'
    },
    '~/cartridge/scripts/braintree/configuration/applePayButtonConfigs': {
        APPLEPAY_Billing_Button_Config: 'ApplePayBillingConfigs',
        APPLEPAY_Cart_Button_Config: 'ApplePayCartConfigs'
    },
    '~/cartridge/scripts/braintree/configuration/googlePayButtonConfigs': {
        GOOGLEPAY_Cart_Button_Config: 'GOOGLEPAY_Cart_Button_Config',
        GOOGLEPAY_Billing_Button_Config: 'GOOGLEPAY_Billing_Button_Config'
    }
});

describe('buttonConfigHelper file', () => {
    const basket = {
        amountPaid: 10000,
        currencyCode: 'USD'
    };
    const clientToken = 'ssSsfs-fs33Sw-ewewrs-22ds32w';
    const messages = {
        CLIENT_REQUEST_TIMEOUT: 'Request timed out waiting for a reply.',
        CLIENT_GATEWAY_NETWORK: 'Cannot contact the gateway at this time.',
        CLIENT_REQUEST_ERROR: 'There was a problem with your request.',
        CLIENT_MISSING_GATEWAY_CONFIGURATION: 'Missing gatewayConfiguration.'
    };
    const orderInfoUrl = 'https://www.braintreepayments.com/order/sssdfswwsdsww2';
    let currentFlow;

    describe('getInstanceType', () => {
        const getInstanceType = buttonConfigHelper.__get__('getInstanceType');

        after(() => {
            dw.system.System.instanceType = null;
        });

        it('result should be 0 if instanceType is production system', () => {
            dw.system.System.instanceType = 0;

            expect(getInstanceType()).to.equal(0);
        });

        it('result should be 1 if instanceType is development system', () => {
            dw.system.System.instanceType = 1;

            expect(getInstanceType()).to.equal(1);
        });
    });

    describe('isChangePMButtonEnabled', () => {
        const isChangePMButtonEnabled = buttonConfigHelper.__get__('isChangePMButtonEnabled');

        it('if customer registered', () => {
            customer.registered = true;

            expect(isChangePMButtonEnabled()).to.be.true;
        });

        it('if customer do not registered', () => {
            customer.registered = false;

            expect(isChangePMButtonEnabled()).to.be.false;
        });
    });

    describe('getPaypalButtonStyleConfigs', () => {
        const getPaypalButtonStyleConfigs = buttonConfigHelper.__get__('getPaypalButtonStyleConfigs');

        it('if pageFlow is PAGE_FLOW_PDP', () => {
            expect(getPaypalButtonStyleConfigs('PAGE_FLOW_PDP')).to.be.deep.equal({ style: 'PdpButtonConfig' });
        });

        it('if pageFlow is PAGE_FLOW_CART', () => {
            expect(getPaypalButtonStyleConfigs('PAGE_FLOW_CART')).to.be.deep.equal({ style: 'CartButtonConfig' });
        });

        it('if pageFlow is PAGE_FLOW_MINICART', () => {
            expect(getPaypalButtonStyleConfigs('PAGE_FLOW_MINICART')).to.be.deep.equal({ style: 'MiniCartButtonConfig' });
        });

        it('if pageFlow is default', () => {
            expect(getPaypalButtonStyleConfigs('default')).to.be.deep.equal({ style: 'BillingButtonConfig' });
        });
    });

    describe('createGeneralButtonConfig', () => {
        const amountPaid = {
            amountPaid: basket.amountPaid,
            currencyCode: basket.currencyCode,
            getValue: function () {
                return this.amountPaid;
            },
            getCurrencyCode: function () {
                return this.currencyCode;
            },
            valueOrNull: null
        };

        before(() => {
            stub(dw.web.Resource, 'msg');
            dw.web.Resource.msg.withArgs('braintree.error.CLIENT_REQUEST_TIMEOUT', 'locale', null).returns(messages.CLIENT_REQUEST_TIMEOUT);
            dw.web.Resource.msg.withArgs('braintree.error.CLIENT_GATEWAY_NETWORK', 'locale', null).returns(messages.CLIENT_GATEWAY_NETWORK);
            dw.web.Resource.msg.withArgs('braintree.error.CLIENT_REQUEST_ERROR', 'locale', null).returns(messages.CLIENT_REQUEST_ERROR);
            dw.web.Resource.msg.withArgs('braintree.error.CLIENT_MISSING_GATEWAY_CONFIGURATION', 'locale', null).returns(messages.CLIENT_MISSING_GATEWAY_CONFIGURATION);
            stub(dw.web.URLUtils, 'url');
            dw.web.URLUtils.url.withArgs('Braintree-GetOrderInfo').returns(orderInfoUrl);
            request.session = { currency: { currencyCode: 'USD' } };
        });

        after(() => {
            dw.web.Resource.msg.restore();
            dw.web.URLUtils.url.restore();
            request.session = {};
            getAmountPaid.reset();
        });

        it('response type should be equal -> object', () => {
            getAmountPaid.returns(amountPaid);
            expect(buttonConfigHelper.createGeneralButtonConfig(basket, clientToken)).to.be.a('object');
        });

        it('response object should have properties -> clientToken, messages, options, getOrderInfoUrl, paymentMethodName, isBuyerAuthenticated, sessionPaymentMethodId', () => {
            amountPaid.valueOrNull = 'value';
            getAmountPaid.returns(amountPaid);

            expect(buttonConfigHelper.createGeneralButtonConfig(basket, clientToken)).to.have.keys('clientToken', 'messages', 'options', 'getOrderInfoUrl', 'isBuyerAuthenticated', 'sessionPaymentMethodId');
        });
    });

    describe('createBraintreePayPalButtonConfig', () => {
        before(() => {
            buttonConfigHelper.__set__('getPaypalButtonStyleConfigs', () => prefs.paypalBillingButtonConfig);
            getCurrent.returns({
                getDefaultLocale: () => 'US'
            });
            stub(dw.web.Resource, 'msg');
            dw.web.Resource.msg.withArgs('braintree.error.PAYPAL_ACCOUNT_TOKENIZATION_FAILED', 'locale', null).returns('PayPal tokenization failed.');
            dw.web.Resource.msg.withArgs('braintree.error.PAYPAL_INVALID_PAYMENT_OPTION', 'locale', null).returns('PayPal payment options are invalid.');
            dw.web.Resource.msg.withArgs('braintree.error.PAYPAL_FLOW_FAILED', 'locale', null).returns('Unable to initialize PayPal flow. Are your options correct?');
            dw.web.Resource.msg.withArgs('braintree.error.PAYPAL_BROWSER_NOT_SUPPORTED', 'locale', null).returns('Browser is not supported.');
            dw.web.Resource.msg.withArgs('braintree.error.CUSTOM_PAYPAL_ZERO_AMOUNT_ERROR', 'locale', null).returns('Order total 0 is not allowed for PayPal.');
            dw.web.Resource.msg.withArgs('braintree.error.PAYPAL_BILLING_ADDRESS_NOT_SUPPORTED', 'locale', null).returns('Merchant PayPal account does not support the Billing Address retrieving. Contact PayPal for details on eligibility and enabling this feature.');
            stub(dw.web.URLUtils, 'url');
            dw.web.URLUtils.url.withArgs('Checkout-Begin', 'stage', 'placeOrder').returns(orderInfoUrl);
            dw.web.URLUtils.url.withArgs('Braintree-ValidateAddresses').returns('/validate-addresses');
            dw.web.URLUtils.url.withArgs('CheckoutShippingServices-UpdateShippingMethodsList').returns('/update-shipping-methods-list');
            stub(buttonConfigHelper, 'createGeneralButtonConfig').returns({
                clientToken: clientToken,
                messages: {
                    CLIENT_REQUEST_TIMEOUT: messages.CLIENT_REQUEST_TIMEOUT,
                    CLIENT_GATEWAY_NETWORK: messages.CLIENT_GATEWAY_NETWORK,
                    CLIENT_REQUEST_ERROR: messages.CLIENT_REQUEST_ERROR,
                    CLIENT_MISSING_GATEWAY_CONFIGURATION: messages.CLIENT_MISSING_GATEWAY_CONFIGURATION
                },
                options: { amount: 10000, currency: 'USD', useraction: null },
                getOrderInfoUrl: orderInfoUrl,
                updateShippingMethodsListUrl: '/update-shipping-methods-list'
            });
        });

        after(() => {
            buttonConfigHelper.__ResetDependency__('getPaypalButtonStyleConfigs');
            getCurrent.reset();
            dw.web.Resource.msg.restore();
            dw.web.URLUtils.url.restore();
            buttonConfigHelper.createGeneralButtonConfig.restore();
            currentFlow = null;
        });

        describe('If currentFlow is CHECKOUT', () => {
            before(() => {
                currentFlow = 'PAGE_FLOW_CHECKOUT';
                customer.registered = true;
                prefs.paypalDisplayName = 'BRAINTREE_PAYPAL';
                prefs.paypalBillingAgreementDescription = 'paypal Billing Agreement description';
                prefs.vaultMode = true;
                prefs.enableFundingList = ['item_1', 'item_2'];
                prefs.paypalOrderIntent = null;
                prefs.isSettle = true;
            });

            after(() => {
                customer.registered = false;
                prefs.paypalDisplayName = null;
                prefs.paypalBillingAgreementDescription = null;
                prefs.vaultMode = false;
                prefs.enableFundingList = null;
                prefs.paypalOrderIntent = 'ready';
                prefs.isSettle = false;
            });

            it('response type should be an object with properties -> clientToken, messages, options, getOrderInfoUrl, changePMButtonEnabled, isFraudToolsEnabled, paymentMethodName, paypalConfig, paypalHandle, redirectUrl', () => {
                expect(buttonConfigHelper.createBraintreePayPalButtonConfig(basket, clientToken, currentFlow)).to.have.keys('clientToken', 'messages', 'options', 'getOrderInfoUrl', 'changePMButtonEnabled', 'isFraudToolsEnabled', 'paymentMethodName', 'paypalConfig', 'paypalHandle', 'redirectUrl', 'validateAddressesUrl', 'updateShippingMethodsListUrl', 'vaultModeEnabled');
            });

            it('result.options.displayName should equal prefs.paypalDisplayName if it\'s empty', () => {
                expect(buttonConfigHelper.createBraintreePayPalButtonConfig(basket, clientToken, currentFlow))
                    .to.have.property('options').which.has.property('displayName', 'BRAINTREE_PAYPAL');
            });

            it('result.options.billingAgreementDescription should equal prefs.paypalBillingAgreementDescription if it\'s empty', () => {
                expect(buttonConfigHelper.createBraintreePayPalButtonConfig(basket, clientToken, currentFlow))
                    .to.have.property('options').which.has.property('billingAgreementDescription', 'paypal Billing Agreement description');
            });

            it('result.options should be property enableFundingList if it is in prefs', () => {
                expect(buttonConfigHelper.createBraintreePayPalButtonConfig(basket, clientToken, currentFlow))
                    .to.have.property('options').which.has.property('enableFundingList', 'item_1,item_2');
            });

            it('result.options should include a property useraction which equals BUTTON_CONFIG_OPTIONS_USERACTION_COMMIT', () => {
                expect(buttonConfigHelper.createBraintreePayPalButtonConfig(basket, clientToken, currentFlow))
                    .to.have.property('options').that.has.property('useraction', 'BUTTON_CONFIG_OPTIONS_USERACTION_COMMIT');
            });

            it('result.options.flow should be CHECKOUT & options.requestBillingAgreement should be set to true if changePMButtonEnabled && vaultModeEnabled are true', () => {
                expect(buttonConfigHelper.createBraintreePayPalButtonConfig(basket, clientToken, currentFlow))
                    .to.have.property('options').that.has.property('flow', 'FLOW_CHECKOUT');
                expect(buttonConfigHelper.createBraintreePayPalButtonConfig(basket, clientToken, currentFlow))
                    .to.have.property('options').that.has.property('requestBillingAgreement', true);
            });
        });

        describe('If currentFlow is ORDER', () => {
            before(() => {
                currentFlow = 'FLOW_ORDER';
                prefs.disableFundingList = ['item_1', 'item_2'];
            });

            after(() => {
                prefs.disableFundingList = null;
            });

            it('response type should be an object with properties -> clientToken, messages, options, getOrderInfoUrl, changePMButtonEnabled, isFraudToolsEnabled, paymentMethodName, paypalConfig, paypalHandle, redirectUrl', () => {
                expect(buttonConfigHelper.createBraintreePayPalButtonConfig(basket, clientToken, currentFlow)).to.have.keys('clientToken', 'messages', 'options', 'getOrderInfoUrl', 'changePMButtonEnabled', 'isFraudToolsEnabled', 'paymentMethodName', 'paypalConfig', 'paypalHandle', 'redirectUrl', 'validateAddressesUrl', 'updateShippingMethodsListUrl', 'vaultModeEnabled');
            });

            it('result.options should be property disableFundingList if it is in prefs', () => {
                expect(buttonConfigHelper.createBraintreePayPalButtonConfig(basket, clientToken, currentFlow))
                    .to.have.property('options').which.has.property('disableFundingList', 'item_1,item_2');
            });
        });
    });

    describe('createBraintreeApplePayButtonConfig', () => {
        const responseObj = {
            clientToken: clientToken,
            messages: messages,
            isRequiredBillingContactFields: true,
            isRequiredShippingContactFields: false,
            options: { amount: 10000, currency: 'USD', displayName: undefined },
            getOrderInfoUrl: orderInfoUrl,
            paymentMethodName: 'BRAINTREE_APPLEPAY',
            isFraudToolsEnabled: false,
            applePayBtnSdk: 'applePayButtonSdk'
        };

        before(() => {
            stub(buttonConfigHelper, 'createGeneralButtonConfig').returns({
                clientToken: clientToken,
                messages: messages,
                options: { amount: 10000, currency: 'USD' },
                getOrderInfoUrl: orderInfoUrl
            });
        });

        after(() => {
            buttonConfigHelper.createGeneralButtonConfig.restore();
            currentFlow = null;
        });

        it('If currentFlow isn\'t CART, response type should be equal responseObj', () => {
            currentFlow = 'PAGE_FLOW_PDP';

            expect(buttonConfigHelper.createBraintreeApplePayButtonConfig(basket, clientToken, currentFlow)).to.deep.equals(responseObj);
        });

        it('If currentFlow is CHECKOUT, response object should include property applePayConfig that equals ApplePayBillingConfigs', () => {
            currentFlow = 'PAGE_FLOW_CHECKOUT';

            expect(buttonConfigHelper.createBraintreeApplePayButtonConfig(basket, clientToken, currentFlow)).to.have.property('applePayConfig', 'ApplePayBillingConfigs');
        });

        it('If currentFlow is CART, response object should include property applePayConfig that equals ApplePayCartConfigs', () => {
            currentFlow = 'PAGE_FLOW_CART';

            expect(buttonConfigHelper.createBraintreeApplePayButtonConfig(basket, clientToken, currentFlow)).to.have.property('applePayConfig', 'ApplePayCartConfigs');
        });
    });

    describe('createBraintreeVenmoButtonConfig', () => {
        const responseObj = {
            clientToken: clientToken,
            messages: Object.assign({ VENMO_ZERO_AMOUNT_ERROR: 'Order total 0 is not allowed for Venmo.' }, messages),
            options: {
                amount: 10000,
                currency: 'USD',
                displayName: 'BRAINTREE_VENMO'
            },
            getOrderInfoUrl: orderInfoUrl,
            paymentMethodName: 'BRAINTREE_VENMO'
        };

        before(() => {
            stub(dw.web.Resource, 'msg');
            dw.web.Resource.msg.withArgs('braintree.error.VENMO_ZERO_AMOUNT_ERROR', 'locale', null).returns('Order total 0 is not allowed for Venmo.');
            stub(buttonConfigHelper, 'createGeneralButtonConfig').returns({
                clientToken: clientToken,
                messages: Object.assign({ VENMO_ZERO_AMOUNT_ERROR: 'Order total 0 is not allowed for Venmo.' }, messages),
                options: { amount: 10000, currency: 'USD' },
                getOrderInfoUrl: orderInfoUrl
            });
        });

        after(() => {
            buttonConfigHelper.createGeneralButtonConfig.restore();
            dw.web.Resource.msg.restore();
        });

        it('response type should be equal -> object', () => {
            expect(buttonConfigHelper.createBraintreeVenmoButtonConfig(basket, clientToken)).to.be.a('object');
        });
        it('response object should be deep equal -> responseObj', () => {
            expect(buttonConfigHelper.createBraintreeVenmoButtonConfig(basket, clientToken)).deep.equal(responseObj);
        });
    });

    describe('createBraintreeLocalPaymentMethodButtonConfig', () => {
        const responseObj = {
            clientToken: clientToken,
            messages: messages,
            options: { amount: 10000, currency: 'USD', displayName: '' },
            getOrderInfoUrl: orderInfoUrl,
            paymentMethodName: 'BRAINTREE_LOCAL',
            paymentConfirmUrl: 'https://www.braintreepayments.com/order/paymentConfirm',
            fallbackUrl: 'https://www.braintreepayments.com/order/fallbackProcess'
        };

        before(() => {
            stub(buttonConfigHelper, 'createGeneralButtonConfig').returns({
                clientToken: clientToken,
                messages: messages,
                options: { amount: 10000, currency: 'USD' },
                getOrderInfoUrl: orderInfoUrl
            });
            stub(dw.web.URLUtils, 'url');
            dw.web.URLUtils.url.withArgs('Braintree-PaymentConfirm').returns('https://www.braintreepayments.com/order/paymentConfirm');
            stub(dw.web.URLUtils, 'https');
            dw.web.URLUtils.https.withArgs('Braintree-FallbackProcess').returns('https://www.braintreepayments.com/order/fallbackProcess');
        });

        after(() => {
            buttonConfigHelper.createGeneralButtonConfig.restore();
            dw.web.URLUtils.url.restore();
            dw.web.URLUtils.https.restore();
        });

        it('response type should be equal responseObj', () => {
            expect(buttonConfigHelper.createBraintreeLocalPaymentMethodButtonConfig(basket, clientToken)).to.deep.equal(responseObj);
        });
    });

    describe('createBraintreeGooglePayButtonConfig', () => {
        const responseObj = {
            clientToken: 'ssSsfs-fs33Sw-ewewrs-22ds32w',
            messages: {
                CLIENT_REQUEST_TIMEOUT: 'Request timed out waiting for a reply.',
                CLIENT_GATEWAY_NETWORK: 'Cannot contact the gateway at this time.',
                CLIENT_REQUEST_ERROR: 'There was a problem with your request.',
                CLIENT_MISSING_GATEWAY_CONFIGURATION: 'Missing gatewayConfiguration.'
            },
            options: {
                amount: 10000,
                currency: 'USD',
                displayName: 'BRAINTREE_GOOGLEPAY',
                isShippingAddressRequired: true
            },
            getOrderInfoUrl: 'https://www.braintreepayments.com/order/sssdfswwsdsww2',
            paymentMethodName: 'BRAINTREE_GOOGLEPAY',
            isFraudToolsEnabled: true,
            googleMerchantId: 'your-merchant-id-from-google',
            instanceType: 'PROD'
        };

        before(() => {
            buttonConfigHelper.__set__('getInstanceType', () => 'PROD');
            stub(buttonConfigHelper, 'createGeneralButtonConfig').returns({
                clientToken: clientToken,
                messages: messages,
                options: { amount: 10000, currency: 'USD' },
                getOrderInfoUrl: orderInfoUrl
            });
        });

        after(() => {
            buttonConfigHelper.__ResetDependency__('getInstanceType');
            buttonConfigHelper.createGeneralButtonConfig.restore();
            toArray.reset();
        });


        it('if currentFlow is PAGE_FLOW_CART and there are avalible countries', () => {
            currentFlow = 'PAGE_FLOW_CART';
            toArray.returns(['en_US', 'it_IT', 'default']);
            responseObj.options.countries = ['US', 'IT'];
            responseObj.style = 'GOOGLEPAY_Cart_Button_Config';
            responseObj.options.isShippingAddressRequired = true;

            expect(buttonConfigHelper.createBraintreeGooglePayButtonConfig(basket, clientToken, currentFlow)).deep.equal(responseObj);
        });

        it('if currentFlow is PAGE_FLOW_CART and there are not avalible countries', () => {
            toArray.returns(['default']);
            responseObj.options.countries = ['US'];
            responseObj.style = 'GOOGLEPAY_Cart_Button_Config';
            responseObj.options.isShippingAddressRequired = true;

            expect(buttonConfigHelper.createBraintreeGooglePayButtonConfig(basket, clientToken, currentFlow)).deep.equal(responseObj);
        });

        it('if there are avalible countries', () => {
            currentFlow = 'PAGE_FLOW_CHECKOUT';
            toArray.returns(['default']);
            responseObj.style = 'GOOGLEPAY_Billing_Button_Config';
            responseObj.options.isShippingAddressRequired = false;

            expect(buttonConfigHelper.createBraintreeGooglePayButtonConfig(basket, clientToken, currentFlow)).deep.equal(responseObj);
        });
    });

    describe('createBraintreeSrcButtonConfig', () => {
        const responseObj = {
            clientToken: clientToken,
            messages: Object.assign({ CUSTOM_SRC_ZERO_AMOUNT_ERROR: 'Order total 0 is not allowed for SRC.' }, messages),
            options: {
                amount: 10000,
                currency: 'USD',
                isShippingAddressRequired: false
            },
            getOrderInfoUrl: orderInfoUrl,
            paymentMethodName: 'BRAINTREE_SRC',
            isFraudToolsEnabled: true,
            SRCImageUrl: 'https://SRCImageUrl',
            settings: undefined,
            isNeedHideContinueButton: true
        };

        before(() => {
            stub(buttonConfigHelper, 'createGeneralButtonConfig').returns({
                clientToken: clientToken,
                messages: Object.assign({ CUSTOM_SRC_ZERO_AMOUNT_ERROR: 'Order total 0 is not allowed for SRC.' }, messages),
                options: { amount: 10000, currency: 'USD' },
                getOrderInfoUrl: orderInfoUrl
            });
            stub(dw.web.Resource, 'msg');
            dw.web.Resource.msg.withArgs('braintree.error.CUSTOM_SRC_ZERO_AMOUNT_ERROR', 'locale', null).returns('Order total 0 is not allowed for SRC.');
        });

        after(() => {
            buttonConfigHelper.createGeneralButtonConfig.restore();
            dw.web.Resource.msg.restore();
            currentFlow = null;
        });

        it('response type should be equal to responseObj', () => {
            currentFlow = 'PAGE_FLOW_MINICART';
            expect(buttonConfigHelper.createBraintreeSrcButtonConfig(basket, clientToken, currentFlow)).to.deep.equal(responseObj);
        });

        it('result.settings should equal prefs.SRCBillingButtonConfig if current flow is CHECKOUT', () => {
            currentFlow = 'PAGE_FLOW_CHECKOUT';

            expect(buttonConfigHelper.createBraintreeSrcButtonConfig(basket, clientToken, currentFlow)).to.have.property('settings').that.deep.equals({});
        });

        it('result.options.displayName that equals BRAINTREE_SRC if current flow is CART', () => {
            currentFlow = 'PAGE_FLOW_CART';

            expect(buttonConfigHelper.createBraintreeSrcButtonConfig(basket, clientToken, currentFlow))
                .to.have.property('options').that.has.property('displayName', 'BRAINTREE_SRC');
        });
    });
});
