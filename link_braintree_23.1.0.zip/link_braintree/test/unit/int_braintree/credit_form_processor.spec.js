const { expect } = require('chai');
const { int_braintree: { credit_form_processorPath } } = require('../path.json');
const { stub } = require('sinon');
const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const paymentForm = {
    paymentMethod: {
        value: 'CREDIT_CARD'
    },
    contactInfoFields: {
        email: { value: 'johnSmith_secondary@gmail.com' }
    }
};

const req = {
    httpParameterMap: {
        accountUUID: {
            stringValue: null
        },
        braintreeSrcNonce: {
            stringValue: null
        },
        braintreeCreditCardList: {
            stringValue: null
        },
        braintreePaymentMethodNonce: {
            empty: true
        },
        get: (str) => {
            return {
                getStringValue: () => {
                    return str;
                }
            };
        }
    },
    session: {
        privacyCache: {
            set: (key, value) => {
                return { [key]: value };
            }
        }
    }
};

const creditFormProcessor = proxyquire(credit_form_processorPath, {
    '*/cartridge/config/braintreeConstants': {
        SESSION_CARD: 'SESSION_CARD',
        VERIFICATION_GATEWAY_REJECTED_STATUS: 'GATEWAY_REJECTED'
    },
    '~/cartridge/scripts/braintree/helpers/paymentHelper': {
        getLogger: () => {
            return {
                error: () => {}
            };
        }
    },
    '~/cartridge/scripts/braintree/helpers/customerHelper': {
        getCustomerPaymentInstrument: () => {
            return {
                creditCardToken: '12234'
            };
        }
    },
    '~/cartridge/scripts/hooks/payment/processor/processorHelper': {
        isUsedSavedCardMethod: () => true,
        getBillingAddressFromStringValue: () => {},
        updateBillingAddressFileds: () => {}
    },
    '~/cartridge/config/braintreePreferences': {
        isCcReVerifyEnabled: false
    },
    'dw/web/Resource': dw.web.Resource,
    '*/cartridge/models/btGraphQLSdk': function () {
        this.verifyCreditCard = () => {
            return {
                status: 'GATEWAY_REJECTED',
                processorResponse: {
                    cvvResponse: 'Not to match'
                }
            };
        };
    }
});

describe('credit_form_processor file', () => {
    describe('processForm', () => {
        const viewData = {
            paymentMethod: {
                value: null
            }
        };
        before(() => {
            stub(dw.order.BasketMgr, 'getCurrentBasket');
            dw.order.BasketMgr.getCurrentBasket.returns({
                getDefaultShipment: () => 'defaultShipment'
            });
            creditFormProcessor.__set__('getEmail', () => {
                return true;
            });
        });
        after(() => {
            dw.order.BasketMgr.getCurrentBasket.restore();
            creditFormProcessor.__ResetDependency__('getEmail');
        });

        describe('If httpParameterMap.braintreeSrcNonce.stringValue === null and httpParameterMap.accountUUID.stringValue === null', () => {
            it('response type should be equal object', () => {
                expect(creditFormProcessor.processForm(req, paymentForm, viewData)).to.be.a('object');
            });
            it('response should consist property error', () => {
                expect(creditFormProcessor.processForm(req, paymentForm, viewData)).has.property('error');
            });
            it('response property error type should be equal boolean', () => {
                expect(creditFormProcessor.processForm(req, paymentForm, viewData).error).to.be.a('boolean');
            });
            it('response property error should be equal false', () => {
                expect(creditFormProcessor.processForm(req, paymentForm, viewData).error).equal(false);
            });
            it('response should consist property viewData', () => {
                expect(creditFormProcessor.processForm(req, paymentForm, viewData)).has.property('viewData');
            });
            it('response property viewData type should be equal boolean', () => {
                expect(creditFormProcessor.processForm(req, paymentForm, viewData).viewData).to.be.a('object');
            });
            it('response property viewData object should consist property paymentMethod', () => {
                expect(creditFormProcessor.processForm(req, paymentForm, viewData).viewData).has.property('paymentMethod');
            });
        });
    });
});
