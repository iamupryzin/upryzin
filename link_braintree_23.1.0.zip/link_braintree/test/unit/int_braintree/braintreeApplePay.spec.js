const { stub } = require('sinon');
const { expect } = require('chai');
const { describe, it, before, after, beforeEach } = require('mocha');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');

require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const { int_braintree: { braintreeApplePayPath } } = require('../path.json');

const createTransactionResult = {
    transaction: {
        paymentMethod: { legacyId: 'token' },
        customer: { id: 'customerId' }
    }
};

const braintreeApplePay = proxyquire(braintreeApplePayPath, {
    'dw/order/Order': dw.order.Order,
    'dw/web/Resource': dw.web.Resource,
    'dw/order/OrderMgr': dw.order.OrderMgr,
    'dw/order/PaymentMgr': dw.order.PaymentMgr,
    'dw/system/Transaction': dw.system.Transaction,
    '~/cartridge/scripts/braintree/helpers/paymentHelper': {
        deleteBraintreePaymentInstruments: () => {},
        getAmountPaid: () => {},
        handleErrorCode: () => {},
        getLogger: () => {
            return { error: error => error };
        }
    },
    '~/cartridge/scripts/hooks/payment/processor/processorHelper': {
        saveGeneralTransactionData: () => {},
        createBaseSaleTransactionData: () => {
            return {
                options: {}
            };
        },
        verifyTransactionStatus: () => {},
        getBillingAddressFromStringValue: () => {
            return {};
        },
        createTransactionBillingAddress: () => {
            return {};
        }
    },
    '~/cartridge/config/braintreePreferences': {
        paymentMethods: { BRAINTREE_APPLEPAY: { paymentMethodId: 'ApplePay' } }
    },
    '*/cartridge/models/btGraphQLSdk': function () {
        this.createTransaction = () => {
            return createTransactionResult;
        };
    }
});

describe('BraintreeApplePay File', () => {
    describe('createSaleTransactionData', () => {
        const order = {};
        const paymentInstrument = {
            custom: {
                braintreePaymentMethodNonce: 'nonce',
                braintreeFraudRiskData: 'fraud risk data',
                braintreePaymentMethodBillingAddress: 'billingAddress'
            }
        };

        const createSaleTransactionData = braintreeApplePay.__get__('createSaleTransactionData');

        it('Sales transaction data successfully created', () => {
            const val = createSaleTransactionData(order, paymentInstrument);

            expect(val).to.be.an('object');
            expect(val).to.have.property('deviceData');
            expect(val.deviceData).to.equal(paymentInstrument.custom.braintreeFraudRiskData);
        });

        it('Nonce not set', () => {
            paymentInstrument.custom.braintreePaymentMethodNonce = '';

            expect(() => createSaleTransactionData(order, paymentInstrument)).to.throw(Error, /^paymentInstrument.custom.braintreePaymentMethodNonce$/);
        });
    });

    describe('authorizeFailedFlow', () => {
        const braintreeError = 'error';
        const orderRecord = { custom: { isBraintree: null } };
        const paymentInstrumentRecord = { custom: { braintreeFailReason: '' } };

        const authorizeFailedFlow = braintreeApplePay.__get__('authorizeFailedFlow');

        before(() => {
            stub(dw.system.Transaction, 'wrap', (callback) => callback());
        });

        after(() => {
            dw.system.Transaction.wrap.restore();
        });

        it('Authorize failed', () => {
            const val = authorizeFailedFlow(orderRecord, paymentInstrumentRecord, braintreeError);

            expect(dw.system.Transaction.wrap.calledOnce).to.be.true;

            expect(val).to.be.an('object');
            expect(val).to.deep.equal({ error: true });

            expect(orderRecord.custom.isBraintree).to.be.true;
            expect(paymentInstrumentRecord.custom.braintreeFailReason).to.equal(braintreeError);
        });
    });

    describe('Handle', () => {
        const originalSession = session;
        const originalHttpParameterMap = request.httpParameterMap;

        const basket = {
            createPaymentInstrument: () => {
                return {
                    custom: {
                        braintreeFraudRiskData: '',
                        braintreePaymentMethodNonce: '',
                        braintreePaymentMethodBillingAddress: ''
                    },
                    paymentTransaction: { setPaymentProcessor: () => {} }
                };
            }
        };

        before(() => {
            session = { forms: { billing: { paymentMethod: { value: 'ApplePay' } } } };
            request.httpParameterMap = {
                braintreeApplePayNonce: { stringValue: 'nonce' },
                braintreeApplePayDeviceDataInput: { stringValue: 'device data' },
                braintreeApplePayBillingAddress: { stringValue: 'billingAddress' }
            };

            stub(dw.order.PaymentMgr, 'getPaymentMethod').returns({ getPaymentProcessor: () => {} });
        });

        after(() => {
            session = originalSession;
            request.httpParameterMap = originalHttpParameterMap;

            dw.order.PaymentMgr.getPaymentMethod.restore();
        });

        beforeEach(() => {
            dw.order.PaymentMgr.getPaymentMethod.reset();
        });

        it('Payment instrument successfully created', () => {
            // eslint-disable-next-line new-cap
            const val = braintreeApplePay.Handle(basket);

            expect(dw.order.PaymentMgr.getPaymentMethod.calledOnce).to.be.true;

            expect(val).to.be.an('object');
            expect(val).to.deep.equal({ success: true });
        });

        it('Nonce not set', () => {
            request.httpParameterMap.braintreeApplePayNonce.stringValue = '';

            // eslint-disable-next-line new-cap
            const val = braintreeApplePay.Handle(basket);

            expect(dw.order.PaymentMgr.getPaymentMethod.calledOnce).to.be.true;

            expect(val).to.be.an('object');
            expect(val).to.have.all.keys('error', 'fieldErrors', 'serverErrors');
            expect(val.error).to.be.true;
            expect(val.fieldErrors).to.be.an('array').that.is.empty;
            expect(val.serverErrors).to.be.an('array').that.have.lengthOf(1);
        });
    });

    describe('Authorize', () => {
        let funcsCallCount;

        before(() => {
            braintreeApplePay.__set__('createSaleTransactionData', () => {
                funcsCallCount.createSaleTransactionData++;

                return { deviceData: 'froad risk data' };
            });

            braintreeApplePay.__set__('authorizeFailedFlow', () => {
                funcsCallCount.authorizeFailedFlow++;

                return { error: true };
            });

            stub(dw.order.OrderMgr, 'getOrder').returns({
                paymentTransaction: { accountID: 'accountID' },
                removePaymentInstrument: () => {
                    funcsCallCount.removePaymentInstrument++;
                }
            });
        });

        after(() => {
            braintreeApplePay.__ResetDependency__('authorizeFailedFlow');
            braintreeApplePay.__ResetDependency__('createSaleTransactionData');

            dw.order.OrderMgr.getOrder.restore();

            funcsCallCount = undefined;
            customer.authenticated = false;
        });

        beforeEach(() => {
            dw.order.OrderMgr.getOrder.reset();
            funcsCallCount = {
                authorizeFailedFlow: 0,
                removePaymentInstrument: 0,
                createSaleTransactionData: 0,
                saveGeneralTransactionData: 0
            };
        });

        let amountValue = 1000;
        const orderNo = '00000001';
        const paymentInstrument = {
            creditCardToken: '',
            paymentTransaction: {},
            getPaymentTransaction: () => {
                return { getAmount: () => { return { getValue: () => amountValue }; } };
            },
            custom: {
                braintreePaymentMethodBillingAddress: 'billingAddress'
            }
        };

        it('If no responseData.paymentMethod, payment instrument object shouldn\'t include property creditCardToken', () => {
            createTransactionResult.transaction.paymentMethod = null;
            // eslint-disable-next-line new-cap
            braintreeApplePay.Authorize(orderNo, paymentInstrument);

            expect(paymentInstrument).to.have.property('creditCardToken', '');
        });

        it('Payment transaction amount greater than zero. Token save', () => {
            createTransactionResult.transaction.paymentMethod = { legacyId: 'token' };
            // eslint-disable-next-line new-cap
            const val = braintreeApplePay.Authorize(orderNo, paymentInstrument);

            expect(dw.order.OrderMgr.getOrder.calledOnce).to.be.true;
            expect(funcsCallCount.createSaleTransactionData).to.equal(1);

            expect(val).to.be.an('object');
            expect(val).to.deep.equal({ authorized: true });
            expect(paymentInstrument.creditCardToken).to.equal('token');
        });

        it('Payment transaction amount greater than zero. Token not saved', () => {
            braintreeApplePay.__set__('saveGeneralTransactionData', () => {
                funcsCallCount.saveGeneralTransactionData++;

                createTransactionResult.transaction.paymentMethod = {};
            });

            // eslint-disable-next-line new-cap
            const val = braintreeApplePay.Authorize(orderNo, paymentInstrument);

            braintreeApplePay.__ResetDependency__('saveGeneralTransactionData');

            expect(dw.order.OrderMgr.getOrder.calledOnce).to.be.true;
            expect(funcsCallCount.createSaleTransactionData).to.equal(1);
            expect(funcsCallCount.saveGeneralTransactionData).to.equal(1);

            expect(val).to.be.an('object');
            expect(val).to.deep.equal({ authorized: true });
            expect(paymentInstrument.creditCardToken).to.be.empty;
        });

        it('Authorize Failed, log error', () => {
            braintreeApplePay.__set__('saveGeneralTransactionData', () => {
                funcsCallCount.saveGeneralTransactionData++;

                throw new Error('Error in saveGeneralTransactionData');
            });

            // eslint-disable-next-line new-cap
            const val = braintreeApplePay.Authorize(orderNo, paymentInstrument);

            braintreeApplePay.__ResetDependency__('saveGeneralTransactionData');

            expect(dw.order.OrderMgr.getOrder.calledOnce).to.be.true;
            expect(funcsCallCount.createSaleTransactionData).to.equal(1);
            expect(funcsCallCount.saveGeneralTransactionData).to.equal(1);
            expect(funcsCallCount.authorizeFailedFlow).to.equal(1);

            expect(val).to.be.an('object');
            expect(val).to.deep.equal({ error: true });
        });

        it('Payment transaction amount is zero', () => {
            amountValue = 0;
            // eslint-disable-next-line new-cap
            const val = braintreeApplePay.Authorize(orderNo, paymentInstrument);

            expect(dw.order.OrderMgr.getOrder.calledOnce).to.be.true;
            expect(funcsCallCount.removePaymentInstrument).to.equal(1);

            expect(val).to.be.an('object');
            expect(val).to.deep.equal({ authorized: true });
        });

        it('If customer is authenticated, order.paymentTransaction.accountID should remain the same & payment method should be authorized', () => {
            customer.authenticated = true;

            // eslint-disable-next-line new-cap
            expect(braintreeApplePay.Authorize(orderNo, paymentInstrument)).to.deep.equal({ authorized: true });
        });
    });
});
