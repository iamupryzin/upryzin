const { describe, it } = require('mocha');
const { expect } = require('chai');
const { int_braintree: { braintreeConstantsPath } } = require('../path.json');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const braintreeConstants = proxyquire(braintreeConstantsPath, {});

describe('braintreeConstants', () => {
    it('response type should be object', () => {
        expect(braintreeConstants).to.be.a('object');
    });

    it('response object should consist property PAGE_FLOW_PDP', () => {
        expect(braintreeConstants).has.property('PAGE_FLOW_PDP');
    });

    it('response object should consist property PAGE_FLOW_CHECKOUT', () => {
        expect(braintreeConstants).has.property('PAGE_FLOW_CHECKOUT');
    });

    it('response object should consist property FLOW_VAULT', () => {
        expect(braintreeConstants).has.property('FLOW_VAULT');
    });

    it('response object should consist property PAGE_FLOW_CART', () => {
        expect(braintreeConstants).has.property('PAGE_FLOW_CART');
    });

    it('response object should consist property PAGE_FLOW_MINICART', () => {
        expect(braintreeConstants).has.property('PAGE_FLOW_MINICART');
    });
});
