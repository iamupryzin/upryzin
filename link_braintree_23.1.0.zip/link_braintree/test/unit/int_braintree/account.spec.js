const { int_braintree: { accountPath } } = require('../path.json');

const { it, describe, before, after, beforeEach } = require('mocha');
const { stub } = require('sinon');
const { expect } = require('chai');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');

Object.setPrototypeOf(
    module,
    Object.assign(Object.getPrototypeOf(module), { superModule: {} })
);

const account = proxyquire(accountPath, {
    'dw/web/URLUtils': dw.web.URLUtils,
    'dw/web/Resource': dw.web.Resource,
    '~/cartridge/scripts/braintree/helpers/customerHelper': {
        isPaymentMethodRemoveAllowed: () => true
    }
});

describe('account file', () => {
    describe('getCustomerPaymentInstruments', () => {
        let paymentInstrument = {};

        before(() => {
            stub(dw.web.Resource, 'msg');
            stub(dw.web.URLUtils, 'staticURL');

            dw.web.Resource.msg.withArgs('braintree.error.account.PAYMENT_METHOD_REMOVAL_IS_NOT_ALLOWED', 'locale', null).returns('Sorry, but you can not delete this payment method, since there are created transactions which are waiting for capturing. When all the transactions will be captured, then you will be able to remove this payment method');
            dw.web.URLUtils.staticURL.withArgs('/images/visa-dark.svg').returns('some/url/for/visa');
        });

        after(() => {
            dw.web.Resource.msg.restore();
            dw.web.URLUtils.staticURL.restore();
        });

        beforeEach(() => {
            paymentInstrument = {
                UUID: 'uuid',
                custom: {
                    braintreeDefaultCard: true
                }
            };
        });

        it('If braintreePaypalAccountEmail property exists in paymentInstrument', () => {
            paymentInstrument.custom.braintreePaypalAccountEmail = 'testmail@mail.com';
            paymentInstrument.custom.braintreePaypalAccountAddresses = 'some random address';

            const userPaymentInstruments = {
                toArray: () => {
                    return [paymentInstrument];
                }
            };

            expect(account.getCustomerPaymentInstruments(userPaymentInstruments)).to.deep.equal(
                [{
                    UUID: 'uuid',
                    email: 'testmail@mail.com',
                    address: 'some random address',
                    isDefault: true
                }]
            );
        });

        it('If braintreeVenmoUserId property exists in paymentInstrument', () => {
            paymentInstrument.custom.braintreeVenmoUserId = 'some-user-venmo-id';

            const userPaymentInstruments = {
                toArray: () => {
                    return [paymentInstrument];
                }
            };

            expect(account.getCustomerPaymentInstruments(userPaymentInstruments)).to.deep.equal(
                [{
                    UUID: 'uuid',
                    userID: 'some-user-venmo-id',
                    isDefault: true
                }]
            );
        });

        it('If neither braintreePaypalAccountEmail nor braintreeVenmoUserId property exists in paymentInstrument', () => {
            paymentInstrument.creditCardHolder = 'Name Sname';
            paymentInstrument.paymentMethod = 'CreditCard';
            paymentInstrument.maskedCreditCardNumber = '9999';
            paymentInstrument.creditCardType = 'VISA';
            paymentInstrument.creditCardExpirationMonth = '12';
            paymentInstrument.creditCardExpirationYear = '2030';
            paymentInstrument.creditCardNumberLastDigits = '2222';
            paymentInstrument.creationDate = '02/02/2022';

            const userPaymentInstruments = {
                toArray: () => {
                    return [paymentInstrument];
                }
            };

            expect(account.getCustomerPaymentInstruments(userPaymentInstruments)).to.deep.equal(
                [{
                    creditCardHolder: 'Name Sname',
                    maskedCreditCardNumber: '9999',
                    creditCardType: 'VISA',
                    creditCardExpirationMonth: '12',
                    creditCardExpirationYear: '2030',
                    creditCardExpirationYearShort: '30',
                    UUID: 'uuid',
                    isDefault: true,
                    braintreeIsCard: true,
                    creditCardNumberLastDigits: '2222',
                    creationDate: '02/02/2022',
                    paymentMethod: 'CreditCard',
                    cardTypeImage: {
                        src: 'some/url/for/visa',
                        alt: 'VISA'
                    }
                }]
            );
        });
    });
});

