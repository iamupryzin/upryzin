const { expect } = require('chai');
const { int_braintree: { src_form_processorPath } } = require('../path.json');
const { stub } = require('sinon');

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const req = {
    httpParameterMap: {
        accountUUID: {
            stringValue: null
        },
        braintreeSrcNonce: {
            stringValue: null
        },
        braintreeSrcShippingAddress: {
            stringValue: {
                firstName: 'John',
                lastName: 'Smith',
                streetAddress: '3746 Carriage Lane',
                extendedAddress: '3746 Carriage Lane, Mansfield, Ohio, United States',
                locality: 'Mansfield',
                postalCode: '44907',
                countryCode: 'United States',
                region: 'Ohio',
                phoneNumber: '567-443-0310',
                email: 'john_smith@gmail.com'
            }
        },
        pageFlowCart: {
            stringValue: null
        }
    },
    session: {
        privacyCache: {
            set: (key, value) => {
                return { [key]: value };
            }
        }
    },
    querystring: { fromCart: true }
};

const paymentForm = {
    paymentMethod: 'defaultPaymentMethod'
};
const viewFormData = {};
const order = { isShippingAddressUpdated: false };

const srcFormProcessor = require('proxyquire').noCallThru()(src_form_processorPath, {
    '~/cartridge/scripts/hooks/payment/processor/processorHelper': {
        'dw/order/BasketMgr': dw.order.BasketMgr,
        updateShippingAddress: () => Object.assign(order, { isShippingAddressUpdated: true }),
        updateBillingForm: () => true,
        getBillingAddressFromStringValue: billingAddress => billingAddress
    }
});

describe('src_form_processor file', () => {
    describe('processForm', () => {
        describe('If data.req.httpParameterMap.braintreeSrcBillingAddress.stringValue === null', () => {
            it('response type should be equal -> boolean', () => {
                expect(srcFormProcessor.processForm(req, paymentForm, viewFormData)).to.be.a('Object');
            });
            it('response should be deep equal -> { error: true }', () => {
                expect(srcFormProcessor.processForm(req, paymentForm, viewFormData)).deep.equal({ error: true });
            });
        });

        describe('If data.req.httpParameterMap.braintreeSrcBillingAddress.stringValue !== null and scrBillingAddress.extendedAddress !== null', () => {
            before(() => {
                req.httpParameterMap.braintreeSrcNonce = { stringValue: 'dde32W BDF32w 32we34 kd34WE' };

                stub(dw.order.BasketMgr, 'getCurrentBasket');
                dw.order.BasketMgr.getCurrentBasket.returns({
                    getDefaultShipment: () => 'defaultShipment'
                });
            });
            after(() => {
                dw.order.BasketMgr.getCurrentBasket.restore();
                req.httpParameterMap.pageFlowCart.stringValue = null;
            });

            it('response type should be equal -> Object', () => {
                expect(srcFormProcessor.processForm(req, paymentForm, viewFormData)).to.be.a('Object');
            });
            it('response should consist property -> error', () => {
                expect(srcFormProcessor.processForm(req, paymentForm, viewFormData)).has.property('error');
            });
            it('response property error should be equal -> false', () => {
                expect(srcFormProcessor.processForm(req, paymentForm, viewFormData).error).equal(false);
            });
            it('response should be an updated shipping address if req.querystring is empty', () => {
                req.httpParameterMap.pageFlowCart.stringValue = true;
                srcFormProcessor.processForm(req, paymentForm, viewFormData);

                expect(order).to.have.property('isShippingAddressUpdated', true);
            });
        });
    });
});
