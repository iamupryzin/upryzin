/* eslint-disable new-cap */
const { int_braintree: { braintreePaypalPath } } = require('../path.json');

const { it, describe, before, after, afterEach } = require('mocha');
const { expect } = require('chai');

const { stub } = require('sinon');

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

let isSessionPayPalAccountUsedResponse;
let creditCardToken;

const prefs = {
    paypalDescriptorName: 'paypalDescriptorName',
    isPaypalFraudToolsEnabled: false,
    vaultMode: true,
    paymentMethods: {
        BRAINTREE_PAYPAL: { paymentMethodId: 'BRAINTREE_PAYPAL' }
    },
    paypalOrderIntent: true
};
const getPaypalCustomerPaymentInstrumentByEmail = stub();
const checkForPaymentInstruments = stub();
const createTransaction = stub();

const braintreePaypal = require('proxyquire').noCallThru()(braintreePaypalPath, {
    'dw/order/OrderMgr': dw.order.OrderMgr,
    'dw/order/PaymentMgr': dw.order.PaymentMgr,
    'dw/system/Transaction': dw.system.Transaction,
    '~/cartridge/scripts/braintree/helpers/paymentHelper': {
        getAmountPaid: () => {},
        deleteBraintreePaymentInstruments: () => {},
        getLogger: () => {
            return {
                error: err => err
            };
        },
        handleErrorCode: () => {}
    },
    '~/cartridge/scripts/braintree/braintreeAPI/braintreeBusinessLogic': {
        createPaymentMethod: () => '123456-eeqsdW-14ds74-dww45E',
        getPaypalCustomerPmDataFromBraintree: () => ({ legacyId: 'legacyId' })
    },
    '~/cartridge/config/braintreePreferences': prefs,
    '~/cartridge/scripts/hooks/payment/processor/processorHelper': {
        saveGeneralTransactionData: () => {},
        createBaseSaleTransactionData: (order, paymentInstrument, _prefs) => {
            return {
                order: order,
                paymentInstrument: paymentInstrument,
                prefs: _prefs
            };
        },
        verifyTransactionStatus: () => {},
        savePaypalAccount: (data, address, token) => Object.assign(data, { token: token, billingAddress: address }),
        isSessionPayPalAccountUsed: () => isSessionPayPalAccountUsedResponse,
        checkForPaymentInstruments,
        updatePaypalAccountBillingAddress: () => {}
    },
    '~/cartridge/scripts/braintree/helpers/customerHelper': {
        getPaypalCustomerPaymentInstrumentByEmail: getPaypalCustomerPaymentInstrumentByEmail,
        getCustomerPaymentInstruments: () => {},
        setBraintreeDefaultCard: () => {},
        clearDefaultProperty: () => {},
        getSavedPayPalPaymentInstrumentByUUID: () => {
            return {
                creditCardToken: creditCardToken,
                custom: {}
            };
        }
    },
    '*/cartridge/models/btGraphQLSdk': function () {
        this.createTransaction = createTransaction;
    }
});

describe('braintreePaypal file', () => {
    describe('createSaleTransactionData', () => {
        const createSaleTransactionData = braintreePaypal.__get__('createSaleTransactionData');
        const order = {};
        let paymentInstrument;

        describe('If paymentInstrument.custom.braintreePaymentMethodNonce !== null, paymentInstrument.creditCardToken !== null and prefs.isPaypalFraudToolsEnabled === false', () => {
            before(() => {
                paymentInstrument = {
                    custom: { braintreePaymentMethodNonce: 'braintreePaymentMethodNonce' },
                    creditCardToken: 'creditCardToken'
                };
            });

            it('response type should be equal -> object', () => {
                expect(createSaleTransactionData(order, paymentInstrument)).to.be.a('object');
            });
            it('response object should consist property -> descriptor', () => {
                expect(createSaleTransactionData(order, paymentInstrument)).has.property('descriptor');
            });
            it('response object property descriptor should be deep equal -> { name: "paypalDescriptorName" }', () => {
                expect(createSaleTransactionData(order, paymentInstrument).descriptor).deep.equal({ name: 'paypalDescriptorName' });
            });
            it('response object should consist property -> isPaypal', () => {
                expect(createSaleTransactionData(order, paymentInstrument)).has.property('isPaypal');
            });
            it('response object property isPaypal should be equal -> true', () => {
                expect(createSaleTransactionData(order, paymentInstrument).isPaypal).equal(true);
            });
            it('response object should has not property -> deviceData', () => {
                expect(createSaleTransactionData(order, paymentInstrument)).has.not.property('deviceData');
            });
        });

        describe('If paymentInstrument.custom.braintreePaymentMethodNonce !== null, paymentInstrument.creditCardToken !== null and prefs.isPaypalFraudToolsEnabled === false', () => {
            before(() => {
                paymentInstrument = {
                    custom: { braintreePaymentMethodNonce: 'braintreePaymentMethodNonce' },
                    creditCardToken: 'creditCardToken'
                };
                prefs.paypalDescriptorName = null;
            });
            after(() => {
                prefs.paypalDescriptorName = 'paypalDescriptorName';
            });

            it('response type should be equal -> object', () => {
                expect(createSaleTransactionData(order, paymentInstrument)).to.be.a('object');
            });
            it('response object should consist property -> descriptor', () => {
                expect(createSaleTransactionData(order, paymentInstrument)).has.property('descriptor');
            });
            it('response object property descriptor should be deep equal -> { name: "" }', () => {
                expect(createSaleTransactionData(order, paymentInstrument).descriptor).deep.equal({ name: '' });
            });
        });

        describe('If paymentInstrument.custom.braintreePaymentMethodNonce !== null, paymentInstrument.creditCardToken !== null and prefs.isPaypalFraudToolsEnabled === true', () => {
            before(() => {
                paymentInstrument = {
                    custom: { braintreePaymentMethodNonce: 'braintreePaymentMethodNonce', braintreeFraudRiskData: 'low' },
                    creditCardToken: 'creditCardToken'
                };
                prefs.isPaypalFraudToolsEnabled = true;
            });

            it('response type should be equal -> object', () => {
                expect(createSaleTransactionData(order, paymentInstrument)).to.be.a('object');
            });
            it('response object should consist property -> descriptor', () => {
                expect(createSaleTransactionData(order, paymentInstrument)).has.property('descriptor');
            });
            it('response object property descriptor should be deep equal -> { name: "paypalDescriptorName" }', () => {
                expect(createSaleTransactionData(order, paymentInstrument).descriptor).deep.equal({ name: 'paypalDescriptorName' });
            });
            it('response object should consist property -> isPaypal', () => {
                expect(createSaleTransactionData(order, paymentInstrument)).has.property('isPaypal');
            });
            it('response object property isPaypal should be equal -> true', () => {
                expect(createSaleTransactionData(order, paymentInstrument).isPaypal).equal(true);
            });
            it('response object should has not property -> deviceData', () => {
                expect(createSaleTransactionData(order, paymentInstrument)).has.property('deviceData');
            });
            it('response object property deviceData should be equal -> low', () => {
                expect(createSaleTransactionData(order, paymentInstrument).deviceData).equal('low');
            });
        });

        describe('If paymentInstrument.custom.braintreePaymentMethodNonce is empty, paymentInstrument.creditCardToken is empty', () => {
            before(() => {
                paymentInstrument = {
                    custom: { braintreePaymentMethodNonce: '' },
                    creditCardToken: ''
                };
            });

            it('error should be thrown with text -> paymentInstrument.custom.braintreePaymentMethodNonce', () => {
                expect(() => createSaleTransactionData(order, paymentInstrument)).to.throw(Error, 'paymentInstrument.custom.braintreePaymentMethodNonce');
            });
        });
    });

    describe('createPaypalBillingAddress', () => {
        const resposeObj = {
            firstName: 'Carl',
            lastName: 'Glassman',
            countryCodeAlpha2: 'USA',
            locality: 'Seattle',
            streetAddress: '5039 Ryder Avenue',
            extendedAddress: '5039 Ryder Avenue, Seattle, Washington, USA',
            postalCode: '98109',
            region: 'WA',
            phone: '425-325-0320'
        };
        const createPaypalBillingAddress = braintreePaypal.__get__('createPaypalBillingAddress');
        const order = {
            getBillingAddress: () => {
                return {
                    getFirstName: () => 'Carl',
                    getLastName: () => 'Glassman',
                    getCountryCode: () => {
                        return { value: 'USA' };
                    },
                    getCity: () => 'Seattle',
                    getAddress1: () => '5039 Ryder Avenue',
                    getAddress2: () => '5039 Ryder Avenue, Seattle, Washington, USA',
                    getPostalCode: () => '98109',
                    getStateCode: () => 'WA',
                    getPhone: () => '425-325-0320'
                };
            }
        };

        it('response type should be equal -> object', () => {
            expect(createPaypalBillingAddress(order)).to.be.a('object');
        });
        it('response object should be deep equal -> responseObj', () => {
            expect(createPaypalBillingAddress(order)).deep.equal(resposeObj);
        });
    });

    describe('saveTransactionData', () => {
        const saveTransactionData = braintreePaypal.__get__('saveTransactionData');
        let orderRecord = {};
        let paymentInstrumentRecord = { creditCardToken: '14dsA4- eeqsdW-14ds74-dww45E' };
        let response = {
            transaction: { paymentMethod: null },
            billingAgreementWithPurchasePaymentMethod: null
        };

        describe('If paypalPaymentMethodData === null and paymentInstrumentRecord.creditCardToken !== null', () => {
            it('response should be equal -> undefined', () => {
                expect(saveTransactionData(orderRecord, paymentInstrumentRecord, response)).equal(undefined);
            });
        });

        describe('If paypalPaymentMethodData !== null and paymentInstrumentRecord.creditCardToken !== null', () => {
            before(() => {
                response.billingAgreementWithPurchasePaymentMethod = 'BRAINTREE_TEST';
            });
            after(() => {
                response.billingAgreementWithPurchasePaymentMethod = null;
            });

            it('response should be equal -> undefined', () => {
                expect(saveTransactionData(orderRecord, paymentInstrumentRecord, response)).equal(undefined);
            });
        });

        describe('If paypalPaymentMethodData is not empty and paymentInstrumentRecord.creditCardToken is not empty', () => {
            before(() => {
                response.billingAgreementWithPurchasePaymentMethod = { legacyId: 'some-id' };
                paymentInstrumentRecord.creditCardToken = '';
            });
            after(() => {
                response.billingAgreementWithPurchasePaymentMethod = null;
                paymentInstrumentRecord.creditCardToken = '14dsA4- eeqsdW-14ds74-dww45E';
            });

            it('response should be equal -> undefined', () => {
                saveTransactionData(orderRecord, paymentInstrumentRecord, response);

                expect(paymentInstrumentRecord.creditCardToken).equal('some-id');
            });
        });
    });

    describe('mainFlow', () => {
        const mainFlow = braintreePaypal.__get__('mainFlow');
        const paymentInstrument = {
            paymentTransaction: {},
            custom: { braintreeSaveCreditCard: true }
        };
        const order = { paymentTransaction: { accountID: null } };

        before(() => {
            braintreePaypal.__set__('createSaleTransactionData', () => {});
            braintreePaypal.__set__('saveTransactionData', () => true);
            braintreePaypal.__set__('createPaypalBillingAddress', () => {});
        });

        after(() => {
            braintreePaypal.__ResetDependency__('createSaleTransactionData');
            braintreePaypal.__ResetDependency__('saveTransactionData');
            braintreePaypal.__ResetDependency__('createPaypalBillingAddress');
            checkForPaymentInstruments.reset();
            getPaypalCustomerPaymentInstrumentByEmail.reset();
            createTransaction.reset();
        });

        it('response object paypalData property shouldn\'t contain property token if customer isn\'t authenticated', () => {
            customer.authenticated = false;
            createTransaction.returns({
                transaction: {
                    paymentMethod: null,
                    paymentMethodSnapshot: { payer: { email: 'test@gmail.com' } },
                    customer: { id: 'customerId' }
                }
            });

            expect(mainFlow(order, paymentInstrument)).to.have.property('paypalData').which.not.has.property('token');
        });

        it('response object paypalData property shouldn\'t contain property token if customer is authenticated, but it\'s not new PP account', () => {
            customer.authenticated = true;
            paymentInstrument.custom.braintreeSaveCreditCard = true;
            checkForPaymentInstruments.returns(false);
            getPaypalCustomerPaymentInstrumentByEmail.returns(true);

            expect(mainFlow(order, paymentInstrument)).to.have.property('paypalData').which.not.has.property('token');
        });

        it('response object paypalData property shouldn\'t contain property token if customer is authenticated, but paymentInstrument.custom.braintreeSaveCreditCard is null', () => {
            expect(mainFlow(order, paymentInstrument)).to.have.property('paypalData').which.not.has.property('token');
        });

        it('response object paypalData property should contain property token if customer is authenticated, it\'s new PP account but paypalPaymentMethodData is null', () => {
            paymentInstrument.custom.braintreeSaveCreditCard = true;
            getPaypalCustomerPaymentInstrumentByEmail.returns(false);

            expect(mainFlow(order, paymentInstrument)).to.have.property('paypalData').which.has.property('token', 'legacyId');
        });

        it('response object paypalData property should contain property token if customer is authenticated, it\'s new PP account but paypalPaymentMethodData isn\'t null', () => {
            paymentInstrument.custom.braintreeSaveCreditCard = true;
            checkForPaymentInstruments.returns(true);
            createTransaction.returns({
                transaction: {
                    paymentMethod: { legacyId: 'legacyIdFromTransaction' },
                    paymentMethodSnapshot: {
                        payer: { email: 'jj@gmail.com' }
                    },
                    customer: { id: 'customerId' }
                },
                billingAgreementWithPurchasePaymentMethod: 'Billing Agreement'
            });

            expect(mainFlow(order, paymentInstrument)).to.have.property('paypalData').which.has.property('token', 'legacyIdFromTransaction');
        });
    });

    describe('intentOrderFlow', () => {
        const intentOrderFlow = braintreePaypal.__get__('intentOrderFlow');
        let order = {
            custom: {
                isBraintree: null,
                isBraintreeIntentOrder: null
            }
        };
        let paymentInstrument = {
            creditCardToken: '14dsA4-eeqsdW-14ds74-dww45E',
            custom: { braintreeFraudRiskData: 'low' }
        };

        describe('If paymentInstrument.creditCardToken !== null', () => {
            it('response should be equal -> undefined', () => {
                expect(intentOrderFlow(order, paymentInstrument)).equal(undefined);
            });
        });

        describe('If paymentInstrument.creditCardToken === null', () => {
            before(() => {
                paymentInstrument.creditCardToken = null;
            });
            it('response should be equal -> undefined', () => {
                expect(intentOrderFlow(order, paymentInstrument)).equal(undefined);
            });
        });
    });

    describe('authorizeFailedFlow', () => {
        const authorizeFailedFlow = braintreePaypal.__get__('authorizeFailedFlow');
        const order = {
            custom: { isBraintree: null }
        };
        const paymentInstrument = {
            custom: { braintreeFailReason: null }
        };
        const braintreeError = 'Some error reason';

        it('response type should be equal -> object', () => {
            expect(authorizeFailedFlow(order, paymentInstrument, braintreeError)).to.be.a('object');
        });
        it('response object should consist property -> error', () => {
            expect(authorizeFailedFlow(order, paymentInstrument, braintreeError)).has.property('error');
        });
        it('response object property error type should be equal -> boolean', () => {
            expect(authorizeFailedFlow(order, paymentInstrument, braintreeError).error).to.be.a('boolean');
        });
        it('response object property error should be equal -> true', () => {
            expect(authorizeFailedFlow(order, paymentInstrument, braintreeError).error).equal(true);
        });
    });

    describe('Handle', () => {
        let basket = {
            createPaymentInstrument: (methodName, amountPaid) => { // eslint-disable-line no-unused-vars
                return {
                    paymentTransaction: { setPaymentProcessor: paymentProcessor => paymentProcessor },
                    custom: {
                        braintreeFraudRiskData: null,
                        braintreeSaveCreditCard: null,
                        braintreePaypalEmail: null,
                        braintreePaymentMethodNonce: null
                    }
                };
            },
            getCustomerEmail: () => 'jj_primery@gmail.com'
        };
        before(() => {
            stub(dw.order.PaymentMgr, 'getPaymentMethod').withArgs('BRAINTREE_PAYPAL').returns({ getPaymentProcessor: () => 'BRAINTREE_PAYPAL' });
        });
        after(() => {
            dw.order.PaymentMgr.getPaymentMethod.restore();
        });

        describe('If isSessionAccountUsed exist, customer.authenticated === false', () => {
            before(() => {
                request = {
                    httpParameterMap: {
                        fromCart: { booleanValue: false },
                        braintreePaypalRiskData: { stringValue: 'low' },
                        braintreePaypalEmail: { stringValue: '' },
                        braintreePaypalNonce: { stringValue: 'Dadsw1-SDdw2q-fdzs33- DW32ww' },
                        braintreePaypalFundingSource: { stringValue: 'paypal' },
                        braintreeSavePaypalAccount: { booleanValue: true }
                    },
                    session: { currency: { currencyCode: 'USD' } }
                };
                isSessionPayPalAccountUsedResponse = true;
                session.forms = {
                    billing: {
                        paymentMethod: { value: 'BRAINTREE_PAYPAL' }
                    }
                };
            });

            it('response type should be equal -> object', () => {
                expect(braintreePaypal.Handle(basket)).to.be.a('object');
            });
            it('response object should consist property -> success', () => {
                expect(braintreePaypal.Handle(basket)).has.property('success');
            });
            it('response property success should be equal -> true', () => {
                expect(braintreePaypal.Handle(basket).success).equal(true);
            });
        });

        describe('If isSessionAccountUsed === false, customer.authenticated === true', () => {
            before(() => {
                request.httpParameterMap = {
                    fromCart: { booleanValue: true },
                    braintreePaypalRiskData: { stringValue: 'low' },
                    braintreePaypalEmail: { stringValue: 'jj_primery@gmail.com' },
                    braintreePaypalNonce: { stringValue: 'Dadsw1-SDdw2q-fdzs33-DW32ww' },
                    braintreePaypalFundingSource: { stringValue: 'paypal' }
                };
                isSessionPayPalAccountUsedResponse = false;
                creditCardToken = null;
                session.forms = {
                    billing: {
                        paymentMethod: { value: 'BRAINTREE_PAYPAL' }
                    }
                };
                customer.authenticated === true;

                stub(dw.system.Transaction, 'wrap', (callback) => callback());
            });

            after(() => {
                creditCardToken = '';

                dw.system.Transaction.wrap.restore();
            });

            afterEach(() => {
                dw.system.Transaction.wrap.reset();
            });

            it('response type should be equal -> object', () => {
                expect(braintreePaypal.Handle(basket)).to.be.a('object');
            });

            it('response object should consist property -> error', () => {
                expect(braintreePaypal.Handle(basket)).has.property('error');
            });

            it('response property error should be equal -> true', () => {
                expect(braintreePaypal.Handle(basket).error).equal(true);
            });

            it('response should be returned successfuly', () => {
                creditCardToken = 'creditCardToken';

                const result = braintreePaypal.Handle(basket);

                expect(result).to.be.an('object');
                expect(result).to.deep.equal({ success: true });
                expect(dw.system.Transaction.wrap.calledTwice).to.be.true;
            });
        });

        describe('If isSessionAccountUsed === false, customer.authenticated === false', () => {
            before(() => {
                request.httpParameterMap = {
                    fromCart: { booleanValue: true },
                    braintreePaypalRiskData: { stringValue: 'low' },
                    braintreePaypalEmail: { stringValue: 'jj_primery@gmail.com' },
                    braintreePaypalNonce: { stringValue: 'Dadsw1-SDdw2q-fdzs33-DW32ww' },
                    braintreePaypalFundingSource: { stringValue: 'paypal' }
                };
                isSessionPayPalAccountUsedResponse = false;
                creditCardToken = 'csWdfe-FSfsf3-ffxfe3-fdsf22';
                session.forms = {
                    billing: {
                        paymentMethod: { value: 'BRAINTREE_PAYPAL' }
                    }
                };
                customer.authenticated = false;
            });
            it('response type should be equal -> object', () => {
                expect(braintreePaypal.Handle(basket)).to.be.a('object');
            });
            it('response object should consist property -> success', () => {
                expect(braintreePaypal.Handle(basket)).has.property('success');
            });
            it('response property success should be equal -> false', () => {
                expect(braintreePaypal.Handle(basket).success).equal(false);
            });
        });
    });

    describe('Authorize', () => {
        let orderNo;
        let paymentInstrument;
        before(() => {
            stub(dw.order.OrderMgr, 'getOrder').returns({});
        });
        after(() => {
            dw.order.OrderMgr.getOrder.restore();
        });

        describe('If paymentInstrument exist, paymentInstrument.getPaymentTransaction().getAmount().getValue() > 0 and paypalOrderIntent === true', () => {
            before(() => {
                paymentInstrument = {
                    getPaymentTransaction: () => {
                        return {
                            getAmount: () => {
                                return { getValue: () => 1000 };
                            }
                        };
                    }
                };

                braintreePaypal.__set__('intentOrderFlow', () => {
                    throw { message: 'Some error message!' }; // eslint-disable-line no-throw-literal
                });
                braintreePaypal.__set__('authorizeFailedFlow', () => {
                    return { error: 'Some error message!' };
                });
            });

            after(() => {
                braintreePaypal.__ResetDependency__('intentOrderFlow');
                braintreePaypal.__ResetDependency__('authorizeFailedFlow');
            });

            it('response type should be equal -> object', () => {
                expect(braintreePaypal.Authorize(orderNo, paymentInstrument)).to.be.a('object');
            });
            it('respose object should be deep equal -> { error: "Some error message!" }', () => {
                expect(braintreePaypal.Authorize(orderNo, paymentInstrument)).deep.equal({ error: 'Some error message!' });
            });
        });

        describe('If paymentInstrument exist, paymentInstrument.getPaymentTransaction().getAmount().getValue() > 0 and paypalOrderIntent === false', () => {
            before(() => {
                paymentInstrument = {
                    getPaymentTransaction: () => {
                        return {
                            getAmount: () => {
                                return { getValue: () => 1000 };
                            }
                        };
                    }
                };

                prefs.paypalOrderIntent = false;
                braintreePaypal.__set__('mainFlow', () => {});
            });

            after(() => {
                braintreePaypal.__ResetDependency__('mainFlow');
            });

            it('response type should be equal -> object', () => {
                expect(braintreePaypal.Authorize(orderNo, paymentInstrument)).to.be.a('object');
            });

            it('respose object should be deep equal -> { authorized: true }', () => {
                expect(braintreePaypal.Authorize(orderNo, paymentInstrument)).deep.equal({ authorized: true });
            });
        });

        describe('If paymentInstrument does not exist', () => {
            before(() => {
                paymentInstrument = {
                    getPaymentTransaction: () => {
                        return {
                            getAmount: () => {
                                return { getValue: () => -1000 };
                            }
                        };
                    }
                };

                dw.order.OrderMgr.getOrder.returns({
                    removePaymentInstrument: () => {}
                });

                stub(dw.system.Transaction, 'wrap', (callback) => callback());
            });

            after(() => {
                dw.system.Transaction.wrap.restore();
            });

            it('payment should be authorized', () => {
                const result = braintreePaypal.Authorize(orderNo, paymentInstrument);

                expect(result).to.be.a('object');
                expect(result).to.deep.equal({ authorized: true });
                expect(dw.system.Transaction.wrap.calledOnce).to.be.true;
            });
        });
    });
});
