const { int_braintree: { processorHelperPath } } = require('../path.json');

const { it, describe, before, after, afterEach } = require('mocha');
const { expect } = require('chai');
const { stub, assert } = require('sinon');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const prefs = {
    customFields: {},
    isL2L3: false,
    isSettle: false,
    paymentMethods: {
        BRAINTREE_GOOGLEPAY: {
            paymentMethodId: 'BRAINTREE_GOOGLEPAY'
        },
        BRAINTREE_SRC: {
            paymentMethodId: 'BRAINTREE_SRC'
        },
        BRAINTREE_CREDIT: {
            paymentMethodId: 'BRAINTREE_CREDIT'
        },
        BRAINTREE_PAYPAL: {
            paymentMethodId: 'BRAINTREE_PAYPAL'
        },
        BRAINTREE_VENMO: {
            paymentMethodId: 'BRAINTREE_VENMO'
        }
    }
};
const customFieldsXml = '<testfield>Test_Field</testfield>';
const items = [{
    id: 'item'
}];
const currencyCode = 'USD';

const getBraintreePaymentInstrument = stub();
const createCustomerId = stub();
const customerHelper = stub();
const getCustomerVaultData = stub();
const createAddressData = stub();
const getPhoneFromProfile = stub();
const clearDefaultProperty = stub();
const createShippingAddressData = stub();
const getApplicableCreditCardPaymentInstruments = stub();

const processorHelper = proxyquire(processorHelperPath, {
    'dw/svc': {},
    'dw/system': dw.system,
    'dw/system/Transaction': dw.system.Transaction,
    'dw/order': dw.order,
    'dw/customer': dw.customer,
    'dw/web/Resource': dw.web.Resource,
    'dw/value/Money': dw.value.Money,
    'dw/system/HookMgr': dw.system.HookMgr,
    'dw/order/PaymentTransaction': {
        TYPE_AUTH: 'AUTH',
        TYPE_CAPTURE: 'CAPTURE'
    },
    'dw/order/BasketMgr': dw.order.BasketMgr,
    'dw/order/PaymentInstrument': dw.order.PaymentInstrument,
    'dw/util/StringUtils': dw.util.StringUtils,
    '~/cartridge/config/braintreePreferences': prefs,
    '~/cartridge/config/basicHelpers': {
        formatComplexCCBrandCode: () => 'Visa'
    },
    '~/cartridge/scripts/braintree/braintreeAPI/braintreeApi': {},
    '~/cartridge/scripts/braintree/helpers/paymentHelper': {
        getBraintreePaymentInstrument,
        customerHelper,
        createAddressData,
        createShippingAddressData,
        getOrderLevelDiscountTotal: () => '0.15',
        getLineItems: () => (items),
        getAmountPaid: () => new dw.value.Money(15, currencyCode),
        getMerchantAccountID: merchantID => merchantID,
        getApplicableCreditCardPaymentInstruments
    },
    '~/cartridge/scripts/braintree/helpers/customerHelper': {
        createCustomerId,
        getPhoneFromProfile,
        clearDefaultProperty,
        getCustomerId: () => 'customerId'
    },
    '~/cartridge/scripts/braintree/braintreeAPI/braintreeApiCalls': {
        getCustomerVaultData
    },
    '~/cartridge/config/braintreeConstants': {
        PAYMENT_PROCCESSOR_ID_BRAINTREE_LOCAL: 'BRAINTREE_LOCAL',
        PAYMENT_PROCCESSOR_ID_BRAINTREE_GOOGLEPAY: 'BRAINTREE_GOOGLEPAY',
        CREDIT_CARD_TYPE_VISA: 'VISA',
        TRANSACTION_STATUS_AUTHORIZED: 'AUTHORIZED',
        TRANSACTION_STATUS_SETTLED: 'SETTLED',
        TRANSACTION_STATUS_SETTLEMENT_PENDING: 'SETTLEMENT_PENDING',
        TRANSACTION_STATUS_SETTLING: 'SETTLING',
        TRANSACTION_STATUS_SUBMITTED_FOR_SETTLEMENT: 'SUBMITTED_FOR_SETTLEMENT',
        SESSION_CARD: 'SESSION_CARD',
        TRANSACTION_VAULT_ON_SUCCESS: 'ON_SUCCESSFUL_TRANSACTION',
        PAYMENT_METHOD_ID_PAYPAL: 'PAYMENT_METHOD_ID_PAYPAL'
    }
});

describe('processorHelper file', () => {
    describe('createFullName function', () => {
        const createFullName = processorHelper.__get__('createFullName');

        describe('trim, split an input string and assign a value', () => {
            let name;

            it('should return a firstName, lastName, secondName if the name.length === 3', () => {
                name = ' Svitlana Serhiivna  Melashenko ';
                expect(createFullName(name)).to.deep.equal({
                    firstName: 'Svitlana',
                    secondName: 'Serhiivna',
                    lastName: 'Melashenko'
                });
            });

            it('should return a firstName, lastName if the name.length === 2', () => {
                name = ' Svitlana  Melashenko ';
                expect(createFullName(name)).to.deep.equal({
                    firstName: 'Svitlana',
                    secondName: null,
                    lastName: 'Melashenko'
                });
            });

            it('should return firstName if name.length === 1', () => {
                name = 'Svitlana';
                expect(createFullName(name)).to.deep.equal(
                    {
                        firstName: 'Svitlana',
                        secondName: null,
                        lastName: null
                    }
                );
            });
        });
    });

    describe('getCustomFields', () => {
        const getCustomFields = processorHelper.__get__('getCustomFields');
        const order = {};
        const paymentInstrument = {
            getPaymentTransaction: () => ({
                getPaymentProcessor: () => ({
                    ID: 'BRAINTREE_TestProcessor'
                })
            })
        };

        before(() => {
            stub(dw.util.StringUtils, 'format');
            stub(dw.system.HookMgr, 'hasHook');
            stub(dw.system.HookMgr, 'callHook');

            dw.util.StringUtils.format.returns('<USD>errw 2322 ewwe w34e</USD>');
            dw.system.HookMgr.hasHook.returns(false);
            dw.system.HookMgr.callHook.returns({ test: 'test-string' });

            prefs.customFields = {
                BRAINTREE_Merchant_Account_IDs: 'USD:errw 2322 ewwe w34e'
            };
        });
        after(() => {
            dw.util.StringUtils.format.restore();
        });

        after(() => {
            dw.system.HookMgr.hasHook.restore();
            dw.system.HookMgr.callHook.restore();
        });

        describe('If order and paymentInstrument provided', () => {
            it('response type should be string', () => {
                expect(getCustomFields(order, paymentInstrument)).to.be.a('string');
            });

            it('response should be equal <USD>errw 2322 ewwe w34e</USD>', () => {
                expect(getCustomFields(order, paymentInstrument)).equal('<USD>errw 2322 ewwe w34e</USD>');
            });

            describe('If HookMgr.hasHook returns true', () => {
                it('response should be equal <USD>errw 2322 ewwe w34e</USD>', () => {
                    dw.system.HookMgr.hasHook.returns(true);

                    const result = getCustomFields(order, paymentInstrument);

                    expect(result).to.be.a('string');
                    expect(result).to.equal('<USD>errw 2322 ewwe w34e</USD><test>test-string</test>');
                });
            });
        });
    });

    describe('getISO3Country', () => {
        const getISO3Country = processorHelper.__get__('getISO3Country');
        let localeId;

        before(() => {
            stub(dw.util.Locale, 'getLocale');
            dw.util.Locale.getLocale.withArgs('US').returns({ getISO3Country: () => 'USA' });
            dw.util.Locale.getLocale.withArgs('FR').returns({ getISO3Country: () => 'FRA' });
        });

        after(() => {
            dw.util.Locale.getLocale.restore();
        });

        describe('If localeId is correct', () => {
            before(() => {
                localeId = 'US';
            });
            it('response type should be string', () => {
                expect(getISO3Country(localeId)).to.be.a('string');
            });
            it('response should be equal USA', () => {
                expect(getISO3Country(localeId)).equal('USA');
            });
        });

        describe('If localeId is correct', () => {
            before(() => {
                localeId = 'FR';
            });
            it('response type should be string', () => {
                expect(getISO3Country(localeId)).to.be.a('string');
            });
            it('response should be equal FRA', () => {
                expect(getISO3Country(localeId)).equal('FRA');
            });
        });
    });

    describe('createGuestCustomerData', () => {
        let registeredCustomer;
        let shippingAddressGetPhone;
        let billingAddressGetPhone;
        let profileGetPhoneMobile;
        let profileGetPhoneHome;
        let profileGetPhoneBusiness;
        let order = {
            getCustomer: () => ({
                getProfile: () => ({
                    getFirstName: () => 'Mike',
                    getLastName: () => 'Obama',
                    getEmail: () => 'a@test.com',
                    getPhoneMobile: () => profileGetPhoneMobile,
                    getPhoneHome: () => profileGetPhoneHome,
                    getPhoneBusiness: () => profileGetPhoneBusiness,
                    getCompanyName: () => 'SF',
                    getFax: () => '22222'
                }),
                isRegistered: () => registeredCustomer
            }),
            getBillingAddress: () => ({
                getFirstName: () => 'Mike',
                getLastName: () => 'Obama',
                getPhone: () => billingAddressGetPhone
            }),
            getDefaultShipment: () => ({
                getShippingAddress: () => ({
                    getPhone: () => shippingAddressGetPhone
                })
            }),
            getCustomerEmail: () => 'a@test.com'
        };

        before(() => {
            createCustomerId.returns('123');
        });

        after(() => {
            createCustomerId.reset();
        });

        it('return Customer data for request customer.isRegistered() == false, billingAddress.getPhone() == true', () => {
            registeredCustomer = false;
            billingAddressGetPhone = '+380';
            expect(processorHelper.createGuestCustomerData(order)).to.deep.equal({
                id: null,
                firstName: 'Mike',
                lastName: 'Obama',
                email: 'a@test.com',
                phone: '+380',
                company: '',
                fax: ''
            });
        });

        it('return Customer data for request customer.isRegistered() == false, shippingAddress.getPhone() == true ', () => {
            registeredCustomer = false;
            billingAddressGetPhone = null;
            shippingAddressGetPhone = '+381';
            expect(processorHelper.createGuestCustomerData(order)).to.deep.equal({
                id: null,
                firstName: 'Mike',
                lastName: 'Obama',
                email: 'a@test.com',
                phone: '+381',
                company: '',
                fax: ''
            });
        });
    });

    describe('isCountryCodesUpperCase function', () => {
        before(() => {
            session.forms = {
                billing: {
                    addressFields: {
                        country: {
                            getOptions: () => {
                                return {
                                    option1: {
                                        value: 'uk '
                                    },
                                    option2: {
                                        value: 'usa'
                                    }
                                };
                            }
                        }
                    }
                }
            };
        });

        after(() => {
            session.forms = {};
        });

        it('should return boolean value false', () => {
            expect(processorHelper.isCountryCodesUpperCase()).equal(false);
        });
    });

    describe('isCountryCodesUpperCase function', () => {
        before(() => {
            session.forms = {
                billing: {
                    addressFields: {
                        country: {
                            getOptions: () => {
                                return {
                                    option1: {
                                        value: 'UK'
                                    }
                                };
                            }
                        }
                    }
                }
            };
        });

        after(() => {
            session.forms = {};
        });

        it('should return boolean value true', () => {
            expect(processorHelper.isCountryCodesUpperCase()).equal(true);
        });

        describe('billingForm == null', () => {
            before(() => {
                session.forms = {
                    billing: null
                };
            });
            it('should return boolean value true', () => {
                expect(processorHelper.isCountryCodesUpperCase()).equal(true);
            });
        });
    });

    describe('saveGeneralTransactionData Save General Transaction Data', () => {
        let order = {
            custom: {
                isBraintree: true,
                braintreePaymentStatus: true
            },
            getCurrencyCode: () => currencyCode
        };
        let responseTransaction = {
            type: 'sale',
            status: 'authorized',
            amount: 100,
            id: '111test'
        };
        const setTransactionID = stub();
        const setAmount = stub();
        const setType = stub();
        const paymentInstrument = {
            custom: {
                braintreePaymentMethodNonce: 'testNonce'
            },
            getPaymentTransaction: () => ({
                setTransactionID,
                setAmount,
                setType
            })
        };
        let PT = {
            TYPE: ''
        };

        before(() => {
            stub(processorHelper, 'saveGeneralTransactionData').returns(PT.TYPE);
        });
        after(() => {
            processorHelper.saveGeneralTransactionData.restore();
        });

        describe('paymentTransaction.setType PT.TYPE_AUTH', () => {
            PT = {
                TYPE: ''
            };
            before(() => {
                PT.TYPE = 'PT.TYPE_AUTH';
            });
            after(() => {
                PT.TYPE = '';
            });
            it('response type should be string', () => {
                expect(processorHelper.saveGeneralTransactionData(order, paymentInstrument, responseTransaction)).to.be.a('string');
            });
            it('should use braintreePaymentMethodNonce as paymentMethodNonce', () => {
                expect(processorHelper.saveGeneralTransactionData(order, paymentInstrument, responseTransaction)).equal('PT.TYPE_AUTH');
            });
        });

        describe('paymentTransaction.setType PT.TYPE_CAPTURE', () => {
            responseTransaction.status = 'settling';
            PT = {
                TYPE: 'PT.TYPE_AUTH'
            };
            before(() => {
                PT.TYPE = 'PT.TYPE_CAPTURE';
            });
            after(() => {
                PT.TYPE = '';
            });
            it('response type should be string', () => {
                expect(processorHelper.saveGeneralTransactionData(order, paymentInstrument, responseTransaction)).to.be.a('string');
            });
            it('should use braintreePaymentMethodNonce as paymentMethodNonce', () => {
                expect(processorHelper.saveGeneralTransactionData(order, paymentInstrument, responseTransaction)).equal('PT.TYPE_AUTH');
            });
        });
    });

    describe('updateShippingAddress', () => {
        const getShippingAddress = stub();
        const createShippingAddress = stub();
        const orderShippingAddress = {
            getShippingAddress,
            createShippingAddress
        };
        const shippingAddress = {
            setCountryCode: stub(),
            setCity: stub(),
            setAddress1: stub(),
            setAddress2: stub(),
            setPostalCode: stub(),
            setStateCode: stub(),
            setPhone: stub(),
            setFirstName: stub(),
            setSecondName: stub(),
            setLastName: stub()
        };
        const createFullName = stub();
        const isCountryCodesUpperCase = stub();

        describe('If full name not required, shipping address exists, country code in lower case', () => {
            before(() => {
                createFullName.withArgs('John Doe').returns('John Doe');
                isCountryCodesUpperCase.returns(false);
                getShippingAddress.returns(shippingAddress);
                const braintreePaypalShippingAddress = {
                    countryCodeAlpha2: 'CA',
                    locality: 'locality',
                    streetAddress: 'streetAddress',
                    extendedAddress: 'extendedAddress',
                    postalCode: 'postalCode',
                    region: 'region',
                    phone: 'phone',
                    firstName: 'firstName',
                    lastName: 'lastName'
                };
                processorHelper.updateShippingAddress(JSON.stringify(braintreePaypalShippingAddress), orderShippingAddress);
            });

            after(() => {
                createFullName.reset();
                isCountryCodesUpperCase.reset();
            });

            it('should set country code into shipping address in lower case', () => {
                assert.calledWith(shippingAddress.setCountryCode, 'CA');
            });

            it('should set city into shipping address', () => {
                assert.calledWith(shippingAddress.setCity, 'locality');
            });

            it('should set address 1 into shipping address', () => {
                assert.calledWith(shippingAddress.setAddress1, 'streetAddress');
            });

            it('should set address2 into shipping address', () => {
                assert.calledWith(shippingAddress.setAddress2, 'extendedAddress');
            });

            it('should set postal code into shipping address', () => {
                assert.calledWith(shippingAddress.setPostalCode, 'postalCode');
            });

            it('should set state code into shipping address', () => {
                assert.calledWith(shippingAddress.setStateCode, 'region');
            });

            it('should set phone into shipping address', () => {
                assert.calledWith(shippingAddress.setPhone, 'phone');
            });

            it('should set first name into shipping address', () => {
                assert.calledWith(shippingAddress.setFirstName, 'firstName');
            });

            it('should set last name into shipping address', () => {
                assert.calledWith(shippingAddress.setLastName, 'lastName');
            });
        });

        describe('If full name required, shipping address not exists, country code in upper case', () => {
            before(() => {
                createFullName.withArgs('John secondName Doe').returns({
                    firstName: 'John',
                    secondName: 'secondName',
                    lastName: 'Doe'
                });
                isCountryCodesUpperCase.returns(true);
                getShippingAddress.returns(null);
                createShippingAddress.returns(shippingAddress);
                const braintreePaypalShippingAddress = {
                    countryCodeAlpha2: 'CO',
                    locality: 'testLocality',
                    streetAddress: 'testStreetAddress',
                    extendedAddress: 'testExtendedAddress',
                    postalCode: 'testPostalCode',
                    region: 'testRegion',
                    phone: 'testPhone',
                    recipientName: 'John secondName Doe'
                };
                processorHelper.updateShippingAddress(JSON.stringify(braintreePaypalShippingAddress), orderShippingAddress);
            });

            after(() => {
                createFullName.reset();
                isCountryCodesUpperCase.reset();
            });

            it('should create shipping address', () => {
                assert.calledOnce(createShippingAddress);
            });

            it('should set country code into shipping address in upper case', () => {
                assert.calledWith(shippingAddress.setCountryCode, 'CO');
            });

            it('should set city into shipping address', () => {
                assert.calledWith(shippingAddress.setCity, 'testLocality');
            });

            it('should set address 1 into shipping address', () => {
                assert.calledWith(shippingAddress.setAddress1, 'testStreetAddress');
            });

            it('should set address2 into shipping address', () => {
                assert.calledWith(shippingAddress.setAddress2, 'testExtendedAddress');
            });

            it('should set postal code into shipping address', () => {
                assert.calledWith(shippingAddress.setPostalCode, 'testPostalCode');
            });

            it('should set state code into shipping address', () => {
                assert.calledWith(shippingAddress.setStateCode, 'testRegion');
            });

            it('should set phone into shipping address', () => {
                assert.calledWith(shippingAddress.setPhone, 'testPhone');
            });

            it('should set first name into shipping address', () => {
                assert.calledWith(shippingAddress.setFirstName, 'John');
            });

            it('should set second name into shipping address', () => {
                assert.calledWith(shippingAddress.setSecondName, 'secondName');
            });

            it('should set last name into shipping address', () => {
                assert.calledWith(shippingAddress.setLastName, 'Doe');
            });
        });

        describe('If shipping address is js object, country code in lower case and all names are empty', () => {
            /* eslint-disable no-global-assign */
            const braintreePaypalShippingAddress = {
                countryCodeAlpha2: 'CO',
                streetAddress: 'testStreetAddress',
                extendedAddress: 'testExtendedAddress',
                postalCode: 'testPostalCode',
                region: 'testRegion',
                phone: 'testPhone',
                recipientName: 'John secondName Doe'
            };
            const originalDecodeURIComponent = decodeURIComponent;

            before(() => {
                processorHelper.__set__('createFullName', () => ({
                    firstName: null,
                    secondName: null,
                    lastName: null
                }));
                processorHelper.__set__('isCountryCodesUpperCase', () => false);
                getShippingAddress.returns(null);
                createShippingAddress.returns(shippingAddress);
                decodeURIComponent = () => false;
            });

            after(() => {
                processorHelper.__ResetDependency__('createFullName');
                processorHelper.__ResetDependency__('isCountryCodesUpperCase');
                decodeURIComponent = originalDecodeURIComponent;
            });

            it('should set country code in lower case', () => {
                processorHelper.updateShippingAddress(braintreePaypalShippingAddress, orderShippingAddress);

                assert.calledWith(shippingAddress.setCountryCode, 'co');
            });
        });
    });

    describe('saveGeneralTransactionData', () => {
        const setType = stub();
        const order = {
            getCurrencyCode: () => {},
            custom: {}
        };
        const paymentInstrument = {
            getPaymentTransaction: () => {
                return {
                    setTransactionID: () => {},
                    setAmount: () => {},
                    setType,
                    custom: {}
                };
            },
            custom: {}
        };
        const responseTransaction = {
            status: 'AUTHORIZED',
            amount: {
                value: 100
            }
        };
        const requestTransaction = {};

        afterEach(() => {
            setType.reset();
        });

        it('If prefs.isSettle === false && transactionStatus = AUTHORIZED', () => {
            processorHelper.saveGeneralTransactionData(order, paymentInstrument, responseTransaction, requestTransaction);

            expect(setType.calledWith('AUTH')).to.be.true;
        });

        it('If prefs.isSettle === false && transactionStatus = AUTHORIZED && requestTransaction type === string && responseTransaction type === string', () => {
            processorHelper.saveGeneralTransactionData(order, paymentInstrument, JSON.stringify(responseTransaction), JSON.stringify(requestTransaction));

            expect(setType.calledWith('AUTH')).to.be.true;
        });

        it('If prefs.isSettle === true && transactionStatus === braintreeConstants.TRANSACTION_STATUS_SUBMITTED_FOR_SETTLEMENT', () => {
            prefs.isSettle = true;
            responseTransaction.status = 'SUBMITTED_FOR_SETTLEMENT';
            processorHelper.saveGeneralTransactionData(order, paymentInstrument, responseTransaction, JSON.stringify(requestTransaction));

            expect(setType.calledWith('CAPTURE')).to.be.true;
        });

        it('If prefs.isSettle === true && transactionStatus === braintreeConstants.TRANSACTION_STATUS_SUBMITTED_FOR_SETTLEMENT', () => {
            prefs.isSettle = false;
            responseTransaction.status = 'SUBMITTED_FOR_SETTLEMENT';
            processorHelper.saveGeneralTransactionData(order, paymentInstrument, responseTransaction, JSON.stringify(requestTransaction));

            expect(setType.notCalled).to.be.true;
        });
    });

    describe('updateDataIfVaultModeAllowed', () => {
        const updateDataIfVaultModeAllowed = processorHelper.__get__('updateDataIfVaultModeAllowed');

        it('If vault mode is allowed data should be adjusted', () => {
            const preferences = { vaultMode: true };
            const data = {};

            updateDataIfVaultModeAllowed(preferences, data);

            expect(data).to.deep.equal({
                vaultPaymentMethodAfterTransacting: { when: 'ON_SUCCESSFUL_TRANSACTION' }
            });
        });
    });

    describe('createBaseSaleTransactionData', () => {
        const authStatus = stub();
        let registeredCustomer;
        const orderShipping = {
            id: 'orderShipping'
        };
        const customerLocale = 'en_US';

        const order = {
            getCustomer: () => ({
                isAuthenticated: authStatus,
                isRegistered: () => registeredCustomer
            }),

            getOrderNo: () => '00095503',
            getCurrencyCode: () => currencyCode,
            getTotalTax: () => ({
                toNumberString: () => 12
            }),
            getCustomerLocaleID: () => customerLocale,
            getDefaultShipment: () => ({
                getShippingAddress: () => orderShipping
            }),
            getShippingTotalPrice: () => ({
                toNumberString: () => 12
            }),
            getBillingAddress: () => ({
                city: 'Boston',
                country: 'USA'
            })
        };
        const prefsData = {
            isSettle: true,
            isL2L3: false
        };
        const paymentInstrument = {
            creditCardToken: '78616fab-b968-0224-1836-1f1a6df32c32',
            custom: {
                braintreePaymentMethodNonce: 'ba7c3ddd-293f-08e2-12b4-6498edca2d5d'
            },
            paymentMethod: null
        };
        processorHelper.__set__('getCustomFields', () => {
            return customFieldsXml;
        });

        before(() => {
            createShippingAddressData.returns({ countryCode: 'USA' });
            processorHelper.__set__('getISO3Country', () => 'US');
        });

        after(() => {
            createShippingAddressData.reset();
            processorHelper.__ResetDependency__('getISO3Country', () => null);
        });


        it('response object customerId property should be null if customer is authenticated and used a stored payment method', () => {
            authStatus.returns(true);

            expect(processorHelper.createBaseSaleTransactionData(order, paymentInstrument, prefsData)).to.have.property('customerId', null);
        });

        it('response object paymentMethodToken property should equal paymentInstrument.creditCardToken if customer is authenticated and used a stored payment method', () => {
            expect(processorHelper.createBaseSaleTransactionData(order, paymentInstrument, prefsData)).to.have.property('paymentMethodToken', '78616fab-b968-0224-1836-1f1a6df32c32');
        });

        it('response object customerId property shouldn\'t be null if customer is authenticated and used a new payment method', () => {
            paymentInstrument.creditCardToken = null;

            expect(processorHelper.createBaseSaleTransactionData(order, paymentInstrument, prefsData)).to.have.property('customerId', 'customerId');
        });

        it('response object paymentMethodToken property should equal paymentInstrument.custom.braintreePaymentMethodNonce if customer is authenticated and used a new payment method', () => {
            expect(processorHelper.createBaseSaleTransactionData(order, paymentInstrument, prefsData)).to.have.property('paymentMethodNonce', 'ba7c3ddd-293f-08e2-12b4-6498edca2d5d');
        });

        it('response object customerId property should be null if customer isn\'t authenticated', () => {
            authStatus.returns(false);
            paymentInstrument.creditCardToken = '78616fab-b968-0224-1836-1f1a6df32c32';

            expect(processorHelper.createBaseSaleTransactionData(order, paymentInstrument, prefsData)).to.have.property('customerId', null);
        });

        it('response object paymentMethodToken property should equal paymentInstrument.custom.braintreePaymentMethodNonce if customer isn\'t authenticated', () => {
            expect(processorHelper.createBaseSaleTransactionData(order, paymentInstrument, prefsData)).to.have.property('paymentMethodNonce', 'ba7c3ddd-293f-08e2-12b4-6498edca2d5d');
        });

        it('response object should contain property taxAmount if prefsData.isL2L3 exists', () => {
            prefsData.isL2L3 = true;

            expect(processorHelper.createBaseSaleTransactionData(order, paymentInstrument, prefsData)).to.have.property('taxAmount', 12);
        });

        it('response object should contain property taxAmount if prefsData.isL2L3 exists', () => {
            expect(processorHelper.createBaseSaleTransactionData(order, paymentInstrument, prefsData))
                .to.have.property('discountAmount', '0.15');
        });

        it('response object shipping.countryCode property should equal us if order locale is same as customer shipping address country', () => {
            createShippingAddressData.returns({ countryCode: 'US' });

            expect(processorHelper.createBaseSaleTransactionData(order, paymentInstrument, prefsData))
                .to.have.property('shipping').which.has.property('countryCode', 'US');
        });
    });

    describe('createOwnerName', () => {
        before(() => {
            stub(dw.util.StringUtils, 'format');

            dw.util.StringUtils.format.returns('John Smith');
        });

        after(() => {
            dw.util.StringUtils.format.restore();
        });

        const createOwnerName = processorHelper.__get__('createOwnerName');
        const createPaymentMethodResponseData = {
            customer: {
                firstName: 'John',
                lastName: 'Smith'
            }
        };
        describe('If createPaymentMethodResponseData exist', () => {
            it('response type should be string', () => {
                expect(createOwnerName(createPaymentMethodResponseData)).to.be.a('string');
            });

            it('response should be equal to John Smith', () => {
                expect(createOwnerName(createPaymentMethodResponseData)).equal('John Smith');
            });

            it('response should be empty string', () => {
                createPaymentMethodResponseData.customer.firstName = '';
                createPaymentMethodResponseData.customer.lastName = '';

                expect(createOwnerName(createPaymentMethodResponseData)).equal(' ');
            });
        });
    });

    describe('saveGeneralPaymentMethodParameters', () => {
        const saveGeneralPaymentMethodParameters = processorHelper.__get__('saveGeneralPaymentMethodParameters');
        const createPaymentMethodResponseData = {
            paymentMethod: {
                legacyId: 'dff2 dad3 4r55 ddss',
                details: {
                    brandCode: 'VISA',
                    expirationMonth: 12,
                    expirationYear: 2050,
                    last4: '1214'
                },
                customer: {
                    firstName: 'John',
                    lastName: 'Doe'
                }
            },
            paymentMethodSnapshot: null
        };

        const creditOwner = 'John Doe';
        const paymentMethodId = 'BRAINTREE_PAYPAL';

        before(() => {
            customer = {
                getProfile: () => {
                    return {
                        getWallet: () => ({
                            createPaymentInstrument: _paymentMethodId => ({
                                paymentMethodId: _paymentMethodId,
                                creditCardHolder: '',
                                creditCardNumber: '',
                                creditCardExpirationMonth: '',
                                creditCardExpirationYear: '',
                                creditCardType: '',
                                creditCardToken: null,
                                custom: {
                                    braintreeDefaultCard: ''
                                },
                                setCreditCardHolder: function (cardOwner) {
                                    this.creditCardHolder = cardOwner;
                                },
                                setCreditCardNumber: function (cardNumber) {
                                    this.creditCardNumber = cardNumber;
                                },
                                setCreditCardExpirationMonth: function (creditCardExpirationMonth) {
                                    this.creditCardExpirationMonth = creditCardExpirationMonth;
                                },
                                setCreditCardExpirationYear: function (creditCardExpirationYear) {
                                    this.creditCardExpirationYear = creditCardExpirationYear;
                                },
                                setCreditCardType: function (creditCardType) {
                                    this.creditCardType = creditCardType;
                                }
                            }),
                            getPaymentInstruments: () => []
                        })
                    };
                }
            };
        });

        after(() => {
            processorHelper.__ResetDependency__('checkForPaymentInstruments');
        });

        it('response type should be object', () => {
            expect(saveGeneralPaymentMethodParameters(createPaymentMethodResponseData, paymentMethodId, creditOwner)).to.be.a('object');
        });

        it('response property error should be equal false', () => {
            expect(saveGeneralPaymentMethodParameters(createPaymentMethodResponseData, paymentMethodId, creditOwner).error).equal(false);
        });

        it('response property customerPaymentInstrument type should be equal object', () => {
            expect(saveGeneralPaymentMethodParameters(createPaymentMethodResponseData, paymentMethodId, creditOwner).customerPaymentInstrument).to.be.a('object');
        });

        it('response property customerPaymentInstrument.creditCardHolder should be equal John Doe', () => {
            expect(saveGeneralPaymentMethodParameters(createPaymentMethodResponseData, paymentMethodId, creditOwner).customerPaymentInstrument.creditCardHolder).equal('John Doe');
        });

        it('response property customerPaymentInstrument.creditCardHolder should be equal John Doe and createOwnerName should be called', () => {
            expect(saveGeneralPaymentMethodParameters(createPaymentMethodResponseData, paymentMethodId).customerPaymentInstrument.creditCardHolder).equal('John Doe');
        });

        it('response property customerPaymentInstrument.creditCardNumber type should be string', () => {
            expect(saveGeneralPaymentMethodParameters(createPaymentMethodResponseData, paymentMethodId, creditOwner).customerPaymentInstrument.creditCardNumber).to.be.a('string');
        });

        it('response property customerPaymentInstrument.creditCardExpirationMonth should be equal 12', () => {
            expect(saveGeneralPaymentMethodParameters(createPaymentMethodResponseData, paymentMethodId, creditOwner).customerPaymentInstrument.creditCardExpirationMonth).equal(12);
        });

        it('response property customerPaymentInstrument.creditCardExpirationYear should be equal 2050', () => {
            expect(saveGeneralPaymentMethodParameters(createPaymentMethodResponseData, paymentMethodId, creditOwner).customerPaymentInstrument.creditCardExpirationYear).equal(2050);
        });

        it('response property customerPaymentInstrument.creditCardType should be equal Visa', () => {
            expect(saveGeneralPaymentMethodParameters(createPaymentMethodResponseData, paymentMethodId, creditOwner).customerPaymentInstrument.creditCardType).equal('Visa');
        });

        it('response property customerPaymentInstrument.creditCardToken should be equal dff2 dad3 4r55 ddss', () => {
            expect(saveGeneralPaymentMethodParameters(createPaymentMethodResponseData, paymentMethodId, creditOwner).customerPaymentInstrument.creditCardToken).equal('dff2 dad3 4r55 ddss');
        });

        it('response property customerPaymentInstrument.custom.braintreeDefaultCard should be equal true', () => {
            expect(saveGeneralPaymentMethodParameters(createPaymentMethodResponseData, paymentMethodId, creditOwner).customerPaymentInstrument.custom.braintreeDefaultCard).equal(true);
        });

        it('response makeCardDefault property should be false if there\'s payment intrument in wallet', () => {
            processorHelper.__set__('checkForPaymentInstruments', () => true);

            expect(saveGeneralPaymentMethodParameters(createPaymentMethodResponseData, paymentMethodId, creditOwner))
                .to.have.property('customerPaymentInstrument').that.has.property('custom').which.has.property('braintreeDefaultCard', false);
        });
    });

    describe('saveSrcAccount', () => {
        const saveSrcAccount = processorHelper.__get__('saveSrcAccount');
        let createPaymentMethodResponseData = {};
        before(() => {
            processorHelper.__set__('saveGeneralPaymentMethodParameters', () => {
                return {
                    customerPaymentInstrument: {
                        custom: {
                            braintreeSRCCustomerId: prefs.paymentMethods.BRAINTREE_SRC.paymentMethodId
                        }
                    }
                };
            });
        });
        after(() => {
            processorHelper.__ResetDependency__('saveGeneralPaymentMethodParameters');
        });

        describe('If createPaymentMethodResponseData exist', () => {
            it('response type should be object', () => {
                expect(saveSrcAccount(createPaymentMethodResponseData)).to.be.a('object');
            });
            it('response property customerPaymentInstrument.custom.braintreeSRCCustomerId type should be string', () => {
                expect(saveSrcAccount(createPaymentMethodResponseData).customerPaymentInstrument.custom.braintreeSRCCustomerId).to.be.a('string');
            });
            it('response property customerPaymentInstrument.custom.braintreeSRCCustomerId should be equal BRAINTREE_SRC', () => {
                expect(saveSrcAccount(createPaymentMethodResponseData).customerPaymentInstrument.custom.braintreeSRCCustomerId).equal('BRAINTREE_SRC');
            });
        });
    });

    describe('saveCustomerCreditCard', () => {
        const saveCustomerCreditCard = processorHelper.__get__('saveCustomerCreditCard');
        let createPaymentMethodResponseData = {};
        const PaymentInstrument = {
            METHOD_CREDIT_CARD: 'CREDIT_CARD'
        };
        const creditOwner = 'John Doe';
        before(() => {
            processorHelper.__set__('saveGeneralPaymentMethodParameters', () => {
                return {
                    customerPaymentInstrument: {
                        custom: {
                            METHOD_CREDIT_CARD: PaymentInstrument.METHOD_CREDIT_CARD
                        }
                    }
                };
            });
        });
        after(() => {
            processorHelper.__ResetDependency__('saveGeneralPaymentMethodParameters');
        });

        describe('If createPaymentMethodResponseData exist', () => {
            it('response type should be object', () => {
                expect(saveCustomerCreditCard(createPaymentMethodResponseData, creditOwner)).to.be.a('object');
            });
            it('response property customerPaymentInstrument.custom.braintreeSRCCustomerId type should be string', () => {
                expect(saveCustomerCreditCard(createPaymentMethodResponseData, creditOwner).customerPaymentInstrument.custom.METHOD_CREDIT_CARD).to.be.a('string');
            });
            it('response property customerPaymentInstrument.custom.braintreeSRCCustomerId should be equal BRAINTREE_SRC', () => {
                expect(saveCustomerCreditCard(createPaymentMethodResponseData, creditOwner).customerPaymentInstrument.custom.METHOD_CREDIT_CARD).equal('CREDIT_CARD');
            });
        });
    });

    describe('savePaypalAccount', () => {
        const savePaypalAccount = processorHelper.__get__('savePaypalAccount');
        const accountAddresses = '';
        let paypalToken = null;
        const createPaymentMethodResponseData = {
            details: {
                email: 'plorents@epam.com'
            },
            transaction: {
                paymentMethodSnapshot: {
                    payer: {
                        email: 'plorents@epam.com'
                    }
                }
            }
        };

        before(() => {
            stub(customer, 'getProfile');
            customer.getProfile.returns({
                getWallet: () => ({
                    createPaymentInstrument: function (paymentMethodId) {
                        return {
                            paymentMethodId: paymentMethodId,
                            creditCardToken: null,
                            creditCardType: null,
                            custom: {
                                braintreePaypalAccountEmail: null,
                                braintreePaypalAccountAddresses: null
                            },
                            setCreditCardType: function (creditCardType) {
                                this.creditCardType = creditCardType;
                            }
                        };
                    }
                })
            });
        });

        after(() => {
            customer.getProfile.restore();
        });

        describe('If paypalToken === ds323f-fdds23-re87u7-ree7w8', () => {
            before(() => {
                paypalToken = 'ds323f-fdds23-re87u7-ree7w8';
            });

            it('responce type should be object', () => {
                expect(savePaypalAccount(createPaymentMethodResponseData, accountAddresses, paypalToken)).to.be.a('object');
            });

            it('responce property token should be a string', () => {
                expect(savePaypalAccount(createPaymentMethodResponseData, accountAddresses, paypalToken).token).to.be.a('string');
            });

            it('responce property token length should be equal 27', () => {
                createPaymentMethodResponseData.details = null;

                expect(savePaypalAccount(createPaymentMethodResponseData, accountAddresses, paypalToken).token.length).equal(27);
            });

            it('responce property token should be equal ds323f-fdds23-re87u7-ree7w8', () => {
                expect(savePaypalAccount(createPaymentMethodResponseData, accountAddresses, paypalToken).token).equal('ds323f-fdds23-re87u7-ree7w8');
            });
        });

        describe('If paypalToken === null', () => {
            before(() => {
                paypalToken = null;
            });

            it('responce type should be object', () => {
                expect(savePaypalAccount(createPaymentMethodResponseData, accountAddresses, paypalToken)).to.be.a('object');
            });

            it('responce property token should not be a string', () => {
                expect(savePaypalAccount(createPaymentMethodResponseData, accountAddresses, paypalToken).token).to.not.be.a('string');
            });

            it('responce property token should be undefined', () => {
                expect(savePaypalAccount(createPaymentMethodResponseData, accountAddresses, paypalToken).token).equal(undefined);
            });
        });
    });

    describe('updatePaypalAccountBillingAddress', () => {
        before(() => {
            stub(customer, 'getProfile');
            customer.getProfile.returns({
                getWallet: () => ({
                    getPaymentInstruments: () => {
                        return {
                            toArray: () => {
                                return [{ custom: { braintreePaypalAccountEmail: 'test@email.com' } }];
                            }
                        };
                    }
                })
            });
            stub(dw.system.Transaction, 'wrap', (callback) => callback());
        });

        after(() => {
            customer.getProfile.restore();
            dw.system.Transaction.wrap.restore();
        });

        afterEach(() => {
            dw.system.Transaction.wrap.reset();
        });

        const createPaymentMethodResponseData = {
            transaction: {
                paymentMethodSnapshot: {
                    payer: {
                        email: 'test@email.com'
                    }
                }
            }
        };
        const accountAddresses = [];

        it('If createPaymentMethodResponseData.details does not exist and current buyers PayPal account found', () => {
            processorHelper.updatePaypalAccountBillingAddress(createPaymentMethodResponseData, accountAddresses);

            expect(dw.system.Transaction.wrap.calledOnce).to.be.true;
        });

        it('If createPaymentMethodResponseData.details exists and current buyers PayPal account not found', () => {
            createPaymentMethodResponseData.details = { email: 'tes1t@email.com' };

            processorHelper.updatePaypalAccountBillingAddress(createPaymentMethodResponseData, accountAddresses);
            expect(dw.system.Transaction.wrap.calledOnce).to.be.false;
        });
    });

    describe('getBillingAddressFromStringValue', () => {
        const getBillingAddressFromStringValue = processorHelper.__get__('getBillingAddressFromStringValue');
        let newBillingAddressAsString;
        const billingAddress = '1502 Vernon Street, Los Angeles, California';

        describe('If newBillingAddressAsString === null', () => {
            before(() => {
                newBillingAddressAsString = null;
            });

            it('response should be equal undefined', () => {
                expect(getBillingAddressFromStringValue(newBillingAddressAsString)).equal(undefined);
            });
        });

        describe('If newBillingAddressAsString === "{}"', () => {
            before(() => {
                newBillingAddressAsString = JSON.stringify({});
            });

            it('response should be equal undefined', () => {
                expect(getBillingAddressFromStringValue(newBillingAddressAsString)).equal(undefined);
            });
        });

        describe('If newBillingAddressAsString !== "{}"', () => {
            before(() => {
                newBillingAddressAsString = JSON.stringify({ billingAddress: billingAddress });
            });

            it('response type should be equal object', () => {
                expect(getBillingAddressFromStringValue(newBillingAddressAsString)).to.be.a('object');
            });

            it('response property billingAddress type should be equal string', () => {
                expect(getBillingAddressFromStringValue(newBillingAddressAsString).billingAddress).to.be.a('string');
            });

            it('response should be equal -> 1502 Vernon Street, Los Angeles, California', () => {
                expect(getBillingAddressFromStringValue(newBillingAddressAsString).billingAddress).equal('1502 Vernon Street, Los Angeles, California');
            });
        });

        describe('If newBillingAddressAsString is array with params: [1, 2, 3]', () => {
            before(() => {
                newBillingAddressAsString = [1, 2, 3];
            });

            it('response type should be equal to false', () => {
                expect(getBillingAddressFromStringValue(newBillingAddressAsString)).to.be.false;
            });
        });
    });

    describe('isSessionPayPalAccountUsed', () => {
        const isSessionPayPalAccountUsed = processorHelper.__get__('isSessionPayPalAccountUsed');
        var nonce;

        describe('If nonce === null', () => {
            before(() => {
                nonce = null;
            });

            it('response type should be boolean', () => {
                expect(isSessionPayPalAccountUsed(nonce)).to.be.a('boolean');
            });
            it('response should be equal false', () => {
                expect(isSessionPayPalAccountUsed(nonce)).equal(false);
            });
        });
        describe('nonce === ""', () => {
            before(() => {
                nonce = '';
            });
            after(() => {
                nonce = null;
            });
            it('response type should be boolean', () => {
                expect(isSessionPayPalAccountUsed(nonce)).to.be.a('boolean');
            });
            it('response should be equal false', () => {
                expect(isSessionPayPalAccountUsed(nonce)).equal(false);
            });
        });
        describe('If nonce !== null', () => {
            before(() => {
                nonce = 'ds09df-dfd889-99dff9-dfddgg';
            });
            after(() => {
                nonce = null;
            });
            it('response type should be boolean', () => {
                expect(isSessionPayPalAccountUsed(nonce)).to.be.a('boolean');
            });
            it('response should be equal true', () => {
                expect(isSessionPayPalAccountUsed(nonce)).equal(true);
            });
        });
    });

    describe('saveVenmoAccount', () => {
        const saveVenmoAccount = processorHelper.__get__('saveVenmoAccount');
        let createPaymentMethodResponseData = {
            paymentMethod: {
                details: {},
                legacyId: 'BRAINTREE_VENMO'
            }
        };
        before(() => {
            stub(customer, 'getProfile');
            customer.getProfile.returns({
                getWallet: () => ({
                    createPaymentInstrument: function (paymentMethodId) {
                        return {
                            paymentMethodId: paymentMethodId,
                            creditCardToken: null,
                            creditCardType: null,
                            custom: {
                                braintreeVenmoUserId: null
                            },
                            setCreditCardType: function (creditCardType) {
                                this.creditCardType = creditCardType;
                            }
                        };
                    }
                })
            });
        });
        after(() => {
            customer.getProfile.restore();
        });

        describe('If createPaymentMethodResponseData was provided corectly', () => {
            it('response type should be equal object', () => {
                expect(saveVenmoAccount(createPaymentMethodResponseData)).to.be.a('object');
            });
            it('response property token type should be equal string', () => {
                expect(saveVenmoAccount(createPaymentMethodResponseData).token).to.be.a('string');
            });
            it('response property token should be equal -> BRAINTREE_VENMO', () => {
                expect(saveVenmoAccount(createPaymentMethodResponseData).token).equal('BRAINTREE_VENMO');
            });
        });
    });

    describe('createPreferredAddressObj', () => {
        const customerAddress = {
            getFullName: () => 'John Abraham Dow',
            getFirstName: () => 'John',
            getSecondName: () => 'Abraham',
            getLastName: () => 'Dow',
            getCountryCode: () => ({
                value: 'USA'
            }),
            getCity: () => 'Newark',
            getAddress1: () => '848 Hedge Street',
            getAddress2: () => '',
            getPostalCode: () => '07102',
            getStateCode: () => 'NJ',
            getPhone: () => '908-743-9066'
        };

        describe('If customerAddress correct', () => {
            it('response type sould be object', () => {
                expect(processorHelper.createPreferredAddressObj(customerAddress)).to.be.a('object');
            });

            it('response type sould be object', () => {
                expect(processorHelper.createPreferredAddressObj(customerAddress)).deep.equal({
                    recipientName: 'John Abraham Dow',
                    firstName: 'John',
                    secondName: 'Abraham',
                    lastName: 'Dow',
                    countryCodeAlpha2: 'USA',
                    locality: 'Newark',
                    streetAddress: '848 Hedge Street',
                    extendedAddress: '',
                    postalCode: '07102',
                    region: 'NJ',
                    phone: '908-743-9066'
                });
            });
        });
    });

    describe('verifyTransactionStatus', () => {
        let responseTransaction = {
            status: 'AUTHORIZED',
            legacyId: 'some-id'
        };
        const paymentInstrument = {
            transactionID: null,
            getPaymentTransaction: () => {
                return {
                    setTransactionID: transactionID => {
                        paymentInstrument.transactionID = transactionID;
                    }
                };
            }
        };
        const order = {
            custom: {
                braintreePaymentStatus: null
            }
        };

        describe('If responseTransaction.status === AUTHORIZED', () => {
            it('response should not return anything', () => {
                expect(processorHelper.verifyTransactionStatus(responseTransaction, paymentInstrument, order)).equal(undefined);
            });

            it('function should throw an error and legacyId === some-id', () => {
                responseTransaction.status = 'invalid-status';

                expect(() => processorHelper.verifyTransactionStatus(responseTransaction, paymentInstrument, order)).to.throw(Error, 'invalid-status');
            });

            it('function should throw an error and legacyId === null', () => {
                responseTransaction.legacyId = null;

                expect(() => processorHelper.verifyTransactionStatus(responseTransaction, paymentInstrument, order)).to.throw(Error, 'invalid-status');
            });
        });
    });

    describe('isUsedSessionCreditCard', () => {
        let selectedCreditCardUuid;

        describe('If selectedCreditCardUuid === SESSION_CARD', () => {
            before(() => {
                selectedCreditCardUuid = 'SESSION_CARD';
            });
            it('Response type should be boolean', () => {
                expect(processorHelper.isUsedSessionCreditCard(selectedCreditCardUuid)).to.be.a('boolean');
            });
            it('Response type should be equal true', () => {
                expect(processorHelper.isUsedSessionCreditCard(selectedCreditCardUuid)).equal(true);
            });
        });

        describe('If selectedCreditCardUuid === null', () => {
            before(() => {
                selectedCreditCardUuid = null;
            });
            it('Response type should be boolean', () => {
                expect(processorHelper.isUsedSessionCreditCard(selectedCreditCardUuid)).to.be.a('boolean');
            });
            it('Response type should be equal false', () => {
                expect(processorHelper.isUsedSessionCreditCard(selectedCreditCardUuid)).equal(false);
            });
        });

        describe('If selectedCreditCardUuid !== SESSION_CARD', () => {
            before(() => {
                selectedCreditCardUuid = 'NOT_SESSION_CARD';
            });
            it('Response type should be boolean', () => {
                expect(processorHelper.isUsedSessionCreditCard(selectedCreditCardUuid)).to.be.a('boolean');
            });
            it('Response type should be equal false', () => {
                expect(processorHelper.isUsedSessionCreditCard(selectedCreditCardUuid)).equal(false);
            });
        });
    });

    describe('isUsedSavedCardMethod', () => {
        let selectedCreditCardUuid = 'SESSION_CARD';
        before(() => {
            stub(processorHelper, 'isUsedSessionCreditCard');
            processorHelper.isUsedSessionCreditCard.withArgs(selectedCreditCardUuid).returns(true);
        });
        after(() => {
            processorHelper.isUsedSessionCreditCard.restore();
        });
        describe('If selectedCreditCardUuid = SESSION_CARD', () => {
            it('Response type should be boolean', () => {
                expect(processorHelper.isUsedSavedCardMethod(selectedCreditCardUuid)).to.be.a('boolean');
            });
            it('Response type should be equal false', () => {
                expect(processorHelper.isUsedSavedCardMethod(selectedCreditCardUuid)).equal(false);
            });
        });
    });

    describe('isSessionCardAlreadyUsed', () => {
        const braintreePaymentMethodNonce = 'BRAINTREE_NONCE';
        let creditCardBasketPaymentInstrument = [
            {
                custom: {
                    braintreePaymentMethodNonce: 'BRAINTREE_NONCE'
                }
            }
        ];

        describe('If braintreePaymentMethodNonce === braintreePaymentMethodNonce', () => {
            describe('Response type should be boolean', () => {
                it('Response type should be boolean', () => {
                    expect(processorHelper.isSessionCardAlreadyUsed(braintreePaymentMethodNonce, creditCardBasketPaymentInstrument)).to.be.a('boolean');
                });
                it('Response type should be equal false', () => {
                    expect(processorHelper.isSessionCardAlreadyUsed(braintreePaymentMethodNonce, creditCardBasketPaymentInstrument)).equal(true);
                });
            });
        });

        describe('If braintreePaymentMethodNonce === null', () => {
            before(() => {
                creditCardBasketPaymentInstrument = null;
            });
            describe('Response type should be boolean', () => {
                it('Response type should be boolean', () => {
                    expect(processorHelper.isSessionCardAlreadyUsed(braintreePaymentMethodNonce, creditCardBasketPaymentInstrument)).to.be.a('boolean');
                });
                it('Response type should be equal false', () => {
                    expect(processorHelper.isSessionCardAlreadyUsed(braintreePaymentMethodNonce, creditCardBasketPaymentInstrument)).equal(false);
                });
            });
        });

        describe('If braintreePaymentMethodNonce !== braintreePaymentMethodNonce', () => {
            before(() => {
                creditCardBasketPaymentInstrument = [
                    {
                        custom: {
                            braintreePaymentMethodNonce: 'PAYPAL_NONCE'
                        }
                    }
                ];
            });
            describe('Response type should be boolean', () => {
                it('Response type should be boolean', () => {
                    expect(processorHelper.isSessionCardAlreadyUsed(braintreePaymentMethodNonce, creditCardBasketPaymentInstrument)).to.be.a('boolean');
                });
                it('Response type should be equal false', () => {
                    expect(processorHelper.isSessionCardAlreadyUsed(braintreePaymentMethodNonce, creditCardBasketPaymentInstrument)).equal(false);
                });
            });
        });
    });

    describe('getUsedCreditCardFromForm', () => {
        const creditCardForm = {
            cardType: {
                value: 'VISA'
            },
            cardNumber: {
                value: '4354 2154 7878 9684'
            },
            cardOwner: {
                value: 'John Dow'
            },
            expirationMonth: {
                htmlValue: 10
            },
            expirationYear: {
                htmlValue: 25
            }
        };
        describe('If creditCardForm exist and provided correctly', () => {
            it('response type should be object', () => {
                expect(processorHelper.getUsedCreditCardFromForm(creditCardForm)).to.be.a('object');
            });
            it('response should be deep equal', () => {
                expect(processorHelper.getUsedCreditCardFromForm(creditCardForm)).deep.equal({
                    creditCardType: 'VISA',
                    creditCardNumber: '4354 2154 7878 9684',
                    creditCardHolder: 'John Dow',
                    creditCardExpirationMonth: 10,
                    creditCardExpirationYear: 2025
                });
            });
        });
    });

    describe('getBillingAddressFromBasket', () => {
        const billingAddress = {
            firstName: 'firstName',
            lastName: 'lastName',
            address1: 'address1',
            address2: 'address2',
            city: 'city',
            postalCode: '32144',
            countryCode: { value: 'UA' },
            stateCode: '32321',
            phone: '000019211'
        };
        const basket = {
            billingAddress,
            customerEmail: 'customerEmail@email.com'
        };

        it('Should return billing address object', () => {
            const result = processorHelper.getBillingAddressFromBasket(basket);

            expect(result).to.be.an('object');
            expect(result).to.deep.equal({
                firstName: 'firstName',
                lastName: 'lastName',
                streetAddress: 'address1',
                extendedAddress: 'address2',
                locality: 'city',
                postalCode: '32144',
                countryCodeAlpha2: 'UA',
                region: '32321',
                phone: '000019211',
                email: 'customerEmail@email.com'
            });
        });
    });

    describe('isBillingAddressesEqual', () => {
        const wrongBillingAddress = {
            firstName: 'firstName',
            lastName: 'lastName',
            streetAddress: 'address1',
            extendedAddress: 'address2',
            locality: 'city',
            postalCode: '32144',
            region: '32321',
            phone: '000019211',
            email: 'customerEmail@email.com'
        };
        const newBillingAddress = {
            firstName: 'firstName',
            lastName: 'lastName',
            streetAddress: 'address1',
            extendedAddress: 'address2',
            locality: 'city',
            postalCode: '32144',
            countryCodeAlpha2: 'UA',
            region: '32321',
            phone: '000019211',
            email: 'customerEmail@email.com'
        };
        const basket = {
            billingAddress: {
                firstName: 'firstName',
                lastName: 'lastName',
                address1: 'address1',
                address2: 'address2',
                city: 'city',
                postalCode: '32144',
                countryCode: { value: 'UA' },
                stateCode: '32321',
                phone: '000019211'
            },
            customerEmail: 'customerEmail@email.com'
        };

        const isBillingAddressesEqual = processorHelper.__get__('isBillingAddressesEqual');

        it('If it is old billing address', () => {
            expect(isBillingAddressesEqual(basket)).to.be.false;
        });

        it('If it is new billing address, but the length of the keys is not equal', () => {
            expect(isBillingAddressesEqual(basket, wrongBillingAddress)).to.be.false;
        });

        it('If the billing addreses are equal', () => {
            expect(isBillingAddressesEqual(basket, newBillingAddress)).to.be.true;
        });
    });

    describe('billingAddressHasBeenChanged', () => {
        const billingAddress = {
            firstName: 'firstName',
            lastName: 'lastName',
            streetAddress: 'address1',
            extendedAddress: 'address2',
            locality: 'city',
            postalCode: '32144',
            countryCodeAlpha2: 'UA',
            region: '32321',
            phone: '000019211',
            email: 'customerEmail@email.com'
        };
        const wrongBillingAddress = {
            firstName: 'firstName',
            lastName: 'lastName',
            streetAddress: 'address1',
            extendedAddress: 'address2',
            locality: 'city',
            postalCode: '32144',
            region: '32321',
            phone: '000019211',
            email: 'customerEmail@email.com'
        };
        const basket = {
            billingAddress: {
                firstName: 'firstName',
                lastName: 'lastName',
                address1: 'address1',
                address2: 'address2',
                city: 'city',
                postalCode: '32144',
                countryCode: { value: 'UA' },
                stateCode: '32321',
                phone: '000019211'
            },
            customerEmail: 'customerEmail@email.com',
            getPaymentInstruments: () => [{
                custom: {
                    braintreePaymentMethodNonce: 'braintreePaymentMethodNonce'
                }
            }]
        };

        it('If billing address has not been changed', () => {
            expect(processorHelper.billingAddressHasBeenChanged(basket, 'braintreePaymentMethodNonce', billingAddress)).to.be.false;
        });

        it('If billing address has not been changed and nonces are not equal', () => {
            expect(processorHelper.billingAddressHasBeenChanged(basket, 'nonce', billingAddress)).to.be.false;
        });

        it('If billing address has been changed and billing addresses are not equal', () => {
            expect(processorHelper.billingAddressHasBeenChanged(basket, 'braintreePaymentMethodNonce', wrongBillingAddress)).to.be.true;
        });
    });

    describe('updateBillingAddressFileds', () => {
        const billingAddress = {
            firstName: 'firstName',
            lastName: 'lastName',
            streetAddress: 'address1',
            extendedAddress: '',
            locality: 'city',
            postalCode: '32144',
            countryCodeAlpha2: 'UA',
            region: '32321',
            phone: '000019211',
            email: 'customerEmail@email.com'
        };
        const data = {
            viewData: {}
        };

        it('If billing address is not being provided', () => {
            expect(processorHelper.updateBillingAddressFileds(undefined, data)).to.be.false;
        });

        it('If billing address is being provided and response was returned', () => {
            expect(processorHelper.updateBillingAddressFileds(billingAddress, data)).to.be.true;
            expect(data.viewData).to.have.all.keys('address', 'phone');
        });
    });

    describe('updateBillingForm', () => {
        const basket = {
            billingAddress: {
                firstName: 'firstName',
                lastName: 'lastName',
                address1: 'address1',
                address2: 'address2',
                city: 'city',
                postalCode: '32144',
                countryCode: { value: 'UA' },
                stateCode: '32321',
                phone: '000019211'
            },
            customerEmail: 'customerEmail@email.com',
            getPaymentInstruments: () => [{
                custom: {
                    braintreePaymentMethodNonce: 'braintreePaymentMethodNonce'
                }
            }]
        };

        const updateBillingObject = {
            billingAddress: {
                firstName: 'firstName',
                lastName: 'lastName',
                streetAddress: 'address1',
                extendedAddress: 'address2',
                locality: 'city',
                postalCode: '32144',
                countryCodeAlpha2: 'UA',
                region: '32321',
                phone: '000019211',
                email: 'customerEmail@email.com'
            },
            nonce: 'braintreePaymentMethodNonce',
            data: { viewData: {} }
        };

        before(() => {
            stub(dw.order.BasketMgr, 'getCurrentBasket');

            dw.order.BasketMgr.getCurrentBasket.returns(basket);
        });

        after(() => {
            dw.order.BasketMgr.getCurrentBasket.restore();
        });

        it('If billing address did not change and function did not return anything', () => {
            expect(processorHelper.updateBillingForm(updateBillingObject)).to.be.undefined;
        });

        it('If billing address was changed and function did not return anything', () => {
            updateBillingObject.billingAddress.firstName = 'newFirstName';

            expect(processorHelper.updateBillingForm(updateBillingObject)).to.be.undefined;
        });
    });

    describe('checkForPaymentInstruments', () => {
        let paymentMethodId = 'BRAINTREE_PAYPAL';

        before(() => {
            stub(customer, 'getProfile').returns({
                getWallet: () => ({
                    paymentInstruments: { BRAINTREE_CREDIT: ['PI'], BRAINTREE_SRC: ['PI'], BRAINTREE_PAYPAL: [] },
                    getPaymentInstruments: function (PI) {
                        return this.paymentInstruments[PI];
                    }
                })
            });
        });

        after(() => {
            customer.getProfile.reset();
        });

        it('response should be false if paymentMethodId is PAYPAL & there\'re no payment instruments for BRAINTREE_PAYPAL in the wallet', () => {
            expect(processorHelper.checkForPaymentInstruments(paymentMethodId)).to.be.false;
        });

        it('response should be true if paymentMethodId isn SRC & there\'re payment insturments in the wallet', () => {
            paymentMethodId = 'BRAINTREE_SRC';

            expect(processorHelper.checkForPaymentInstruments(paymentMethodId)).to.be.true;
        });
    });

    describe('createTransactionBillingAddress', () => {
        const billingAddress = {
            firstName: 'firstName',
            lastName: 'lastName',
            streetAddress: 'streetAddress',
            locality: 'locality',
            stateCode: 'stateCode',
            postalCode: 'postalCode',
            countryCodeAlpha2: 'countryCode'
        };
        const transactionBillingAddress = {
            firstName: 'firstName',
            lastName: 'lastName',
            addressLine1: 'streetAddress',
            locality: 'locality',
            region: 'stateCode',
            postalCode: 'postalCode',
            countryCode: 'countryCode'
        };

        it('response object should be equal to transactionBillingAddress object', () => {
            expect(processorHelper.createTransactionBillingAddress(billingAddress)).to.deep.equal(transactionBillingAddress);
        });
    });
});
