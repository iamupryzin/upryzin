const { int_braintree: { braintreePreferencesPath } } = require('../path.json');

const { it, describe, before, after } = require('mocha');
const { stub } = require('sinon');
const { expect } = require('chai');

const proxyquire = require('proxyquire').noCallThru();

require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const get = stub();
const put = stub();

Object.setPrototypeOf(
    Array,
    { some: () => {} }
);

const paypalButtonConfigs = {};

const braintreePreferences = proxyquire(braintreePreferencesPath, {
    'dw/order/PaymentMgr': {
        getActivePaymentMethods: () => {}
    },
    'dw/system/Site': {
        getCurrent: () => {
            return {
                getDefaultCurrency: () => {},
                getCustomPreferenceValue: (mock) => {
                    return {
                        getValue: () => mock,
                        slice: () => []
                    };
                }
            };
        }
    },
    'dw/system/CacheMgr': {
        getCache: () => {
            return {
                get: get,
                put: put
            };
        }
    },
    'dw/svc/LocalServiceRegistry': {
        createService: () => {
            return {
                configuration: {
                    credential: {
                        custom: {
                            BRAINTREE_Tokenization_Key: 'BRAINTREE_Tokenization_Key'
                        }
                    }
                }
            };
        }
    },
    '~/cartridge/scripts/braintree/configuration/paypalButtonConfigs': paypalButtonConfigs,
    '../scripts/braintree/configuration/SRCButtonConfig': {},
    '../scripts/braintree/helpers/SDKEnableFundingHelper': {
        filterEnableFundingList: () => {}
    },
    '~/cartridge/scripts/braintree/helpers/paymentHelper': {
        getActivePaymentMethods: () => ({
            paymentMethod: {}
        })
    }
});

describe('braintreePreferences file', () => {
    const expectedSitePrefsKeys = [
        'merchantAccountIDs', 'vaultMode', 'isSettle', 'isL2L3', 'customFields',
        'is3DSecureEnabled', 'is3DSecureFallback', 'is3DSecureSkipClientValidationResult', 'is3DSecureVerificationAccountPage',
        'paypalDisplayName', 'paypalOrderIntent', 'paypalBillingAgreementDescription', 'paypalButtonLocation', 'changePMButtonEnabled', 'enableFundingList', 'disableFundingList',
        'applepayDisplayName', 'applepayVisibilityOnCart', 'venmoDisplayName', 'googlepayDisplayName', 'googlepayVisibilityOnCart', 'googleMerchantId', 'srcDisplayName',
        'cwppButtonEnabled', 'cwppButtonUrl', 'cwppStaticImageLink', 'apmaEnabled', 'cwppAgentPassword', 'cwppAgentLogin', 'srcVisibilityOnCart', 'isPayPalCreditEnabledInDropIn',
        'srcAvailabilityCountries', 'venmoAvailabilityCountries', 'creditCardComplexBrandCodes', 'isCcReVerifyEnabled'];

    const expectedKeys = ['loggingMode', 'isFraudToolsEnabled', 'isPaypalFraudToolsEnabled', 'creditCardDescriptorPhone', 'creditCardDescriptorName',
        'creditCardDescriptorUrl', 'paypalDescriptorName', 'paypalIntent', 'tokenizationKey', 'paypalCartButtonConfig', 'paypalBillingButtonConfig',
        'paypalMiniCartButtonConfig', 'paypalPdpButtonConfig', 'SRCBillingButtonConfig', 'SRCCartButtonConfig', 'SRCAccountButtonConfig', 'apiVersion',
        'btPaypalPaymentMethodId', 'SRCImageLink', 'paymentMethods', 'currencyCode', 'braintreeChannel', 'userAgent', ...expectedSitePrefsKeys];

    describe('getPreference', () => {
        const getPreference = braintreePreferences.__get__('getPreference');

        const checkResult = (res) => {
            expect(res).to.be.an('object');
            expect(res).to.have.all.keys(...expectedKeys);
        };

        before(() => {
            braintreePreferences.__set__('addPrefsToWhiteList', () => {});
            braintreePreferences.__set__('getBTPaypalPaymentProcessorId', () => {});

            get.returns(undefined);
        });

        after(() => {
            braintreePreferences.__ResetDependency__('getBTPaypalPaymentProcessorId');
            braintreePreferences.__ResetDependency__('addPrefsToWhiteList', () => undefined);

            get.reset();
        });

        it('If function returns not cached result', () => {
            const result = getPreference();

            checkResult(result);
        });

        it('If function returns not cached result and all properties are null', () => {
            paypalButtonConfigs.PAYPAL_Cart_Button_Config = null;
            paypalButtonConfigs.PAYPAL_Billing_Button_Config = null;
            paypalButtonConfigs.PAYPAL_MiniCart_Button_Config = null;
            paypalButtonConfigs.PAYPAL_PDP_Button_Config = null;

            braintreePreferences.__set__('getCustomSitePreferencies', () => {
                return expectedKeys.reduce((obj, key) => {
                    obj[key] = null;
                    return obj;
                }, {});
            });

            const result = getPreference();

            checkResult(result);
            expect(result).to.not.include({
                'paypalCartButtonConfig': null,
                'paypalBillingButtonConfig': null,
                'paypalMiniCartButtonConfig': null,
                'paypalPdpButtonConfig': null
            });

            braintreePreferences.__ResetDependency__('getCustomSitePreferencies');
        });

        it('If function returns cached result', () => {
            get.withArgs('btPreference').returns(expectedKeys.reduce((obj, key) => {
                obj[key] = '';
                return obj;
            }, {}));

            const result = getPreference();

            checkResult(result);
        });
    });

    describe('getCustomSitePreferencies', () => {
        const getCustomSitePreferencies = braintreePreferences.__get__('getCustomSitePreferencies');

        it('If function returns custom site prefs object', () => {
            const result = getCustomSitePreferencies();

            expect(result).to.be.an('object');
            expect(result).to.have.all.keys(...expectedSitePrefsKeys);
        });
    });

    describe('getTokenizationKey', () => {
        const getTokenizationKey = braintreePreferences.__get__('getTokenizationKey');

        it('If tokenization key returned successfully', () => {
            expect(getTokenizationKey()).to.equal('BRAINTREE_Tokenization_Key');
        });
    });
});
