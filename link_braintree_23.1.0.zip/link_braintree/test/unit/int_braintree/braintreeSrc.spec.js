/* eslint-disable new-cap */
const { int_braintree: { braintreeSrcPath } } = require('../path.json');

const { it, describe, before, after, beforeEach, afterEach } = require('mocha');
const { stub } = require('sinon');
const { expect } = require('chai');

const verifyTransactionStatus = stub();

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');

require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const braintreeSrc = proxyquire(braintreeSrcPath, {
    'dw/order/PaymentMgr': dw.order.PaymentMgr,
    'dw/system/Transaction': dw.system.Transaction,
    '~/cartridge/scripts/braintree/helpers/paymentHelper': {
        handleErrorCode: () => {},
        deleteBraintreePaymentInstruments: () => {},
        getAmountPaid: () => {},
        getLogger: () => {
            return { error: error => error };
        }
    },
    '~/cartridge/scripts/hooks/payment/processor/processorHelper': {
        createBaseSaleTransactionData: () => {
            return {};
        },
        saveGeneralTransactionData: () => {},
        saveSrcAccount: () => {},
        checkForPaymentInstruments: () => false,
        verifyTransactionStatus
    },
    '~/cartridge/scripts/braintree/helpers/customerHelper': {
        setBraintreeDefaultCard: () => {}
    },
    '~/cartridge/config/braintreePreferences': {
        vaultMode: true,
        paymentMethods: {
            BRAINTREE_SRC: {}
        }
    },
    '*/cartridge/models/btGraphQLSdk': () => {
        return {
            createTransaction: () => {
                return {
                    transaction: {
                        paymentMethod: { legacyId: 'some-id' },
                        customer: { id: 'customerId' }
                    }
                };
            }
        };
    },
    'dw/order/OrderMgr': dw.order.OrderMgr
});

describe('braintreeSrc file', () => {
    describe('createSaleTransactionData', () => {
        const order = {};
        const paymentInstrument = {
            custom: {
                braintreePaymentMethodNonce: 'nonce',
                braintreeFraudRiskData: 'braintreeFraudRiskData'
            },
            creditCardToken: 'creditCardToken'
        };

        const createSaleTransactionData = braintreeSrc.__get__('createSaleTransactionData');

        it('If sales transaction data successfully created', () => {
            const result = createSaleTransactionData(order, paymentInstrument);

            expect(result).to.be.an('object');
            expect(result).to.have.property('deviceData');
            expect(result.deviceData).to.equal(paymentInstrument.custom.braintreeFraudRiskData);
        });

        it('If braintreePaymentMethodNonce and creditCardToken are empty', () => {
            paymentInstrument.custom.braintreePaymentMethodNonce = '';
            paymentInstrument.creditCardToken = '';

            expect(() => createSaleTransactionData(order, paymentInstrument)).to.throw(Error, 'paymentInstrument.custom.braintreePaymentMethodNonce');
        });
    });

    describe('authorizeFailedFlow', () => {
        let orderRecord;
        let paymentInstrumentRecord;
        let braintreeError = 'braintreeError';

        const authorizeFailedFlow = braintreeSrc.__get__('authorizeFailedFlow');

        before(() => {
            stub(dw.system.Transaction, 'wrap', (callback) => callback());
        });

        after(() => {
            dw.system.Transaction.wrap.restore();
        });

        beforeEach(() => {
            orderRecord = { custom: {} };
            paymentInstrumentRecord = { custom: {} };
        });

        afterEach(() => {
            dw.system.Transaction.wrap.reset();
        });

        it('If authorize failed and braintreeError exists', () => {
            const result = authorizeFailedFlow(orderRecord, paymentInstrumentRecord, braintreeError);

            expect(dw.system.Transaction.wrap.calledOnce).to.be.true;

            expect(result).to.be.an('object');
            expect(result).to.deep.equal({ error: true });

            expect(orderRecord.custom.isBraintree).to.be.true;
            expect(paymentInstrumentRecord.custom.braintreeFailReason).to.equal(braintreeError);
        });

        it('If authorize failed and braintreeError does not exists', () => {
            braintreeError = null;

            const result = authorizeFailedFlow(orderRecord, paymentInstrumentRecord, braintreeError);

            expect(dw.system.Transaction.wrap.calledOnce).to.be.true;

            expect(result).to.be.an('object');
            expect(result).to.deep.equal({ error: true });

            expect(orderRecord.custom.isBraintree).to.be.true;
            expect(paymentInstrumentRecord.custom).to.not.have.property('braintreeFailReason');
        });
    });

    describe('Handle', () => {
        const originalSession = session;
        const originalHttpParameterMap = request.httpParameterMap;

        const basket = {
            createPaymentInstrument: () => {
                return {
                    custom: {},
                    paymentTransaction: { setPaymentProcessor: () => {} }
                };
            }
        };

        before(() => {
            session = { forms: { billing: { paymentMethod: { value: 'SRC' } } } };
            request.httpParameterMap = {
                braintreeSrcCardType: 'Credit card',
                braintreeSrcCreditCardNumber: '0000',
                braintreeSrcNonce: { stringValue: 'nonce' },
                braintreeSrcCardDescription: { stringValue: 'description' },
                braintreeSaveSRCAccount: { booleanValue: true },
                braintreeSrcDeviceDataInput: { stringValue: 'device data' }
            };

            stub(dw.order.PaymentMgr, 'getPaymentMethod').returns({ getPaymentProcessor: () => {} });
        });

        after(() => {
            session = originalSession;
            request.httpParameterMap = originalHttpParameterMap;

            dw.order.PaymentMgr.getPaymentMethod.restore();
        });

        beforeEach(() => {
            dw.order.PaymentMgr.getPaymentMethod.reset();
        });

        it('If payment instrument successfully created', () => {
            const result = braintreeSrc.Handle(basket);

            expect(dw.order.PaymentMgr.getPaymentMethod.calledOnce).to.be.true;

            expect(result).to.be.an('object');
            expect(result).to.deep.equal({ success: true });
        });
    });

    describe('Authorize', () => {
        let paymentProcessor;
        let paymentInstrument;
        let amountValue = 100;

        const originalCustomer = customer;
        const orderNo = '00000';

        before(() => {
            braintreeSrc.__set__('authorizeFailedFlow', (order, _paymentInstrument, err) => { // eslint-disable-line no-shadow
                return `Failed flow authorized with error: ${err}`;
            });
            braintreeSrc.__set__('createSaleTransactionData', () => {});

            stub(dw.order.OrderMgr, 'getOrder').returns({
                removePaymentInstrument: () => {},
                paymentTransaction: { accountID: 'accountID' }
            });
        });

        after(() => {
            customer = originalCustomer;

            braintreeSrc.__ResetDependency__('authorizeFailedFlow');
            braintreeSrc.__ResetDependency__('createSaleTransactionData');

            dw.order.OrderMgr.getOrder.restore();
        });

        beforeEach(() => {
            paymentProcessor = {};
            paymentInstrument = {
                creditCardToken: '',
                paymentTransaction: {},
                getPaymentTransaction: () => {
                    return {
                        getAmount: () => {
                            return {
                                getValue: () => amountValue
                            };
                        },
                        setPaymentProcessor: () => {}
                    };
                },
                custom: {
                    braintreeSaveCreditCard: true
                }
            };
        });

        afterEach(() => {
            verifyTransactionStatus.resetBehavior();
            dw.order.OrderMgr.getOrder.reset();
        });

        it('If error was thrown with message property and failed flow was authorized', () => {
            verifyTransactionStatus.throws({ message: 'error-message' });

            const result = braintreeSrc.Authorize(orderNo, paymentInstrument, paymentProcessor);

            expect(result).to.be.an('string');
            expect(result).to.equal('Failed flow authorized with error: error-message');
        });

        it('If error was thrown with customMessage property and failed flow was authorized', () => {
            verifyTransactionStatus.throws({ customMessage: 'custom-message' });

            const result = braintreeSrc.Authorize(orderNo, paymentInstrument, paymentProcessor);

            expect(result).to.be.an('string');
            expect(result).to.equal('Failed flow authorized with error: custom-message');
        });

        it('If payment authorized and credit card token was saved', () => {
            const result = braintreeSrc.Authorize(orderNo, paymentInstrument, paymentProcessor);

            expect(result).to.be.an('object');
            expect(result).to.deep.equal({ error: false });

            expect(paymentInstrument.creditCardToken).to.equal('some-id');
            expect(paymentInstrument.custom.braintreeSaveCreditCard).to.equal(null);
        });

        it('If payment authorized and credit card token was saved', () => {
            paymentInstrument.creditCardToken = 'token';

            const result = braintreeSrc.Authorize(orderNo, paymentInstrument, paymentProcessor);

            expect(result).to.be.an('object');
            expect(result).to.deep.equal({ error: false });

            expect(paymentInstrument.creditCardToken).to.equal('token');
            expect(paymentInstrument.custom.braintreeSaveCreditCard).to.equal(null);
        });

        it('If payment authorized, SRC account saved and card is set to default', () => {
            customer.authenticated = true;

            const result = braintreeSrc.Authorize(orderNo, paymentInstrument, paymentProcessor);

            expect(result).to.be.an('object');
            expect(result).to.deep.equal({ error: false });

            expect(paymentInstrument.creditCardToken).to.equal('some-id');
            expect(paymentInstrument.custom.braintreeSaveCreditCard).to.equal(null);
        });

        it('If payment instrument amount equals zero', () => {
            amountValue = 0;

            const result = braintreeSrc.Authorize(orderNo, paymentInstrument, paymentProcessor);

            expect(dw.order.OrderMgr.getOrder.calledOnce).to.be.true;

            expect(result).to.be.an('object');
            expect(result).to.deep.equal({ error: true });
        });
    });
});
