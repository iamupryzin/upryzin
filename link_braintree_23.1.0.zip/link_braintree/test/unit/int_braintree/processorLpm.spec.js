const { expect } = require('chai');
const { int_braintree: { processorLpmPath } } = require('../path.json');
const { stub } = require('sinon');

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const prefs = {
    paymentMethods: {
        BRAINTREE_LOCAL: {
            paymentMethodIds: ['BRAINTREE_LOCAL_1', 'BRAINTREE_LOCAL_2', 'BRAINTREE_LOCAL_3']
        }
    }
};

const braintreeConstants = {
    TRANSACTION_STATUS_SETTLING: 'SETTLING',
    TRANSACTION_STATUS_SUBMITTED_FOR_SETTLEMENT: 'SUBMITTED_FOR_SETTLEMENT'
};

const processorLpm = require('proxyquire').noCallThru()(processorLpmPath, {
    'dw/order/PaymentMgr': dw.order.PaymentMgr,
    'dw/system/Transaction': dw.system.Transaction,
    'dw/web/Resource': dw.web.Resource,
    'dw/order/PaymentTransaction': dw.order.PaymentTransaction,
    '~/cartridge/scripts/braintree/helpers/paymentHelper': {
        getAmountPaid: () => 1000,
        deleteBraintreePaymentInstruments: () => {},
        getLogger: () => {
            return {
                error: error => error
            };
        }
    },
    '~/cartridge/config/braintreePreferences': prefs,
    '~/cartridge/scripts/hooks/payment/processor/processorHelper': {
        createBaseSaleTransactionData: () => {
            return {
                options: {
                    submitForSettlement: null
                },
                deviceData: null
            };
        },
        saveGeneralTransactionData: () => true,
        verifyTransactionStatus: () => true
    },
    '~/cartridge/config/braintreeConstants': braintreeConstants,
    '*/cartridge/models/btGraphQLSdk': function () {
        this.createTransaction = () => {};
    }
});

describe('processorLpm file', () => {
    describe('createSaleTransactionData', () => {
        const paymentInstrument = {
            custom: {
                braintreePaymentMethodNonce: 'dffe3wS-ds332wD-df34wer-22ERdf',
                braintreeFraudRiskData: {}
            },
            creditCardToken: null
        };
        const order = {};
        const createSaleTransactionData = processorLpm.__get__('createSaleTransactionData');

        it('response type should be equal -> object', () => {
            expect(createSaleTransactionData(order, paymentInstrument)).to.be.a('object');
        });

        it('response object should consist property deviceData', () => {
            expect(createSaleTransactionData(order, paymentInstrument)).has.property('deviceData');
        });

        it('response object should consist property options', () => {
            expect(createSaleTransactionData(order, paymentInstrument)).has.property('options');
        });

        it('response property options type should be equal object', () => {
            expect(createSaleTransactionData(order, paymentInstrument).options).to.be.a('object');
        });

        it('response should be an error if there\'s no braintreePaymentMethodNonce & creditCardToken', () => {
            paymentInstrument.custom.braintreePaymentMethodNonce = null;

            expect(() => createSaleTransactionData(order, paymentInstrument)).to.throw('paymentInstrument.custom.braintreePaymentMethodNonce or paymentInstrument.creditCardToken are empty');
        });
    });

    describe('saveTransactionData', () => {
        const saveTransactionData = processorLpm.__get__('saveTransactionData');
        const order = {};
        const paymentInstrument = {
            getPaymentTransaction: () => {
                return {
                    type: null,
                    setType: function (type) {
                        this.type = type;
                    }
                };
            }
        };
        const responseTransaction = { transaction: { status: 'SETTLING' } };

        it('response type should be undefined if transaction status is SETTLING', () => {
            expect(saveTransactionData(order, paymentInstrument, responseTransaction)).to.be.a('undefined');
        });

        it('response type should be undefined if transaction status is SUBMITTED_FOR_SETTLEMENT', () => {
            responseTransaction.transaction.status = 'SUBMITTED_FOR_SETTLEMENT';

            expect(saveTransactionData(order, paymentInstrument, responseTransaction)).to.be.a('undefined');
        });

        it('response type should be undefined if transaction status is AUTHORIZED', () => {
            responseTransaction.transaction.status = 'AUTHORIZED';

            expect(saveTransactionData(order, paymentInstrument, responseTransaction)).to.be.a('undefined');
        });
    });

    describe('createLpmPaymentInstrument', () => {
        let order = {
            createPaymentInstrument: (lpmName, amountPaid) => {
                return {
                    lpmName: lpmName,
                    amountPaid: amountPaid,
                    paymentTransaction: {
                        paymentProcessor: null,
                        setPaymentProcessor: function (paymentProcessor) {
                            this.paymentProcessor = paymentProcessor;
                        }
                    },
                    custom: {
                        braintreeFraudRiskData: null
                    }
                };
            }
        };
        let responseData = {
            lpmName: null,
            deviceData: 'low'
        };
        const createLpmPaymentInstrument = processorLpm.__get__('createLpmPaymentInstrument');
        before(() => {
            Array.indexOf = function (a, b) {
                return Array.prototype.indexOf.call(a, b);
            };
            stub(dw.web.Resource, 'msg');
            dw.web.Resource.msg.withArgs('braintree.error.lpm_unconfigured_method', 'locale', null).returns('Please configure local payment methods');
        });
        after(() => {
            dw.web.Resource.msg.restore();
        });

        describe('If responseData.lpmName is not included in prefs.paymentMethods.BRAINTREE_LOCAL.paymentMethodIds', () => {
            before(() => {
                responseData.lpmName = 'BRAINTREE_LOCAL_4';
            });
            it('response type should be equal -> object', () => {
                expect(createLpmPaymentInstrument(order, responseData)).to.be.a('object');
            });
            it('response object should consist property error', () => {
                expect(createLpmPaymentInstrument(order, responseData)).has.property('error');
            });
            it('response property error type should be equal -> boolean', () => {
                expect(createLpmPaymentInstrument(order, responseData).error).to.be.a('boolean');
            });
            it('response property error should be equal -> true', () => {
                expect(createLpmPaymentInstrument(order, responseData).error).equal(true);
            });
            it('response object should consist property message', () => {
                expect(createLpmPaymentInstrument(order, responseData)).has.property('message');
            });
            it('response property message type should be equal -> string', () => {
                expect(createLpmPaymentInstrument(order, responseData).message).to.be.a('string');
            });
            it('response property message should be equal -> Please configure local payment methods', () => {
                expect(createLpmPaymentInstrument(order, responseData).message).equal('Please configure local payment methods');
            });
        });

        describe('If responseData.lpmName is included in prefs.paymentMethods.BRAINTREE_LOCAL.paymentMethodIds', () => {
            before(() => {
                responseData.lpmName = 'BRAINTREE_LOCAL_3';
                stub(dw.order.PaymentMgr, 'getPaymentMethod');
                dw.order.PaymentMgr.getPaymentMethod.withArgs(responseData.lpmName).returns({
                    getPaymentProcessor: () => 'BRAINTREE_LPM'
                });
            });
            after(() => {
                dw.order.PaymentMgr.getPaymentMethod.restore();
            });
            it('response type should be equal -> object', () => {
                expect(createLpmPaymentInstrument(order, responseData)).to.be.a('object');
            });
            it('response object should consist property -> success', () => {
                expect(createLpmPaymentInstrument(order, responseData)).has.property('success');
            });
            it('response property success type should be equal -> boolean', () => {
                expect(createLpmPaymentInstrument(order, responseData).success).to.be.a('boolean');
            });
            it('response property success shold be equal -> true', () => {
                expect(createLpmPaymentInstrument(order, responseData).success).equal(true);
            });
            it('response object should consist property -> lpmPaymentInstrument', () => {
                expect(createLpmPaymentInstrument(order, responseData)).has.property('lpmPaymentInstrument');
            });
            it('response property lpmPaymentInstrument type should be equal -> object', () => {
                expect(createLpmPaymentInstrument(order, responseData).lpmPaymentInstrument).to.be.a('object');
            });
        });
    });

    describe('setLpmTransactionSale', () => {
        const order = {};
        const responseData = { nonce: 'Dadsw1-SDdw2q-fdzs33-DW32ww' };

        after(() => {
            processorLpm.__ResetDependency__('createLpmPaymentInstrument');
            processorLpm.__ResetDependency__('createSaleTransactionDatat');
            processorLpm.__ResetDependency__('saveTransactionDatat');
        });

        it('response should be an object with property error if lmpPIHandle returns an error', () => {
            processorLpm.__set__('createLpmPaymentInstrument', () => {
                return {
                    error: true,
                    message: 'Please configure local payment methods'
                };
            });

            expect(processorLpm.setLpmTransactionSale(order, responseData)).to.have.property('error', true);
        });

        it('response should be an object with property message if lmpPIHandle returns an error', () => {
            expect(processorLpm.setLpmTransactionSale(order, responseData)).to.have.property('message', 'Please configure local payment methods');
        });

        it('response should be an object with property error if catch block catches an error', () => {
            processorLpm.__set__('createLpmPaymentInstrument', () => {
                throw Error();
            });

            expect(processorLpm.setLpmTransactionSale(order, responseData)).to.have.property('error', true);
        });

        it('response should be an object with property success if transaction status is verified and transaction data is saved', () => {
            processorLpm.__set__('createLpmPaymentInstrument', () => ({
                lpmPaymentInstrument: { custom: { braintreePaymentMethodNonce: null } }
            }));
            processorLpm.__set__('createSaleTransactionData', () => {});
            processorLpm.__set__('saveTransactionData', () => {});

            expect(processorLpm.setLpmTransactionSale(order, responseData)).to.deep.equal({ success: true });
        });
    });
});
