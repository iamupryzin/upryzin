const { expect } = require('chai');
const { stub } = require('sinon');
const { int_braintree: { venmo_form_processorPath } } = require('../path.json');
const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const isBillingAddressesEqual = stub();

const venmoFormProcessor = proxyquire(venmo_form_processorPath, {
    '~/cartridge/scripts/hooks/payment/processor/processorHelper': {
        isBillingAddressesEqual,
        updateBillingAddressFileds: () => true
    },
    'dw/order/BasketMgr': {
        currentBasket: {
            defaultShipment: { shippingAddress: {} }
        }
    }
});

describe('venmoFormProcessor file', () => {
    describe('processForm', () => {
        let req = {
            session: {
                privacyCache: {
                    set: (key, value) => {
                        return {
                            [key]: value
                        };
                    }
                }
            }
        };
        let paymentForm = {
            paymentMethod: {
                value: 'BRAINTREE_VENMO',
                htmlName: 'BRAINTREE_VENMO_FIELD'
            },
            contactInfoFields: {
                email: {
                    value: 'johnDow@gmail.com'
                }
            }
        };
        let viewFormData = {
            paymentMethod: {
                value: null,
                htmlName: null
            }
        };

        const result = {
            paymentMethod: {
                value: 'BRAINTREE_VENMO',
                htmlName: 'BRAINTREE_VENMO_FIELD'
            }
        };

        isBillingAddressesEqual.returns(true);

        before(() => {
            venmoFormProcessor.__set__('createBillingAddressFromShippingAddress', () => {});
        });

        after(() => {
            venmoFormProcessor.__ResetDependency__('createBillingAddressFromShippingAddress');
            isBillingAddressesEqual.reset();
        });

        it('response type shoud be object', () => {
            expect(venmoFormProcessor.processForm(req, paymentForm, viewFormData)).to.be.a('object');
        });
        it('response shoud have property error', () => {
            expect(venmoFormProcessor.processForm(req, paymentForm, viewFormData)).has.property('error');
        });
        it('response property error type should be boolean', () => {
            expect(venmoFormProcessor.processForm(req, paymentForm, viewFormData).error).to.be.a('boolean');
        });
        it('response property error should be equal -> false', () => {
            expect(venmoFormProcessor.processForm(req, paymentForm, viewFormData).error).equal(false);
        });
        it('response property viewData type should be object', () => {
            expect(venmoFormProcessor.processForm(req, paymentForm, viewFormData).viewData).to.be.a('object');
        });
        it('response property viewData should be deep equal -> result', () => {
            expect(venmoFormProcessor.processForm(req, paymentForm, viewFormData).viewData).deep.equal(result);
        });
        it('response property viewData should be deep equal -> result even if billing address fields are updated', () => {
            isBillingAddressesEqual.returns(false);

            expect(venmoFormProcessor.processForm(req, paymentForm, viewFormData).viewData).deep.equal(result);
        });
    });

    describe('createBillingAddressFromShippingAddress', () => {
        const shippingAddress = {
            firstName: 'firstName',
            lastName: 'lastName',
            address1: 'address1',
            address2: 'address2',
            city: 'city',
            postalCode: 'postalCode',
            countryCode: { value: 'countryCode' },
            stateCode: 'stateCode',
            phone: 'phone'
        };
        const billingAddressFromShippingAddress = {
            firstName: 'firstName',
            lastName: 'lastName',
            streetAddress: 'address1',
            extendedAddress: 'address2',
            locality: 'city',
            postalCode: 'postalCode',
            countryCodeAlpha2: 'countryCode',
            region: 'stateCode',
            phone: 'phone'
        };
        const createBillingAddressFromShippingAddress = venmoFormProcessor.__get__('createBillingAddressFromShippingAddress');

        it('response object should equal billingAddressFromShippingAddress object', () => {
            expect(createBillingAddressFromShippingAddress(shippingAddress)).to.deep.equal(billingAddressFromShippingAddress);
        });
    });
});
