'use strict';

const path = require('path');

// int_braintree, int_braintree_dropin_ui
const cartridgeName = 'int_braintree';
const entryChunkName = `${cartridgeName}.min`;
const entries = {
    [entryChunkName]: `${__dirname}/cartridges/${cartridgeName}/cartridge/client/default/js/${cartridgeName}.js`
};

module.exports = [{
    mode: 'development',
    devtool: 'source-map',
    name: 'js',
    entry: entries,
    output: {
        path: path.resolve(`./cartridges/${cartridgeName}/cartridge/static/default/js`),
        filename: '[name].js'
    },
    module: {
        rules: [
            {
                use: {
                    loader: 'babel-loader',
                    options: {
                        presets: [
                            [
                                '@babel/preset-env',
                                {
                                    targets: {
                                        chrome: '53',
                                        firefox: '49',
                                        edge: '38',
                                        ie: '11',
                                        safari: '10'
                                    }
                                }
                            ]
                        ],
                        plugins: [
                            '@babel/plugin-proposal-object-rest-spread',
                            '@babel/plugin-transform-destructuring'
                        ]
                    }
                }
            }
        ]
    }
}];
