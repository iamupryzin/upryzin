/* eslint-disable no-console */
/* eslint-disable require-jsdoc */

'use strict';

const shell = require('shelljs');
const path = require('path');
const fs = require('fs');
const webpack = require('webpack');
const chokidar = require('chokidar');
const os = require('os');

const cwd = process.cwd();
const pwd = __dirname;

const bootstrapPackages = {
    Alert: 'exports-loader?Alert!bootstrap/js/src/alert',
    // Button: 'exports-loader?Button!bootstrap/js/src/button',
    Carousel: 'exports-loader?Carousel!bootstrap/js/src/carousel',
    Collapse: 'exports-loader?Collapse!bootstrap/js/src/collapse',
    // Dropdown: 'exports-loader?Dropdown!bootstrap/js/src/dropdown',
    Modal: 'exports-loader?Modal!bootstrap/js/src/modal',
    // Popover: 'exports-loader?Popover!bootstrap/js/src/popover',
    Scrollspy: 'exports-loader?Scrollspy!bootstrap/js/src/scrollspy',
    Tab: 'exports-loader?Tab!bootstrap/js/src/tab',
    // Tooltip: 'exports-loader?Tooltip!bootstrap/js/src/tooltip',
    Util: 'exports-loader?Util!bootstrap/js/src/util'
};

function dwuploadModule() {
    const modulesPath = './node_modules/.bin/dwupload';

    let dwupload = fs.existsSync(path.resolve(cwd, modulesPath))
        ? path.resolve(cwd, modulesPath)
        : path.resolve(pwd, modulesPath);

    if (os.platform() === 'win32') {
        dwupload += '.cmd';
    }

    return dwupload;
}

function shellCommands(param, fileOrCartridge) {
    const dwupload = dwuploadModule();

    if (os.platform() === 'win32') {
        return `cd ./cartridges && ${dwupload} ${param} ${fileOrCartridge} && cd ..`;
    }

    console.log(`command was ${`cd ./cartridges && node ${dwupload} ${param} ${fileOrCartridge} && cd ..`}`);

    return `cd ./cartridges && node ${dwupload} ${param} ${fileOrCartridge} && cd ..`;
}

function uploadFiles(files) {
    shell.cp('dw.json', './cartridges/'); // copy dw.json file into cartridges directory temporarily

    files.forEach(file => {
        const relativePath = path.relative(path.join(cwd, './cartridges/'), file);

        console.log('upload', relativePath);

        shell.exec(shellCommands('--file', relativePath));
    });

    shell.rm('./cartridges/dw.json'); // remove dw.json file from cartridges directory
}

const compiler = webpack({
    mode: 'development',
    devtool: 'source-map',
    name: 'js',
    entry: {
        'int_paypal_cart.min': `${__dirname}/cartridges/int_paypal/cartridge/client/default/js/cart/cart.js`,
        'int_paypal_billing.min': `${__dirname}/cartridges/int_paypal/cartridge/client/default/js/billing/billing.js`
    },
    output: {
        path: path.resolve('./cartridges/int_paypal/cartridge/static/default/js'),
        filename: '[name].js'
    },
    module: {
        rules: [
            {
                use: {
                    loader: 'babel-loader',
                    options: {
                        presets: [
                            [
                                '@babel/preset-env',
                                {
                                    targets: {
                                        chrome: '53',
                                        firefox: '49',
                                        edge: '38',
                                        ie: '11',
                                        safari: '10'
                                    }
                                }
                            ]
                        ],
                        plugins: [
                            '@babel/plugin-proposal-object-rest-spread',
                            '@babel/plugin-transform-destructuring']
                    }
                }
            }
        ]
    }
});

compiler.watch({
    aggregateTimeout: 300,
    poll: undefined
}, (err) => {
    if (err) {
        console.log(err);
    }
});

const watcher = chokidar.watch(path.join(cwd, 'cartridges/int_paypal'), {
    ignored: [
        '**/cartridge/js/**',
        '**/cartridge/client/**',
        '**/*.scss'
    ],
    persistent: true,
    ignoreInitial: true,
    followSymlinks: false,
    awaitWriteFinish: {
        stabilityThreshold: 300,
        pollInterval: 100
    }
});

watcher.on('change', filename => {
    console.log(`Detected change in file: ${filename}`);

    uploadFiles([filename]);
});
