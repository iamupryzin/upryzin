const { int_paypal: { middlewarePath } } = require('../path.json');

const { expect } = require('chai');
const { it, describe, beforeEach } = require('mocha');
const { stub } = require('sinon');

const proxyquire = require('proxyquire').noCallThru();

const getPaypalPaymentInstrument = stub();
const removePaypalPaymentInstrument = stub();
const removeNonPayPalPaymentInstrument = stub();
const calculateNonGiftCertificateAmount = stub();
const isExpiredTransaction = stub();
const isPaypalButtonEnabled = stub();
const createErrorMsg = stub();
const getUrls = stub();
const createErrorLog = stub();
const getLoginRedirectURL = stub();

const req = {
    form: {
        orderID: 'ID',
        orderToken: 'Token'
    },
    body: '{"someData":"Data"}',
    querystring: { state: null },
    session: { privacyCache: null }
};

const res = {
    parsedBody: {},
    setStatusCode: () => {},
    print: () => {},
    json: () => {},
    redirect: () => {}
};

const next = () => () => {};

const form = {
    paymentMethod: {
        htmlValue: 'paypal'
    }
};

const basket = {};

const paypalPreferences = {
    paypalPaymentMethodId: 'paypal'
};

const middleware = proxyquire(middlewarePath, {
    'server': {
        forms: {
            getForm: () => form
        }
    },
    'dw/order/BasketMgr': dw.order.BasketMgr,
    'dw/order/OrderMgr': dw.order.OrderMgr,
    'dw/order/PaymentMgr': dw.order.PaymentMgr,
    'dw/system/HookMgr': dw.system.HookMgr,
    'dw/web/Resource': dw.web.Resource,
    '*/cartridge/scripts/paypal/helpers/paymentInstrumentHelper': {
        getPaypalPaymentInstrument,
        removePaypalPaymentInstrument,
        removeNonPayPalPaymentInstrument,
        calculateNonGiftCertificateAmount
    },
    '*/cartridge/scripts/paypal/helpers/paypalHelper': {
        isExpiredTransaction,
        isPaypalButtonEnabled
    },
    '*/cartridge/scripts/paypal/paypalUtils': {
        createErrorMsg,
        getUrls,
        createErrorLog
    },
    '*/cartridge/config/paypalPreferences': paypalPreferences,
    '*/cartridge/scripts/helpers/accountHelpers': {
        getLoginRedirectURL
    },
    '*/cartridge/config/paypalConstants': {
        CONNECT_WITH_PAYPAL_CONSENT_DENIED: 'CONNECT_WITH_PAYPAL_CONSENT_DENIED'
    },
    '*/cartridge/config/paypalUrls': {}
});

describe('middleware file', () => {
    describe('validatePaymentMethod function', () => {
        before(() => {
            basket.getPaymentInstruments = () => null;
        });

        it('if there is not basket', () => {
            dw.order.BasketMgr.getCurrentBasket = () => {};
            expect(middleware.validatePaymentMethod(req, res, next)).to.be.a('function');
        });

        it('if there is basket', () => {
            dw.order.BasketMgr.getCurrentBasket = () => basket;
            expect(middleware.validatePaymentMethod(req, res, next)).to.be.a('function');
        });

        it('if change payment method from different one to paypal we remove already existing payment instrument', () => {
            basket.getPaymentInstruments = () => 'paypal';
            dw.order.BasketMgr.getCurrentBasket = () => basket;
            getPaypalPaymentInstrument.returns(false);
            expect(middleware.validatePaymentMethod(req, res, next)).to.be.a('function');
        });

        it('if change payment from paypal to different one we remove paypal as payment instrument', () => {
            form.paymentMethod.htmlValue = 'card';
            dw.order.BasketMgr.getCurrentBasket = () => basket;
            getPaypalPaymentInstrument.returns(true);
            expect(middleware.validatePaymentMethod(req, res, next)).to.be.a('function');
        });
    });

    describe('parseBody function', () => {
        it('if there is no errors', () => {
            expect(middleware.parseBody(req, res, next)).to.be.a('function');
        });

        it('if there is an error', () => {
            req.body = 'data:data';
            expect(middleware.parseBody.call({ emit: () => {} }, req, res, next)).to.have.been.called;
        });
    });

    describe('removeNonPaypalPayment function', () => {
        beforeEach(() => {
            dw.order.BasketMgr.getCurrentBasket = () => basket;
        });

        it('if there is no basket', () => {
            dw.order.BasketMgr.getCurrentBasket = () => {};
            expect(middleware.removeNonPaypalPayment(req, res, next)).to.be.a('function');
        });

        it('if there is basket without paymentInstruments', () => {
            expect(middleware.removeNonPaypalPayment(req, res, next)).to.be.a('function');
        });

        it('if there is basket wit paymentInstruments', () => {
            basket.paymentInstruments = 'paypal';
            expect(middleware.removeNonPaypalPayment(req, res, next)).to.be.a('function');
        });
    });

    describe('validateHandleHook function', () => {
        it('if there is no hook for processor', () => {
            dw.order.PaymentMgr.getPaymentMethod = () => ({ getPaymentProcessor: () => ({ ID: 'ID' }) });
            expect(middleware.validateHandleHook.call({ emit: () => {} }, req, res, next)).to.have.been.called;
        });

        it('if there is hook for processor', () => {
            dw.system.HookMgr.hasHook = () => true;
            expect(middleware.validateHandleHook(req, res, next)).to.be.a('function');
        });
    });

    describe('validateGiftCertificateAmount function', () => {
        before(() => {
            dw.order.BasketMgr.getCurrentBasket = () => basket;
        });

        it('if there is calculatedNonGiftCertificateAmount', () => {
            calculateNonGiftCertificateAmount.returns({ value: 1 });
            expect(middleware.validateGiftCertificateAmount(req, res, next)).to.be.a('function');
        });

        it('if there is no calculatedNonGiftCertificateAmount', () => {
            basket.giftCertificatePaymentInstruments = 'gift';
            calculateNonGiftCertificateAmount.returns({ value: 0 });
            expect(middleware.validateGiftCertificateAmount(req, res, next)).to.be.a('function');
        });

        describe('if there is giftCertificatePaymentInstruments but is no calculatedNonGiftCertificateAmount', () => {
            before(() => {
                basket.giftCertificatePaymentInstruments = '';
                calculateNonGiftCertificateAmount.returns({ value: 0 });
            });

            it('if there is no this.name', () => {
                expect(middleware.validateGiftCertificateAmount(req, res, next)).to.have.been.called;
            });

            it('if this.name is SubmitPayment', () => {
                expect(middleware.validateGiftCertificateAmount.call({ name: 'SubmitPayment', emit: () => {} }, req, res, next)).to.have.been.called;
            });

            it('if this.name is ReturnFromCart', () => {
                expect(middleware.validateGiftCertificateAmount.call({ name: 'ReturnFromCart', emit: () => {} }, req, res, next)).to.have.been.called;
            });
        });
    });

    describe('validateConnectWithPaypalUrl function', () => {
        const emit = stub();

        after(() => {
            request.httpParameterMap = null;
            getLoginRedirectURL.reset();
        });

        it('if there is no error value, next method should be called', () => {
            request.httpParameterMap = { get: () => ({ empty: true }) };

            expect(middleware.validateConnectWithPaypalUrl(req, res, next)).to.be.a('function');
        });

        it('if there is error value which equals CONNECT_WITH_PAYPAL_CONSENT_DENIED, route:Complete should be emitted', () => {
            request.httpParameterMap = { get: () => ({ empty: false, value: 'CONNECT_WITH_PAYPAL_CONSENT_DENIED' }) };
            getLoginRedirectURL.returns(null);

            expect(middleware.validateConnectWithPaypalUrl.call({ emit }, req, res, next)).to.be.undefined;
            expect(emit.calledWith('route:Complete', req, res)).to.be.true;
        });

        it('if there is error value which doesn\'t equal CONNECT_WITH_PAYPAL_CONSENT_DENIED, next method should be called', () => {
            request.httpParameterMap = { get: () => ({ empty: false, value: '' }) };

            expect(middleware.validateConnectWithPaypalUrl(req, res, next)).to.be.a('function');
        });
    });
});
