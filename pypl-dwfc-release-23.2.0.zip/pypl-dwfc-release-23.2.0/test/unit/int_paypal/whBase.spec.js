const { int_paypal: { whBasePath } } = require('../path.json');

const { expect } = require('chai');
const { it, describe } = require('mocha');
const { stub } = require('sinon');

const proxyquire = require('proxyquire').noCallThru();

const createErrorLog = stub();

const response = {
    ok: true,
    object: {
        property: 'value'
    }
};

const paypalTokenService = () => ({
    setThrowOnError: () => ({
        call: () => response
    })
});

const paypalConstants = {
    ACCESS_TOKEN: 'access_token',
    USER_INFO: 'userinfo',
    VERIFY_WH_SIG: 'verify-webhook-signature'
};

const whBase = proxyquire(whBasePath, {
    'dw/web/Resource': dw.web.Resource,
    '*/cartridge/scripts/service/paypalTokenService': paypalTokenService,
    '*/cartridge/config/paypalConstants': paypalConstants,
    '*/cartridge/scripts/paypal/paypalUtils': {
        createErrorLog
    }
});

describe('whBase file', () => {
    const whBaseModel = new whBase();

    describe('verifyWhSignature', () => {
        const whEvent = {};
        const headers = {
            get: (value) => value
        };

        const webHookId = 'webHookId';

        it('if response is not successful', () => {
            response.ok = false;
            response.errorMessage = '{"error_description": "error_description"}';

            expect(() => whBaseModel.verifyWhSignature(whEvent, headers, webHookId)).to.throw('error_description');
        });

        it('if response is successful', () => {
            response.ok = true;

            expect(whBaseModel.verifyWhSignature(whEvent, headers, webHookId)).to.be.deep.equal({
                property: 'value'
            });
        });
    });

    describe('logEventError ', () => {
        const eventType = {};
        const endpointName = 'endpointName';

        it('if response is not successful', () => {
            expect(() => whBaseModel.logEventError(eventType, endpointName)).to.throw();
        });
    });
});
