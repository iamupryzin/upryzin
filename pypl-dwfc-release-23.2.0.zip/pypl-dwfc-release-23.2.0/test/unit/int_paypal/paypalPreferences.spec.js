const { int_paypal: { paypalPreferencesPath } } = require('../path.json');

const { expect } = require('chai');
const { it, describe } = require('mocha');
const { stub } = require('sinon');

const proxyquire = require('proxyquire').noCallThru();

const paypalCartButtonConfig = stub();
const paypalBillingButtonConfig = stub();
const paypalPdpButtonConfig = stub();
const paypalMinicartButtonConfig = stub();
const paypalStaticImageLink = stub();
const CWPPStaticImageLink = stub();

Object.setPrototypeOf(Array,
    { some: () => {} });

let ID = '';

const paypalPreferences = proxyquire(paypalPreferencesPath, {
    'dw/order/PaymentMgr': {
        getActivePaymentMethods: () => [
            {
                ID: ID,
                paymentProcessor: {
                    ID: ID
                }
            }
        ]
    },
    'dw/system/Site': {
        current: {
            getCustomPreferenceValue: () => ({
                getValue: () => {}
            })
        }
    },
    './sdkConfig': {
        paypalCartButtonConfig,
        paypalBillingButtonConfig,
        paypalPdpButtonConfig,
        paypalMinicartButtonConfig,
        paypalStaticImageLink,
        CWPPStaticImageLink
    }
});

describe('paypalPreferences file', () => {
    describe('getPaypalPaymentMethodId', () => {
        /* eslint no-underscore-dangle: 0 */
        const getPaypalPaymentMethodId = paypalPreferences.__get__('getPaypalPaymentMethodId');

        it('active Payment Method is PAYPAL', () => {
            ID = 'PAYPAL';

            expect(getPaypalPaymentMethodId()).to.equal('PAYPAL');
        });

        it('active Payment Method is not PAYPAL', () => {
            ID = '';

            expect(getPaypalPaymentMethodId()).to.be.undefined;
        });
    });
});
