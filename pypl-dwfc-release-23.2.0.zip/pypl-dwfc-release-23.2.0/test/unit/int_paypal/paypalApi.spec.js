const { int_paypal: { paypalApiPath } } = require('../path.json');

const { expect } = require('chai');
const {
    it, describe, beforeEach, after
} = require('mocha');

const { stub } = require('sinon');

const proxyquire = require('proxyquire').noCallThru();

const partnerAttributionId = stub();
const createErrorLog = stub();
const createErrorMsg = stub();

const paymentInstrument = {
    paymentTransaction: {
        amount: {
            value: null
        },
        setAmount: () => {}
    },
    custom: {
        paypalOrderID: null,
        currentPaypalEmail: null,
        PP_API_ActiveBillingAgreement: ''
    }
};

const purchaseUnit = {
    amount: {
        value: null
    }
};

const bodyObj = {

};

const response = {
    id: null,
    ok: null,
    token_id: null,
    state: null,
    payer: {
        payer_info: null,
        email_address: null
    },
    purchase_units: null,
    shipping_address: null,
    emails: null,
    name: null,
    address: null
};

const paypalRestService = {
    call: () => response
};

const paypalTokenService = {
    setThrowOnError: () => ({
        call: () => ({
            ok: true,
            object: {
                access_token: 'access_token'
            }
        })
    })
};

const paypalPreferences = {
    isCapture: true,
    partnerAttributionId
};

function makeResponseDefault() {
    response.id = null;
    response.state = null;
    response.token_id = null;
    response.payer.email_address = null;
    response.purchase_units = null;
    response.payer.payer_info = null;
    response.shipping_address = null;
}

const paypalApi = proxyquire(paypalApiPath, {
    'dw/system/Transaction': dw.system.Transaction,
    'dw/value/Money': dw.value.Money,
    'dw/web/Resource': {
        msg: () => {}
    },
    '*/cartridge/scripts/service/paypalRestService': paypalRestService,
    '*/cartridge/scripts/service/paypalTokenService': () => paypalTokenService,
    '*/cartridge/config/paypalPreferences': paypalPreferences,
    '*/cartridge/scripts/paypal/paypalUtils': {
        createErrorLog,
        createErrorMsg
    },
    '*/cartridge/config/paypalConstants': {
        ACCESS_TOKEN: 'ACCESS_TOKEN',
        REGEXP_PHONE: /^[0-9]{1,14}?$/,
        REGEXP_EMAIL: /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
    }
});

describe('paypalApi file', () => {
    describe('getOrderDetails', () => {
        beforeEach(() => {
            dw.system.Transaction.wrap = (func) => func();
            paymentInstrument.custom.paypalOrderID = 'orderID';
        });

        after(() => {
            paypalRestService.call = () => response;
            paymentInstrument.custom.paypalOrderID = null;
            makeResponseDefault();
        });

        it('if paymentInstrument has not paypalOrderID', () => {
            paymentInstrument.custom.paypalOrderID = null;
            createErrorMsg.returns('paypal.error.api_order_id_notfound');

            expect(paypalApi.getOrderDetails(paymentInstrument)).to.be.deep.equal({
                err: 'paypal.error.api_order_id_notfound'
            });
        });

        it('if paymentInstrument has paypalOrderID and service responsed', () => {
            response.payer.email_address = 'test@gmail.com';
            response.payer.payer_info = 'payer_info';
            response.purchase_units = 'purchase_units';

            expect(paypalApi.getOrderDetails(paymentInstrument)).to.be.deep.equal({
                payer: {
                    email_address: response.payer.email_address,
                    payer_info: response.payer.payer_info
                },
                purchase_units: response.purchase_units
            });
        });

        it('if paymentInstrument has paypalOrderID and service respons failed', () => {
            createErrorMsg.returns('No payer info was found. Order ID ');
            paypalRestService.call = () => null;

            expect(paypalApi.getOrderDetails(paymentInstrument)).to.be.deep.equal({
                err: 'No payer info was found. Order ID '
            });
        });
    });

    describe('updateOrderDetails', () => {
        beforeEach(() => {
            dw.system.Transaction.wrap = (func) => {
                func();
            };

            paymentInstrument.custom.paypalOrderID = 'orderID';
        });

        after(() => {
            paymentInstrument.custom.paypalOrderID = null;
            paymentInstrument.paymentTransaction.amount.value = null;
            purchaseUnit.amount.value = null;
        });

        it('if paymentInstrument has not paypalOrderID', () => {
            createErrorMsg.returns('paypal.error.api_order_id_notfound');
            paymentInstrument.custom.paypalOrderID = null;

            expect(paypalApi.updateOrderDetails(paymentInstrument, purchaseUnit)).to.be.deep.equal({
                err: 'paypal.error.api_order_id_notfound'
            });
        });

        it('if paymentInstrument has paypalOrderID and service responsed and amount values are the same', () => {
            paymentInstrument.paymentTransaction.amount.value = 5;
            purchaseUnit.amount.value = 5;

            expect(paypalApi.updateOrderDetails(paymentInstrument, purchaseUnit)).to.be.deep.equal({
                isOkUpdate: true
            });
        });

        it('if paymentInstrument has paypalOrderID and service responsed and amount values are different', () => {
            paymentInstrument.paymentTransaction.amount.value = 5;
            purchaseUnit.amount.value = 6;

            expect(paypalApi.updateOrderDetails(paymentInstrument, purchaseUnit)).to.be.deep.equal({
                isOkUpdate: true
            });
        });
    });

    describe('createTransaction', () => {
        beforeEach(() => {
            paymentInstrument.custom.paypalOrderID = 'orderID';
            response.id = 1;
            response.state = 'ACTIVE';
            response.token_id = 'token_id';
            response.payer.email_address = 'test@gmail.com';
            response.payer.payer_info = 'payer_info';
            response.purchase_units = 'purchase_units';
            response.shipping_address = 'Test Address';
        });

        after(() => {
            paymentInstrument.custom.paypalOrderID = null;
            paypalPreferences.isCapture = true;
            makeResponseDefault();
        });

        it('if paymentInstrument has not paypalOrderID', () => {
            createErrorMsg.returns('paypal.error.api_order_id_notfound');
            paymentInstrument.custom.paypalOrderID = null;

            expect(paypalApi.createTransaction(paymentInstrument, bodyObj)).to.be.deep.equal({
                err: 'paypal.error.api_order_id_notfound'
            });
        });

        it('if paymentInstrument has paypalOrderID and isCapture is true', () => {
            expect(paypalApi.createTransaction(paymentInstrument, bodyObj)).to.be.deep.equal({
                response: response
            });
        });

        it('if paymentInstrument has paypalOrderID and isCapture is false', () => {
            paypalPreferences.isCapture = false;

            expect(paypalApi.createTransaction(paymentInstrument, bodyObj)).to.be.deep.equal({
                response: response
            });
        });

        it('if paymentInstrument has paypalOrderID, but it is without bodyObj', () => {
            expect(paypalApi.createTransaction(paymentInstrument)).to.be.deep.equal({
                response: response
            });
        });
    });

    describe('getBillingAgreementToken', () => {
        beforeEach(() => {
            paypalRestService.call = () => response;
        });

        it('if there is no response', () => {
            createErrorMsg.returns('No billing agreement-tokens was found');
            paypalRestService.call = () => null;

            expect(paypalApi.getBillingAgreementToken()).to.be.deep.equal({
                err: 'No billing agreement-tokens was found'
            });
        });

        it('if there is response', () => {
            response.token_id = 'token_id';

            expect(paypalApi.getBillingAgreementToken()).to.be.deep.equal({
                billingAgreementToken: 'token_id'
            });
        });
    });

    describe('createBillingAgreement', () => {
        const billingToken = 'billingToken';

        beforeEach(() => {
            paypalRestService.call = () => response;
            response.id = 1;
            response.state = 'ACTIVE';
            response.token_id = 'token_id';
            response.payer.email_address = 'test@gmail.com';
            response.purchase_units = 'purchase_units';
        });

        after(() => {
            makeResponseDefault();
        });

        it('if there is no billingToken', () => {
            createErrorMsg.returns('No billing Token provided');

            expect(paypalApi.createBillingAgreement()).to.be.deep.equal({
                err: 'No billing Token provided'
            });
        });

        it('if there is billingToken and response', () => {
            expect(paypalApi.createBillingAgreement(billingToken)).to.be.deep.equal(response);
        });

        it('if there is billingToken and no response', () => {
            paypalRestService.call = () => null;
            createErrorMsg.returns('No billing agreement ID was found');

            expect(paypalApi.createBillingAgreement(billingToken)).to.be.deep.equal({
                err: 'No billing agreement ID was found'
            });
        });
    });

    describe('createOrder', () => {
        beforeEach(() => {
            paypalRestService.call = () => response;
            paypalPreferences.isCapture = true;
            response.id = 1;
            response.state = 'ACTIVE';
            response.token_id = 'token_id';
            response.payer.email_address = 'test@gmail.com';
            response.purchase_units = 'purchase_units';
        });

        after(() => {
            makeResponseDefault();
        });

        it('if there is no purchaseUnit', () => {
            createErrorMsg.returns('No purchaseUnit was found');

            expect(paypalApi.createOrder()).to.be.deep.equal({
                err: 'No purchaseUnit was found'
            });
        });

        it('if there is purchaseUnit, response and isCapture is true', () => {
            expect(paypalApi.createOrder(purchaseUnit)).to.be.deep.equal({
                resp: response
            });
        });

        it('if there is purchaseUnit, response and isCapture is false', () => {
            paypalPreferences.isCapture = false;

            expect(paypalApi.createOrder(purchaseUnit)).to.be.deep.equal({
                resp: response
            });
        });

        const lineItemCtnr = {
            billingAddress: {
                phone: '01123456789',
                countryCode: 'US',
                customerEmail: 'test@test.com'
            }
        };

        it('if there is purchaseUnit and lineItemCtnr.billingAddress', () => {
            expect(paypalApi.createOrder(purchaseUnit, lineItemCtnr)).to.be.deep.equal({
                resp: response
            });
        });
    });

    describe('getBADetails', () => {
        beforeEach(() => {
            paypalRestService.call = () => response;
            paymentInstrument.custom.PP_API_ActiveBillingAgreement = '{"result":true}';
            response.id = 1;
            response.state = 'ACTIVE';
            response.token_id = 'token_id';
            response.payer.email_address = 'test@gmail.com';
            response.purchase_units = 'purchase_units';
            response.payer.payer_info = 'payer_info';
        });

        after(() => {
            paymentInstrument.custom.PP_API_ActiveBillingAgreement = '';
            makeResponseDefault();
        });

        it('if PP_API_ActiveBillingAgreement is not activated', () => {
            paymentInstrument.custom.PP_API_ActiveBillingAgreement = null;
            createErrorMsg.returns('No active billing agreement was found');

            expect(paypalApi.getBADetails(paymentInstrument)).to.be.deep.equal({
                err: 'No active billing agreement was found'
            });
        });

        it('if can not parse PP_API_ActiveBillingAgreement ', () => {
            paymentInstrument.custom.PP_API_ActiveBillingAgreement = 'notJSON';

            expect(paypalApi.getBADetails(paymentInstrument)).to.be.deep.equal(new Error(SyntaxError));
        });

        it('if there is normal response', () => {
            expect(paypalApi.getBADetails(paymentInstrument)).to.be.deep.equal({
                id: response.id,
                billing_info: response.payer.payer_info,
                shipping_address: response.shipping_address,
                active: true
            });
        });

        it('if response state in not ACTIVE', () => {
            response.state = 'INACTIVE';

            expect(paypalApi.getBADetails(paymentInstrument)).to.be.deep.equal({
                active: false
            });
        });
    });

    describe('getBADetailsById', () => {
        beforeEach(() => {
            paypalRestService.call = () => response;
            response.id = 1;
            response.state = 'ACTIVE';
            response.token_id = 'token_id';
            response.payer.email_address = 'test@gmail.com';
            response.purchase_units = 'purchase_units';
            response.payer.payer_info = 'payer_info';
        });

        after(() => {
            makeResponseDefault();
        });

        it('if server call is successful', () => {
            expect(paypalApi.getBADetailsById('baID')).to.be.deep.equal(response);
        });

        it('if server call is unsuccessful', () => {
            paypalRestService.call = () => {
                throw new Error('error');
            };

            expect(paypalApi.getBADetailsById('baID')).to.be.deep.equal({ err: 'No active billing agreement was found' });
        });
    });

    describe('cancelBillingAgreement', () => {
        beforeEach(() => {
            paypalRestService.call = () => response;
            paypalPreferences.isCapture = true;
            paymentInstrument.custom.PP_API_ActiveBillingAgreement = '{"result":true}';
            response.id = 1;
            response.state = 'ACTIVE';
            response.token_id = 'token_id';
            response.payer.email_address = 'test@gmail.com';
            response.purchase_units = 'purchase_units';
            response.payer.payer_info = 'payer_info';
        });

        after(() => {
            paymentInstrument.custom.PP_API_ActiveBillingAgreement = '';
            makeResponseDefault();
        });

        it('if there is not baID', () => {
            createErrorMsg.returns('No billing agreement ID provided');

            expect(paypalApi.cancelBillingAgreement()).to.be.deep.equal({
                err: 'No billing agreement ID provided'
            });
        });

        it('if there is baID', () => {
            const baID = 'baID';

            createErrorMsg.returns('No billing agreement ID provided');

            expect(paypalApi.cancelBillingAgreement(baID)).to.be.deep.equal(response);
        });
    });

    describe('cancelBillingAgreement', () => {
        beforeEach(() => {
            paypalRestService.call = () => ({ status: 'OK' });
        });

        after(() => {
            paypalRestService.call = () => response;
        });

        it('if there is not baID', () => {
            createErrorMsg.returns('No billing agreement ID provided');

            expect(paypalApi.cancelBillingAgreement()).to.be.deep.equal({
                err: 'No billing agreement ID provided'
            });
        });

        it('if there is baID', () => {
            const baID = 'baID';

            createErrorMsg.returns('No billing agreement ID provided');

            expect(paypalApi.cancelBillingAgreement(baID)).to.be.deep.equal({ status: 'OK' });
        });
    });

    describe('exchangeAuthCodeForAccessToken', () => {
        after(() => {
            paypalTokenService.setThrowOnError = () => ({
                call: () => ({
                    ok: true,
                    object: {
                        access_token: 'access_token'
                    }
                })
            });
        });

        it('if result is OK', () => {
            expect(paypalApi.exchangeAuthCodeForAccessToken()).to.be.deep.equal('access_token');
        });

        it('if result is not OK', () => {
            paypalTokenService.setThrowOnError = () => ({ call: () => ({ ok: false, errorMessage: '{"error_description": "response error"}' }) });

            expect(() => paypalApi.exchangeAuthCodeForAccessToken()).to.throw('response error');
        });
    });

    describe('getPaypalCustomerInfo', () => {
        after(() => {
            paypalTokenService.setThrowOnError = () => ({
                call: () => ({
                    ok: true,
                    object: {
                        access_token: 'access_token'
                    }
                })
            });

            response.emails = null;
            response.name = null;
            response.address = null;
        });

        it('if result is OK', () => {
            response.emails = [{ value: 'test@test.com', primary: true, confirmed: true }];
            response.name = 'TestName';
            response.address = 'TestAddress';

            paypalTokenService.setThrowOnError = () => ({
                call: () => ({
                    isOk: () => true,
                    object: response
                })
            });

            expect(paypalApi.getPaypalCustomerInfo('accessToken')).to.be.deep.equal(response);
        });

        it('if result is not OK', () => {
            paypalTokenService.setThrowOnError = () => ({
                call: () => ({
                    isOk: () => false
                })
            });

            expect(paypalApi.getPaypalCustomerInfo('accessToken')).to.be.null;
        });
    });
});
