const { int_paypal: { paypalPath } } = require('../path.json');

const { expect } = require('chai');
const { it, describe, beforeEach } = require('mocha');
const { stub } = require('sinon');

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const proxyquire = require('proxyquire').noCallThru();

const createErrorLog = stub();
const handle = stub();
const authorize = stub();

const form = {};

const paypal = proxyquire(paypalPath, {
    'dw/order/OrderMgr': dw.order.OrderMgr,
    '*/cartridge/config/paypalPreferences': {
        paypalPaymentMethodId: 'paypal'
    },
    '*/cartridge/scripts/paypal/paypalUtils': {
        createErrorLog
    },
    '*/cartridge/scripts/paypal/processor': {
        handle,
        authorize
    }
});

describe('paypal file', () => {
    describe('processForm', () => {
        const viewData = {};

        it('must return viewData', () => {
            expect(paypal.processForm({}, form, viewData)).to.be.deep.equal({
                viewData: {
                    paymentInformation: {
                        billingForm: {
                            paymentMethod: {
                                htmlName: 'paypal',
                                value: 'paypal'
                            }
                        }
                    },
                    paymentMethod: {
                        htmlName: 'paypal',
                        value: 'paypal'
                    }
                }
            });
        });
    });

    describe('Handle', () => {
        it('must return object with details', () => {
            handle.returns({
                success: true,
                paymentInstrument: 'paymentInstrument',
                shippingAddress: 'shippingAddress'
            });

            expect(paypal.Handle({}, form)).to.be.deep.equal({
                success: true,
                paymentInstrument: 'paymentInstrument',
                shippingAddress: 'shippingAddress'
            });
        });
    });

    describe('Authorize', () => {
        it('must return object with authorized status', () => {
            dw.order.OrderMgr.createOrderSequenceNo = () => {};
            authorize.returns({
                authorized: true
            });

            expect(paypal.Authorize({}, form)).to.be.deep.equal({
                authorized: true
            });
        });
    });

    describe('createOrderNo', () => {
        before(() => {
            session = {
                privacy: {
                    paypalUsedOrderNo: ''
                }
            };
        });

        beforeEach(() => {
            dw.order.OrderMgr.createOrderSequenceNo = () => 'orderNo';
        });

        it('if there is no paypalUsedOrderNo', () => {
            expect(paypal.createOrderNo()).to.be.equal('orderNo');
        });

        it('if order is not exist', () => {
            session.privacy.paypalUsedOrderNo = 'paypalUsedOrderNo';
            dw.order.OrderMgr.getOrder = () => 'order';

            expect(paypal.createOrderNo()).to.be.equal('orderNo');
        });

        it('If an error occurs', () => {
            dw.order.OrderMgr.getOrder = () => {
                throw (new Error());
            };

            expect(paypal.createOrderNo()).to.be.equal('orderNo');
        });
    });
});
