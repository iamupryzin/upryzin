const { int_paypal: { paypalRestServicePath } } = require('../path.json');

const { expect } = require('chai');
const {
    it, describe, beforeEach, afterEach
} = require('mocha');

const { stub } = require('sinon');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const get = stub();
const put = stub();

const ServiceCredential = () => {};
let status = true;

const LocalServiceRegistry = {
    createService: (name, obj) => ({
        call: () => ({
            isOk: () => status,
            object: {
                createRequest: obj.createRequest,
                parseResponse: obj.parseResponse,
                filterLogMessage: obj.filterLogMessage,
                getRequestLogMessage: obj.getRequestLogMessage,
                getResponseLogMessage: obj.getResponseLogMessage
            }
        })
    })
};

const dependencies = {
    'int_paypal.http.rest': 'serviceName',
    'dw/svc/ServiceCredential': ServiceCredential,
    'dw/svc/LocalServiceRegistry': LocalServiceRegistry,
    'dw/web/Resource': {
        msgf: () => {}
    },
    'dw/system/CacheMgr': {
        getCache: () => ({
            get,
            put
        })
    },
    '*/cartridge/scripts/paypal/paypalUtils': {
        createErrorLog: () => {}
    },
    '*/cartridge/scripts/paypal/helpers/paypalHelper': {
        getUrlPath: () => {}
    }
};

const paypalRestService = proxyquire(paypalRestServicePath, dependencies);

describe('paypalRestService file', () => {
    const resService = paypalRestService.call();

    it('if can not create service instance', () => {
        LocalServiceRegistry.createService = () => {
            throw new Error();
        };

        expect(() => proxyquire(paypalRestServicePath, dependencies)).to.throw();
    });

    it('if result is not Ok', () => {
        status = false;

        expect(() => paypalRestService.call()).to.throw();
    });

    describe('parseResponse', () => {
        it('should parse', () => {
            expect(resService.parseResponse({}, { getText: () => '{"prop": "value"}' })).to.be.deep.equal({ prop: 'value' });
        });
    });

    describe('filterLogMessage', () => {
        it('should retrun message', () => {
            expect(resService.filterLogMessage('msg')).to.be.equal('msg');
        });
    });

    describe('getRequestLogMessage', () => {
        it('should retrun request', () => {
            expect(resService.getRequestLogMessage('request')).to.be.equal('request');
        });
    });

    describe('getResponseLogMessage', () => {
        it('should retrun request', () => {
            expect(resService.getResponseLogMessage({ text: 'response' })).to.be.equal('response');
        });
    });

    describe('createRequest', () => {
        const reqService = {
            configuration: {
                credential: new ServiceCredential()
            },
            setURL: () => {},
            setRequestMethod: () => {},
            addHeader: () => {}
        };

        const reqData = {
            setRequestMethod: () => {},
            setURL: () => {},
            path: '',
            method: '',
            body: '',
            createToken: '',
            partnerAttributionId: ''
        };

        beforeEach(() => {
            reqService.configuration.credential = new ServiceCredential();
        });

        afterEach(() => {
            reqData.partnerAttributionId = '';
            reqData.createToken = '';
            get.returns('');
            status = true;
        });

        it('should throw an error while credentials is not instanceof ServiceCredential', () => {
            reqService.configuration.credential = {};
            reqData.createToken = 'createToken';

            expect(() => resService.createRequest(reqService, reqData)).to.throw();
        });

        it('must return empty string if there is createToken', () => {
            reqData.createToken = 'createToken';

            expect(resService.createRequest(reqService, reqData)).to.be.equal('');
        });

        it('if there is bearerToken and partnerAttributionId', () => {
            reqData.partnerAttributionId = 'partnerAttributionId';
            get.returns('bearerToken');

            expect(resService.createRequest(reqService, reqData)).to.be.equal('');
        });

        it('if there is bearerToken and body', () => {
            reqData.body = {
                key: 'value'
            };
            get.returns('bearerToken');

            expect(resService.createRequest(reqService, reqData)).to.be.equal('{"key":"value"}');
        });
    });

    describe('getToken', () => {
        // eslint-disable-next-line no-underscore-dangle
        const getToken = paypalRestService.__get__('getToken');

        const reqService = {
            setThrowOnError: () => ({
                call: () => {}
            }),
            response: {}
        };

        afterEach(() => {
            get.returns('');
            reqService.response = {};
        });

        it('if there is bearerToken', () => {
            get.returns('bearerToken');

            expect(getToken(reqService)).to.be.equal('Bearer bearerToken');
        });

        it('if there is access_token ', () => {
            reqService.response.access_token = 'access_token';
            put.returns('access_token');

            expect(getToken(reqService)).to.be.equal('Bearer access_token');
        });

        it('if there is error_description', () => {
            reqService.response.error_description = 'error_description';

            expect(() => getToken(reqService)).to.throw('error_description');
        });

        it('if there is error without any description', () => {
            expect(() => getToken(reqService)).to.throw('Unknown error occurred');
        });
    });

    describe('errorHandler', () => {
        // eslint-disable-next-line no-underscore-dangle
        const errorHandler = paypalRestService.__get__('errorHandler');

        const errorResponse = {
            configuration: {
                credential: {}
            }
        };

        const requestData = {};

        it('if there is no errorMessage', () => {
            expect(() => errorHandler(errorResponse, requestData)).to.throw(Error);
        });

        it('if error has details', () => {
            errorResponse.errorMessage = '{"name" : "name", "message": "message", "details": [{"issue" : "issue", "description" : "description"}]}';

            expect(() => errorHandler(errorResponse, requestData)).to.throw('issue');
        });

        it('if error has not details', () => {
            errorResponse.errorMessage = '{"name" : "name", "message": "message"}';

            expect(() => errorHandler(errorResponse, requestData)).to.throw('name');
        });

        it('if errorName is invalid_client', () => {
            errorResponse.errorMessage = '{"error":"invalid_client", "description":"error description"}';
            errorResponse.configuration.credential.ID = 'credentialID';

            expect(() => errorHandler(errorResponse, requestData)).to.throw('invalid_client');
        });

        it('if errorName is not invalid_client', () => {
            errorResponse.errorMessage = '{"error":"unknown_error", "description":"error description"}';

            expect(() => errorHandler(errorResponse, requestData)).to.throw('unknown_error');
        });
    });
});
