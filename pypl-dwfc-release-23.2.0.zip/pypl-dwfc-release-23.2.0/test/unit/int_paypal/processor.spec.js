/* eslint-disable no-underscore-dangle */
const { int_paypal: { processorPath } } = require('../path.json');

const { expect } = require('chai');
const { stub } = require('sinon');
const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const createPaymentInstrument = stub();
const getPaypalPaymentInstrument = stub();
const isSameBillingAgreement = stub();
const createBaFromForm = stub();
const getPurchaseUnit = stub();
const isPurchaseUnitChanged = stub();
const createErrorLog = stub();
const handleError = stub();
const encodeString = stub();
const updateBillingInfoIfAccountChanged = stub();
const updateOrderBillingAddress = stub();
const updateBABillingAddress = stub();
const validateCheckoutOrdersPaypalAddresses = stub();
const validateBaPaypalAddresses = stub();
const getOrderDetails = stub();
const getBADetails = stub();
const updateOrderDetails = stub();
const createTransaction = stub();
const createOrder = stub();
const getTransactionId = stub();
const getTransactionStatus = stub();
const prepareTransactionHistory = stub();

const DEBIT_CREDIT_CARD_ID = 'PayPal Debit/Credit Card';

request.httpReferer = 'https://dx.commercecloud.salesforce.com/on/demandware.store/Sites-RefArch-Site/en_US/Cart-Show';

const processor = proxyquire(processorPath, {
    'dw/order/Order': dw.order.Order,
    'dw/system/Transaction': dw.system.Transaction,
    'dw/web/Resource': dw.web.Resource,
    '*/cartridge/scripts/paypal/helpers/paymentInstrumentHelper': { createPaymentInstrument, getPaypalPaymentInstrument },
    '*/cartridge/scripts/paypal/helpers/billingAgreementHelper': { createBaFromForm, isSameBillingAgreement },
    '*/cartridge/scripts/paypal/helpers/paypalHelper': {
        getPurchaseUnit,
        isPurchaseUnitChanged,
        getTransactionId,
        getTransactionStatus,
        prepareTransactionHistory,
        updateBillingInfoIfAccountChanged
    },
    '*/cartridge/scripts/paypal/paypalUtils': {
        createErrorLog,
        encodeString,
        handleError
    },
    '*/cartridge/scripts/paypal/helpers/addressHelper': {
        updateOrderBillingAddress,
        updateBABillingAddress,
        validateCheckoutOrdersPaypalAddresses,
        validateBaPaypalAddresses
    },
    '*/cartridge/scripts/paypal/paypalApi': {
        getOrderDetails,
        getBADetails,
        updateOrderDetails,
        createTransaction,
        createOrder
    },
    '*/cartridge/config/paypalConstants': {
        PAYMENT_METHOD_ID_VENMO: 'venmo',
        PAYMENT_METHOD_ID_Debit_Credit_Card: DEBIT_CREDIT_CARD_ID,
        PAYMENT_METHOD_ID_PAYPAL: 'PayPal'
    },
    '*/cartridge/scripts/util/collections': {
        forEach: () => {}
    }
});

describe('processor file', () => {
    describe('handle', () => {
        before(() => {
            stub(dw.web.Resource, 'msg');
            dw.web.Resource.msg.returns('Some server error');
            validateCheckoutOrdersPaypalAddresses.returns({ error: false });
            validateBaPaypalAddresses.returns({ error: false });
            session = {
                privacy: {
                    paypalPayerEmail: ''

                }
            };
        });

        after(() => {
            dw.web.Resource.msg.restore();
            validateCheckoutOrdersPaypalAddresses.reset();
            validateBaPaypalAddresses.reset();
        });

        afterEach(() => {
            createErrorLog.reset();
        });

        let paymentInformation = {
            billingForm: {
                paypal: {
                    billingAgreementID: {
                        maxLength: 2147483647,
                        minLength: 0,
                        regEx: null,
                        valid: true
                    },
                    paypalOrderID: {},
                    usedPaymentMethod: {}
                },
                paymentMethod: {
                    htmlName: 'PayPal',
                    value: 'PayPal'
                }
            }
        };

        let payer = {
            address: {},
            email_address: 'I.VinogradovVN@gmail.com',
            name: {},
            payer_id: 'QMG34HJTGX6NU',
            phone_number: {
                national_number: '4084607119',
                phone_type: 'HOME'
            }
        };

        let purchase_units = [{
            amount: {},
            description: 'Casual Spring Easy Jacket',
            invoice_id: '00003402',
            payee: {
                email_address: 'user@business.example.com',
                merchant_id: 'BZKDAFFRXNJ7G'
            }
        }];

        let basket = {};

        it('handle function returns an expected object if isBillingAgreementID is false', () => {
            paymentInformation.billingForm.paypal.usedPaymentMethod.value = 'venmo';
            createPaymentInstrument.returns({
                paymentMethod: 'PayPal',
                UUID: 'ee6d20764050743b97cab7e8f6',
                custom: {
                    paypalOrderID: '8UU486582S253361B'
                }
            });
            getOrderDetails.returns({
                payer,
                purchase_units

            });
            let expectedObj = {
                success: true,
                paymentInstrument: {
                    paymentMethod: 'PayPal',
                    UUID: 'ee6d20764050743b97cab7e8f6',
                    custom:
                    {
                        paypalOrderID: undefined,
                        currentPaypalEmail: 'I.VinogradovVN@gmail.com',
                        paymentId: 'venmo'
                    }
                },
                shippingAddress: {
                    amount: {},
                    description: 'Casual Spring Easy Jacket',
                    invoice_id: '00003402',
                    payee:
                    {
                        email_address: 'user@business.example.com',
                        merchant_id: 'BZKDAFFRXNJ7G'
                    },
                    phone: undefined
                }
            };

            expect(processor.handle(basket, paymentInformation)).to.deep.equal(expectedObj);
        });

        it('handle function returns an expected object if isBillingAgreementID is false', () => {
            paymentInformation.billingForm.paypal.usedPaymentMethod.value = DEBIT_CREDIT_CARD_ID;
            createPaymentInstrument.returns({
                paymentMethod: 'PayPal',
                UUID: 'ee6d20764050743b97cab7e8f6',
                custom: {
                    paypalOrderID: '8UU486582S253361B'
                }
            });
            getOrderDetails.returns({
                payer,
                purchase_units

            });
            let expectedObj = {
                success: true,
                paymentInstrument: {
                    paymentMethod: 'PayPal',
                    UUID: 'ee6d20764050743b97cab7e8f6',
                    custom:
                    {
                        paypalOrderID: undefined,
                        currentPaypalEmail: 'I.VinogradovVN@gmail.com',
                        paymentId: DEBIT_CREDIT_CARD_ID
                    }
                },
                shippingAddress: {
                    amount: {},
                    description: 'Casual Spring Easy Jacket',
                    invoice_id: '00003402',
                    payee:
                    {
                        email_address: 'user@business.example.com',
                        merchant_id: 'BZKDAFFRXNJ7G'
                    },
                    phone: undefined
                }
            };

            expect(processor.handle(basket, paymentInformation)).to.deep.equal(expectedObj);
        });

        it('handle function returns an error object if isBillingAgreementID is false and OrderDetailsError isn\'t empty', () => {
            createPaymentInstrument.returns({
                paymentMethod: 'PayPal',
                UUID: 'ee6d20764050743b97cab7e8f6',
                custom: {
                    paypalOrderID: '8UU486582S253361B'
                }
            });
            getOrderDetails.returns({
                payer,
                purchase_units,
                err: {}
            });

            expect(processor.handle(basket, paymentInformation)).to.deep.equal({
                error: true,
                fieldErrors: [],
                serverErrors: ['Some server error']
            });
        });

        it('handle function returns an error object if isBillingAgreementID is try', () => {
            paymentInformation.billingForm.paypal.billingAgreementID.htmlValue = 'B-73122468JR707841D';
            createPaymentInstrument.returns({
                paymentMethod: 'PayPal',
                UUID: 'ee6d20764050743b97cab7e8f6',
                custom: {
                    paypalOrderID: '8UU486582S253361B'
                }
            });
            createBaFromForm.returns({
                baID: 'B-73122468JR707841D',
                default: true,
                email: 'I.VinogradovVN@gmail.com',
                saveToProfile: true
            });
            let shipping_address = {
                city: 'Servierville',
                country_code: 'US',
                line1: '473 Wiseman Street',
                phone: '408-922-3384',
                postal_code: '37862',
                recipient_name: 'Joy Gray',
                state: 'TN'
            };

            let billing_info = {
                billing_address: {
                    city: 'Pond',
                    country_code: 'US',
                    line1: '4866 Rodney Street',
                    postal_code: '63040',
                    state: 'MO'
                },
                email: 'I.VinogradovVN@gmail.com',
                first_name: 'Ivan',
                last_name: 'C Vinogradov',
                payer_id: 'QMG34HJTGX6NU',
                phone: '408-922-3384'
            };

            getBADetails.returns({
                shipping_address,
                billing_info
            });
            let result = {
                success: true,
                paymentInstrument: {
                    paymentMethod: 'PayPal',
                    UUID: 'ee6d20764050743b97cab7e8f6',
                    custom:
                    {
                        paypalOrderID: '8UU486582S253361B',
                        currentPaypalEmail: 'I.VinogradovVN@gmail.com',
                        PP_API_ActiveBillingAgreement:
                            '{"baID":"B-73122468JR707841D","default":true,"email":"I.VinogradovVN@gmail.com","saveToProfile":true}'
                    }
                },
                shippingAddress: {
                    city: 'Servierville',
                    country_code: 'US',
                    line1: '473 Wiseman Street',
                    phone: '408-922-3384',
                    postal_code: '37862',
                    recipient_name: 'Joy Gray',
                    state: 'TN'
                }
            };

            expect(processor.handle(basket, paymentInformation)).to.deep.equal(result);
        });

        it('If error appeared while getting BA details', () => {
            paymentInformation.billingForm.paypal.billingAgreementID.htmlValue = 'B-73122468JR707841D';
            createPaymentInstrument.returns({
                paymentMethod: 'PayPal',
                UUID: 'ee6d20764050743b97cab7e8f6',
                custom: {
                    paypalOrderID: '8UU486582S253361B'
                }
            });
            createBaFromForm.returns({
                baID: 'B-73122468JR707841D',
                default: true,
                email: 'I.VinogradovVN@gmail.com',
                saveToProfile: true
            });
            getBADetails.returns({ err: 'Error' });

            const result = processor.handle(basket, paymentInformation);

            expect(result).to.be.an('object');
            expect(result.error).to.be.true;
            expect(createErrorLog.calledOnce).to.be.true;
        });

        it('handle function returns an object, isBillingAgreementID is true and shipping address is empty', () => {
            paymentInformation.billingForm.paypal.billingAgreementID.htmlValue = 'B-73122468JR707841D';
            createPaymentInstrument.returns({
                paymentMethod: 'PayPal',
                UUID: 'ee6d20764050743b97cab7e8f6',
                custom: {
                    paypalOrderID: '8UU486582S253361B'
                }
            });
            createBaFromForm.returns({
                baID: 'B-73122468JR707841D',
                default: true,
                email: 'I.VinogradovVN@gmail.com',
                saveToProfile: true
            });
            let billing_info = {
                billing_address: {
                    city: 'Pond',
                    country_code: 'US',
                    line1: '4866 Rodney Street',
                    postal_code: '63040',
                    state: 'MO'
                },
                email: 'I.VinogradovVN@gmail.com',
                first_name: 'Ivan',
                last_name: 'C Vinogradov',
                payer_id: 'QMG34HJTGX6NU',
                phone: '408-922-3384'
            };

            getBADetails.returns({
                billing_info
            });
            let result = {
                success: true,
                paymentInstrument: {
                    paymentMethod: 'PayPal',
                    UUID: 'ee6d20764050743b97cab7e8f6',
                    custom:
                    {
                        paypalOrderID: '8UU486582S253361B',
                        currentPaypalEmail: 'I.VinogradovVN@gmail.com',
                        PP_API_ActiveBillingAgreement:
                            '{"baID":"B-73122468JR707841D","default":true,"email":"I.VinogradovVN@gmail.com","saveToProfile":true}'
                    }
                },
                shippingAddress: {
                    city: 'Pond',
                    country_code: 'US',
                    line1: '4866 Rodney Street',
                    postal_code: '63040',
                    state: 'MO',
                    recipient_name: 'Ivan C Vinogradov',
                    phone: '408-922-3384'
                }
            };

            expect(processor.handle(basket, paymentInformation)).to.deep.equal(result);
        });

        describe('validation for shipping or billing addresses', () => {
            const validationResult = {
                error: true,
                errorName: 'shipping.address.invalid',
                fields: { country: 'Invalid field' },
                message: 'Shipping address validation is failure'
            };

            const result = {
                error: true,
                errorName: 'shipping.address.invalid',
                statusCode: 422,
                fieldErrors: [{ country: 'Invalid field' }],
                serverErrors: ['Shipping address validation is failure']
            };

            before(() => {
                validateCheckoutOrdersPaypalAddresses.returns(validationResult);
                validateBaPaypalAddresses.returns(validationResult);
            });

            after(() => {
                validateCheckoutOrdersPaypalAddresses.reset();
                validateBaPaypalAddresses.reset();
            });

            it('if validation for shipping or billing addresses is failed (isBillingAgreementID true)', () => {
                const val = processor.handle(basket, paymentInformation);

                expect(val).to.be.an('object').and.deep.equal(result);
            });

            it('if validation for shipping or billing addresses is failed (isBillingAgreementID false)', () => {
                paymentInformation.billingForm.paypal.billingAgreementID.htmlValue = '';

                getOrderDetails.returns({
                    payer,
                    purchase_units
                });

                const val = processor.handle(basket, paymentInformation);

                expect(val).to.be.an('object').and.deep.equal(result);
            });
        });
    });

    describe('authorize', () => {
        let purchaseUnit = {
            amount: {},
            description: 'Long Sleeve Crew Neck',
            invoice_id: '00003603',
            shipping: {}
        };

        let order = {};
        let paymentInstrument = {};

        isPurchaseUnitChanged.returns(true);
        getPurchaseUnit.returns(purchaseUnit);

        before(() => {
            stub(dw.web.Resource, 'msg');

            processor.__set__('createBAReqBody', () => {
                return {
                    payment_source: {
                        token: {
                            id: 'B-7J122468JR707841D',
                            type: 'BILLING_AGREEMENT'
                        }
                    }
                };
            });
            processor.__set__('getTransactionId', () => {
                return '7ML06956NU4656408';
            });
            processor.__set__('getTransactionStatus', () => {
                return 'COMPLETED';
            });
            processor.__set__('prepareTransactionHistory', () => {
                return [];
            });
        });

        after(() => {
            dw.web.Resource.msg.restore();

            processor.__ResetDependency__('createBAReqBody');
            processor.__ResetDependency__('getTransactionId');
            processor.__ResetDependency__('getTransactionStatus');
            processor.__ResetDependency__('prepareTransactionHistory');
        });

        afterEach(() => {
            createErrorLog.reset();
            updateOrderDetails.reset();
            createOrder.reset();
            createTransaction.reset();
        });

        it('should return object {error: true} if paymentInstrument or order is empty ', () => {
            dw.web.Resource.msg.returns('Some server error');
            expect(processor.authorize(order, paymentInstrument)).to.deep.equal({
                error: true,
                fieldErrors: [],
                serverErrors: ['Some server error']
            });
        });

        it('should return object {error: true} if paymentInstrument.paymentTransaction.amount.value is 0', () => {
            dw.web.Resource.msg.returns('Some server error');
            let paymentInstrument2 = { paymentTransaction: { amount: { value: 0 } } };
            let order2 = {
                status: {
                    displayValue: 'CREATED',
                    value: 0
                }
            };

            expect(processor.authorize(order2, paymentInstrument2)).to.deep.equal({
                error: true,
                fieldErrors: [],
                serverErrors: ['Some server error']
            });
        });

        it('shoud return {authorized: true} if BA is active', () => {
            let paymentInstrument3 = {
                paymentTransaction: { amount: { value: 47.23 }, custom: {} },
                custom: {
                    currentPayPalEmail: 'I.VinogradovVN@gmail.com',
                    PP_API_ActiveBillingAgreement: '{"baID":"B-73122468JR707841D","default":true,"email":"I.VinogradovVN@gmail.com","saveToProfile":true}'
                },
                getPaymentTransaction: () => {
                    return { setTransactionID: () => { } };
                }

            };

            let order3 = {
                createdBy: 'Customer',
                currencyCode: 'USD',
                currentOrderNo: '00003605',
                customerEmail: 'I.VinogradovVN@gmail.com',
                customerLocaleID: 'en_US',
                customerName: 'Ivan C Vinofradov',
                status: {
                    displayValue: 'CREATED',
                    value: 0
                },
                custom: {}
            };

            let resp = {
                id: '7ML06956NU4656408',
                links: [
                    {
                        href: 'https://api.sandbox.paypal.com/v2/checkout/orders/7ML06956NU4656408',
                        method: 'GET',
                        rel: 'self'
                    },
                    {
                        href: 'https://www.sandbox.paypal.com/checkoutnow?token=7ML06956NU4656408',
                        method: 'GET',
                        rel: 'approve'
                    },
                    {
                        href: 'https://api.sandbox.paypal.com/v2/checkout/orders/7ML06956NU4656408',
                        method: 'PATCH',
                        rel: 'update'
                    },
                    {
                        href: 'https://api.sandbox.paypal.com/v2/checkout/orders/7ML06956NU4656408',
                        method: 'POST',
                        rel: 'authorize'
                    }
                ],
                status: 'CREATED'
            };

            createOrder.returns({ resp });
            createTransaction.returns({
                id: '7ML06956NU4656408',
                links: [],
                payer: {},
                purchase_units: [{
                    payments: [],
                    reference_id: 'default',
                    shipping: []
                }],
                status: 'COMPLETED'
            });

            expect(processor.authorize(order3, paymentInstrument3)).to.deep.equal({ authorized: true });
        });

        it('If on order details update error was thrown', () => {
            const paymentInstrument4 = {
                custom: { paypalOrderID: 'id' },
                paymentTransaction: {
                    amount: { value: 100 }
                }
            };

            const order4 = { status: 'AUTHORIZED' };

            updateOrderDetails.returns({ err: 'updateOrderDetailsError' });

            const result = processor.authorize(order4, paymentInstrument4);

            expect(result).to.be.an('object');
            expect(result.message).to.equal('updateOrderDetailsError');
            expect(createErrorLog.calledOnce).to.be.true;
        });

        it('If order details were successfully updated', () => {
            const paymentInstrument4 = {
                custom: { paypalOrderID: 'id' },
                paymentTransaction: {
                    custom: {},
                    amount: { value: 100 }
                },
                getPaymentTransaction: () => {
                    return { setTransactionID: () => { } };
                }
            };

            const order4 = {
                status: 'AUTHORIZED',
                custom: {}
            };

            updateOrderDetails.returns({});

            const result = processor.authorize(order4, paymentInstrument4);

            expect(result).to.be.an('object');
            expect(result.authorized).to.be.true;
            expect(createErrorLog.calledOnce).to.be.false;
        });

        it('If on order creation error was thrown', () => {
            const paymentInstrument5 = {
                custom: {
                    paypalOrderID: 'id',
                    PP_API_ActiveBillingAgreement: true
                },
                paymentTransaction: {
                    amount: { value: 100 }
                }
            };

            const order5 = { status: 'AUTHORIZED' };

            createOrder.returns({ err: 'createOrder' });

            const result = processor.authorize(order5, paymentInstrument5);

            expect(result).to.be.an('object');
            expect(result.error).to.be.true;
            expect(result.message).to.equal('createOrder');
            expect(createErrorLog.calledOnce).to.be.true;
        });

        it('If on BA req body creation error was thrown', () => {
            const paymentInstrument5 = {
                custom: {
                    paypalOrderID: 'id',
                    PP_API_ActiveBillingAgreement: true
                },
                paymentTransaction: {
                    amount: { value: 100 }
                }
            };

            const order5 = { status: 'AUTHORIZED' };

            createOrder.returns({ resp: { id: 'id' }, err: false });
            processor.__set__('createBAReqBody', () => {
                throw Error;
            });

            const result = processor.authorize(order5, paymentInstrument5);

            expect(result).to.be.an('object');
            expect(result.error).to.be.true;
            expect(createErrorLog.calledOnce).to.be.true;

            processor.__ResetDependency__('createBAReqBody');
        });

        it('If on transaction creation error was thrown', () => {
            const paymentInstrument5 = {
                custom: {
                    paypalOrderID: 'id',
                    PP_API_ActiveBillingAgreement: false
                },
                paymentTransaction: {
                    amount: { value: 100 }
                }
            };

            const order5 = { status: 'AUTHORIZED', custom: {} };

            createTransaction.returns({ err: 'Error' });

            const result = processor.authorize(order5, paymentInstrument5);

            expect(result).to.be.an('object');
            expect(result.error).to.be.true;
            expect(createErrorLog.calledOnce).to.be.true;
        });
    });

    describe('createBAReqBody', () => {
        const createBAReqBody = processor.__get__('createBAReqBody');

        const paymentInstrument = {
            custom: {
                PP_API_ActiveBillingAgreement: JSON.stringify({ baID: 'id' })
            }
        };

        it('should return body for request', () => {
            const result = createBAReqBody(paymentInstrument);

            expect(result).to.be.an('object');
            expect(result).to.deep.equal({
                payment_source: {
                    token: {
                        id: 'id',
                        type: 'BILLING_AGREEMENT'
                    }
                }
            });
        });
    });

    describe('clearCustomPropertyCurrentPaypalEmail', () => {
        const clearCustomPropertyCurrentPaypalEmail = processor.__get__('clearCustomPropertyCurrentPaypalEmail');

        const paymentInstrument = {
            custom: {
                currentPaypalEmail: 'test@test.com'
            }
        };

        before(() => {
            stub(dw.system.Transaction, 'wrap');
        });

        after(() => {
            dw.system.Transaction.wrap.restore();
        });

        it('should call once Transacrion.wrap function and clear custom property', () => {
            const val = clearCustomPropertyCurrentPaypalEmail(paymentInstrument);

            expect(val).to.be.undefined;
            expect(dw.system.Transaction.wrap.calledOnce).to.be.true;
        });
    });
});
