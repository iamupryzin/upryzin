/* eslint-disable no-underscore-dangle */
const { int_paypal: { paypalSDKPath } } = require('../path.json');

const proxyquire = require('proxyquire').noCallThru();
const { expect } = require('chai');
const { stub } = require('sinon');

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const disableFunds = ['sepa', 'bancontact', 'eps', 'giropay', 'ideal', 'mybank', 'p24', 'sofort'];

const sdkConfig = {
    disableFunds: JSON.parse(JSON.stringify(disableFunds)),
    allowedCurrencies: []
};

const getClientId = stub();

const paypalPreferences = {
    billingAgreementEnabled: undefined,
    isCapture: undefined,
    enabledLPMs: undefined,
    isPayNowFlowEnabled: undefined,
    CWPPButtonUrl: 'CWPPButtonUrl',
    partnerAttributionId: 'partnerAttributionId',
    enableFundingList: []
};

session = {
    currency: {
        currencyCode: 'USD'
    }
};

const dwSystem = {
    DEVELOPMENT_SYSTEM: 0,
    instanceType: 0
};

const paypalSDK = proxyquire(paypalSDKPath, {
    '*/cartridge/config/sdkConfig': sdkConfig,
    '*/cartridge/config/paypalPreferences': paypalPreferences,
    '*/cartridge/scripts/paypal/paypalUtils': {
        getClientId: getClientId
    },
    'dw/system/System': dwSystem
});

describe('paypalSDK', () => {
    describe('isAllowedCurrency', () => {
        const isAllowedCurrency = paypalSDK.__get__('isAllowedCurrency');

        const allowedCurrencies = ['USD', 'EUR'];
        const storeCurrency = 'EUR';

        it('should return true', () => {
            expect(isAllowedCurrency(allowedCurrencies, storeCurrency)).to.be.true;
        });
    });

    describe('disabledPaymentOptions', () => {
        const disabledPaymentOptions = paypalSDK.__get__('disabledPaymentOptions');

        before(() => {
            Array.indexOf = function(a, b) {
                return Array.prototype.indexOf.call(a, b);
            };
        });

        describe('if enabledLPMs exists', () => {
            const newDisabledFunds = ['sepa', 'bancontact', 'eps', 'ideal', 'mybank', 'sofort', 'card',
                'credit', 'venmo'];

            before(() => {
                sdkConfig.disableFunds = JSON.parse(JSON.stringify(disableFunds));

                paypalPreferences.enabledLPMs = ['p24', 'giropay'];
            });

            after(() => {
                paypalPreferences.enabledLPMs = undefined;
            });

            it('should return disableFunds without enabled', () => {
                expect(disabledPaymentOptions()).to.deep.equals(newDisabledFunds);
            });
        });

        describe('if thare is no enabledLPMs', () => {
            const newDisabledFunds = ['sepa', 'bancontact', 'eps', 'ideal', 'mybank', 'sofort', 'card',
                'credit', 'venmo'];

            before(() => {
                sdkConfig.disableFunds = JSON.parse(JSON.stringify(disableFunds));

                paypalPreferences.enabledLPMs = ['p24', 'giropay'];
                paypalPreferences.debitCreditButtonEnabled = false;
            });

            after(() => {
                paypalPreferences.enabledLPMs = undefined;
                paypalPreferences.debitCreditButtonEnabled = true;
            });

            it('should return disableFunds without enabled', () => {
                expect(disabledPaymentOptions()).to.deep.equals(newDisabledFunds);
            });
        });
    });

    describe('addEnableFundigParam', () => {
        const addEnableFundigParam = paypalSDK.__get__('addEnableFundigParam');

        const url = '';
        const customEnableFundingList = ['USD', 'EUR'];

        before(() => {
            paypalSDK.__set__('FUNDING_PREFS', [
                { name: 'debitCreditButtonEnabled', value: false },
                { name: 'paypalCreditOrPayLaterButtonEnabled', value: false },
                { name: 'venmoEnabled', value: true }
            ]);
        });

        after(() => {
            paypalSDK.__ResetDependency__('FUNDING_PREFS');
        });

        it('should return adjusted url', () => {
            const result = addEnableFundigParam(url, customEnableFundingList);

            expect(result).to.be.a('string');
            expect(result).to.equal('&enable-funding=USD,EUR,venmo');
        });
    });

    describe('addDisableFundigParam', () => {
        const addDisableFundigParam = paypalSDK.__get__('addDisableFundigParam');

        const url = '';
        const customEnableFundingList = ['USD', 'EUR'];

        before(() => {
            paypalSDK.__set__('disabledPaymentOptions', () => []);
        });

        after(() => {
            paypalSDK.__ResetDependency__('disabledPaymentOptions');
        });

        it('should return url with the necessary values in the part of disable-funding', () => {
            const result = addDisableFundigParam(url, customEnableFundingList);

            expect(result).to.be.a('string');
            expect(result).to.equal('&disable-funding=USD,EUR');
        });
    });

    describe('createCartSDKUrl', () => {
        const createCartSDKUrl = paypalSDK.__get__('createCartSDKUrl');
        const clientID = 'AdYw0mYpZkz6qk3RNTmDTDAnNhWwUpL_zawBcv7wjinBmcm9b-10rKlRDwmRUzjcOwScbT9xDsiodvAu';
        const disabledFunding = '&disable-funding=sepa,bancontact,eps,giropay,ideal,mybank,p24,sofort';

        before(() => {
            session = {
                currency: {
                    currencyCode: 'USD'
                }
            };
            customer = {
                authenticated: true
            };
            getClientId.returns(clientID);

            paypalSDK.__set__('isAllowedCurrency', () => {
                return true;
            });
            paypalSDK.__set__('disabledPaymentOptions', () => {
                return disableFunds;
            });
        });

        after(() => {
            session = {};
            paypalSDK.__ResetDependency__('isAllowedCurrency');
            getClientId.reset();
        });

        describe('if enableFundingList contains lpm', () => {
            before(() => {
                paypalPreferences.isCapture = false;
                paypalPreferences.enableFundingList = ['mybank'];
                paypalPreferences.billingAgreementEnabled = false;
                paypalPreferences.isPayNowFlowEnabled = false;
                customer = {
                    authenticated: false
                };
            });

            after(() => {
                paypalPreferences.enableFundingList = [];
                paypalPreferences.isCapture = undefined;
                paypalPreferences.billingAgreementEnabled = undefined;
                paypalPreferences.isPayNowFlowEnabled = undefined;
                customer = {};
            });

            it('Should not append lpm to the enable funding list of sdk', () => {
                const url = `https://www.paypal.com/sdk/js?client-id=${clientID}&commit=${paypalPreferences.isPayNowFlowEnabled}&components=buttons,messages,funding-eligibility&intent=authorize&currency=USD${disabledFunding}`;

                expect(createCartSDKUrl()).to.be.equals(url);
            });
        });

        describe('if paymentAction is Auth and billing agreement is disabled', () => {
            before(() => {
                paypalPreferences.isCapture = false;
                paypalPreferences.billingAgreementEnabled = false;
                paypalPreferences.isPayNowFlowEnabled = false;
                customer = {
                    authenticated: false
                };
            });

            after(() => {
                paypalPreferences.isCapture = undefined;
                paypalPreferences.billingAgreementEnabled = undefined;
                paypalPreferences.isPayNowFlowEnabled = undefined;
                customer = {};
            });

            it('should append "&intent=authorize" to url, currency and disabled funds', () => {
                const url = `https://www.paypal.com/sdk/js?client-id=${clientID}&commit=${paypalPreferences.isPayNowFlowEnabled}&components=buttons,messages,funding-eligibility&intent=authorize&currency=USD${disabledFunding}`;

                expect(createCartSDKUrl()).to.be.equals(url);
            });
        });

        describe('if paymentAction is Capture and billing agreement is disabled', () => {
            before(() => {
                paypalSDK.__set__('isCapture', true);
                paypalSDK.__set__('billingAgreementEnabled', false);
                paypalPreferences.isPayNowFlowEnabled = true;
                customer = {
                    authenticated: false
                };
            });

            after(() => {
                paypalPreferences.isPayNowFlowEnabled = undefined;
                customer = {};
            });

            it('should append only currency and disabled funding to url', () => {
                const url = `https://www.paypal.com/sdk/js?client-id=${clientID}&commit=${paypalPreferences.isPayNowFlowEnabled}&components=buttons,messages,funding-eligibility&intent=authorize&currency=USD${disabledFunding}`;

                expect(createCartSDKUrl()).to.be.equals(url);
            });
        });

        describe('if billing agreement is enabled', () => {
            before(() => {
                paypalSDK.__set__('isCapture', false);
                paypalPreferences.billingAgreementEnabled = true;
                paypalPreferences.isPayNowFlowEnabled = false;
                customer = {
                    authenticated: true
                };
            });

            after(() => {
                customer = {};
                paypalPreferences.billingAgreementEnabled = undefined;
                paypalPreferences.isPayNowFlowEnabled = undefined;
            });

            it('should append &vault=true to url, currency and disabled funds', () => {
                const url = `https://www.paypal.com/sdk/js?client-id=${clientID}&commit=${paypalPreferences.isPayNowFlowEnabled}&components=buttons,messages,funding-eligibility&vault=true&currency=USD${disabledFunding}`;

                expect(createCartSDKUrl()).to.be.equals(url);
            });
        });

        describe('if currency is not allowed', () => {
            before(() => {
                paypalSDK.__set__('isCapture', true);
                paypalSDK.__set__('billingAgreementEnabled', false);
                paypalPreferences.isPayNowFlowEnabled = false;
                customer = {
                    authenticated: true
                };
                paypalSDK.__set__('isAllowedCurrency', () => {
                    return false;
                });
            });

            after(() => {
                paypalPreferences.isPayNowFlowEnabled = undefined;
                paypalSDK.__ResetDependency__('isAllowedCurrency');
                customer = {};
            });

            it('should append only disabled funding to url', () => {
                const url = `https://www.paypal.com/sdk/js?client-id=${clientID}&commit=${paypalPreferences.isPayNowFlowEnabled}&components=buttons,messages,funding-eligibility&intent=authorize${disabledFunding}`;

                expect(createCartSDKUrl()).to.be.equals(url);
            });
        });
    });

    describe('createBillingSDKUrl', () => {
        const createBillingSDKUrl = paypalSDK.__get__('createBillingSDKUrl');
        const clientID = 'AdYw0mYpZkz6qk3RNTmDTDAnNhWwUpL_zawBcv7wjinBmcm9b-10rKlRDwmRUzjcOwScbT9xDsiodvAu';
        const disabledFunding = '&disable-funding=sepa,bancontact,eps,giropay,ideal,mybank,p24,sofort';
        const components = '&components=buttons,marks,payment-fields,funding-eligibility';
        const buyerCountry = '&buyer-country=FR';
        const originalRequest = request;

        before(() => {
            session = {
                currency: {
                    currencyCode: 'USD'
                }
            };
            customer = {
                authenticated: true
            };
            getClientId.returns(clientID);
            paypalSDK.__set__('isAllowedCurrency', () => {
                return true;
            });
            paypalSDK.__set__('disabledPaymentOptions', () => {
                return disableFunds;
            });
        });

        after(() => {
            session = {};
            paypalSDK.__ResetDependency__('isAllowedCurrency');
            getClientId.reset();
        });

        describe('if InstanceType is Development && currency code is USD', () => {
            before(() => {
                paypalSDK.__set__('isCapture', false);
                paypalSDK.__set__('billingAgreementEnabled', false);
                paypalSDK.__set__('enabledLPMs', ['sofort']);
                customer = {
                    authenticated: false
                };
            });

            after(() => {
                customer = {};
            });

            const url = `https://www.paypal.com/sdk/js?client-id=${clientID}${components}&commit=false&intent=authorize&currency=USD${disabledFunding}`;

            it('should not append "buyer-country" to url', () => {
                expect(createBillingSDKUrl()).to.be.equals(url);
            });
        });

        describe('if InstanceType is Development && currency code is EUR', () => {
            before(() => {
                paypalSDK.__set__('isCapture', false);
                paypalSDK.__set__('billingAgreementEnabled', false);
                paypalSDK.__set__('enabledLPMs', ['sofort']);
                customer = {
                    authenticated: false
                };
                request = {
                    locale: 'fr_FR'
                };
                session = {
                    currency: {
                        currencyCode: 'EUR'
                    }
                };
            });

            after(() => {
                customer = {};
                request = originalRequest;
                session = {
                    currency: {
                        currencyCode: 'USD'
                    }
                };
            });

            const url = `https://www.paypal.com/sdk/js?client-id=${clientID}${components}&commit=false&intent=authorize&currency=EUR${disabledFunding}${buyerCountry}`;

            it('should append "buyer-country=FR" to url', () => {
                expect(createBillingSDKUrl()).to.be.equals(url);
            });
        });

        describe('if InstanceType is Production', () => {
            before(() => {
                dwSystem.instanceType = 2;
                session = {
                    currency: {
                        currencyCode: 'EUR'
                    }
                };
                paypalSDK.__set__('isCapture', false);
                paypalSDK.__set__('billingAgreementEnabled', false);
                paypalSDK.__set__('enabledLPMs', ['sofort']);
                customer = {
                    authenticated: false
                };
            });

            after(() => {
                dwSystem.instanceType = 0;
                customer = {};
                session = {
                    currency: {
                        currencyCode: 'USD'
                    }
                };
            });

            const url = `https://www.paypal.com/sdk/js?client-id=${clientID}${components}&commit=false&intent=authorize&currency=EUR${disabledFunding}`;

            it('should not append "buyer-country" to url', () => {
                expect(createBillingSDKUrl()).to.be.equals(url);
            });
        });

        describe('if paymentAction is Auth and billing agreement is disabled', () => {
            before(() => {
                paypalSDK.__set__('isCapture', false);
                paypalSDK.__set__('billingAgreementEnabled', false);
                paypalSDK.__set__('enabledLPMs', ['sofort']);
                customer = {
                    authenticated: false
                };
            });

            after(() => {
                customer = {};
            });

            const url = `https://www.paypal.com/sdk/js?client-id=${clientID}${components}&commit=false&intent=authorize&currency=USD${disabledFunding}`;

            it('should append "&intent=authorize" to url, currency and disabled funds', () => {
                expect(createBillingSDKUrl()).to.be.equals(url);
            });
        });

        describe('if paymentAction is Capture and billing agreement is disabled', () => {
            before(() => {
                paypalSDK.__set__('isCapture', true);
                paypalSDK.__set__('billingAgreementEnabled', false);
                paypalSDK.__set__('enabledLPMs', ['sofort']);
                customer = {
                    authenticated: false
                };
            });

            after(() => {
                customer = {};
            });

            const url = `https://www.paypal.com/sdk/js?client-id=${clientID}${components}&commit=false&intent=authorize&currency=USD${disabledFunding}`;

            it('should append only currency and disabled funding to url', () => {
                expect(createBillingSDKUrl()).to.be.equals(url);
            });
        });

        describe('if billing agreement is enabled', () => {
            before(() => {
                paypalPreferences.isCapture = false;
                paypalPreferences.billingAgreementEnabled = true;
                paypalPreferences.enabledLPMs = undefined;
                customer = {
                    authenticated: true
                };
            });

            after(() => {
                customer = {};
                paypalPreferences.billingAgreementEnabled = undefined;
                paypalPreferences.isCapture = undefined;
            });

            const url = `https://www.paypal.com/sdk/js?client-id=${clientID}${components}&commit=false&vault=true&currency=USD${disabledFunding}`;

            it('should append &vault=true to url, currency and disabled funds', () => {
                expect(createBillingSDKUrl()).to.be.equals(url);
            });
        });

        describe('if currency is not allowed', () => {
            before(() => {
                paypalSDK.__set__('isCapture', true);
                paypalSDK.__set__('billingAgreementEnabled', false);
                paypalSDK.__set__('enabledLPMs', ['sofort']);
                paypalPreferences.isPayNowFlowEnabled = false;
                customer = {
                    authenticated: true
                };
                paypalSDK.__set__('isAllowedCurrency', () => {
                    return false;
                });
            });

            after(() => {
                paypalPreferences.isPayNowFlowEnabled = undefined;
                paypalSDK.__ResetDependency__('isAllowedCurrency');
                customer = {};
            });

            it('should append only disabled funding to url', () => {
                const url = `https://www.paypal.com/sdk/js?client-id=${clientID}${components}&commit=${paypalPreferences.isPayNowFlowEnabled}&intent=authorize${disabledFunding}`;

                expect(createBillingSDKUrl()).to.be.equals(url);
            });
        });
    });

    describe('createFraudNetNoScriptURL', () => {
        const createFraudNetNoScriptURL = paypalSDK.__get__('createFraudNetNoScriptURL');

        it('should returns a correct url string', () => {
            const url = 'https://c.paypal.com/v1/r/d/b/ns?f=uid&js=0&r=1';

            expect(createFraudNetNoScriptURL('uid')).to.be.equals(url);
        });
    });
});
