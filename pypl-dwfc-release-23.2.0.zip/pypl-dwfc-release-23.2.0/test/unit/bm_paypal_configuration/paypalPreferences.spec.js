/* eslint-disable no-underscore-dangle */
const { bm_paypal_configuration: { paypalPreferencesPath } } = require('../path.json');

const { expect } = require('chai');
const { it, describe } = require('mocha');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const paypalPreferences = proxyquire(paypalPreferencesPath, {
    'dw/svc/LocalServiceRegistry': {
        createService: () => ({ configuration: { credential: { user: 'g12346F' } } })
    },
    'dw/system/Site': {
        current: {
            getCustomPreferenceValue: () => ({
                getValue: () => {}
            })
        }
    }
});

describe('paypalPreferences file', () => {
    it('should returns an object with keys', () => {
        expect(paypalPreferences).to.be.an('object').that.all.keys([
            'clientId', 'buttonStylesApi', 'payPalShowOnPdp',
            'payPalShowOnCart', 'payPalShowOnCategory', 'payPalButtonLocation'
        ]);

        expect(paypalPreferences.buttonStylesApi).to.be.an('object').that.all.keys([
            'cwpp', 'payPalSmart', 'payPalCredit'
        ]);
    });

    describe('getClientId', () => {
        const getClientId = paypalPreferences.__get__('getClientId');

        it('should returns a string value that not empty', () => {
            expect(getClientId()).to.be.a('string').that.not.empty;
        });
    });
});
