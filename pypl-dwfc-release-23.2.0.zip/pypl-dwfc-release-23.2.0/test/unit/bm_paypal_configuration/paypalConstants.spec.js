const { bm_paypal_configuration: { paypalConstantsPath } } = require('../path.json');

const { expect } = require('chai');
const { it, describe } = require('mocha');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

Object.setPrototypeOf(module,
    Object.assign(Object.getPrototypeOf(module), {
        superModule: {
            INSTANCE_PRODUCTION: 'production',
            INSTANCE_SANDBOX: 'sandbox'
        }
    }));

const paypalConstants = proxyquire(paypalConstantsPath, {
    'dw/system/System': {
        instanceType: 0,
        PRODUCTION_SYSTEM: 2
    }
});

describe('paypalConstants file', () => {
    it('should returns an object with keys', () => {
        expect(paypalConstants).to.be.an('object').that.all.keys([
            'instanceType', 'INSTANCE_PRODUCTION', 'INSTANCE_SANDBOX'
        ]);
    });

    it('instanceType should be equal to sandbox', () => {
        expect(paypalConstants.instanceType).to.be.a('string').that.equal('sandbox');
    });
});
