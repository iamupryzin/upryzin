const { bm_paypal_configuration: { buttonConfigHelperPath } } = require('../path.json');

const { expect } = require('chai');
const { it, describe } = require('mocha');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const paypalPreferences = {
    payPalShowOnPdp: 'show-on-pdp',
    payPalShowOnCart: 'show-on-cart',
    payPalShowOnCategory: 'show-on-category'
};

const buttonConfigHelper = proxyquire(buttonConfigHelperPath, {
    'dw/system/Site': dw.system.Site,
    '*/cartridge/config/paypalPreferences': paypalPreferences
});

describe('buttonConfigHelper file', () => {
    describe('getBannerConfigPages', () => {
        it('should returns an active paypal credit messaging', () => {
            expect(buttonConfigHelper.getBannerConfigPages()).to.be.an('object').that.all.keys(['pdp', 'cart', 'category']);
        });

        it('should returns an active paypal credit messaging that have a value', () => {
            paypalPreferences.payPalShowOnPdp = null;

            expect(buttonConfigHelper.getBannerConfigPages()).to.be.an('object').that.all.keys(['cart', 'category']);
        });

        it('should returns an empty object', () => {
            paypalPreferences.payPalShowOnCart = null;
            paypalPreferences.payPalShowOnCategory = null;

            expect(buttonConfigHelper.getBannerConfigPages()).to.be.an('object').that.is.empty;
        });
    });

    describe('getLocaleWithHyphen', () => {
        before(() => {
            dw.system.Site.current = { defaultLocale: 'en_US' };
        });

        after(() => {
            delete dw.system.Site.current;
        });

        it('should return en-us if locale is default', () => {
            expect(buttonConfigHelper.getLocaleWithHyphen('default')).to.be.equal('en-us');
        });

        it('should return pl-pl if locale don\'t have a underscore', () => {
            expect(buttonConfigHelper.getLocaleWithHyphen('pl')).to.be.equal('pl-pl');
        });

        it('should return en-us if locale have a underscore', () => {
            expect(buttonConfigHelper.getLocaleWithHyphen('en_US')).to.be.equal('en-us');
        });
    });
});
