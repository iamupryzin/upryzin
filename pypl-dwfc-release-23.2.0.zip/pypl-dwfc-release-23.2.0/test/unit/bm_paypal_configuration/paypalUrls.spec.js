const { bm_paypal_configuration: { paypalUrlsPath } } = require('../path.json');

const { expect } = require('chai');
const { it, describe } = require('mocha');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const paypalUrls = proxyquire(paypalUrlsPath, {
    'dw/web/URLUtils': {
        url: (msg) => ({
            toString: () => msg.toLowerCase()
        })
    }
});

describe('paypalUrls file', () => {
    it('should returns an object with keys', () => {
        expect(paypalUrls).to.be.an('object').that.all.keys(['cwppConfigUrl', 'payPalSDK', 'payPalExternalSDK']);
    });
});
