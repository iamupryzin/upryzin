const { bm_paypal_configuration: { paypalHelperPath } } = require('../path.json');

const { expect } = require('chai');
const { it, describe } = require('mocha');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const paypalPreferences = {
    payPalButtonLocation: 'CartMinicartPdp'
};

const paypalHelper = proxyquire(paypalHelperPath, {
    '*/cartridge/config/paypalPreferences': paypalPreferences
});

describe('paypalHelper file', () => {
    describe('isPaypalButtonEnabled', () => {
        it('should return true if cart is contains in paypal button location', () => {
            expect(paypalHelper.isPaypalButtonEnabled('cart')).to.be.a('boolean').that.true;
        });

        it('should return true if minicart is contains in paypal button location', () => {
            expect(paypalHelper.isPaypalButtonEnabled('minicart')).to.be.a('boolean').that.true;
        });

        it('should return true if pdp is contains in paypal button location', () => {
            expect(paypalHelper.isPaypalButtonEnabled('pdp')).to.be.a('boolean').that.true;
        });

        it('should return false if agrument is not set', () => {
            expect(paypalHelper.isPaypalButtonEnabled()).to.be.a('boolean').that.false;
        });

        it('should return false if paypal button location equal to \'none\'', () => {
            paypalPreferences.payPalButtonLocation = 'None';

            expect(paypalHelper.isPaypalButtonEnabled('pdp')).to.be.a('boolean').that.false;
        });
    });
});
