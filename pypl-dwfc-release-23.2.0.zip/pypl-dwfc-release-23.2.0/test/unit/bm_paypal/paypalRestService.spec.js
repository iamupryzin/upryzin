const { bm_paypal: { paypalRestServicePath } } = require('../path.json');

const { describe, it, afterEach } = require('mocha');
const { expect } = require('chai');
const { stub } = require('sinon');

require('dw-api-mock/demandware-globals');

const ServiceCredential = function(url) {
    this.URL = url;
};

const getTokenCache = stub();

const bmPaypalRestService = require('proxyquire').noCallThru()(paypalRestServicePath, {
    'dw/svc/ServiceCredential': ServiceCredential,
    'dw/web/Resource': dw.web.Resource,
    'dw/svc/LocalServiceRegistry': {
        createService: (name, obj) => ({
            createRequest: obj.createRequest,
            parseResponse: obj.parseResponse,
            filterLogMessage: obj.filterLogMessage,
            getRequestLogMessage: obj.getRequestLogMessage,
            getResponseLogMessage: obj.getResponseLogMessage
        })
    },
    'dw/system/CacheMgr': {
        getCache: () => {
            return {
                get: getTokenCache,
                put: () => {}
            };
        }
    },
    '*/cartridge/config/paypalConstants': {
        SERVICE_NAME: 'service'
    }
});

describe('bmPaypalRestService file', () => {
    const service = bmPaypalRestService();

    describe('createRequest', () => {
        const reqService = {
            response: {
                error_description: null,
                access_token: 'access token'
            },
            configuration: { credential: new ServiceCredential('url') },
            setURL: function(url) {
                this.response.url = url;
            },
            addHeader: function(key, value) {
                this.response.header[key] = value;
            },
            setRequestMethod: function(method) {
                this.response.method = method;
            },
            setThrowOnError: () => {
                return { call: () => {} };
            }
        };

        const reqData = {
            path: null,
            method: null,
            body: null,
            createToken: null,
            partnerAttributionId: null
        };

        afterEach(() => {
            getTokenCache.reset();
            reqService.configuration.credential = new ServiceCredential('url');
            reqService.response.error_description = null;
            reqService.response.url = null;
            reqService.response.header = {};
            reqService.response.method = null;
            reqData.createToken = null;
            reqData.body = null;
            reqData.path = null;
            reqData.method = null;
            reqData.partnerAttributionId = null;
        });

        it('result should be an error if credentials aren\'t an instance of ServiceCredential', () => {
            reqService.configuration.credential = {};

            expect(() => service.createRequest(reqService, reqData)).to.throw();
        });

        it('result should be an error if there\'s no token in cache & reqService.response.error_description is set to true', () => {
            getTokenCache.returns(null);
            reqService.response.error_description = true;

            expect(() => service.createRequest(reqService, reqData)).to.throw();
        });

        it('result should be reqService.response.header.Authorization set to "Bearer access token" if there\'s no token in cache', () => {
            getTokenCache.returns(null);

            expect(service.createRequest(reqService, reqData)).to.equal('');
            expect(reqService.response.header).to.have.property('Authorization').that.equals('Bearer access token');
        });

        it('result should be a correctly built url if ServiceCredential takes an url ending in a slash as a value', () => {
            reqService.configuration.credential = new ServiceCredential('url/');
            reqData.path = 'path';

            expect(service.createRequest(reqService, reqData)).to.equal('');
            expect(reqService.response.url).to.equal('url/path');
        });

        it('result should be url and header set to their values if createToken is present in reqData', () => {
            reqData.createToken = true;

            expect(service.createRequest(reqService, reqData)).to.equal('');
            expect(reqService.response.url).to.equal('url/v1/oauth2/token?grant_type=client_credentials');
            expect(reqService.response.header).to.have.property('Content-Type').that.equals('application/x-www-form-urlencoded');
        });

        it('result should be a parsed reqData.body returned & url, method & header set to their values if reqData comes with values', () => {
            getTokenCache.returns('paypalRestOauthToken');
            reqData.body = {};
            reqData.path = 'path';
            reqData.method = 'get';
            reqData.partnerAttributionId = 'partnerAttributionId';

            expect(service.createRequest(reqService, reqData)).to.equal('{}');
            expect(reqService.response.url).to.equal('url/path');
            expect(reqService.response.method).to.equal('get');
            expect(reqService.response.header).to.have.property('Content-Type').that.equals('application/json');
            expect(reqService.response.header).to.have.property('Authorization').that.equals('Bearer paypalRestOauthToken');
            expect(reqService.response.header).to.have.property('PayPal-Partner-Attribution-Id').that.equals('partnerAttributionId');
        });
    });

    describe('parseResponse', () => {
        it('result should be equal to 200', () => {
            expect(service.parseResponse({}, { getText: () => '200' })).to.equal(200);
        });
    });

    describe('filterLogMessage', () => {
        it('result should be equal to "msg"', () => {
            expect(service.filterLogMessage('msg')).to.equal('msg');
        });
    });

    describe('getRequestLogMessage', () => {
        it('result should be equal to "request msg"', () => {
            expect(service.getRequestLogMessage('request msg')).to.equal('request msg');
        });
    });

    describe('getResponseLogMessage', () => {
        it('result should be equal to "log msg"', () => {
            expect(service.getResponseLogMessage({ text: 'log msg' })).to.equal('log msg');
        });
    });
});
