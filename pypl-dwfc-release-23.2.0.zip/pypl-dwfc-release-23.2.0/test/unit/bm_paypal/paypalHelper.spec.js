/* eslint-disable no-underscore-dangle */
const { bm_paypal: { paypalHelperPath } } = require('../path.json');

const {
    describe, it, before, after
} = require('mocha');

const { expect } = require('chai');
const { stub, createStubInstance } = require('sinon');

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const createErrorLog = stub();
const getAllOrders = stub();
const isJson = stub();
const pluralize = stub();
const getPaypalPaymentInstrument = stub();

getPaypalPaymentInstrument.returns({
    custom: {
        paypalRequest: null,
        paypalResponse: null
    }
});
const orderMgr = {
    queryOrder: () => {},
    createOrderSequenceNo: () => {}
};

const bmPaypalHelper = require('proxyquire').noCallThru()(paypalHelperPath, {
    'dw/system/Logger': dw.system.Logger,
    'dw/web/Resource': dw.web.Resource,
    'dw/util/Calendar': dw.util.Calendar,
    'dw/order/OrderMgr': orderMgr,
    'dw/util/StringUtils': dw.util.StringUtils,
    'dw/object/CustomObject': dw.object.CustomObject,
    'dw/object/CustomObjectMgr': dw.object.CustomObjectMgr,
    'dw/system/Transaction': dw.system.Transaction,
    '*/cartridge/scripts/helpers/coreHelpers': {
        isJson,
        pluralize,
        sortByProperty: (arr, prop) => {
            return arr.sort((prev, next) => prev[prop] > next[prop] ? 1 : -1);
        },
        filterByProperty: (arr, prop, val) => {
            return arr.filter((el) => el[prop] === val);
        }
    },
    '*/cartridge/config/paypalConstants': {
        SEARCH_BY_ORDER_NUMBER: 'by order number',
        SEARCH_BY_TRANSACTION_ID: 'by transaction id',
        SEARCH_BY_PAYMENT_STATUS: 'by payment status',
        PAYMENT_ACTION_AUTHORIZATION: 'authorization',
        PAYMENT_ACTION_AUTHORIZE: 'action authorize',
        PAYMENT_ACTION_CAPTURE: 'action capture',
        TRANSACTION_STATUSES: [],
        TRANSACTION_FAILED_STATUSES: ['declined', undefined]
    },
    '*/cartridge/scripts/paypal/bmPaypalUtils': {
        createErrorLog
    },
    '*/cartridge/scripts/paypal/bmPaymentInstrumentHelper': {
        getPaypalPaymentInstrument: getPaypalPaymentInstrument
    },
    '*/countriesCodes': ['UA'],
    '*/cartridge/models/ppOrderMgr': function() {
        return {
            getAllOrders
        };
    }
});

describe('bmPaypalHelper file', () => {
    describe('parseStatus', () => {
        before(() => {
            stub(dw.system.Logger, 'getLogger');
        });

        after(() => {
            dw.system.Logger.getLogger.restore();
        });

        it('if an underscore in paymentsStatus string is replaced with a space', () => {
            expect(bmPaypalHelper.parseStatus('created_now')).to.be.equals('Created now');
        });

        it('if error', () => {
            dw.system.Logger.getLogger.returns({ error: () => {} });

            expect(bmPaypalHelper.parseStatus(null)).to.be.null;
        });
    });

    describe('createCustomTransactionInvNum', () => {
        before(() => {
            stub(orderMgr, 'queryOrder');
            stub(orderMgr, 'createOrderSequenceNo');
            orderMgr.createOrderSequenceNo.returns('orderNo');
        });

        after(() => {
            orderMgr.queryOrder.restore();
            orderMgr.createOrderSequenceNo.restore();
        });

        it('if inventory number is created', () => {
            orderMgr.queryOrder.returns({
                orderNo: 'orderNo'
            });

            expect(bmPaypalHelper.createCustomTransactionInvNum()).to.be.equal('pp_orderNo');
        });

        it('if an order is empty', () => {
            orderMgr.queryOrder.returns(null);

            expect(bmPaypalHelper.createCustomTransactionInvNum()).to.be.equal('pp_orderNo');
        });

        it('if an error occurs', () => {
            orderMgr.queryOrder.throws(Error);

            expect(bmPaypalHelper.createCustomTransactionInvNum()).to.be.equal('pp_orderNo');
        });
    });

    describe('getCountriesLabelsAndCodes', () => {
        before(() => {
            stub(dw.web.Resource, 'msg');
        });

        after(() => {
            dw.web.Resource.msg.restore();
        });

        const codesAndLabels = [{ value: 'UA', label: 'Ukraine' }];

        it('if an array with the object containing a country code and a label is created', () => {
            dw.web.Resource.msg.returns('Ukraine');
            expect(bmPaypalHelper.getCountriesLabelsAndCodes()).to.deep.equal(codesAndLabels);
        });
    });

    describe('isSearchQueryEmpty', () => {
        const transactionId = {};
        const orderNo = {};
        const paymentStatus = {};

        it('if a search query is empty', () => {
            expect(bmPaypalHelper.isSearchQueryEmpty(transactionId, orderNo, paymentStatus)).to.equal(true);
        });

        it('if a search query is partially empty', () => {
            transactionId.stringValue = '00001293';

            expect(bmPaypalHelper.isSearchQueryEmpty(transactionId, orderNo, paymentStatus)).to.equal(false);
        });

        it('if a search query is not empty', () => {
            orderNo.stringValue = 'pp_00001293';
            paymentStatus.stringValue = 'created';

            expect(bmPaypalHelper.isSearchQueryEmpty(transactionId, orderNo, paymentStatus)).to.equal(false);
        });
    });

    describe('getSearchType', () => {
        const transactionId = { submitted: true };
        const paymentStatus = { submitted: true, stringValue: 'created' };

        it('if a search type is by transaction id', () => {
            expect(bmPaypalHelper.getSearchType(transactionId, paymentStatus)).to.equal('by transaction id');
        });

        it('if a search type is by payment status', () => {
            transactionId.submitted = false;
            expect(bmPaypalHelper.getSearchType(transactionId, paymentStatus)).to.equal('by payment status');
        });

        it('if a search type is by payment status', () => {
            paymentStatus.submitted = false;
            expect(bmPaypalHelper.getSearchType(transactionId, paymentStatus)).to.equal('by order number');
        });
    });

    describe('formatedDate', () => {
        before(() => {
            stub(dw.util.StringUtils, 'formatCalendar');
        });

        after(() => {
            dw.util.StringUtils.formatCalendar.restore();
        });

        it('if isoString is not undefined', () => {
            dw.util.StringUtils.formatCalendar.returns('10/05/2022 14:48');
            expect(bmPaypalHelper.formatedDate('2022-10-05T14:48:00Z')).to.equal('10/05/2022 14:48');
        });
    });

    describe('isExpiredHonorPeriod', () => {
        it('if returns boolean', () => {
            expect(bmPaypalHelper.isExpiredHonorPeriod('2022-10-05T14:48:00Z')).to.be.a('boolean');
        });
    });

    describe('getPaymentStatus', () => {
        const transactionResponse = {
            purchase_units: [{
                payments: {
                    captures: [{ status: 'completed' }],
                    authorizations: [{ status: 'completed' }]
                }
            }
            ]
        };

        it('if status from payments.captures is not undefined', () => {
            expect(bmPaypalHelper.getPaymentStatus(transactionResponse)).to.not.undefined;
        });

        it('if status from payments.authorizations is not undefined', () => {
            transactionResponse.purchase_units[0].payments.captures = null;
            expect(bmPaypalHelper.getPaymentStatus(transactionResponse)).to.not.undefined;
        });
    });

    describe('getPaymentActionType', () => {
        it('if doesn\'t return an undefined and if payment action type is capture', () => {
            expect(bmPaypalHelper.getPaymentActionType('')).to.equal('action capture');
        });

        it('if payment action type is authorize', () => {
            expect(bmPaypalHelper.getPaymentActionType('authorization')).to.equal('action authorize');
        });
    });

    describe('getPaymentStatusTransactionStatistics', () => {
        const orders = {
            statuses: [{}],
            iterator: function() {
                return new dw.util.Iterator(this.statuses);
            }
        };

        let result;

        getAllOrders.returns(orders);

        it('if status is undefined, still return an object but with N/A values', () => {
            expect(bmPaypalHelper.getPaymentStatusTransactionStatistics()).to.not.be.undefined;
        });

        it('if status object is built correctly', () => {
            pluralize.returns('transactions');
            result = [{
                title: 'New transactions', count: 2, value: 'new', label: 'New', color: 'success'
            }];
            orders.statuses = [{ status: 'new' }, { status: 'new' }];

            expect(bmPaypalHelper.getPaymentStatusTransactionStatistics()).to.deep.equal(result);
        });

        it('if objects with status set to success go before those set to failure', () => {
            pluralize.returns('transaction');
            result = [{
                title: 'New transaction', count: 1, value: 'new', label: 'New', color: 'success'
            },
            {
                title: 'Declined transaction', count: 1, value: 'declined', label: 'Declined', color: 'failure'
            }];
            orders.statuses = [{ status: 'declined' }, { status: 'new' }];

            expect(bmPaypalHelper.getPaymentStatusTransactionStatistics()).to.deep.equal(result);
        });
    });

    describe('getOrderByOrderNo', () => {
        before(() => {
            stub(dw.object.CustomObjectMgr, 'getCustomObject');
            stub(orderMgr, 'queryOrder');
        });

        after(() => {
            dw.object.CustomObjectMgr.getCustomObject.restore();
            orderMgr.queryOrder.restore();
        });

        it('if empty', () => {
            dw.object.CustomObjectMgr.getCustomObject.returns();
            orderMgr.queryOrder.returns();

            expect(bmPaypalHelper.getOrderByOrderNo('orderNo')).to.be.undefined;
        });
    });

    describe('saveTransationRequestAndResponse', () => {
        before(() => {
            stub(orderMgr, 'queryOrder');
            stub(dw.object.CustomObjectMgr, 'getCustomObject');
            stub(dw.system.Transaction, 'wrap', callback => callback());
        });

        after(() => {
            orderMgr.queryOrder.restore();
            dw.system.Transaction.wrap.restore();
            dw.object.CustomObjectMgr.getCustomObject.restore();
        });

        const requestData = { orderNo: '', custom: {} };
        const responseDate = {};

        it('if there\'s no order', () => {
            orderMgr.queryOrder.returns();

            expect(bmPaypalHelper.saveTransationRequestAndResponse(requestData, responseDate)).to.be.undefined;
        });

        it('if order is an instance of dw.object.CustomObject', () => {
            dw.object.CustomObjectMgr.getCustomObject.returns(new dw.object.CustomObject());

            expect(bmPaypalHelper.saveTransationRequestAndResponse(requestData, responseDate)).to.be.undefined;
        });

        it('if order isn\'t an instance of dw.object.CustomObject', () => {
            dw.object.CustomObjectMgr.getCustomObject.returns();
            orderMgr.queryOrder.returns({ orderNo: 'orderNo' });

            expect(bmPaypalHelper.saveTransationRequestAndResponse(requestData, responseDate)).to.be.undefined;
        });
    });

    describe('getTransactionHistory', () => {
        const dateTime = '2023-02-28T12:00:00.000Z';

        before(() => {
            stub(Date.prototype, 'toISOString').returns(dateTime);
        });

        after(() => {
            Date.prototype.toISOString.restore();
        });

        const getTransactionHistory = bmPaypalHelper.__get__('getTransactionHistory');

        const transaction = {
            request: {
                methodName: 'DoRefundPartial',
                refundtype: 'Partial'
            },
            response: {},
            amount: '50.00',
            status: 'Capture'
        };

        it('should returns an object with keys', () => {
            const val = getTransactionHistory(transaction);

            expect(val).to.be.an('object').that.has.all.keys([
                'amount', 'timestamp', 'status', 'methodName', 'refundType'
            ]);

            expect(val).to.include({
                amount: '50.00',
                methodName: 'DoRefundPartial',
                refundType: 'Partial',
                status: 'Capture',
                timestamp: dateTime
            });
        });

        it('should returns an object and amount get from request amt', () => {
            transaction.request.amt = '40.00';

            const val = getTransactionHistory(transaction);

            expect(val).to.include({
                amount: '40.00',
                methodName: 'DoRefundPartial',
                refundType: 'Partial',
                status: 'Capture',
                timestamp: dateTime
            });
        });

        it('should returns an object and refundType are empty', () => {
            delete transaction.request.refundtype;

            const val = getTransactionHistory(transaction);

            expect(val).to.include({
                amount: '40.00',
                methodName: 'DoRefundPartial',
                refundType: '',
                status: 'Capture',
                timestamp: dateTime
            });
        });
    });

    describe('prepareTransactionHistory', () => {
        const data = {
            requst: {}, response: {}, amount: '40.00', status: 'Capture'
        };

        const objectType = { custom: { paypalTransactionHistory: null } };

        before(() => {
            isJson.returns(false);

            bmPaypalHelper.__set__('getTransactionHistory', () => ({
                amount: '40.00',
                methodName: 'DoRefundPartial',
                refundType: 'Partial',
                status: 'Capture',
                timestamp: '2023-02-28T12:00:00.000Z'
            }));
        });

        after(() => {
            isJson.reset();
            bmPaypalHelper.__ResetDependency__('getTransactionHistory');
        });

        it('should returns one item of transaction history in json format', () => {
            const val = bmPaypalHelper.prepareTransactionHistory(objectType, data);

            expect(val).to.be.a('string').that.is.not.empty;
            expect(JSON.parse(val)).to.have.lengthOf(1);
        });

        it('should returns a list of transaction history in json format', () => {
            isJson.returns(true);

            objectType.custom.paypalTransactionHistory = JSON.stringify([{
                amount: '40.00',
                status: 'Created',
                timestamp: '2023-02-28T10:00:00.000Z'
            }]);

            const val = bmPaypalHelper.prepareTransactionHistory(objectType, data);

            expect(val).to.be.a('string').that.is.not.empty;
            expect(JSON.parse(val)).to.have.lengthOf(2);
        });
    });

    describe('saveTransactionHistory', () => {
        const requestData = { orderNo: '0000001' };
        const responseData = {};

        const orderResponse = {
            totalGrossPrice: { value: '40.00' },
            custom: { paypalTransactionHistory: null }
        };

        const customObject = createStubInstance(dw.object.CustomObject, orderResponse);

        before(() => {
            stub(bmPaypalHelper, 'getOrderByOrderNo').returns(orderResponse);

            stub(bmPaypalHelper, 'prepareTransactionHistory').returns(JSON.stringify([]));

            getPaypalPaymentInstrument.returns({
                custom: { paypalPaymentStatus: 'COMPLETED' },
                paymentTransaction: { custom: {} }
            });

            stub(dw.system.Transaction, 'wrap', callback => callback());
        });

        after(() => {
            getPaypalPaymentInstrument.reset();
            dw.system.Transaction.wrap.restore();
            bmPaypalHelper.getOrderByOrderNo.restore();
            bmPaypalHelper.prepareTransactionHistory.restore();
        });

        it('should update custom attribute `paypalTransactionHistory` for System Object Type', () => {
            const val = bmPaypalHelper.saveTransactionHistory(requestData, responseData);

            expect(val).to.be.undefined;
        });

        it('should update custom attribute `paypalTransactionHistory` for Custom Object Type', () => {
            bmPaypalHelper.getOrderByOrderNo.returns(customObject);

            const val = bmPaypalHelper.saveTransactionHistory(requestData, responseData);

            expect(val).to.be.undefined;
        });

        it('order is not found', () => {
            bmPaypalHelper.getOrderByOrderNo.returns(null);

            const val = bmPaypalHelper.saveTransactionHistory(requestData, responseData);

            expect(val).to.be.undefined;
        });
    });
});
