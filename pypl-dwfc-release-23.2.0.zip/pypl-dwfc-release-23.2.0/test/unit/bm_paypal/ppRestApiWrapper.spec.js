/* eslint-disable no-underscore-dangle */
const { bm_paypal: { ppRestApiWrapperPath } } = require('../path.json');

const { expect } = require('chai');
const {
    it, describe, before, after, afterEach
} = require('mocha');

const { stub } = require('sinon');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const createErrorLog = stub();
const reauthorizeTransaction = stub();
const refundTransaction = stub();
const captureTransaction = stub();
const getOrder = stub();

const ppRestApiWrapper = proxyquire(ppRestApiWrapperPath, {
    'dw/web/Resource': dw.web.Resource,
    'dw/order/OrderMgr': {
        getOrder
    },
    '*/cartridge/scripts/paypal/paypalApi/bmPaypalApi': {
        createOrder: () => ({}),
        createTransaction: () => {
            return {
                status: 'authorized',
                purchase_units: {},
                payer: 'payer',
                id: 'id'
            };
        },
        voidTransaction: () => {},
        getOrderDetails: () => ({}),
        reauthorizeTransaction,
        refundTransaction,
        captureTransaction
    },
    '*/cartridge/config/paypalConstants': {
        ACTION_STATUS_SUCCESS: 'SUCCESS',
        STATUS_COMPLETED: 'COMPLETED',
        STATUS_CREATED: 'CREATED',
        STATUS_SAVED: 'SAVED'
    },
    '*/cartridge/scripts/paypal/bmPaypalHelper': {
        getPaymentActionType: () => 'authorize'
    },
    '*/cartridge/scripts/paypal/bmPaypalUtils': { createErrorLog }
});

describe('ppRestApiWrapper file', () => {
    describe('getPurchaseUnit', () => {
        const getPurchaseUnit = ppRestApiWrapper.__get__('getPurchaseUnit');
        const mandatoryKeys = ['description', 'amount', 'invoice_id'];

        let data = {
            desc: 'description',
            currencycode: 'USD',
            amt: 100,
            itemamt: 100,
            invmun: 0
        };

        afterEach(() => {
            data = {
                desc: 'description',
                currencycode: 'USD',
                amt: 100,
                itemamt: 100,
                invmun: 0
            };
        });

        it('If data.shiptoName && data.shiptoStreet were not provided', () => {
            const result = getPurchaseUnit(data);

            expect(result).to.be.an('object');
            expect(result).to.have.all.keys(mandatoryKeys);
            expect(result.amount.breakdown.shipping.value).to.equal('0');
            expect(result.amount.breakdown.tax_total.value).to.equal('0');
        });

        it('If data.shiptoName && data.shiptoStreet were provided', () => {
            data.shiptoName = 'name';
            data.shiptoStreet = 'street';

            const result = getPurchaseUnit(data);

            expect(result).to.be.an('object');
            expect(result).to.have.all.keys(...mandatoryKeys, 'shipping');
            expect(result.amount.breakdown.shipping.value).to.equal('0');
            expect(result.amount.breakdown.tax_total.value).to.equal('0');
            expect(result.shipping.name.full_name).to.equal('name');
        });
    });

    describe('ppRestSdk', () => {
        it('ppRestSdk should be a function', () => {
            expect(ppRestApiWrapper()).to.equal(undefined);
            expect(ppRestApiWrapper).to.be.a('function');
        });
    });

    describe('createOrder', () => {
        const reqData = {};
        const paymentAction = 'authorize';

        before(() => {
            stub(dw.web.Resource, 'msg');
            dw.web.Resource.msg.returns('Api error');

            ppRestApiWrapper.__set__('getPurchaseUnit', () => ({}));
        });

        after(() => {
            dw.web.Resource.msg.restore();
            createErrorLog.reset();
            ppRestApiWrapper.__ResetDependency__('getPurchaseUnit');
        });

        it('If reqData was not provided', () => {
            const result = ppRestApiWrapper.prototype.createOrder(null, paymentAction);

            expect(result).to.be.an('object');
            expect(result).to.have.all.keys('err', 'responseData');
            expect(result.responseData.l_longmessage0).to.equal('');
            expect(createErrorLog.calledWith('Api error')).to.be.true;
        });

        it('If order successfully returned', () => {
            const result = ppRestApiWrapper.prototype.createOrder(reqData, paymentAction);

            expect(result).to.be.an('object');
            expect(result).to.deep.equal({});
        });
    });

    describe('createTransaction', () => {
        let reqData = {};

        before(() => {
            stub(dw.web.Resource, 'msg');
            dw.web.Resource.msg.returns('Error');
        });

        after(() => {
            dw.web.Resource.msg.restore();
        });

        afterEach(() => {
            reqData = {};

            createErrorLog.reset();
        });

        it('If reqData.referenceid was not provided', () => {
            const result = ppRestApiWrapper.prototype.createTransaction(reqData);

            expect(result).to.be.an('object');
            expect(result).to.have.all.keys('err', 'responseData');
            expect(result.responseData.l_longmessage0).to.equal('');
            expect(createErrorLog.calledWith('Error')).to.be.true;
        });

        it('If order was successfully created', () => {
            reqData.referenceid = 'id';

            const result = ppRestApiWrapper.prototype.createTransaction(reqData);

            expect(result).to.be.an('object');
            expect(result.responseData).to.have.all.keys('ack', 'paymentstatus', 'purchaseUnits', 'payer', 'transactionid');
            expect(result.responseData.purchaseUnits).to.deep.equal({});
        });
    });

    describe('doVoid', () => {
        let reqData = {};

        before(() => {
            stub(dw.web.Resource, 'msg');
            dw.web.Resource.msg.returns('Error during voiding');
        });

        after(() => {
            dw.web.Resource.msg.restore();
            createErrorLog.reset();
        });

        afterEach(() => {
            reqData = {};
        });

        it('If reqData.authorizationId was not provided', () => {
            const result = ppRestApiWrapper.prototype.doVoid(reqData);

            expect(result).to.be.an('object');
            expect(result).to.have.all.keys('err', 'responseData');
            expect(result.responseData.l_longmessage0).to.equal('');
            expect(createErrorLog.calledWith('Error during voiding')).to.be.true;
        });

        it('If voiding was successfully performed', () => {
            reqData.authorizationId = 'id';

            const result = ppRestApiWrapper.prototype.doVoid(reqData);

            expect(result).to.be.an('object');
            expect(result).to.deep.equal({
                responseData: {
                    ack: 'SUCCESS'
                },
                status: 'COMPLETED'
            });
        });
    });

    describe('doReauthorize', () => {
        let reqData = {};

        before(() => {
            stub(dw.web.Resource, 'msg');
            dw.web.Resource.msg.withArgs('api.error.noid.during.reauthorization', 'paypalbm', null).returns('Error during reauthorization');
            dw.web.Resource.msg.withArgs('api.error.not.successful.reauthorize', 'paypalbm', null).returns('Error, not successful reauthorize');
        });

        after(() => {
            dw.web.Resource.msg.restore();
        });

        afterEach(() => {
            createErrorLog.reset();
            reauthorizeTransaction.reset();

            reqData = {};
        });

        it('If reqData.authorizationId was not provided', () => {
            const result = ppRestApiWrapper.prototype.doReauthorize(reqData);

            expect(result).to.be.an('object');
            expect(result).to.have.all.keys('err', 'responseData');
            expect(result.responseData.l_longmessage0).to.equal('');
            expect(createErrorLog.calledWith('Error during reauthorization')).to.be.true;
        });

        it('If resp.status !== ppConstants.STATUS_CREATED and error was thrown', () => {
            reqData.authorizationId = 'id';
            reauthorizeTransaction.returns({
                status: 'ERROR'
            });

            const result = ppRestApiWrapper.prototype.doReauthorize(reqData);

            expect(result).to.be.an('object');
            expect(result).to.have.all.keys('err', 'responseData');
            expect(result.responseData.l_longmessage0).to.equal('');
            expect(createErrorLog.calledWith('Error, not successful reauthorize')).to.be.true;
        });

        it('If reauthorization successfully performed', () => {
            reqData.authorizationId = 'id';
            reauthorizeTransaction.returns({
                status: 'CREATED'
            });

            const result = ppRestApiWrapper.prototype.doReauthorize(reqData);

            expect(result).to.be.an('object');
            expect(result).to.deep.equal({
                status: 'CREATED',
                responseData: {
                    ack: 'SUCCESS'
                }
            });
        });
    });

    describe('doRefundTransaction', () => {
        let reqData = {};

        before(() => {
            stub(dw.web.Resource, 'msg');
            dw.web.Resource.msg.withArgs('api.error.no.captureid', 'paypalbm', null).returns('Error no capture id');
            dw.web.Resource.msg.withArgs('api.error.not.successful.refund', 'paypalbm', null).returns('Error, not successful refund');
        });

        after(() => {
            dw.web.Resource.msg.restore();
        });

        afterEach(() => {
            createErrorLog.reset();
            refundTransaction.reset();

            reqData = {};
        });

        it('If reqData.transactionid was not provided', () => {
            const result = ppRestApiWrapper.prototype.doRefundTransaction(reqData);

            expect(result).to.be.an('object');
            expect(result).to.have.all.keys('err', 'responseData');
            expect(result.responseData.l_longmessage0).to.equal('');
            expect(createErrorLog.calledWith('Error no capture id')).to.be.true;
        });

        it('If resp.status !== ppConstants.STATUS_COMPLETED and error was thrown', () => {
            reqData.transactionid = 'id';
            reqData.invNum = '00001';
            reqData.note = 'note';
            reqData.amt = 100;
            reqData.currencyCode = 'USD';

            refundTransaction.returns({
                status: 'ERROR'
            });

            const result = ppRestApiWrapper.prototype.doRefundTransaction(reqData);

            expect(result).to.be.an('object');
            expect(result).to.have.all.keys('err', 'responseData');
            expect(result.responseData.l_longmessage0).to.equal('');
            expect(createErrorLog.calledWith('Error, not successful refund')).to.be.true;
        });

        it('If refund successfully performed', () => {
            reqData.transactionid = 'id';

            refundTransaction.returns({
                status: 'COMPLETED'
            });

            const result = ppRestApiWrapper.prototype.doRefundTransaction(reqData);

            expect(result).to.be.an('object');
            expect(result).to.deep.equal({
                status: 'COMPLETED',
                responseData: {
                    ack: 'SUCCESS'
                }
            });
        });
    });

    describe('doCapture', () => {
        let reqData = {};

        before(() => {
            stub(dw.web.Resource, 'msg');
            dw.web.Resource.msg.returns('Error during capturing');
        });

        after(() => {
            dw.web.Resource.msg.restore();
        });

        afterEach(() => {
            createErrorLog.reset();
            captureTransaction.reset();

            reqData = {};
        });

        it('If reqData.authorizationId was not provided', () => {
            const result = ppRestApiWrapper.prototype.doCapture(reqData);

            expect(result).to.be.an('object');
            expect(result).to.have.all.keys('err', 'responseData');
            expect(result.responseData.l_longmessage0).to.equal('');
            expect(createErrorLog.calledWith('Error during capturing')).to.be.true;
        });

        it('If invoice id and note to payer were not provided', () => {
            reqData.authorizationId = 'id';

            captureTransaction.returns({});

            const result = ppRestApiWrapper.prototype.doCapture(reqData);

            expect(result).to.be.an('object');
            expect(result).to.deep.equal({
                responseData: {
                    ack: 'SUCCESS'
                }
            });
        });

        it('If invoice id and note to payer were provided', () => {
            reqData.authorizationId = 'id';
            reqData.invNum = '00001';
            reqData.note = 'note';

            captureTransaction.returns({
                note: 'note',
                invNum: '00001'
            });

            const result = ppRestApiWrapper.prototype.doCapture(reqData);

            expect(result).to.be.an('object');
            expect(result).to.deep.equal({
                note: 'note',
                invNum: '00001',
                responseData: {
                    ack: 'SUCCESS'
                }
            });
        });
    });

    describe('getOrderDetails', () => {
        let id;

        before(() => {
            stub(dw.web.Resource, 'msg');
            dw.web.Resource.msg.returns('Error, no token or id');
        });

        after(() => {
            dw.web.Resource.msg.restore();
        });

        it('If no id provided', () => {
            const result = ppRestApiWrapper.prototype.getOrderDetails(id);

            expect(result).to.be.an('object');
            expect(result).to.have.all.keys('err', 'responseData');
            expect(result.responseData.l_longmessage0).to.equal('');
            expect(createErrorLog.calledWith('Error, no token or id')).to.be.true;
        });

        it('If order details successfully returned', () => {
            id = 'id';

            const result = ppRestApiWrapper.prototype.getOrderDetails(id);

            expect(result).to.be.an('object');
            expect(result).to.deep.equal({});
        });
    });
});
