const { describe, it } = require('mocha');
const { expect } = require('chai');

const { bm_paypal: { coreHelpersPath } } = require('../path.json');

require('dw-api-mock/demandware-globals');

const coreHelpers = require('proxyquire').noCallThru()(coreHelpersPath, {});

describe('coreHelpers file', () => {
    describe('pluralize', () => {
        const word = 'word';
        let value = 1;

        it('result should be equal to "word" if value is set to 1', () => {
            expect(coreHelpers.pluralize(value, word)).to.equal('word');
        });

        it('result should be equal to "words" if value is set to 2', () => {
            value = 2;
            expect(coreHelpers.pluralize(value, word)).to.equal('words');
        });

        it('result should be equal to "words" if value is set to 2 & plural isn\'t null', () => {
            const plural = 'words';

            expect(coreHelpers.pluralize(value, word, plural)).to.equal('words');
        });
    });

    describe('sortByProperty', () => {
        const arr = [
            { status: 'new' },
            { status: 'open' },
            { status: 'new' }
        ];

        it('result should be a sorted array by object property', () => {
            expect(coreHelpers.sortByProperty(arr, 'status')).to.deep.equal([
                { status: 'new' },
                { status: 'new' },
                { status: 'open' }
            ]);
        });
    });

    describe('filterByProperty', () => {
        const arr = [
            { status: 'new' },
            { status: 'open' },
            { status: 'new' }
        ];

        it('result should be a filtered array by object property value', () => {
            expect(coreHelpers.filterByProperty(arr, 'status', 'open')).to.deep.equal([
                { status: 'open' }
            ]);
        });
    });

    describe('isJson', () => {
        it('result returns false if input value not a string', () => {
            expect(coreHelpers.isJson(50)).to.be.false;
            expect(coreHelpers.isJson(3.14)).to.be.false;
            expect(coreHelpers.isJson([])).to.be.false;
            expect(coreHelpers.isJson({})).to.be.false;
            expect(coreHelpers.isJson(null)).to.be.false;
            expect(coreHelpers.isJson(undefined)).to.be.false;
        });

        it('result returns false if input value is not json', () => {
            expect(coreHelpers.isJson('test')).to.be.false;
        });

        it('result returns false if input value is json', () => {
            const jsonObj = JSON.stringify({});
            const jsonArr = JSON.stringify([{}, {}]);

            expect(coreHelpers.isJson(jsonObj)).to.be.true;
            expect(coreHelpers.isJson(jsonArr)).to.be.true;
        });
    });
});
