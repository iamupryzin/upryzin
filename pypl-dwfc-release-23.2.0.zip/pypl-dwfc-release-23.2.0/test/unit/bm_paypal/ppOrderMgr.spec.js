/* eslint-disable no-underscore-dangle */
const { bm_paypal: { ppOrderMgrPath } } = require('../path.json');

const { expect } = require('chai');
const {
    it, describe, before, after
} = require('mocha');

const { stub } = require('sinon');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const getOrderDetails = stub();
const createErrorLog = stub();
const getPaymentStatus = stub();
const getPaypalPaymentInstrument = stub();
const isPaypalPaymentInstrument = stub();
const getOrder = stub();

let arrayList = {
    arr: [],
    push: (el) => arrayList.arr.push(el),
    sort: () => {},
    toArray: () => [{
        custom: { orderNo: '0000' },
        orderNo: '0000'
    }]
};

const ppOrderMgr = proxyquire(ppOrderMgrPath, {
    'dw/object/SystemObjectMgr': dw.object.SystemObjectMgr,
    'dw/object/CustomObjectMgr': dw.object.CustomObjectMgr,
    'dw/util/ArrayList': () => arrayList,
    'dw/util/StringUtils': {
        formatCalendar: () => '09-11-2022'
    },
    'dw/util/PropertyComparator': () => {},
    'dw/value/Money': () => 5,
    'dw/util/Calendar': () => {},
    'dw/order/Order': {
        PAYMENT_STATUS_PAID: 'PAID'
    },
    'dw/order/OrderMgr': {
        getOrder
    },
    'dw/system/Transaction': dw.system.Transaction,
    'dw/web/Resource': dw.web.Resource,
    '*/cartridge/scripts/paypal/bmPaymentInstrumentHelper': {
        getPaypalPaymentInstrument,
        isPaypalPaymentInstrument
    },
    '*/cartridge/scripts/paypal/bmPaypalHelper': {
        getPaymentStatus
    },
    '*/cartridge/scripts/paypal/bmPaypalUtils': {
        createErrorLog
    },
    '*/cartridge/config/paypalConstants': {
        STATUS_COMPLETED: 'COMPLETED',
        STATUS_REFUNDED: 'REFUNDED'
    },
    '*/cartridge/models/ppOrder': () => ({
        getTransactionIdFromOrder: () => 'transaction-id'
    }),
    '*/cartridge/scripts/paypal/paypalApi/ppRestApiWrapper': () => ({
        getOrderDetails
    })
});

describe('ppOrderMgr file', () => {
    describe('getOrders', () => {
        const getOrders = ppOrderMgr.__get__('getOrders');

        const hasNextSystem = stub();
        const hasNextPP = stub();

        hasNextSystem.onFirstCall().returns(true);
        hasNextPP.onFirstCall().returns(true);
        hasNextSystem.onSecondCall().returns(false);
        hasNextPP.onSecondCall().returns(false);

        before(() => {
            stub(dw.object.SystemObjectMgr, 'querySystemObjects');
            dw.object.SystemObjectMgr.querySystemObjects.returns({
                hasNext: hasNextSystem,
                next: () => ({
                    creationDate: '2022-11-09',
                    orderToken: 'token',
                    orderNo: '0000',
                    createdBy: 'test',
                    customer: { registered: true },
                    customerName: 'name',
                    customerEmail: 'email',
                    totalGrossPrice: 100,
                    status: { displayValue: 'CANCELLED' },
                    custom: {},
                    externalOrderNo: 'O-9RR85649FD345344Y',
                    getCurrencyCode: () => 'USD'
                })
            });
            stub(dw.object.CustomObjectMgr, 'queryCustomObjects');
            dw.object.CustomObjectMgr.queryCustomObjects.returns({
                hasNext: hasNextPP,
                next: () => ({
                    custom: {
                        orderDate: '2022-11-09',
                        orderTotal: 500,
                        orderNo: '0000',
                        firstName: 'firstname',
                        lastName: 'lastname',
                        email: 'email',
                        paymentStatus: 'AUTHORIZED',
                        currencyCode: 'USD'
                    }
                }),
                getCount: () => 7000
            });

            getPaypalPaymentInstrument.returns({
                custom: { paypalPaymentStatus: 'VOIDED' },
                getPaymentTransaction: () => ({ getAmount: () => 100 })
            });
        });

        after(() => {
            dw.object.SystemObjectMgr.querySystemObjects.restore();
            dw.object.CustomObjectMgr.queryCustomObjects.restore();

            getPaypalPaymentInstrument.reset();
        });

        afterEach(() => {
            isPaypalPaymentInstrument.reset();
            hasNextSystem.reset();

            arrayList = {
                arr: [],
                push: (el) => arrayList.arr.push(el),
                sort: () => { },
                toArray: () => [{
                    custom: { orderNo: '0000' },
                    orderNo: '0000'
                }]
            };
        });

        it('If paypalOrdersCount < maxPaypalOrdersCount and orders returned', () => {
            isPaypalPaymentInstrument.returns(true);
            const result = getOrders();

            expect(result.arr).to.be.an('array');
            expect(result.arr).to.have.length(2);
            expect(result.arr[0]).to.have.all.keys('orderToken', 'orderNo', 'orderDate', 'createdBy', 'isRegestered', 'customer', 'email', 'orderTotal', 'currencyCode', 'paypalAmount', 'status', 'dateCompare', 'isCustom');
        });

        it('If no orders returned', () => {
            isPaypalPaymentInstrument.onFirstCall().returns(false);
            isPaypalPaymentInstrument.onSecondCall().returns(true);
            hasNextSystem.onSecondCall().returns(true);
            hasNextSystem.onThirdCall().returns(false);

            dw.object.CustomObjectMgr.queryCustomObjects.returns({
                hasNext: hasNextPP,
                next: () => ({
                    custom: {
                        orderDate: '2022-11-09',
                        orderTotal: 500,
                        orderNo: '0000',
                        firstName: 'firstname',
                        lastName: 'lastname',
                        email: 'email',
                        paymentStatus: 'AUTHORIZED',
                        currencyCode: 'USD'
                    }
                }),
                getCount: () => 10000
            });

            const result = getOrders('000', 'null');

            expect(result.arr).to.be.an('array');
            expect(result.arr).to.have.length(0);
        });
    });

    describe('updateCustomOrderStatus', () => {
        const updateCustomOrderStatus = ppOrderMgr.__get__('updateCustomOrderStatus');
        const orderNo = '0000';

        before(() => {
            stub(dw.object.CustomObjectMgr, 'getCustomObject');
            dw.object.CustomObjectMgr.getCustomObject.returns({
                custom: {
                    transactionId: 'id'
                }
            });
            stub(dw.web.Resource, 'msg');
            dw.web.Resource.msg.withArgs('transaction.details.error', 'paypalbm', null).returns('Details error');
        });

        after(() => {
            dw.object.CustomObjectMgr.getCustomObject.restore();
            dw.web.Resource.msg.restore();

            getPaymentStatus.reset();
        });

        afterEach(() => {
            createErrorLog.reset();
            getOrderDetails.reset();
        });

        it('If error was thrown', () => {
            getOrderDetails.returns({
                err: true
            });

            expect(() => updateCustomOrderStatus(orderNo)).to.throw(Error, 'Details error');
            expect(createErrorLog.calledOnce).to.be.true;
        });

        it('If custom order status was successfully updated', () => {
            getOrderDetails.returns({
                err: false
            });

            updateCustomOrderStatus(orderNo);
            expect(createErrorLog.calledOnce).to.be.false;
            expect(getPaymentStatus.calledOnce).to.be.true;
        });
    });

    describe('updateOrderStatus', () => {
        const updateOrderStatus = ppOrderMgr.__get__('updateOrderStatus');
        const setPaymentStatus = stub();

        before(() => {
            stub(dw.web.Resource, 'msg');
            dw.web.Resource.msg.withArgs('transaction.details.error', 'paypalbm', null).returns('Details error');

            getPaypalPaymentInstrument.returns({
                custom: {},
                getCustom: () => ({
                    paypalOrderID: 'id'
                })
            });
            getOrder.returns({
                setPaymentStatus
            });
        });

        after(() => {
            getOrder.reset();
            getPaypalPaymentInstrument.reset();
            getPaymentStatus.reset();

            dw.web.Resource.msg.restore();
        });

        afterEach(() => {
            createErrorLog.reset();
            getOrderDetails.reset();
            setPaymentStatus.reset();
        });

        it('If error was thrown', () => {
            getOrderDetails.returns({
                err: true
            });

            expect(() => updateOrderStatus()).to.throw(Error, 'Details error');
            expect(createErrorLog.calledOnce).to.be.true;
        });

        it('If order status was successfully updated and payment status was set', () => {
            getOrderDetails.returns({
                err: false
            });
            getPaymentStatus.returns('REFUNDED');

            updateOrderStatus();

            expect(createErrorLog.calledOnce).to.be.false;
            expect(setPaymentStatus.calledWith('PAID')).to.be.true;
        });

        it('If order status was successfully updated', () => {
            getOrderDetails.returns({
                err: false
            });
            getPaymentStatus.returns('VOIDED');

            updateOrderStatus();

            expect(createErrorLog.calledOnce).to.be.false;
            expect(setPaymentStatus.calledOnce).to.be.false;
        });
    });

    describe('OrderMgrModel', () => {
        it('OrderMgrModel should be a function', () => {
            expect(ppOrderMgr).to.be.a('function');
            expect(ppOrderMgr()).to.equal(undefined);
        });
    });

    describe('getOrderByOrderNo', () => {
        before(() => {
            ppOrderMgr.__set__('getOrders', () => ({}));
        });

        after(() => {
            ppOrderMgr.__ResetDependency__('getOrders');
        });

        it('If orders was successfully returned', () => {
            expect(ppOrderMgr.prototype.getOrderByOrderNo()).to.deep.equal({});
        });
    });

    describe('getOrderByTransactionId', () => {
        before(() => {
            stub(dw.object.SystemObjectMgr, 'querySystemObjects');
            stub(dw.object.CustomObjectMgr, 'queryCustomObjects');

            ppOrderMgr.__set__('getOrders', () => ({}));
        });

        after(() => {
            dw.object.SystemObjectMgr.querySystemObjects.restore();
            dw.object.CustomObjectMgr.queryCustomObjects.restore();

            ppOrderMgr.__ResetDependency__('getOrders');
        });

        it('If orderNo got from paypalOrder', () => {
            dw.object.SystemObjectMgr.querySystemObjects.returns({
                count: 0
            });
            dw.object.CustomObjectMgr.queryCustomObjects.returns({
                count: 1
            });

            expect(ppOrderMgr.prototype.getOrderByTransactionId()).to.deep.equal({});
        });

        it('If orderNo got from systemOrder', () => {
            dw.object.SystemObjectMgr.querySystemObjects.returns({
                count: 1
            });
            dw.object.CustomObjectMgr.queryCustomObjects.returns({
                count: 0
            });

            expect(ppOrderMgr.prototype.getOrderByTransactionId()).to.deep.equal({});
        });
    });

    describe('getAllOrders', () => {
        before(() => {
            ppOrderMgr.__set__('getOrders', () => ({}));
        });

        after(() => {
            ppOrderMgr.__ResetDependency__('getOrders');
        });

        it('If all orders successfully returned', () => {
            expect(ppOrderMgr.prototype.getAllOrders()).to.deep.equal({});
        });
    });

    describe('getOrderByPaymentStatus', () => {
        before(() => {
            ppOrderMgr.__set__('getOrders', () => ({}));
        });

        after(() => {
            ppOrderMgr.__ResetDependency__('getOrders');
        });

        it('If all orders successfully returned', () => {
            expect(ppOrderMgr.prototype.getOrderByPaymentStatus()).to.deep.equal({});
        });
    });

    describe('getCustomOrderInfo', () => {
        before(() => {
            stub(dw.object.CustomObjectMgr, 'getCustomObject');
        });

        after(() => {
            dw.object.CustomObjectMgr.getCustomObject.restore();
        });

        afterEach(() => {
            createErrorLog.reset();
        });

        it('If error appeared and error log created', () => {
            dw.object.CustomObjectMgr.getCustomObject.throws(Error);

            ppOrderMgr.prototype.getCustomOrderInfo();

            expect(createErrorLog.calledOnce).to.be.true;
        });

        it('If custom order info successfully returned', () => {
            dw.object.CustomObjectMgr.getCustomObject.returns({
                custom: { transactionId: 'id' }
            });

            const result = ppOrderMgr.prototype.getCustomOrderInfo();

            expect(result).to.be.an('object');
            expect(result).to.have.all.keys('transactionIdFromOrder', 'order');
            expect(result.order).to.deep.equal({
                custom: { transactionId: 'id' }
            });
        });
    });

    describe('getOrderData', () => {
        const orderNo = '000001';
        const orderToken = 'token';
        let isCustomOrder = true;

        const originalGetCustomOrderInfo = ppOrderMgr.prototype.getCustomOrderInfo;

        before(() => {
            ppOrderMgr.prototype.getCustomOrderInfo = () => ({
                order: {}
            });
            getOrder.returns({});
        });

        after(() => {
            ppOrderMgr.prototype.getCustomOrderInfo = originalGetCustomOrderInfo;
            getOrder.reset();
        });

        afterEach(() => {
            createErrorLog.reset();
        });

        it('If no transaction id from order returned and error was thrown', () => {
            expect(() => ppOrderMgr.prototype.getOrderData(isCustomOrder, orderNo, orderToken)).to.throw(Error);
            expect(createErrorLog.calledOnce).to.be.true;
        });

        it('If order data returned successfully', () => {
            isCustomOrder = false;

            const result = ppOrderMgr.prototype.getOrderData(isCustomOrder, orderNo, orderToken);

            expect(result).to.be.an('object');
            expect(result.transactionIdFromOrder).to.equal('transaction-id');
            expect(result.order).to.deep.equal({});
        });
    });

    describe('updateOrderData', () => {
        const orderNo = '000001';
        const orderToken = 'token';
        let isCustomOrder = true;

        before(() => {
            ppOrderMgr.__set__('updateCustomOrderStatus', () => {
                throw new Error();
            });
            ppOrderMgr.__set__('updateOrderStatus', () => { });
        });

        after(() => {
            ppOrderMgr.__ResetDependency__('updateCustomOrderStatus');
            ppOrderMgr.__ResetDependency__('updateOrderStatus');
        });

        afterEach(() => {
            createErrorLog.reset();
        });

        it('If error appeared while updating custom order status', () => {
            expect(ppOrderMgr.prototype.updateOrderData(orderNo, isCustomOrder, orderToken)).to.be.false;
            expect(createErrorLog.calledOnce).to.be.true;
        });

        it('If order data successfully updated', () => {
            isCustomOrder = false;

            expect(ppOrderMgr.prototype.updateOrderData(orderNo, isCustomOrder, orderToken)).to.be.true;
            expect(createErrorLog.calledOnce).to.be.false;
        });
    });

    describe('createNewTransactionCustomObject', () => {
        before(() => {
            stub(dw.object.CustomObjectMgr, 'createCustomObject');
            dw.object.CustomObjectMgr.createCustomObject.returns({ custom: {} });
            getPaymentStatus.returns('AUTHORIZED');
        });

        after(() => {
            dw.object.CustomObjectMgr.createCustomObject.restore();
            getPaymentStatus.reset();
        });

        afterEach(() => {
            createErrorLog.reset();
        });

        it('If transaction was returned with error and error log created', () => {
            getOrderDetails.returns({
                err: true,
                responseData: {}
            });

            expect(() => ppOrderMgr.prototype.createNewTransactionCustomObject()).to.throw(Error);
            expect(createErrorLog.calledOnce).to.be.true;
        });

        it('If new transaction custom object successfully created', () => {
            getOrderDetails.returns({
                err: false,
                purchase_units: [{
                    invoice_id: 'id',
                    amount: {
                        value: 1,
                        currency_code: 'USD'
                    }
                }],
                create_time: '00:00',
                id: 'id',
                payer: {
                    name: {
                        given_name: 'given_name',
                        surname: 'surname'
                    }
                }
            });

            ppOrderMgr.prototype.createNewTransactionCustomObject();

            expect(dw.object.CustomObjectMgr.createCustomObject.calledOnce).to.be.true;
            expect(getPaymentStatus.calledOnce).to.be.true;
        });
    });
});
