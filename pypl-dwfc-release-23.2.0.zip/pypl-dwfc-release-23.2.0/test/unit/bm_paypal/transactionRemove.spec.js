const { bm_paypal: { transactionRemovePath } } = require('../path.json');

const proxyquire = require('proxyquire').noCallThru();
const { expect } = require('chai');
const { describe, it, after } = require('mocha');
const { stub } = require('sinon');

const queryCustomObjects = stub();
const transactions = [{}];

const transactionRemove = proxyquire(transactionRemovePath, {
    'dw/object/CustomObjectMgr': {
        remove: () => transactions.pop(),
        queryCustomObjects
    }
});

require('dw-api-mock/demandware-globals');

describe('transactionRemove', () => {
    after(() => {
        queryCustomObjects.reset();
    });

    it('transactionRemove has property execute', function() {
        expect(transactionRemove).has.property('execute');
    });

    it('transactionRemove execute is function', function() {
        expect(transactionRemove.execute).to.be.a('function');
    });

    it('transactionRemove execute returns undefined', () => {
        queryCustomObjects.returns({
            hasNext: () => false,
            next: () => false
        });

        expect(transactionRemove.execute()).to.be.a('undefined');
    });

    it('transactionRemove execute should remove a transaction', () => {
        queryCustomObjects.returns({
            hasNext: () => transactions.length,
            next: () => true
        });
        transactionRemove.execute();

        expect(transactions).to.have.lengthOf(0);
    });
});
