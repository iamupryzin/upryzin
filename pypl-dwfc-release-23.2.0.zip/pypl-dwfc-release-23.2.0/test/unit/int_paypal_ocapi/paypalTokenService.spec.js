const { int_paypal_ocapi: { paypalTokenServicePath } } = require('../path.json');

const {
    describe, it, before, after
} = require('mocha');

const { expect } = require('chai');
const { stub } = require('sinon');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');
require('babel-register')({
    plugins: ['babel-plugin-rewire']
});

const ServiceCredential = () => {};

const paypalTokenService = proxyquire(paypalTokenServicePath, {
    'dw/web/Resource': dw.web.Resource,
    'dw/svc/ServiceCredential': ServiceCredential,
    'dw/svc/LocalServiceRegistry': {
        createService: (name, obj) => ({
            createRequest: obj.createRequest,
            parseResponse: obj.parseResponse,
            filterLogMessage: obj.filterLogMessage,
            getRequestLogMessage: obj.getRequestLogMessage,
            getResponseLogMessage: obj.getResponseLogMessage
        })
    },
    '*/cartridge/scripts/paypal/helpers/paypalHelper': {
        getAccessToken: () => 'accessToken',
        getUrlPath: () => {}
    },
    '*/cartridge/scripts/util/paypalConstants': {
        ACCESS_TOKEN: 'ACCESS_TOKEN',
        USER_INFO: 'USER_INFO',
        VERIFY_WH_SIG: 'VERIFY_WH_SIG'
    }
});

describe('paypalRestService file', () => {
    const service = paypalTokenService();

    describe('createRequest', () => {
        const serviceInstance = {
            configuration: { credential: new ServiceCredential() },
            setURL: () => {},
            setRequestMethod: () => {},
            addHeader: function() {
                return [...arguments][0].includes('Authorization')
                    ? Object.assign(this.headers, { authorization: [...arguments].join(' ') })
                    : Object.assign(this.headers, { contentType: [...arguments].join(' ') });
            },
            headers: {
                authorization: null,
                contentType: null
            }
        };

        const requestData = {
            requestType: null,
            code: 'code',
            accessToken: 'accessTokenFromRequest',
            whObject: {}
        };

        before(() => {
            stub(dw.web.Resource, 'msgf').withArgs('service.nocredentials', 'paypalerrors', null, 'int_paypal.http.token.service').returns('no credentials');
        });

        after(() => {
            dw.web.Resource.msgf.restore();
        });

        it('response should be an error if service credentials aren\'t instance of ServiceCredential', () => {
            serviceInstance.configuration.credential = null;

            expect(() => service.createRequest(serviceInstance, requestData)).to.throw('no credentials');
        });

        it('response should be empty string & header Authorization added', () => {
            serviceInstance.configuration.credential = new ServiceCredential();

            expect(service.createRequest(serviceInstance, requestData)).to.equal('');
            expect(serviceInstance.headers.authorization).to.equal('Authorization Basic accessToken');
        });

        it('response shouldn\'t be empty string & headers Authorization & Content-Type added if requestType is ACCESS_TOKEN', () => {
            requestData.requestType = 'ACCESS_TOKEN';

            expect(service.createRequest(serviceInstance, requestData)).to.equal('grant_type=authorization_code&code=code');
            expect(serviceInstance.headers.authorization).to.equal('Authorization Basic accessToken');
            expect(serviceInstance.headers.contentType).to.equal('Content-Type application/x-www-form-urlencoded;charset=UTF-8');
        });

        it('response should be empty string & headers Authorization & Content-Type added if requestType is USER_INFO', () => {
            requestData.requestType = 'USER_INFO';

            expect(service.createRequest(serviceInstance, requestData)).to.equal('');
            expect(serviceInstance.headers.authorization).to.equal('Authorization Bearer accessTokenFromRequest');
            expect(serviceInstance.headers.contentType).to.equal('Content-Type application/json');
        });

        it('response should be empty string & headers Authorization & Content-Type added if requestType is VERIFY_WH_SIG', () => {
            requestData.requestType = 'VERIFY_WH_SIG';

            expect(service.createRequest(serviceInstance, requestData)).to.equal('{}');
            expect(serviceInstance.headers.authorization).to.equal('Authorization Basic accessToken');
            expect(serviceInstance.headers.contentType).to.equal('Content-Type application/json');
        });
    });

    describe('parseResponse', () => {
        it('response should be a parsed object', () => {
            expect(service.parseResponse({}, { text: '{"prop": "value"}' })).to.be.deep.equal({ prop: 'value' });
        });
    });

    describe('filterLogMessage', () => {
        it('response should be log message returned', () => {
            expect(service.filterLogMessage('msg')).to.be.equal('msg');
        });
    });

    describe('getRequestLogMessage', () => {
        it('response should be request log message returned', () => {
            expect(service.getRequestLogMessage('request')).to.be.equal('request');
        });
    });

    describe('getResponseLogMessage', () => {
        it('response should be response log message returned', () => {
            expect(service.getResponseLogMessage({ text: 'response' })).to.be.equal('response');
        });
    });
});
