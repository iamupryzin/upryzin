const { int_paypal_ocapi: { addressHelperPath } } = require('../path.json');

const {
    describe, it, before, after
} = require('mocha');

const { expect } = require('chai');
const { stub } = require('sinon');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');

const addressHelper = proxyquire(addressHelperPath, {
    'dw/order/BasketMgr': dw.order.BasketMgr
});

describe('addressHelper file', () => {
    describe('getBAShippingAddress', () => {
        const shippingAddress = {
            getAddress1: () => 'address1',
            getCity: () => 'city',
            getStateCode: () => 'stateCode',
            getPostalCode: () => 'postalCode',
            getCountryCode: () => ({ getValue: () => 'countryCode' }),
            getFullName: () => 'fullName'
        };

        const responseObj = {
            city: 'city',
            country_code: 'countryCode',
            line1: 'address1',
            postal_code: 'postalCode',
            recipient_name: 'fullName',
            state: 'stateCode'
        };

        it('response should deep equal responseObj', () => {
            expect(addressHelper.getBAShippingAddress(shippingAddress)).to.deep.equal(responseObj);
        });
    });

    describe('createShippingAddress', () => {
        const shippingAddress = {
            address1: 'address1',
            address2: 'address2',
            city: 'city',
            stateCode: 'stateCode',
            postalCode: 'postalCode',
            countryCode: { value: 'countryCode' },
            fullName: 'fullName'
        };

        const responseObj = {
            name: { full_name: 'fullName' },
            address: {
                address_line_1: 'address1',
                address_line_2: 'address2',
                admin_area_1: 'stateCode',
                admin_area_2: 'city',
                postal_code: 'postalCode',
                country_code: 'COUNTRYCODE'
            }
        };

        it('response should deep equal responseObj', () => {
            expect(addressHelper.createShippingAddress(shippingAddress)).to.deep.equal(responseObj);
        });
    });

    describe('createBillingAddressFromOrder', () => {
        const customerData = {
            name: {
                given_name: 'name',
                surname: 'surname'
            },
            address: {
                address_line_1: 'address1',
                address_line_2: 'address2',
                admin_area_1: 'stateCode',
                admin_area_2: 'city',
                postal_code: 'postalCode',
                country_code: 'COUNTRYCODE'
            },
            phone: {
                phone_number: { national_number: 'national_number' }
            },
            email_address: 'email'
        };

        const responseObj = {
            firstName: 'name',
            lastName: 'surname',
            countryCode: 'COUNTRYCODE',
            city: 'city',
            address1: 'address1',
            address2: 'address2',
            postalCode: 'postalCode',
            stateCode: 'stateCode',
            phone: 'national_number',
            email: 'email'
        };

        before(() => {
            stub(dw.order.BasketMgr, 'getCurrentBasket');
        });

        after(() => {
            dw.order.BasketMgr.getCurrentBasket.restore();
        });

        it('response should deep equal responseObj', () => {
            dw.order.BasketMgr.getCurrentBasket.returns({ customer: {} });

            expect(addressHelper.createBillingAddressFromOrder(customerData)).to.deep.equal(responseObj);
        });

        it('response property address2 should be empty string if it is null in customerData', () => {
            customerData.address.address_line_2 = null;

            expect(addressHelper.createBillingAddressFromOrder(customerData)).to.have.property('address2', '');
        });

        it('response property email should be taken from basket.profile if it is exists', () => {
            dw.order.BasketMgr.getCurrentBasket.returns({
                customer: {
                    profile: { email: 'emailFromBasket' }
                }
            });

            expect(addressHelper.createBillingAddressFromOrder(customerData)).to.have.property('email', 'emailFromBasket');
        });
    });
});
