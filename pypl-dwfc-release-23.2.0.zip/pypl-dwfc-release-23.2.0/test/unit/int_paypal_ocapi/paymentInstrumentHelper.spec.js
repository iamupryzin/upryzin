const { int_paypal_ocapi: { paymentInstrumentHelperPath } } = require('../path.json');

const { describe, it } = require('mocha');
const { expect } = require('chai');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');

const paymentInstrumentHelper = proxyquire(paymentInstrumentHelperPath, {
    'dw/value/Money': () => ({
        add: (amount) => amount
    }),
    '*/cartridge/scripts/util/paypalConstants': {
        PAYMENT_METHOD_ID_PAYPAL: 'PAYMENT_METHOD_ID_PAYPAL'
    }
});

describe('paymentInstrumentHelper file', () => {
    describe('calculateNonGiftCertificateAmount', () => {
        const lineItemCtnr = {
            currencyCode: 'USD',
            totalGrossPrice: {
                price: 100,
                subtract: function(amount) {
                    return this.price - amount;
                }
            },
            getGiftCertificatePaymentInstruments: () => ({
                giftCertificatePI: [{
                    getPaymentTransaction: () => ({
                        getAmount: () => 10
                    })
                }],
                iterator: function() {
                    return new dw.util.Iterator(this.giftCertificatePI);
                }
            })
        };

        it('response should be amount minus gift certificate amount', () => {
            expect(paymentInstrumentHelper.calculateNonGiftCertificateAmount(lineItemCtnr)).to.equal(90);
        });
    });

    describe('getPaypalPaymentInstrument', () => {
        const basket = {
            paymentInstruments: [{ pmID: 'PAYMENT_METHOD_ID_CREDIT' }, { pmID: 'PAYMENT_METHOD_ID_PAYPAL' }],
            getPaymentInstruments: function(pmID) {
                return this.paymentInstruments.filter((pi) => pi.pmID === pmID);
            }
        };

        it('response should be paypal payment instrument returned', () => {
            expect(paymentInstrumentHelper.getPaypalPaymentInstrument(basket)).to.deep.equal({ pmID: 'PAYMENT_METHOD_ID_PAYPAL' });
        });
    });
});
