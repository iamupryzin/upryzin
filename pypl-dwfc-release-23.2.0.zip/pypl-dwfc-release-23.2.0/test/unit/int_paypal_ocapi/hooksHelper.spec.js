const { int_paypal_ocapi: { hooksHelperPath } } = require('../path.json');

const { describe, it } = require('mocha');
const { expect } = require('chai');

const proxyquire = require('proxyquire').noCallThru();

require('dw-api-mock/demandware-globals');

const hooksHelper = proxyquire(hooksHelperPath, {
    'dw/system/Status': dw.system.Status,
    '~/cartridge/scripts/util/paypalConstants': {
        CUSTOM_ERROR_TYPE: 'CUSTOM_ERROR_TYPE'
    },
    '~/cartridge/scripts/paypal/paypalUtils': {
        createErrorLog: () => {}
    }
});

describe('hooksHelper', () => {
    describe('createObjectFromQueryString', () => {
        it('response shouldn\'t be an empty object if httpQueryString in request isn\'t null', () => {
            request.httpQueryString = {
                split: () => 'q1=sth&q2=sth_else'.split('&')
            };

            expect(hooksHelper.createObjectFromQueryString()).to.deep.equal({ q1: 'sth', q2: 'sth_else' });
        });

        it('response should be an empty object if there\'s no httpQueryString in request', () => {
            request.httpQueryString = null;

            expect(hooksHelper.createObjectFromQueryString()).to.deep.equal({});
        });
    });

    describe('createErrorStatus', () => {
        const error = {};

        it('response should include property code with value CUSTOM_ERROR_TYPE if error object doesn\'t include value for its code property', () => {
            expect(hooksHelper.createErrorStatus(error)).to.include({ code: 'CUSTOM_ERROR_TYPE' });
        });

        it('response should include property message with error object as its value if error object itself doesn\'t include value for message property', () => {
            expect(hooksHelper.createErrorStatus(error)).to.have.property('message').that.deep.equals({});
        });

        it('response should include property code with value CUSTOM_ERROR_TYPE if error object doesn\'t include values for its message and code properties', () => {
            error.code = 'err_code';
            error.message = 'err_message';

            expect(hooksHelper.createErrorStatus(error)).to.include({ code: 'err_code', message: 'err_message' });
        });
    });
});
