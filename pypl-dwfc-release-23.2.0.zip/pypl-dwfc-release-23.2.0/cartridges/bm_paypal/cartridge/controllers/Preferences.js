'use strict';

/* global request response */

/**
 * Get site preference groups
 */
function groups() {
    response.redirect(require('dw/web/URLUtils').url('ViewApplication-BM',
        'screen',
        'preference#site_preference_groups'));
}

groups.public = true;

exports.Groups = groups;
