module.exports = {
    // search types
    SEARCH_BY_TRANSACTION_ID: 'SEARCH_BY_TRANSACTION_ID',
    SEARCH_BY_ORDER_NUMBER: 'SEARCH_BY_ORDER_NUMBER',
    SEARCH_BY_PAYMENT_STATUS: 'SEARCH_BY_PAYMENT_STATUS',
    // intents
    INTENT_CAPTURE: 'CAPTURE',
    INTENT_AUTHORIZE: 'AUTHORIZE',
    // statuses
    STATUS_COMPLETED: 'COMPLETED',
    STATUS_CAPTURED: 'CAPTURED',
    STATUS_REFUNDED: 'REFUNDED',
    STATUS_CREATED: 'CREATED',
    STATUS_SAVED: 'SAVED',
    STATUS_CANCELLED: 'CANCELLED',
    // payment actions
    PAYMENT_ACTION_AUTHORIZATION: 'Authorization',
    PAYMENT_ACTION_AUTHORIZE: 'authorize',
    PAYMENT_ACTION_CAPTURE: 'capture',
    // transaction actions
    ACTION_CREATE_TRANSACTION: 'CreateTransaction',
    ACTION_VOID: 'DoVoid',
    ACTION_REAUTHORIZE: 'DoReauthorize',
    ACTION_AUTHORIZE: 'DoAuthorize',
    ACTION_REFUND: 'DoRefundTransaction',
    ACTION_CAPTURE: 'DoCapture',
    // payment method id
    PAYMENT_METHOD_ID_PAYPAL: 'PayPal',
    // service
    SERVICE_NAME: 'int_paypal.http.rest',
    // etc.
    UNKNOWN: 'Unknown',
    PARTNER_ATTRIBUTION_ID: 'SFCC_EC_B2C_23_1_0',
    ACTION_STATUS_SUCCESS: 'Success',
    TOKEN_TYPE_BILLING_AGREEMENT: 'BILLING_AGREEMENT',
    INVALID_CLIENT: 'invalid_client',
    INVALID_RESOURCE_ID: 'invalid_resource_id',
    // https://developer.paypal.com/docs/api/payments/v1/#definition-related_resources
    TRANSACTION_STATUSES: [
        'CREATED', 'PARTIALLY_CAPTURED', 'CAPTURED',
        'VOIDED', 'PENDING', 'AUTHORIZED', 'COMPLETED',
        'REFUNDED', 'PARTIALLY_REFUNDED', 'CANCELLED',
        'EXPIRED', 'DENIED', 'DECLINED', 'FAILED'
    ],
    TRANSACTION_FAILED_STATUSES: [
        'EXPIRED', 'DENIED', 'DECLINED', 'FAILED'
    ],
    // Instances
    INSTANCE_PRODUCTION: 'production',
    INSTANCE_SANDBOX: 'sandbox'
};
