'use strict';

/**
 * Pluralize
 * @param {number} value number value
 * @param {string} word word to pluralize
 * @param {string} plural word in plural
 * @returns {string} original or converted word
 */
function pluralize(value, word, plural) {
    return [1, -1].includes(Number(value)) ? word : (plural || word + 's');
}

/**
 * Sort array of objects by property
 * @param {Object[]} array array of objects
 * @param {string} property property of object
 * @returns {Object[]} array of objects
 */
function sortByProperty(array, property) {
    return array.sort(function(prev, next) {
        return prev[property] > next[property] ? 1 : -1;
    });
}

/**
 * Filter array of objects by property
 * @param {Object[]} array array of objects
 * @param {string} property property of object
 * @param {string} value by which value to filter
 * @returns {Object[]} filtered array of objects
 */
function filterByProperty(array, property, value) {
    return array.filter(function(item) {
        return item[property] === value;
    });
}

/**
 * Determines whether the given input is valid JSON or not.
 *
 * @param {string} input - The input value to check.
 * @returns {boolean} - `true` if the input is valid JSON, `false` otherwise.
 */
function isJson(input) {
    if (typeof input !== 'string') {
        return false;
    }

    try {
        const parsedJson = JSON.parse(input);
        const parsedType = Object.prototype.toString.call(parsedJson);

        return parsedType === '[object Object]' || parsedType === '[object Array]';
    } catch (error) {
        return false;
    }
}

module.exports = {
    isJson: isJson,
    pluralize: pluralize,
    sortByProperty: sortByProperty,
    filterByProperty: filterByProperty
};
