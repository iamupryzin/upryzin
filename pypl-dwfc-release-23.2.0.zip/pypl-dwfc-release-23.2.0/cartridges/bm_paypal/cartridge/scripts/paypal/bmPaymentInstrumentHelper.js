'use strict';

var PaymentMgr = require('dw/order/PaymentMgr');

var allowedProcessorsIds = 'PAYPAL';

/**
 * Returns paypal payment method ID
 * @returns {string} active paypal payment method id
 */
function getPaypalPaymentMethodId() {
    var activePaymentMethods = PaymentMgr.getActivePaymentMethods();
    var paypalPaymentMethodID;

    Array.some(activePaymentMethods, function(paymentMethod) {
        if (paymentMethod.paymentProcessor.ID === allowedProcessorsIds) {
            paypalPaymentMethodID = paymentMethod.ID;

            return true;
        }

        return false;
    });

    return paypalPaymentMethodID;
}

/**
 * Returns PayPal order payment instrument
 * @param {dw.order.Order} order - The order object
 * @returns {dw.order.OrderPaymentInstrument} payment instrument with id PAYPAL
 */
function getPaypalPaymentInstrument(order) {
    var paymentInstruments = order.getPaymentInstruments(getPaypalPaymentMethodId());

    return !empty(paymentInstruments) && paymentInstruments[0];
}

/**
 * It updates the payment instrument of the order with the payment status of the transaction.
 * @param {dw.web.HttpParameterMap} httpParameterMap - The object that contains the parameters that are passed to the script.
 * @param {boolean} isCustomOrder - shows if an order transaction created via the "New Transaction" form in BM
 */
function updatePaypalPaymentInstrument(httpParameterMap, isCustomOrder) {
    const Transaction = require('dw/system/Transaction');

    const PPOrderMgrModel = require('*/cartridge/models/ppOrderMgr');
    const PPTransactionMgrModel = require('*/cartridge/models/ppTransactionMgr');
    const PPTransactionModel = require('*/cartridge/models/ppTransaction');

    const ppOrderMgrModel = new PPOrderMgrModel();
    const ppTransactionMgrModel = new PPTransactionMgrModel();

    const orderData = ppOrderMgrModel.getOrderData(isCustomOrder, httpParameterMap.orderNo.stringValue, httpParameterMap.orderToken.stringValue);
    const transaction = ppTransactionMgrModel.getTransactionData(httpParameterMap, orderData.transactionIdFromOrder);
    const ppTransactionModel = new PPTransactionModel(transaction, orderData.order, isCustomOrder);
    const paymentInstrument = getPaypalPaymentInstrument(orderData.order);

    Transaction.wrap(function() {
        paymentInstrument.custom.paypalPaymentStatus = ppTransactionModel.paymentstatus;
    });
}

/**
 * If the order has a payment instrument with the ID of the PayPal payment method, return true
 * @param {dw.order.Order} order - The order object
 * @returns {boolean} returns true, if the order has a payment instrument with PayPal ID
 */
function isPaypalPaymentInstrument(order) {
    return !empty(order.getPaymentInstruments(getPaypalPaymentMethodId()));
}

module.exports = {
    isPaypalPaymentInstrument: isPaypalPaymentInstrument,
    getPaypalPaymentInstrument: getPaypalPaymentInstrument,
    updatePaypalPaymentInstrument: updatePaypalPaymentInstrument
};
