'use strict';

/* global empty dw request session customer */

const Logger = require('dw/system/Logger');
const Resource = require('dw/web/Resource');
const Calendar = require('dw/util/Calendar');
const OrderMgr = require('dw/order/OrderMgr');
const StringUtils = require('dw/util/StringUtils');
const CustomObjectMgr = require('dw/object/CustomObjectMgr');

const coreHelpers = require('*/cartridge/scripts/helpers/coreHelpers');
const ppConstants = require('*/cartridge/config/paypalConstants');
const paypalUtils = require('*/cartridge/scripts/paypal/bmPaypalUtils');
const paymentInstrumentHelper = require('*/cartridge/scripts/paypal/bmPaymentInstrumentHelper');

const paypalHelper = {};

/**
 * Remove underscore and capitalize first letter in payment status
 * @param {string} paymentStatus payment status
 * @return {string} Formatted payment status
 */
paypalHelper.parseStatus = function(paymentStatus) {
    let result = null;

    try {
        const status = paymentStatus.toLowerCase();
        const firstLetter = status.charAt(0);

        result = status.replace(/_/g, ' ').replace(firstLetter, firstLetter.toUpperCase());
    } catch (error) {
        Logger.getLogger('PayPal-BM', 'PayPal_General').error(error);
    }

    return result;
};

/**
 * Creates invoice number for custom transaction (created via 'create transaction' button in BM)
 * @returns {string} invoice number
 */
paypalHelper.createCustomTransactionInvNum = function() {
    let invNum = OrderMgr.createOrderSequenceNo();

    try {
        if (!empty(OrderMgr.queryOrder('orderNo = {0}', invNum))) {
            invNum = OrderMgr.createOrderSequenceNo();
        }
    } catch (error) {
        paypalUtils.createErrorLog(error);
    }

    return 'pp_' + invNum;
};

/**
 * Creates an array of objects with countries. Each object contains a label and a value of separate country.
 * @returns {Array} Array of objects.
 */
paypalHelper.getCountriesLabelsAndCodes = function() {
    const countriesCode = require('*/countriesCodes');

    return countriesCode.map(function(code) {
        return {
            value: code,
            label: Resource.msg('country.' + code.toLocaleLowerCase(), 'paypalbm', null)
        };
    });
};

/**
 * Returns boolean value whether search query inputs are empty or not
 * @param {string} transactionId transaction Id
 * @param {string} orderNo order No
 * @param {string} paymentStatus payment status
 * @returns {boolean} value
 */
paypalHelper.isSearchQueryEmpty = function(transactionId, orderNo, paymentStatus) {
    return empty(transactionId.stringValue) && empty(orderNo.stringValue) && empty(paymentStatus.stringValue);
};

/**
 * Gets search type based on submitted search query
 * @param {string} transactionId transaction Id
 * @param {string} paymentStatus payment status
 * @returns {string} search type
 */
paypalHelper.getSearchType = function(transactionId, paymentStatus) {
    let searchType = ppConstants.SEARCH_BY_ORDER_NUMBER;
    const isSearchByTransactionId = transactionId.submitted;
    const isSearchByPaymentStatus = paymentStatus.submitted && !empty(paymentStatus.stringValue);

    if (isSearchByTransactionId) {
        searchType = ppConstants.SEARCH_BY_TRANSACTION_ID;
    } else if (isSearchByPaymentStatus) {
        searchType = ppConstants.SEARCH_BY_PAYMENT_STATUS;
    }

    return searchType;
};

/**
 * Returns Formated Date
 * @param {string} isoString - iso time String
 * @returns {dw.util.StringUtils} formated creation date
 */
paypalHelper.formatedDate = function(isoString) {
    const formatedString = isoString.replace('Z', '.000Z');

    return StringUtils.formatCalendar(new Calendar(new Date(formatedString)), 'M/dd/yy h:mm a');
};

/**
 * Returns transaction end time, result
 * (min) transaction lifetime (by default 72h or 4320min)
 * @param {string} creationDate  date
 * @returns {boolean} true or false
 */
paypalHelper.isExpiredHonorPeriod = function(creationDate) {
    const min = 4320;

    // For testing after 3 mins reauthorize button appears.
    return Date.now() >= new Date(creationDate.replace('Z', '.000Z')).getTime() + min * 60000;
};

/**
 * Returns transaction payment status
 * @param  {Object} transactionResponse transaction details
 * @returns {string} payment status
 */
paypalHelper.getPaymentStatus = function(transactionResponse) {
    const payments = transactionResponse.purchase_units[0].payments;
    let paymentStatus;

    if (payments.captures) {
        paymentStatus = payments.captures[0].status;
    } else {
        paymentStatus = payments.authorizations[0].status;
    }

    return paymentStatus;
};

/**
 * Returns payment action: authorize/capture
 * @param  {string} paymentAction Authorization/Sale
 * @returns {string} payment action for api call
 */
paypalHelper.getPaymentActionType = function(paymentAction) {
    return paymentAction === ppConstants.PAYMENT_ACTION_AUTHORIZATION
        ? ppConstants.PAYMENT_ACTION_AUTHORIZE : ppConstants.PAYMENT_ACTION_CAPTURE;
};

/**
 * Returns Transaction Statistics of payment statuses
 * @returns {Object[]} an array with the number of orders for each payment status
 */
paypalHelper.getPaymentStatusTransactionStatistics = function() {
    let order;
    let status;
    let statuses = {};

    const PPOrderMgrModel = require('*/cartridge/models/ppOrderMgr');

    const TRANSACTION_STATUSES = ppConstants.TRANSACTION_STATUSES;
    const FAILED_STATUSES = ppConstants.TRANSACTION_FAILED_STATUSES;

    // to search for orders for which the value of the field is not set
    FAILED_STATUSES.push(null);
    TRANSACTION_STATUSES.push(null);

    const orders = (new PPOrderMgrModel()).getAllOrders();
    const iterator = orders.iterator();

    while (iterator.hasNext()) {
        order = iterator.next();
        status = order.status;

        if (status in statuses) {
            statuses[status].count++;
        } else {
            statuses[status] = {
                count: 1,
                value: status,
                label: status ? paypalHelper.parseStatus(status) : 'N/A',
                color: FAILED_STATUSES.includes(status) ? 'failure' : 'success'
            };
        }
    }

    const statusesArr = Object.keys(statuses).map(function(key) {
        const statusItem = statuses[key];
        const plural = coreHelpers.pluralize(statusItem.count, Resource.msg('transaction.word', 'paypalbm', null));

        statusItem.title = [statusItem.label, plural].join(' ');

        return statusItem;
    });

    statuses = statusesArr;

    const successfulStatuses = coreHelpers.sortByProperty(coreHelpers.filterByProperty(statuses, 'color', 'success'),
        'value');

    const failedStatuses = coreHelpers.sortByProperty(coreHelpers.filterByProperty(statuses, 'color', 'failure'),
        'value');

    return successfulStatuses.concat(failedStatuses);
};

/**
 * Return an order or object of PayPalNewTransactions custom object
 * @param {*} orderNo Order number
 * @returns {dw.order.Order} Order instance
 */
paypalHelper.getOrderByOrderNo = function(orderNo) {
    return CustomObjectMgr.getCustomObject('PayPalNewTransactions', orderNo) || OrderMgr.queryOrder('orderNo = {0}', orderNo);
};

/**
 * @param {Object} requestData Request data to API call
 * @param {Object} responseData Response data to API call
 * @returns {void}
 */
paypalHelper.saveTransationRequestAndResponse = function(requestData, responseData) {
    const order = paypalHelper.getOrderByOrderNo(requestData.orderNo);

    if (order) {
        const Transaction = require('dw/system/Transaction');

        Transaction.wrap(function() {
            if (order instanceof dw.object.CustomObject) {
                // Updates order of a PayPalNewTransactions Custom Object
                order.custom.paypalRequest = JSON.stringify(requestData);
                order.custom.paypalResponse = JSON.stringify(responseData);
            } else {
                const paymentInstrument = paymentInstrumentHelper.getPaypalPaymentInstrument(order);

                paymentInstrument.custom.paypalRequest = JSON.stringify(requestData);
                paymentInstrument.custom.paypalResponse = JSON.stringify(responseData);
            }
        });
    }
};

/**
 * Get transaction details for paypalTransactionHistory
 * @param {Object} transaction - Transaction data (request, response, amount, status)
 * @param {Object} transaction.request - Request data to API call
 * @param {Object} transaction.response - Response data from API call
 * @param {string} transaction.amount - Total amount
 * @param {string} transaction.status - Payment status
 * @returns {Object} - Transaction history details
 */
function getTransactionHistory(transaction) {
    const dateTime = new Date().toISOString();
    const methodName = transaction.request.methodName;
    const refundType = transaction.request.refundtype || '';

    const status = transaction.status;
    const amount = transaction.request.amt ? transaction.request.amt : transaction.amount;

    return {
        amount: amount,
        status: status,
        timestamp: dateTime,
        refundType: refundType,
        methodName: methodName
    };
}

/**
 * @param {dw.object.CustomObject|dw.order.PaymentInstrument} objectType - a system or custom object type
 * @param {Object} data - object (request, response, amount, status)
 * @returns {string} - a transaction history result
 */
paypalHelper.prepareTransactionHistory = function(objectType, data) {
    let transactionHistory = [];

    const paypalTransactionHistory = objectType.custom.paypalTransactionHistory;

    if (coreHelpers.isJson(paypalTransactionHistory)) {
        transactionHistory = JSON.parse(paypalTransactionHistory);
    }

    transactionHistory.push(getTransactionHistory(data));

    return JSON.stringify(transactionHistory);
};

/**
 * @param {Object} requestData Request data to API call
 * @param {Object} responseData Response data from API call
 * @returns {void}
 */
paypalHelper.saveTransactionHistory = function(requestData, responseData) {
    const order = paypalHelper.getOrderByOrderNo(requestData.orderNo);

    if (order) {
        const Transaction = require('dw/system/Transaction');
        const data = { request: requestData, response: responseData };

        Transaction.wrap(function() {
            if (order instanceof dw.object.CustomObject) {
                data.amount = order.custom.orderTotal;
                data.status = order.custom.paymentStatus;
                // Updates order of a PayPalNewTransactions Custom Object
                order.custom.paypalTransactionHistory = paypalHelper.prepareTransactionHistory(order, data);
            } else {
                const paymentInstrument = paymentInstrumentHelper.getPaypalPaymentInstrument(order);
                const paymentTransaction = paymentInstrument.paymentTransaction;

                data.amount = order.totalGrossPrice.value;
                data.status = paymentInstrument.custom.paypalPaymentStatus;

                paymentTransaction.custom.paypalTransactionHistory = paypalHelper.prepareTransactionHistory(paymentTransaction, data);
            }
        });
    }
};

module.exports = paypalHelper;
