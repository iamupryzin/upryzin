'use strict';

const baseConstants = module.superModule;

// Page flows
baseConstants.PAGE_FLOW_PLP = 'plp';
// OCAPI query parameter
baseConstants.QUERY_PARAMETER_CURRENCY_CODE = 'currencyCode';
baseConstants.QUERY_PARAMETER_CURRENCY_CODE_VALUE = 'GBP';
baseConstants.QUERY_PARAMETER_COUNTRY_CODE = 'countryCode';
baseConstants.QUERY_PARAMETER_COUNTRY_CODE_VALUE = 'GB';
baseConstants.QUERY_PARAMETER_PAGE_ID = 'pageId';
baseConstants.ALLOWED_QUERY_PARAMETER_PAGE_IDS = ['plp', 'pdp', 'cart', 'minicart', 'billing'];
// Intent types
baseConstants.INTENT_AUTHORIZE = 'AUTHORIZE';
baseConstants.INTENT_CAPTURE = 'CAPTURE';
// Action type
baseConstants.ACTION_TYPE_AUTHORIZE = 'authorize';
baseConstants.ACTION_TYPE_CAPTURE = 'capture';

module.exports = baseConstants;
