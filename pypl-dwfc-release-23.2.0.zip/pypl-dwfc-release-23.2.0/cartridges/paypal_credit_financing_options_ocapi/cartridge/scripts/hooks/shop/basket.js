'use strict';

const Resource = require('dw/web/Resource');
const Logger = require('dw/system/Logger');
const Status = require('dw/system/Status');

// Helpers and tools
const validationHelper = require('~/cartridge/scripts/paypal/helpers/validationHelper');
const hookHelper = require('*/cartridge/scripts/paypal/helpers/hooksHelper');
const paypalConstants = require('~/cartridge/scripts/util/paypalConstants');
const financialPreferences = require('~/cartridge/config/financialPreferences');

// Hook dw.ocapi.shop.product.beforeGET functionality

/**
 * The hook that performs validation of request query prameters
 * @returns {Status} returns a custom error object in a case of mistake with required query parameters
* */
function beforeGET() {
    try {
        const queryParamsObject = hookHelper.createObjectFromQueryString(request.httpQueryString);

        if (financialPreferences.isActive && !validationHelper.isEmptyObject(queryParamsObject)) {
            const queryParams = Object.keys(queryParamsObject);

            if (!queryParams.includes(paypalConstants.QUERY_PARAMETER_CURRENCY_CODE)
                || !queryParams.includes(paypalConstants.QUERY_PARAMETER_COUNTRY_CODE)
                || !queryParams.includes(paypalConstants.QUERY_PARAMETER_PAGE_ID)) {
                throw new Error(Resource.msg('paypal.query.parameter.not.allowed.name.error', 'paypalerrors', null));
            }

            if (queryParamsObject.countryCode !== paypalConstants.QUERY_PARAMETER_COUNTRY_CODE_VALUE) {
                throw new Error(Resource.msg('paypal.query.parameter.not.allowed.countryCode.error', 'paypalerrors', null));
            }

            if (queryParamsObject.currencyCode !== paypalConstants.QUERY_PARAMETER_CURRENCY_CODE_VALUE) {
                throw new Error(Resource.msg('paypal.query.parameter.not.allowed.currencyCode.error', 'paypalerrors', null));
            }

            if (!paypalConstants.ALLOWED_QUERY_PARAMETER_PAGE_IDS.includes(queryParamsObject.pageId)) {
                throw new Error(Resource.msg('paypal.query.parameter.not.allowed.pageId.error', 'paypalerrors', null));
            }
        }
    } catch (error) {
        Logger.error(error);

        return new Status(Status.ERROR, paypalConstants.CUSTOM_ERROR_TYPE, error);
    }
}

// Hook dw.ocapi.shop.basket.modifyGETResponse functionality

/**
 * The function modify get response by adding custom attributes
 * Used in the follwing resource: /baskets
 * @param {dw.order.Basket} basket The current basket
 * @param {basketResponse} basketResponse Document representing a basket.
 * @returns {Status} new Status. Depends of hook execution OK/ERROR
 */
function modifyGETResponse(basket, basketResponse) {
    const creditFinancialOptionsHelper = require('*/cartridge/scripts/paypal/paypalCreditFinancingOptionsHelper');

    try {
        const queryParamsObject = hookHelper.createObjectFromQueryString(request.httpQueryString);
        const currencyCode = queryParamsObject.currencyCode;
        const countryCode = queryParamsObject.countryCode;
        // Sets a PayPal credit bunner configs for current page

        if (financialPreferences.isActive && !validationHelper.isEmptyObject(queryParamsObject)) {
            const price = basket.totalGrossPrice.value;
            const allOptionsData = creditFinancialOptionsHelper.getDataForAllOptionsBanner(price, currencyCode, countryCode);
            const lowestPossibleMonthlyCost = creditFinancialOptionsHelper.getLowestPossibleMonthlyCost(price, currencyCode, countryCode);

            allOptionsData.lowestPossibleMonthlyCost = {
                value: lowestPossibleMonthlyCost.value,
                currencyCode: lowestPossibleMonthlyCost.currencyCode,
                formatted: lowestPossibleMonthlyCost.formatted
            };
            // Adding c_allOptionsData property for basket response
            basketResponse.c_allOptionsData = allOptionsData;
        }

        basketResponse.c_financialPreferences = financialPreferences;
    } catch (err) {
        Logger.error(err);

        return new Status(Status.ERROR, paypalConstants.CUSTOM_ERROR_TYPE, err);
    }
}

exports.beforeGET = beforeGET;
exports.modifyGETResponse = modifyGETResponse;
