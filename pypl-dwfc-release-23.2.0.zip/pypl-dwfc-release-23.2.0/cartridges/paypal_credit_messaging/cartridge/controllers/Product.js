'use strict';

const page = module.superModule;
const server = require('server');

const Site = require('dw/system/Site');

const {
    getClientId
} = require('*/cartridge/scripts/paypal/paypalUtils');

const {
    cartSdkUrl
} = require('*/cartridge/config/paypalSDK');

const {
    isPaypalButtonEnabled
} = require('*/cartridge/scripts/paypal/helpers/paypalHelper');

const {
    productDetailMessageConfig
} = require('*/cartridge/config/creditMessageConfig');

const {
    addEnableFundigParamPaylater
} = require('*/cartridge/scripts/helpers/enableFundingHelper');

const {
    paypalPaymentMethodId,
    billingAgreementEnabled
} = require('*/cartridge/config/paypalPreferences');

server.extend(page);

server.append('Show', function(req, res, next) {
    const currentSite = Site.getCurrent();
    const paypal = res.getViewData().paypal;
    const sdkUrl = paypal.sdkUrl;
    const creditMessageAvailable = !billingAgreementEnabled
        && paypalPaymentMethodId
        && currentSite.getCustomPreferenceValue('PP_Show_On_PDP');

    paypal.sdkUrl = addEnableFundigParamPaylater(sdkUrl);

    if (creditMessageAvailable) {
        const clientID = getClientId();
        const creditMessageSdk = ['https://www.paypal.com/sdk/js?client-id=', clientID, '&components=messages'].join('');
        const bannerSdkUrl = (isPaypalButtonEnabled('pdp') || isPaypalButtonEnabled('minicart'))
            ? (cartSdkUrl)
            : creditMessageSdk;

        res.setViewData({
            bannerSdkUrl: bannerSdkUrl,
            bannerConfig: productDetailMessageConfig,
            creditMessageAvailable: creditMessageAvailable,
            paypal: paypal
        });
    }

    next();
});

module.exports = server.exports();
