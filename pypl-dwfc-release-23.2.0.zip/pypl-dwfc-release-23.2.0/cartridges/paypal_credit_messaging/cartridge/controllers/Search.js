'use strict';

const page = module.superModule;
const server = require('server');

const Site = require('dw/system/Site');
const BasketMgr = require('dw/order/BasketMgr');

const {
    getClientId
} = require('*/cartridge/scripts/paypal/paypalUtils');

const {
    cartSdkUrl
} = require('*/cartridge/config/paypalSDK');

const {
    isPaypalButtonEnabled
} = require('*/cartridge/scripts/paypal/helpers/paypalHelper');

const {
    categoryMessageConfig
} = require('*/cartridge/config/creditMessageConfig');

const {
    paypalPaymentMethodId,
    billingAgreementEnabled
} = require('*/cartridge/config/paypalPreferences');

server.extend(page);

server.append('Show', function(req, res, next) {
    const currentSite = Site.getCurrent();
    const creditMessageAvailable = !billingAgreementEnabled && paypalPaymentMethodId && currentSite.getCustomPreferenceValue('PP_Show_On_Category');

    if (creditMessageAvailable) {
        const basket = BasketMgr.getCurrentBasket();
        const clientID = getClientId();

        var creditMessageSdk = ['https://www.paypal.com/sdk/js?client-id=', clientID, '&components=messages'].join('');
        var bannerSdkUrl = isPaypalButtonEnabled('minicart') ? (cartSdkUrl) : creditMessageSdk;

        res.setViewData({
            paypal: {
                bannerSdkUrl: bannerSdkUrl,
                bannerConfig: categoryMessageConfig,
                paypalAmount: basket && basket.totalGrossPrice.value
            },
            creditMessageAvailable: creditMessageAvailable
        });
    }

    next();
});

module.exports = server.exports();
