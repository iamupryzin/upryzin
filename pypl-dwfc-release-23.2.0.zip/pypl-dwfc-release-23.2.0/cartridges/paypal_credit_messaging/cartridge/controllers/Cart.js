'use strict';

const page = module.superModule;
const server = require('server');

const Site = require('dw/system/Site');
const BasketMgr = require('dw/order/BasketMgr');

const {
    getClientId
} = require('*/cartridge/scripts/paypal/paypalUtils');

const {
    cartMessageConfig
} = require('*/cartridge/config/creditMessageConfig');

const {
    addEnableFundigParamPaylater
} = require('*/cartridge/scripts/helpers/enableFundingHelper');

const {
    paypalPaymentMethodId,
    billingAgreementEnabled
} = require('*/cartridge/config/paypalPreferences');

server.extend(page);

server.append('Show', function(req, res, next) {
    const currentSite = Site.getCurrent();
    const creditMessageAvailable = !billingAgreementEnabled
        && paypalPaymentMethodId
        && currentSite.getCustomPreferenceValue('PP_Show_On_Cart');

    if (!creditMessageAvailable) {
        return next();
    }

    const paypal = res.getViewData().paypal;
    const sdkUrl = paypal.sdkUrl;

    paypal.sdkUrl = addEnableFundigParamPaylater(sdkUrl);

    this.on('route:BeforeComplete', function(req, res) { // eslint-disable-line no-shadow
        const basket = BasketMgr.getCurrentBasket();

        if (!basket) {
            return;
        }

        const clientID = getClientId();
        const bannerSdkUrl = ['https://www.paypal.com/sdk/js?client-id=', clientID, '&components=messages'].join('');

        res.setViewData({
            paypalAmount: basket.totalGrossPrice.value,
            bannerSdkUrl: bannerSdkUrl,
            bannerConfig: cartMessageConfig,
            creditMessageAvailable: creditMessageAvailable,
            paypal: paypal
        });
    });

    return next();
});

module.exports = server.exports();
