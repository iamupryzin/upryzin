'use strict';

const paypalConstants = require('*/cartridge/scripts/util/paypalConstants');

// Hook dw.ocapi.shop.basket.modifyGETResponse functionality

/**
 * Returns a specific cart / minicart page config object
 * @returns {Object} An object
 */
function getCartPageConfigs() {
    const creditMessageConfig = require('*/cartridge/config/creditMessageConfig');
    const paypalUtils = require('*/cartridge/scripts/paypal/paypalUtils');
    const paypalPreferences = require('*/cartridge/config/paypalPreferences');

    const creditMessageAvaliable = !paypalPreferences.billingAgreementEnabled && paypalPreferences.paypalPaymentMethodId
        && paypalPreferences.cartCreditBannersEnabled;

    if (creditMessageAvaliable) {
        const currentBasket = require('dw/order/BasketMgr').getCurrentBasket();
        const clientID = paypalUtils.getClientId();
        const bannerSdkUrl = paypalConstants.PAYPAL_SDK_HOST + clientID + paypalConstants.PAYPAL_SDK_COMPONENTS_MESSAGES;

        return {
            paypal: {
                bannerSdkUrl: bannerSdkUrl,
                bannerConfig: creditMessageConfig.cartMessageConfig,
                paypalAmount: currentBasket && currentBasket.totalGrossPrice.value
            },
            creditMessageAvaliable: creditMessageAvaliable
        };
    }

    return null;
}

/**
 * The function modify get response by adding custom attributes
 * Used in the follwing resource: /baskets
 * @param {dw.order.Basket} basket The current basket
 * @param {basketResponse} basketResponse Document representing a basket.
 * @returns {Status} new Status. Depends of hook execution OK/ERROR
 */
function modifyGETResponse(basket, basketResponse) {
    try {
        // Add credit banners configuration
        basketResponse.c_paypalCartBannersConfig = getCartPageConfigs();
    } catch (err) {
        const Logger = require('dw/system/Logger');
        const Status = require('dw/system/Status');

        Logger.error(err);

        return new Status(Status.ERROR, paypalConstants.CUSTOM_ERROR_TYPE, err);
    }
}

exports.modifyGETResponse = modifyGETResponse;
