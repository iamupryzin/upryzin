CHANGELOG
=========

## 22.1.0
* SFRA support up to 6.1.0

## 23.1.0
* SFRA base cartridge updated to 6.3.0 version.
* Usage of "actions.order.create" method was removed from client JS side.
* Usage of "actions.order.capture" method was removed from client JS side.
* Pay Now flow added.
* Improvements for the PayPal Transactions in the BM added.
* General small code improvements and bug fixing added.
