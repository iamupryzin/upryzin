CHANGELOG
=========

## 21.3.0
* SFRA support up to 6.0

## 23.1.0
* SFRA base cartridge updated to 6.3.0 version.
* Usage of "actions.order.create" method was removed from client JS side.
* Usage of "actions.order.capture" method was removed from client JS side.
* Pay Now flow added.
* Improvements for the PayPal Transactions in the BM added.
* General small code improvements and bug fixing added.

## 23.2.0
* Credit CTA / Pay Later CTA configuration
* Introduce PayPal CTA to SFRA Quick View
* Local payment methods: BLIK
* BM: Transaction History
* BM: Connect with PayPal CTA style configurator
* BM: PayPal preferences UI
* General stability, test coverage and functionality improvements