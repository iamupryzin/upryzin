'use strict';

/**
 * @namespace Login
 */

const server = require('server');

server.extend(module.superModule);

server.append('Show', function(req, res, next) {
    const viewData = res.getViewData();

    viewData.paypal = {
        sdkUrl: require('*/cartridge/config/paypalSDK').cartSdkUrl
    };

    res.setViewData(viewData);

    next();
});

module.exports = server.exports();
