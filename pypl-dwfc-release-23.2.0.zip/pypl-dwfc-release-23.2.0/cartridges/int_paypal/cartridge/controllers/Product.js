'use strict';

const page = module.superModule;
const server = require('server');

const BasketMgr = require('dw/order/BasketMgr');

const csrfProtection = require('*/cartridge/scripts/middleware/csrf');
const prefs = require('*/cartridge/config/paypalPreferences');
const paypalHelper = require('*/cartridge/scripts/paypal/helpers/paypalHelper');
const paymentInstrumentHelper = require('*/cartridge/scripts/paypal/helpers/paymentInstrumentHelper');
const BillingAgreementModel = require('*/cartridge/models/billingAgreement');
const paypalSDK = require('*/cartridge/config/paypalSDK');

server.extend(page);

server.append('Show', csrfProtection.generateToken, function(_, res, next) {
    const isPdpButtonEnabled = paypalHelper.isPaypalButtonEnabled('pdp');

    if (!prefs.paypalPaymentMethodId || !isPdpButtonEnabled) {
        return next();
    }

    const basket = BasketMgr.getCurrentBasket();
    const paypalPaymentInstrument = basket && paymentInstrumentHelper.getPaypalPaymentInstrument(basket) || null;

    let defaultBA = {};
    let showStaticImage = false;

    if (customer.authenticated && prefs.billingAgreementEnabled) {
        const billingAgreementModel = new BillingAgreementModel();
        const savedPaypalBillingAgreements = billingAgreementModel.getBillingAgreements(true);

        if (!empty(savedPaypalBillingAgreements)) {
            defaultBA = billingAgreementModel.getDefaultBillingAgreement();
            // for PDP page static image is shown only in case when user has saved paypal acounts
            showStaticImage = true;
        }
    }

    res.setViewData({
        paypal: {
            sdkUrl: paypalSDK.cartSdkUrl,
            partnerAttributionId: prefs.partnerAttributionId,
            pdpButtonEnabled: isPdpButtonEnabled,
            buttonConfig: prefs.paypalPdpButtonConfig,
            billingFormFields: paypalHelper.getPreparedBillingFormFields(paypalPaymentInstrument, defaultBA),
            showStaticImage: showStaticImage,
            paypalStaticImageLink: prefs.paypalStaticImageLink,
            defaultBAemail: defaultBA.email,
            billingAgreementEnabled: prefs.billingAgreementEnabled
        }
    });

    paypalHelper.updateViewDataForFraudNet(res);

    return next();
});

server.append('ShowQuickView', csrfProtection.generateToken, function(_, res, next) {
    const basket = BasketMgr.getCurrentBasket();
    const isPvpButtonEnabled = paypalHelper.isPaypalButtonEnabled('pvp');
    const paypalPaymentInstrument = basket && paymentInstrumentHelper.getPaypalPaymentInstrument(basket) || null;

    let defaultBA = {};
    let showStaticImage = false;

    if (customer.authenticated && prefs.billingAgreementEnabled) {
        const billingAgreementModel = new BillingAgreementModel();
        const savedPaypalBillingAgreements = billingAgreementModel.getBillingAgreements(true);

        if (!empty(savedPaypalBillingAgreements)) {
            defaultBA = billingAgreementModel.getDefaultBillingAgreement();
            // for PVP page static image is shown only in case when user has saved paypal acounts
            showStaticImage = true;
        }
    }

    res.setViewData({
        paypal: {
            partnerAttributionId: prefs.partnerAttributionId,
            pvpButtonEnabled: isPvpButtonEnabled,
            buttonConfig: prefs.paypalPvpButtonConfig,
            billingFormFields: paypalHelper.getPreparedBillingFormFields(paypalPaymentInstrument, defaultBA),
            showStaticImage: showStaticImage,
            paypalStaticImageLink: prefs.paypalStaticImageLink,
            defaultBAemail: defaultBA.email,
            billingAgreementEnabled: prefs.billingAgreementEnabled,
            payNowData: {
                isPayNowFlowEnabled: prefs.isPayNowFlowEnabled
            }
        }
    });

    next();
});

module.exports = server.exports();
