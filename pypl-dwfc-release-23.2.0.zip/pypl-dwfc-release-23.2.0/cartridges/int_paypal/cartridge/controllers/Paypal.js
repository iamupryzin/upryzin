/* eslint-disable no-shadow */

'use strict';

const server = require('server');

const Transaction = require('dw/system/Transaction');
const HookMgr = require('dw/system/HookMgr');
const PaymentMgr = require('dw/order/PaymentMgr');
const Money = require('dw/value/Money');
const BasketMgr = require('dw/order/BasketMgr');
const OrderMgr = require('dw/order/OrderMgr');
const Order = require('dw/order/Order');
const Status = require('dw/system/Status');
const URLUtils = require('dw/web/URLUtils');
const Resource = require('dw/web/Resource');

const paypalHelper = require('*/cartridge/scripts/paypal/helpers/paypalHelper');
const middleware = require('*/cartridge/scripts/paypal/middleware');
const csrfProtection = require('*/cartridge/scripts/middleware/csrf');
const userLoggedIn = require('*/cartridge/scripts/middleware/userLoggedIn');
const paypalApi = require('*/cartridge/scripts/paypal/paypalApi');
const utils = require('*/cartridge/scripts/paypal/paypalUtils');
const paymentInstrumentHelper = require('*/cartridge/scripts/paypal/helpers/paymentInstrumentHelper');
const addressHelper = require('*/cartridge/scripts/paypal/helpers/addressHelper');
const loginPayPalAddressHelper = require('*/cartridge/scripts/paypal/helpers/loginPayPalAddressHelper');
const prefs = require('*/cartridge/config/paypalPreferences');
const COHelpers = require('*/cartridge/scripts/checkout/checkoutHelpers');
const BillingAgreementModel = require('*/cartridge/models/billingAgreement');
const CustomerModel = require('*/cartridge/models/customer');
const paypalConstants = require('*/cartridge/config/paypalConstants');
const paypalSDK = require('*/cartridge/config/paypalSDK');

server.get('GetPaypalOrderId', server.middleware.https, csrfProtection.validateAjaxRequest, function(req, res, next) {
    const currentBasket = BasketMgr.currentBasket;

    // Sets a zero amount shiping method to the basket in case of the Pay Now flow
    if (prefs.isPayNowFlowEnabled) {
        addressHelper.applyOnlinePickupShippingMethodToBasket(currentBasket);
    }

    const purchaseUnit = paypalHelper.getPurchaseUnit(currentBasket);
    const result = paypalApi.createOrder(purchaseUnit, currentBasket);

    if (result.err) {
        utils.createErrorLog(result.err);
        res.setStatusCode(500);
        res.json({
            error: true
        });

        return next();
    }

    session.privacy.paypalOrderID = result.resp.id;

    res.json({ id: result.resp.id });

    return next();
});

server.use('UpdateOrderDetails', server.middleware.https, function(req, res, next) {
    const {
        currentBasket
    } = BasketMgr;

    const isCartFlow = req.querystring.isCartFlow === 'true';
    const purchaseUnit = paypalHelper.getPurchaseUnit(currentBasket, isCartFlow);
    const paymentInstrument = paymentInstrumentHelper.getPaypalPaymentInstrument(currentBasket);
    const isUpdateRequired = paypalHelper.isPurchaseUnitChanged(purchaseUnit, paymentInstrument);

    const isAddressNeedChange = req.querystring.isAddressNeedChange === 'true';

    let shippingAddress;

    if (isAddressNeedChange) {
        const shipping = customer.addressBook.preferredAddress;

        shippingAddress = {
            city: shipping.city,
            country_code: shipping.countryCode.value,
            line1: shipping.address1,
            phone: shipping.phone,
            postal_code: shipping.postalCode,
            recipient_name: shipping.fullName,
            state: shipping.stateCode
        };

        if (paymentInstrument.custom.paypalOrderID) {
            if (!paypalHelper.hasOnlyGiftCertificates(currentBasket)) {
                addressHelper.updateOrderShippingAddress(currentBasket, shippingAddress);
            }
        } else {
            addressHelper.updateBAShippingAddress(currentBasket, shippingAddress);
        }
    }

    if (paypalHelper.isExpiredTransaction(paymentInstrument)) {
        paymentInstrumentHelper.removePaypalPaymentInstrument(currentBasket);

        res.setStatusCode(500);
        res.json({
            errorMsg: utils.createErrorMsg('expiredpayment')
        });

        return next();
    }

    if (paymentInstrument.custom.PP_API_ActiveBillingAgreement) {
        if (paymentInstrument.paymentTransaction.amount.value.toString() !== purchaseUnit.amount.value) {
            const newAmount = new Money(purchaseUnit.amount.value, purchaseUnit.amount.currency_code);

            Transaction.wrap(function() {
                paymentInstrument.paymentTransaction.setAmount(newAmount);
            });
        }

        res.json({});

        return next();
    }

    if (isUpdateRequired) {
        if (purchaseUnit.amount.value === '0') {
            res.setStatusCode(500);
            res.json({
                errorMsg: utils.createErrorMsg('zeroamount')
            });

            return next();
        }

        const {
            err
        } = paypalApi.updateOrderDetails(paymentInstrument, purchaseUnit);

        if (err) {
            res.setStatusCode(500);
            res.json({
                errorMsg: err
            });

            return next();
        }

        session.privacy.orderDataHash = utils.encodeString(purchaseUnit);

        res.json({});

        return next();
    }

    return '';
});

server.post('ReturnFromCart',
    server.middleware.https,
    middleware.removeNonPaypalPayment,
    middleware.validateProcessor,
    middleware.validateHandleHook,
    middleware.validateGiftCertificateAmount,
    function(req, res, next) {
        const {
            currentBasket
        } = BasketMgr;

        const isAddressNeedChange = req.querystring.isAddressNeedChange === 'true';

        let shippingAddress;

        if (isAddressNeedChange) {
            shippingAddress = addressHelper.getPreferredShippingAddressShortObj();
        }

        const paymentForm = server.forms.getForm('billing');
        const processorId = PaymentMgr.getPaymentMethod(prefs.paypalPaymentMethodId).getPaymentProcessor().ID.toLowerCase();

        let paymentFormResult;

        if (HookMgr.hasHook('app.payment.form.processor.' + processorId)) {
            paymentFormResult = HookMgr.callHook('app.payment.form.processor.' + processorId,
                'processForm',
                req,
                paymentForm,
                {});
        } else {
            paymentFormResult = HookMgr.callHook('app.payment.form.processor.default_form_processor', 'processForm');
        }

        if (!paymentFormResult || paymentFormResult.error) {
            res.setStatusCode(500);
            res.print(utils.createErrorMsg());

            return next();
        }

        const processorHandle = HookMgr.callHook('app.payment.processor.' + processorId,
            'Handle',
            currentBasket,
            paymentFormResult.viewData.paymentInformation,
            shippingAddress);

        if (!processorHandle || !processorHandle.success) {
            res.setStatusCode(processorHandle.statusCode || 500);
            res.print(processorHandle.serverErrors || utils.createErrorMsg(processorHandle.errorName));

            return next();
        }

        if (!shippingAddress) {
            shippingAddress = processorHandle.shippingAddress;
        }

        if (processorHandle.paymentInstrument.custom.paypalOrderID) {
            if (!paypalHelper.hasOnlyGiftCertificates(currentBasket)) {
                addressHelper.updateOrderShippingAddress(currentBasket, shippingAddress);
            }
        } else {
            addressHelper.updateBAShippingAddress(currentBasket, shippingAddress);
        }

        res.json();

        return next();
    });

server.get('GetBillingAgreementToken', server.middleware.https, function(req, res, next) {
    const isCartFlow = req.querystring.isCartFlow === 'true';
    const isSkipShippingAddress = req.querystring.isSkipShippingAddress === 'true';
    const {
        billingAgreementToken,
        err
    } = paypalApi.getBillingAgreementToken(paypalHelper.getBARestData(isCartFlow, isSkipShippingAddress));

    if (err) {
        res.setStatusCode(500);
        res.print(err);

        return next();
    }

    res.json({
        token: billingAgreementToken
    });

    session.privacy.baToken = billingAgreementToken;

    return next();
});

server.post('CreateBillingAgreement', server.middleware.https, function(_, res, next) {
    const response = paypalApi.createBillingAgreement(session.privacy.baToken);

    const errObject = {
        error: false
    };

    if (response.shipping_address && !response.shipping_address.id) {
        const payload = addressHelper.generateShippingAddressesPayloadFromBA(response);
        const addressValidation = addressHelper.validateShippingAddressForm(payload);

        if (addressValidation.error) {
            res.setStatusCode(500);

            Object.assign(errObject, addressValidation);
        }
    }

    if (response.err) {
        Object.assign(errObject, {
            error: true,
            errorName: response.err
        });
    }

    if (errObject.error) {
        res.json(errObject);
    } else {
        res.json(response);
    }

    session.privacy.baToken = null;

    return next();
});

server.use('RemoveBillingAgreement', server.middleware.https, function(req, res, next) {
    const billingAgreementModel = new BillingAgreementModel();

    const baEmail = req.querystring.billingAgreementEmail;
    const billingAgreement = billingAgreementModel.getBillingAgreementByEmail(baEmail);

    billingAgreementModel.removeBillingAgreement(billingAgreement);
    paypalApi.cancelBillingAgreement(billingAgreement.baID);

    if (BasketMgr.currentBasket) {
        paymentInstrumentHelper.removePayPalPaymentInstrumentByEmail(BasketMgr.currentBasket, baEmail);
    }

    res.json({});

    return next();
});

server.post('SaveBillingAgreement', server.middleware.https, middleware.parseBody, function(req, res, next) {
    const billingAgreementModel = new BillingAgreementModel();
    const baData = res.parsedBody;
    const isAutomaticPmAddingFlow = baData && baData.isAutomaticPmAddingFlow;
    const customerInstance = new CustomerModel(customer);

    try {
        if (baData) {
            const savedBA = billingAgreementModel.getBillingAgreements();
            const isAccountAlreadyExist = billingAgreementModel.isAccountAlreadyExist(baData.email);

            if (!isAccountAlreadyExist) {
                if (empty(savedBA)) {
                    baData.default = true;
                }

                baData.saveToProfile = true;
                delete baData.isAutomaticPmAddingFlow;
                billingAgreementModel.saveBillingAgreement(baData);

                if (isAutomaticPmAddingFlow) {
                    Transaction.wrap(function() {
                        const resource = 'paypal.account.paymentmethodadded.notification.msg';

                        customerInstance.addFlashMessage(Resource.msg(resource, 'locale', null),
                            CustomerModel.FLASH_MESSAGE_SUCCESS);
                    });
                }
            }
        }
    } catch (err) {
        if (isAutomaticPmAddingFlow) {
            Transaction.wrap(function() {
                const resource = 'paypal.account.paymentmethodnotadded.notification.msg';

                customerInstance.addFlashMessage(Resource.msg(resource, 'locale', null),
                    CustomerModel.FLASH_MESSAGE_DANGER);
            });
        }

        utils.createErrorLog(err);
    }

    res.json({});

    return next();
});

server.post('ValidateStaticImage', server.middleware.https, middleware.parseBody, function(req, res, next) {
    let formFields;

    try {
        formFields = JSON.parse(res.parsedBody.formFields);
    } catch (er) {
        formFields = null;
    }

    const addressBook = customer.addressBook.preferredAddress;

    let isAddressNeedChange = false;

    if (addressBook && formFields) {
        const billingAgreementDetails = paypalApi.getBADetailsById(formFields.billingAgreementID.value);

        const billingAgreementShippingAddress = addressHelper.generateShippingAddressesPayloadFromBA(billingAgreementDetails);
        const addressBookAddress = addressHelper.generateShippingAddressesPayloadFromAddressBook(addressBook);

        isAddressNeedChange = !addressHelper.compareShippingAddresses(billingAgreementShippingAddress, addressBookAddress);
    }

    res.json({
        isAddressNeedChange: isAddressNeedChange
    });

    next();
});

server.post('FinishPayNowFlow', server.middleware.https, middleware.parseBody, function(_, res, next) {
    const { pmName } = res.parsedBody;
    const { currentBasket } = BasketMgr;

    currentBasket.paymentInstruments.toArray().forEach(function(payment) {
        if (payment.paymentMethod !== 'GIFT_CERTIFICATE') {
            Transaction.wrap(function() {
                currentBasket.removePaymentInstrument(payment);
            });
        }
    });

    const lpmsList = prefs.enabledLPMs;
    const paymentInstrument = paymentInstrumentHelper.createPaymentInstrument(currentBasket,
        paypalConstants.PAYMENT_METHOD_ID_PAYPAL);

    Transaction.wrap(function() {
        paymentInstrument.custom.paypalOrderID = session.privacy.paypalOrderID;

        paymentInstrument.custom.paymentId = pmName;
    });

    const createTransactionResponse = paypalApi.createTransaction(paymentInstrument).response;
    const transactionId = paypalHelper.getTransactionId(createTransactionResponse);
    const payer = createTransactionResponse.payer;
    const paymentTransaction = paymentInstrument.paymentTransaction;
    const paymentSource = createTransactionResponse.payment_source;
    const paymentSourceName = Object.keys(paymentSource)[0];

    // Fills data to the payment instrument, payment transaction from transaction response
    Transaction.wrap(function() {
        paymentInstrument.custom.currentPaypalEmail = payer ? payer.email_address : null;
        paymentInstrument.custom.paypalLpmAccountHolderName = lpmsList.indexOf(paymentSourceName) !== -1
            ? paymentSource[paymentSourceName].name : null;
        paymentInstrument.getPaymentTransaction().setTransactionID(transactionId);
        paymentInstrument.custom.paypalPaymentStatus = paypalHelper.getTransactionStatus(createTransactionResponse);
        paymentInstrument.custom.paypalRequest = JSON.stringify({});
        paymentInstrument.custom.paypalResponse = JSON.stringify(createTransactionResponse);

        paymentTransaction.custom.paypalTransactionHistory = paypalHelper.prepareTransactionHistory(paymentTransaction,
            createTransactionResponse);
    });

    // Update billing address.
    // Only PayPal payment source contains information about payer. LPM won't update billing address from payment method.
    if (paymentSource.paypal || paymentSource.venmo) {
        addressHelper.updateOrderBillingAddress(currentBasket, payer);
    }

    // Creates a new order.
    const order = COHelpers.createOrder(currentBasket);

    if (!order) {
        res.setStatusCode(500);
        res.print(utils.createErrorMsg());

        return next();
    }

    // Places the order.
    try {
        Transaction.begin();
        const placeOrderStatus = OrderMgr.placeOrder(order);

        if (placeOrderStatus === Status.ERROR) {
            throw new Error();
        }

        order.setConfirmationStatus(Order.CONFIRMATION_STATUS_CONFIRMED);
        order.setExportStatus(Order.EXPORT_STATUS_READY);
        order.custom.paypalPaymentMethod = 'express';
        order.custom.PP_API_TransactionID = transactionId;
        Transaction.commit();
    } catch (e) {
        Transaction.wrap(function() {
            OrderMgr.failOrder(order, true);
        });
        utils.createErrorLog(e);
        res.setStatusCode(500);
        res.print(e.message);

        return next();
    }

    res.json({
        redirectUrl: URLUtils.https('Order-Confirm', 'orderID', order.orderNo, 'orderToken', order.orderToken).toString()
    });

    return next();
});

server.get('RenderCWPP', server.middleware.include, function(req, res, next) {
    const locations = { 1: 'login', 2: 'billing' };
    const currentFlow = locations[req.querystring.oauthLoginTargetEndPoint];
    const buttonConfigHelper = require('~/cartridge/scripts/paypal/helpers/buttonConfigHelper');

    const cwppButtonParameters = buttonConfigHelper.createCwppButtonConfig(currentFlow);

    // Fixed "Authorization code not found in cache" for session login user
    cwppButtonParameters.prompt = 'login';

    res.render('/paypal/components/cwppButton', {
        CWPPButtonEnabled: prefs.isCWPPEnabled,
        CWPPSdkLink: prefs.payPalExternalApiSdk,
        CWPPButtonParameters: JSON.stringify(cwppButtonParameters),
        CWPPStaticImageLink: prefs.CWPPStaticImageLink,
        CWPPButtonUrl: utils.createCWPPButtonUrl(res.viewData.queryString),
        CWPPStaticImageAlt: Resource.msg('paypal.connect.with.paypal.image.alt', 'locale', null)
    });

    return next();
});

server.get('ConnectWithPaypal', middleware.validateConnectWithPaypalUrl, function(req, res, next) {
    try {
        // Gets the access token according to the authentification code
        const accessToken = paypalApi.exchangeAuthCodeForAccessToken(request.httpParameterMap.code.value);
        // Gets the Paypal customer information according to the access token
        const payPalCustomerInfo = paypalApi.getPaypalCustomerInfo(accessToken);
        const errorMessage = Resource.msg('error.oauth.login.failure', 'login', null);

        if (!payPalCustomerInfo) {
            throw errorMessage;
        }

        if (!payPalCustomerInfo.emailConfirmed) {
            throw Resource.msg('paypal.error.email.unconfirmed', 'paypalerrors', null);
        }

        const customerEmail = payPalCustomerInfo.email;
        let newlyRegisteredUser = false;
        let customerInstance = CustomerModel.get(customerEmail);

        if (!customerInstance) {
            Transaction.wrap(function() {
                customerInstance = CustomerModel.create(customerEmail);
                customerInstance.setEmail(customerEmail);
                customerInstance.setFirstName(payPalCustomerInfo.firstName);
                customerInstance.setLastName(payPalCustomerInfo.lastName);
                customerInstance.setPhone(Resource.msg('paypal.account.address.phonenumber.notprovided', 'locale', null));

                customerInstance.sendRegistrationEmail();
                newlyRegisteredUser = true;
            });
        }

        if (CustomerModel.externalProfileExist(customerEmail)) {
            Transaction.wrap(function() {
                customerInstance.addFlashMessage(Resource.msg('account.legacy', 'notifications', null),
                    CustomerModel.FLASH_MESSAGE_INFO);
            });
        }

        const AgentUserMgr = require('dw/customer/AgentUserMgr');
        const requestLocale = request.getLocale();

        if (session.customerAuthenticated) {
            AgentUserMgr.logoutAgentUser();
        }

        const guestBasket = BasketMgr.getCurrentBasket();

        if (AgentUserMgr.loginAgentUser(prefs.PP_CWPP_Agent_Login, prefs.PP_CWPP_Agent_Password).error) {
            throw errorMessage;
        }

        if (AgentUserMgr.loginOnBehalfOfCustomer(customerInstance.dw).error) {
            throw errorMessage;
        }

        if (!customerInstance.getPreferredLocale()) {
            request.setLocale(requestLocale);
        }

        if (guestBasket) {
            Transaction.wrap(function() {
                customerInstance.restoreBasket(guestBasket);
            });
        }

        const accountHelpers = require('*/cartridge/scripts/helpers/accountHelpers');
        const oauthReentryEndpoint = req.querystring.state;
        // req.querystring.state - oAuth reentry endpoint(Account - 1 or Checkout - 2)
        const redirectURL = accountHelpers.getLoginRedirectURL(oauthReentryEndpoint,
            req.session.privacyCache,
            newlyRegisteredUser);

        // Automatic payment method adding flow
        if (prefs.automaticPmAddingEnabled && customerInstance.isEnabledFeatureAPMA()) {
            const urlArgs = [
                paypalConstants.ENDPOINT_PAYPAL_APMA,
                'redirectURL',
                redirectURL,
                'addressObject',
                encodeURIComponent(JSON.stringify(loginPayPalAddressHelper.getAddressObjectFromPayPal(payPalCustomerInfo)))
            ];

            res.redirect(URLUtils.url.apply(null, urlArgs));
            // Default flow
        } else {
            res.redirect(redirectURL);
        }
    } catch (err) {
        res.render('/error', {
            message: err
        });

        utils.createErrorLog(err);
    }

    return next();
});

server.post('PaymentAuthorizationAndCaptureHook', function(req, res, next) {
    const AuthorizationAndCaptureWhMgr = require('*/cartridge/models/authorizationAndCaptureWhMgr');
    const responseObject = {};

    let authorizationAndCaptureWhMgr;

    try {
        const whEvent = JSON.parse(request.httpParameterMap.requestBodyAsString);
        const eventType = whEvent.event_type;
        const eventResource = whEvent.resource;

        authorizationAndCaptureWhMgr = new AuthorizationAndCaptureWhMgr();

        // Cheks if endpoint received an appropriate event
        const isApproppriateEventType = authorizationAndCaptureWhMgr.isApproppriateEventType(eventType);

        // Throws an error and stop procced the rest of logic
        if (!isApproppriateEventType) {
            authorizationAndCaptureWhMgr.logEventError(eventType, this.name);
        }

        // Verify webhook event notifications
        const verifiedResponse = authorizationAndCaptureWhMgr.verifyWhSignature(whEvent,
            request.httpHeaders,
            prefs.authorizationAndCaptureWhId);

        const verificationStatus = verifiedResponse.verification_status;

        if (verificationStatus === paypalConstants.STATUS_SUCCESS) {
            const orderNo = eventResource.invoice_id;
            const paymentStatus = eventResource.status;

            if (!orderNo || !paymentStatus) {
                throw Resource.msg('paypal.webhook.order.details.error', 'paypalerrors', null);
            }

            // Gets order needed to update payment status
            const order = paypalHelper.getOrderByOrderNo(orderNo);

            if (!order) {
                const orderErrorMsg = Resource.msg('paypal.webhook.order.notexist.error', 'paypalerrors', null);

                utils.createDebugLog(orderErrorMsg);

                responseObject.error = orderErrorMsg;
                responseObject.success = false;
                res.json(responseObject);

                return next();
            }

            // Handles different WebHook scenarios in depends of received webHook event
            switch (eventType) {
                case paypalConstants.PAYMENT_AUTHORIZATION_VOIDED:
                    authorizationAndCaptureWhMgr.voidPaymentOnDwSide(order, paymentStatus, whEvent);

                    break;
                case paypalConstants.PAYMENT_CAPTURE_REFUNDED:
                    authorizationAndCaptureWhMgr.refundPaymentOnDwSide(order, paypalConstants.PAYMENT_STATUS_REFUNDED, whEvent);

                    break;
                case paypalConstants.PAYMENT_CAPTURE_COMPLETED:
                    authorizationAndCaptureWhMgr.completePaymentOnDwSide(order, paymentStatus, whEvent);

                    break;
                default:
                    break;
            }
        } else {
            throw Resource.msgf('paypal.webhook.verified.error', 'paypalerrors', null, verificationStatus);
        }
    } catch (err) {
        responseObject.error = err;
        responseObject.success = false;

        res.json(responseObject);

        utils.createErrorLog(err);

        return next();
    }

    res.setStatusCode(200);
    responseObject.success = true;
    res.json(responseObject);

    return next();
});

server.get('APMA', server.middleware.https, userLoggedIn.validateLoggedIn, function(req, res, next) {
    if (!req.querystring.redirectURL || !req.querystring.addressObject) {
        res.redirect(URLUtils.url(paypalConstants.ENDPOINT_HOME_SHOW));

        return next();
    }

    const customerInstance = new CustomerModel(customer);
    const hasBillingAgreement = customerInstance.hasBillingAgreement();
    const addressObjectString = decodeURIComponent(req.querystring.addressObject);

    const addressValidation = {
        error: false
    };

    if (addressObjectString) {
        const addressObject = JSON.parse(addressObjectString);
        const payload = {
            firstName: addressObject.firstName,
            lastName: addressObject.lastName,
            phone: addressObject.phone,
            shippingAddress: {
                city: addressObject.city,
                countryCode: addressObject.countryCode,
                state: addressObject.stateCode,
                line1: addressObject.address1,
                postalCode: addressObject.postalCode
            }
        };

        Object.assign(addressValidation, addressHelper.validateShippingAddressForm(payload));
    }

    const hasAddress = customerInstance.hasAddress(JSON.parse(addressObjectString));

    if (!customerInstance.isEnabledFeatureAPMA() || (hasBillingAgreement && hasAddress) || addressValidation.error) {
        res.redirect(req.querystring.redirectURL);

        return next();
    }

    Transaction.wrap(function() {
        customerInstance.disableFeatureAPMA();
    });

    let addingStage = paypalConstants.APMA_STAGE_COMPLETE;

    if (hasBillingAgreement) {
        addingStage = paypalConstants.APMA_STAGE_ADDRESS;
    }

    if (hasAddress) {
        addingStage = paypalConstants.APMA_STAGE_ACCOUNT;
    }

    res.render('paypal/automaticPaymentMethodAdding/automaticPaymentMethodAdding', {
        paypal: {
            sdkUrl: paypalSDK.accountSDKUrl
        },
        addingStage: addingStage,
        addressObject: addressObjectString,
        redirectURL: req.querystring.redirectURL
    });

    return next();
});

/**
 * Uses only for 'Automatic payment method adding' flow due Connect with PayPal button
 */
server.post('SavePaypalDefaultAddress', server.middleware.https, middleware.parseBody, function(req, res, next) {
    const customerInstance = new CustomerModel(customer);

    try {
        // Creates a customer address from the address provided by 'Connect with PayPal' feature
        Transaction.wrap(function() {
            customerInstance.addAddress(res.parsedBody.addressObject);
        });

        const StringUtils = require('dw/util/StringUtils');
        const resourceContext = res.parsedBody.isAccountPage ? 'account' : 'checkout';

        Transaction.wrap(function() {
            const resource = StringUtils.format('paypal.{0}.shippingaddressadded.notification.msg', resourceContext);

            customerInstance.addFlashMessage(Resource.msg(resource, 'locale', null), CustomerModel.FLASH_MESSAGE_SUCCESS);
        });
    } catch (err) {
        Transaction.wrap(function() {
            const resource = 'paypal.account.shippingaddressnotadded.notification.msg';

            customerInstance.addFlashMessage(Resource.msg(resource, 'locale', null), CustomerModel.FLASH_MESSAGE_DANGER);
        });

        utils.createErrorLog(err);
    }

    res.json({});

    return next();
});

server.get('IncludeConstants', server.middleware.include, function(req, res, next) {
    res.render('common/paypalConstants', {
        paypalConstantsString: JSON.stringify(paypalConstants)
    });

    next();
});

server.get('IncludeUrls', server.middleware.include, function(req, res, next) {
    const paypalUrls = require('*/cartridge/config/paypalUrls');

    res.render('common/paypalUrls', {
        paypalUrlsString: JSON.stringify(paypalUrls)
    });

    next();
});

server.get('IncludeSDK', server.middleware.include, function(req, res, next) {
    res.render('common/paypalSDK', {
        paypalSDKString: JSON.stringify(paypalSDK)
    });

    next();
});

server.get('IncludePreferences', server.middleware.include, function(req, res, next) {
    res.render('common/paypalPreferences', {
        // eslint-disable-next-line no-underscore-dangle
        braintreePreferencesString: JSON.stringify(prefs._whiteListedForStorefront)
    });

    next();
});

module.exports = server.exports();
