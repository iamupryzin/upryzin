'use strict';

/**
 * @namespace Default
 */

const server = require('server');
const cache = require('*/cartridge/scripts/middleware/cache');
const consentTracking = require('*/cartridge/scripts/middleware/consentTracking');

server.extend(module.superModule);

server.append('Start', consentTracking.consent, cache.applyDefaultCache, function(req, res, next) {
    res.setViewData({
        action: 'Home-Show'
    });

    next();
});

module.exports = server.exports();
