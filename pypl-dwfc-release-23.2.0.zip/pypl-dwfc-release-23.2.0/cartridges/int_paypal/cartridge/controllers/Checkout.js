'use strict';

const page = module.superModule;
const server = require('server');

const Money = require('dw/value/Money');
const BasketMgr = require('dw/order/BasketMgr');
const StringUtils = require('dw/util/StringUtils');

const paymentInstrumentHelper = require('*/cartridge/scripts/paypal/helpers/paymentInstrumentHelper');
const BillingAgreementModel = require('*/cartridge/models/billingAgreement');
const prefs = require('*/cartridge/config/paypalPreferences');
const paypalConstants = require('*/cartridge/config/paypalConstants');
const paypalSDK = require('*/cartridge/config/paypalSDK');
const shippingHelpers = require('*/cartridge/scripts/checkout/shippingHelpers');
const paypalHelper = require('*/cartridge/scripts/paypal/helpers/paypalHelper');
const buttonConfigHelper = require('*/cartridge/scripts/paypal/helpers/buttonConfigHelper');

server.extend(page);

server.append('Begin',
    function(req, res, next) {
        const basket = BasketMgr.getCurrentBasket();
        const currency = basket.getCurrencyCode();
        const paypalPaymentInstrument = paymentInstrumentHelper.getPaypalPaymentInstrument(basket);
        const isPayNowFlowEnabled = prefs.isPayNowFlowEnabled;

        let paymentAmount = new Money(0, currency);
        let amount;
        let isBALimitReached;
        let hasDefaultPaymentMethod;
        let savedPaypalBillingAgreements;
        let paypalEmail;
        let isAccountAlreadyExist = false;
        let activeBAEmail;
        let activeBAID;
        let isVenmoUsed = false;

        if (!prefs.paypalPaymentMethodId || !basket) {
            return next();
        }

        if (paypalHelper.isExpiredTransaction(paypalPaymentInstrument)) {
            paymentInstrumentHelper.removePaypalPaymentInstrument(basket);
        }

        if (customer.authenticated && prefs.billingAgreementEnabled) {
            const billingAgreementModel = new BillingAgreementModel();

            savedPaypalBillingAgreements = billingAgreementModel.getBillingAgreements(true);
            isBALimitReached = billingAgreementModel.isBaLimitReached();
            hasDefaultPaymentMethod = !empty(savedPaypalBillingAgreements);

            if (paypalPaymentInstrument) {
                isAccountAlreadyExist = billingAgreementModel.isAccountAlreadyExist(paypalPaymentInstrument.custom.currentPaypalEmail);
            }
        }

        if (paypalPaymentInstrument) {
            const billingAgreementData = paypalHelper.getBillingAgreementProperties(paypalPaymentInstrument, hasDefaultPaymentMethod);

            activeBAEmail = billingAgreementData.activeBAEmail;
            activeBAID = billingAgreementData.activeBAID;
            hasDefaultPaymentMethod = billingAgreementData.hasDefaultPaymentMethod;
            amount = paypalPaymentInstrument.paymentTransaction.amount.value;
            paymentAmount = new Money(amount, currency);
            paypalEmail = paypalPaymentInstrument.custom.currentPaypalEmail;
            isVenmoUsed = paypalPaymentInstrument.custom.paymentId === paypalConstants.PAYMENT_METHOD_ID_VENMO;
        }

        const viewData = {
            paypal: {
                paymentAmount: StringUtils.formatMoney(paymentAmount),
                billingAgreementEnabled: prefs.billingAgreementEnabled,
                paypalPaymentMethodId: prefs.paypalPaymentMethodId,
                paypalEmail: paypalEmail,
                partnerAttributionId: prefs.partnerAttributionId,
                buttonConfig: prefs.paypalBillingButtonConfig,
                customerPaypalPaymentInstruments: savedPaypalBillingAgreements,
                hasDefaultPaymentMethod: hasDefaultPaymentMethod,
                isBALimitReached: isBALimitReached,
                sdkUrl: paypalSDK.billingSdkUrl,
                isAccountAlreadyExist: isAccountAlreadyExist,
                activeBAEmail: activeBAEmail,
                activeBAID: activeBAID,
                isVenmoUsed: isVenmoUsed,
                isActiveVenmo: !prefs.billingAgreementEnabled && prefs.isVenmoEnabled,
                isCapture: prefs.isCapture,
                availableLPMSArray: buttonConfigHelper.getAvailableLPMSArray()
            }
        };

        res.setViewData(viewData);

        if (isPayNowFlowEnabled) {
            res.viewData.paypal.payNowData = {
                currentBasketShipmentUUID: res.viewData.order.shipping[0].UUID,
                onlinePickupMethodID: shippingHelpers.getOnlinePickupShippingMethod(basket.currencyCode).ID
            };
        }

        paypalHelper.updateViewDataForFraudNet(res);

        return next();
    });

module.exports = server.exports();
