const initPaypalBAButton = require('./registered/initPaypalBAButton');
const connectWithPayPal = require('../connectWithPayPal');

const SessionStorageModel = require('../models/sessionStorage');
const sessionStorageInstance = new SessionStorageModel();

import { updateCheckoutView } from '../helper';

import {
    handleTabChange,
    togglePaypalBtnVisibility,
    updateSessionAccountEmail,
    updateClientSide,
    updateSubmitOrderButton,
    shippingAddressFormFillingVerifing,
    isShippingAddressFormEmptyChecking
} from './billingHelper';

import {
    toggleBABtnVisibility,
    assignEmailForSavedBA,
    handleCheckboxChange
} from './registered/billingAgreementHelper';

// Mark 'credit-card' tab as active if no tab is set in session
if (!sessionStorageInstance.getActiveBillingPmTab()) {
    sessionStorageInstance.setActiveBillingPmTab(window.paypalConstants.CREDIT_CARD_TAB);
}

const $restPaypalAccountsList = document.getElementById('restPaypalAccountsList');
const isRegisteredUser = document.querySelector('.data-checkout-stage').getAttribute('data-customer-type') === 'registered';
const $billingButtonContainer = document.getElementById('billing-paypal-button-container');
const isBAEnabled = $billingButtonContainer && window.paypalPreferences.billingAgreementEnabled;

if (window.paypalPreferences.isCWPPEnabled) {
    connectWithPayPal.init();
}

/**
 * Activates the PayPal tab
 */
const activatePayPalTab = () => {
    const $ppPaymentOptionID = document.querySelector('.nav-link.paypal-tab').parentElement.getAttribute('data-method-id');
    const $activeTab = document.querySelector('.payment-information');

    document.querySelector('.nav-item .paypal-tab').click();

    if ($ppPaymentOptionID !== $activeTab.getAttribute('data-payment-method-id')) {
        $activeTab.setAttribute('data-payment-method-id', $ppPaymentOptionID);
    }
};

$('body').on('checkout:updateCheckoutView', (e, data) => {
    e.stopPropagation();

    updateClientSide(data);
    updateCheckoutView(data);

    if (!isRegisteredUser || !isBAEnabled) {
        updateSessionAccountEmail(data);
    }

    if (!isBAEnabled) {
        updateSubmitOrderButton();
    }
});

$('.payment-options[role=tablist] a[data-toggle="tab"]').on('shown.bs.tab', e => {
    handleTabChange(e, sessionStorageInstance);
});

// Order id flow
if (window.paypal && !isBAEnabled) {
    const PayPalBaseModel = require('../models/buttons/payPalBase');
    const payPalBaseInstance = new PayPalBaseModel('.js-paypal-button-on-billing-form');
    const $lpmBtns = document.querySelectorAll('.js-lpm-btn');
    const $venmoContent = document.querySelector('.js-venmo-content');

    if ($venmoContent) {
        const venmoBaseInstance = new PayPalBaseModel('.js-venmo-btn');

        venmoBaseInstance.initPayPalBtn(window.paypal.FUNDING.VENMO);
    }

    if ($lpmBtns.length) {
        const lpmsBuilder = require('./lpmsBuilder');

        lpmsBuilder.initLpms($lpmBtns);
    }

    payPalBaseInstance.initPayPalBtn();

    // Activate PayPal tab in case of Pay now flow
    if (payPalBaseInstance.isPayNowFlowEnabled && sessionStorageInstance.getActiveBillingPmTab() === window.paypalConstants.PAYPAL_TAB) {
        activatePayPalTab();
    }
} else {
    if (window.paypal && isBAEnabled) {
        initPaypalBAButton();
        assignEmailForSavedBA();
    }

    activatePayPalTab();
}

if ($restPaypalAccountsList) {
    $restPaypalAccountsList.onchange = function(e) {
        const $accountList = e ? e.target : $restPaypalAccountsList;

        if (!isBAEnabled) {
            togglePaypalBtnVisibility($accountList);
        } else {
            toggleBABtnVisibility($accountList);
            assignEmailForSavedBA();
        }
    };
}

if (!isBAEnabled) {
    updateSubmitOrderButton();

    document.querySelector('.payment-summary .edit-button').onclick = function() {
        document.querySelector('button.place-order').innerText = 'Place Order';
    };
}

if (document.querySelector('.paypal-checkbox-container')) {
    document.querySelectorAll('.paypal-checkbox-container .custom-checkbox')
        .forEach(checkbox => checkbox.addEventListener('change', handleCheckboxChange));
}

// This functionality checks that the shipping address form is filled out correctly
const isShippingAddressFormFillied = shippingAddressFormFillingVerifing();
const isShippingAddressFormEmpty = isShippingAddressFormEmptyChecking();
const $shippingEditButton = document.querySelector('.shipping-summary .edit-button');
const $shippingUpdateButton = document.querySelector('.shipping-address .shipment-selector-block .form-group .btn-show-details');
const $shippingSubmitButton = document.querySelector('.submit-shipping');

if (window.location.hash === '#placeOrder' && !isShippingAddressFormFillied && $shippingEditButton && $shippingSubmitButton) {
    $shippingEditButton.click();
    $shippingSubmitButton.click();
}

if (window.location.hash === '#shipping'
    && !isShippingAddressFormEmpty
    && !isShippingAddressFormFillied
    && $shippingUpdateButton
    && $shippingSubmitButton) {
    $shippingUpdateButton.click();
    $shippingSubmitButton.click();
}
