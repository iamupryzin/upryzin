import { getBillingAgreementToken, createBillingAgreementCall } from '../api';

const loaderInstance = require('../loader');
const $loaderContainer = document.querySelector('.paypalLoader');
const loader = loaderInstance($loaderContainer);

const AlertHandlerModel = require('../models/alertHandler');
const alertHandler = new AlertHandlerModel();

let paypalInstance;

/**
 *  Creates Billing Agreement
 *
 * @returns {string} returns JSON response that includes an data token
 */
function createBillingAgreement() {
    loader.show();
    const isCartFlow = true;

    return getBillingAgreementToken(isCartFlow)
        .then((data) => data.token)
        .fail(err => {
            paypalInstance.close();
            loader.hide();

            alertHandler.showError(err.responseText);
        });
}

/**
 * Makes post call using facilitator Access Token
 * @returns {Object} JSON response that includes the billing agreement ID and information about the payer
 */
function onApprove() {
    return createBillingAgreementCall()
        .then(({ id, payer }) => {
            const email = payer.payer_info.email;

            return $.ajax({
                url: window.paypalUrls.saveBillingAgreement,
                type: 'POST',
                contentType: 'application/json',
                data: JSON.stringify({ baID: id, email })
            });
        })
        .then(() => {
            loader.hide();
            location.reload();
        })
        .fail((err) => {
            paypalInstance.close();
            loader.hide();

            const errorResponse = err.responseJSON;

            alertHandler.showError(errorResponse.message);
        });
}

/**
 * Hides loader on paypal widget closing without errors
 */
function onCancel() {
    loader.hide();
}

/**
 * Shows errors if paypal widget was closed with errors
 */
function onError() {
    loader.hide();
}

/**
 * Inits paypal Billing Agreement button on billing checkout page
 */
function initPaypalBAButton() {
    loader.show();

    paypalInstance = window.paypal.Buttons({
        createBillingAgreement,
        onApprove,
        onCancel,
        onError,
        onClose: () => initPaypalBAButton()
    });

    paypalInstance.render('.paypal-account-button')
        .then(() => {
            loader.hide();
        });
}

export default initPaypalBAButton;
