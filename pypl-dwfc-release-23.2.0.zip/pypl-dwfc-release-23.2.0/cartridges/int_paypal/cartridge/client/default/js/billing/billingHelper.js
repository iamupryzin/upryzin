const billingAgreementHelper = require('./registered/billingAgreementHelper');
const billingAddressHelpers = require('../billingAddressHelpers');

const CC_CONTENT_ID = '#credit-card-content';
const PP_BTN_SELECTOR = '.js-paypal-button-on-billing-form';
const $paypalButton = document.querySelector(PP_BTN_SELECTOR);
const $continueButton = document.querySelector('button[value=submit-payment]');
const isRegisteredUser = document.querySelector('.data-checkout-stage')
    && document.querySelector('.data-checkout-stage').getAttribute('data-customer-type') === 'registered';

const $paypalAccountsDropdown = document.getElementById('paypalAccountsDropdown');
const $restPaypalAccountsList = document.getElementById('restPaypalAccountsList');
const $billingButtonContainer = document.getElementById('billing-paypal-button-container');
const $usedPaymentMethod = document.getElementById('usedPaymentMethod');
const isBAEnabled = $billingButtonContainer && window.paypalPreferences.billingAgreementEnabled;

let payPalBaseInstance;

if (!isBAEnabled) {
    const PayPalBase = require('../models/buttons/payPalBase');

    payPalBaseInstance = new PayPalBase(PP_BTN_SELECTOR);
}

/**
 * Shows continue button if it's not visible
 */
function showContinueButton() {
    if ($continueButton.style.display !== '') {
        $continueButton.style.display = '';
    }
}

/**
 * Hides continue button if it's not hidden
 */
function hideContinueButton() {
    if ($continueButton.style.display !== 'none') {
        $continueButton.style.display = 'none';
    }
}

/**
 * Shows PayPal div container if it's not visible and hides continue button
 */
function showPaypalBtn() {
    if ($paypalButton.style.display !== 'block') {
        $paypalButton.style.display = 'block';
    }

    hideContinueButton();
}

/**
 * Hides PayPal div container if it's not hidden and shows continue button
 */
function hidePaypalBtn() {
    if ($paypalButton.style.display !== 'none') {
        $paypalButton.style.display = 'none';
    }

    showContinueButton();
}

/**
 * Shows PayPal block with accounts dropdown if it's not visible
 */
function showPaypalBlock() {
    if ($paypalAccountsDropdown.style.display !== 'block') {
        $paypalAccountsDropdown.style.display = 'block';
    }
}

/**
 * Hides PayPal block with accounts dropdown if it's visible
 */
function hidePaypalBlock() {
    if ($paypalAccountsDropdown.style.display !== 'none') {
        $paypalAccountsDropdown.style.display = 'none';
    }
}

/**
 * Shows is new account selected
 * @param {Element} $accountList - $accountList element
 * @returns {boolean} value whether new account selected
 */
function isNewAccountSelected($accountList) {
    return $accountList.querySelector('option:checked').value === 'newaccount';
}

/**
 * Changes PayPal button visibility depending on checked option of element
 * @param {Element} $accountList - $accountList element
 */
function togglePaypalBtnVisibility($accountList) {
    isNewAccountSelected($accountList) ? showPaypalBtn() : hidePaypalBtn();
}

/**
 * Enables Billing Agreeement if payment method is not Paypal
 */
function activateBA() {
    billingAgreementHelper.clearSessionOption();
    const $defaultBA = $restPaypalAccountsList.querySelector('option[data-default=true]');

    if ($defaultBA) {
        $defaultBA.selected = true;
    } else {
        hidePaypalBlock();
    }

    billingAgreementHelper.toggleBABtnVisibility();
}

/**
 * Disables Billing Agreeement if payment method is not Paypal
 * @param {Element} $sessionPaypalAccount - $sessionPaypalAccount element
 */
function deactivateBA($sessionPaypalAccount) {
    $sessionPaypalAccount.value = '';
    $restPaypalAccountsList.querySelector('option:checked').value = 'newaccount';
    document.getElementById('usedPaymentMethod').value = '';
    hidePaypalBlock();
    togglePaypalBtnVisibility($restPaypalAccountsList);
}

/**
 * Handles switching of the tab content
 * @param {string} tabContentId The payment method tab contend id
 */
const adjustTabContent = tabContentId => {
    switch (tabContentId) {
        case CC_CONTENT_ID:
            showContinueButton();

            break;
        case '#paypal-content':
            $usedPaymentMethod.value = window.paypalConstants.PAYMENT_METHOD_ID_PAYPAL;
            isBAEnabled ? billingAgreementHelper.toggleBABtnVisibility($restPaypalAccountsList) : togglePaypalBtnVisibility($restPaypalAccountsList);

            break;
        case '#venmo-content':
            $usedPaymentMethod.value = window.paypalConstants.PAYMENT_METHOD_ID_VENMO;
            hideContinueButton();

            break;
        // LPM
        default:
            $usedPaymentMethod.value = tabContentId.slice(1, tabContentId.indexOf('-'));
            hideContinueButton();

            break;
    }
};

/**
 * Handles tabs changing
 * @param {event} e - event
 * @param {Function} sessionStorageInstance - An instance of sessionStorageModel
 */
function handleTabChange(e, sessionStorageInstance) {
    const isPayNowFlow = $paypalButton !== null && payPalBaseInstance.isPayNowFlowEnabled;
    const contentId = e.target.hash;

    let shipmentsDomInstance;

    if ($paypalButton) {
        const ShipmentsDomModel = require('../models/shipmentsDom');

        shipmentsDomInstance = new ShipmentsDomModel();
    }

    adjustTabContent(contentId);

    // Activates general credit card functionality
    if (contentId === CC_CONTENT_ID) {
        billingAddressHelpers.enableBillingAddressFunctionality();

        // Unblocks shipment behavior in case if Pay now flow in enabled
        if (isPayNowFlow) {
            shipmentsDomInstance.showShippingSectionsOnBillingPage();
            shipmentsDomInstance.hideShippingAddressInfoMsg();
            shipmentsDomInstance.selectShippingMethodOnBillingPage(shipmentsDomInstance.getLastUsedShippingMethodId());
        }

        sessionStorageInstance.setActiveBillingPmTab(window.paypalConstants.CREDIT_CARD_TAB);

        return;
    }

    // PayPal related functionality (Venmo, LPM, PayPal)

    sessionStorageInstance.setActiveBillingPmTab(window.paypalConstants.PAYPAL_TAB);

    // Applies shipment behavior for Pay now flow
    if (isPayNowFlow) {
        shipmentsDomInstance.hideShippingSectionsOnBillingPage();
        shipmentsDomInstance.showShippingAddressInfoMsg();
        shipmentsDomInstance.selectShippingMethodOnBillingPage();
    }

    billingAddressHelpers.disableBillingAddressFunctionality();

    if (isRegisteredUser && isBAEnabled) {
        billingAgreementHelper.assignEmailForSavedBA();
        billingAgreementHelper.handleCheckboxChange();
    }
}

/**
 * Updates session account email if it is differ from existed or email doesn't exist (for guest or disabled billing agreement)
 *
 */
function updateSessionAccountEmail({ order: { paypalPayerEmail, paymentMethodId } }) {
    if (!paypalPayerEmail) {
        return;
    }

    if (paymentMethodId !== window.paypalConstants.PAYMENT_METHOD_ID_VENMO) {
        showPaypalBlock();
        const $sessionPaypalAccount = document.getElementById('sessionPaypalAccount');

        if ($sessionPaypalAccount && $sessionPaypalAccount.value !== paypalPayerEmail) {
            $sessionPaypalAccount.value = paypalPayerEmail;
            $sessionPaypalAccount.innerText = paypalPayerEmail;
            $sessionPaypalAccount.selected = true;
            $restPaypalAccountsList.onchange();
        }
    }
}

/**
 * Updates paypal content to initial state on client side if payment method was changed from paypal to different one
 * @param {Object} data - customer data object
 */
function updateClientSide(data) {
    const selectedPaymentInstruments = data.order.billing.payment.selectedPaymentInstruments;
    const paypalPaymentMethod = document.querySelector('.nav-link.paypal-tab').parentElement.getAttribute('data-method-id');
    const giftCertTabLink = document.querySelector('.nav-link.gift-cert-tab');
    const $sessionPaypalAccount = $restPaypalAccountsList.querySelector('option[id=sessionPaypalAccount]');
    const $activeTab = document.querySelector('.payment-options a[data-toggle="tab"].active');

    if (!selectedPaymentInstruments) {
        return;
    }

    if ($sessionPaypalAccount && $sessionPaypalAccount.value) {
        selectedPaymentInstruments
            .filter((paymentInstr) => paymentInstr.paymentMethod !== paypalPaymentMethod)
            .forEach(() => {
                isBAEnabled ? activateBA() : deactivateBA($sessionPaypalAccount);

                if ($activeTab.getAttribute('href') === CC_CONTENT_ID) {
                    showContinueButton();
                }
            });
    } else if (giftCertTabLink && selectedPaymentInstruments.find((paymentInstr) => {
        return paymentInstr.paymentMethod === giftCertTabLink.parentElement.getAttribute('data-method-id');
    })) {
        giftCertTabLink.click();
    }
}

/**
 * Updates "Submit order" button text on billing page in case of Venmo checkout
 * Needed in case of checkout NOT through smart button (when Venmo account is chosen in dropdown)
 */
function updateSubmitOrderButton() {
    const placeOrderBtn = document.querySelector('button.place-order');

    if (placeOrderBtn && $usedPaymentMethod && $usedPaymentMethod.value === 'Venmo') {
        placeOrderBtn.innerText = 'Place Order with Venmo';
    }
}

/**
 * If the state and country fields exist and filled, return true, otherwise return false.
 * @returns {boolean} true/false
 */
function shippingAddressFormFillingVerifing() {
    const $stateField = document.getElementById('shippingStatedefault');
    const $countryField = document.getElementById('shippingCountrydefault');

    if ($stateField && $countryField) {
        return $stateField.value !== '' && $countryField.value !== '';
    }

    return false;
}

/**
 * If the three fields exist, then return true if all three fields are not empty. Otherwise, return
 * true.
 * @returns {boolean} a boolean value.
 */
function isShippingAddressFormEmptyChecking() {
    const $fistNameField = document.getElementById('shippingFirstNamedefault');
    const $secondNameField = document.getElementById('shippingLastNamedefault');
    const $addressField = document.getElementById('shippingAddressOnedefault');

    if ($fistNameField && $secondNameField && $addressField) {
        return $fistNameField.value.trim() === '' && $secondNameField.value.trim() === '' && $addressField.value.trim() === '';
    }

    return false;
}

export {
    showPaypalBlock,
    showPaypalBtn,
    hidePaypalBtn,
    hideContinueButton,
    handleTabChange,
    togglePaypalBtnVisibility,
    updateSessionAccountEmail,
    isNewAccountSelected,
    updateClientSide,
    showContinueButton,
    updateSubmitOrderButton,
    shippingAddressFormFillingVerifing,
    isShippingAddressFormEmptyChecking
};
