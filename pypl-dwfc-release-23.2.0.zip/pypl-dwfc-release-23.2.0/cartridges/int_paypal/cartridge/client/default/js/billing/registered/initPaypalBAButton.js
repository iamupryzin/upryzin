/* eslint-disable no-useless-escape */
/* eslint-disable no-control-regex */
const { getBillingAgreementToken, createBillingAgreementCall } = require('../../api');
const { clearSessionOption, updateSessionOption, setBAFormValues } = require('./billingAgreementHelper');
const { getPaypalButtonStyle } = require('../../helper');

const loaderInstance = require('../../loader');

const $loaderContainer = document.querySelector('.paypalLoader');
const loader = loaderInstance($loaderContainer);

const dataAttributes = {
    ID: 'data-ba-id',
    SAVED_ACCOUNT: 'data-has-saved-account',
    DEFAULT_ACCOUNT: 'data-has-default-account'
};

/**
 * Create's Billing Agreement
 * @returns {string} returns JSON response that includes an data token
 */
function createBillingAgreement() {
    loader.show();

    return getBillingAgreementToken()
        .then((data) => data.token)
        .fail(() => {
            loader.hide();
        });
}

/**
 * Makes post call using facilitator Access Token
 * save's billingAgreementID & billingAgreementPayerEmail to input field
 * and triggers checkout place order stage
 * @returns {Object} JSON response that includes the billing agreement ID and information about the payer
 */
function onApprove() {
    return createBillingAgreementCall()
        .then(({ id, payer }) => {
            const payerInfo = payer.payer_info;
            const billingAddress = payerInfo.billing_address;
            const $restPaypalAccountsList = document.getElementById('restPaypalAccountsList');
            const hasDefaultPaymentMethod = JSON.parse($restPaypalAccountsList.getAttribute(dataAttributes.DEFAULT_ACCOUNT));
            const hasPPSavedAccount = JSON.parse($restPaypalAccountsList.getAttribute(dataAttributes.SAVED_ACCOUNT));
            let billingAddressFields = [];

            document.getElementById('sessionPaypalAccount').setAttribute(dataAttributes.ID, id);
            setBAFormValues(id, payerInfo.email);

            if (hasDefaultPaymentMethod && !hasPPSavedAccount) {
                $restPaypalAccountsList.setAttribute(dataAttributes.DEFAULT_ACCOUNT, false);
                $('#restPaypalAccountsList').data(dataAttributes.DEFAULT_ACCOUNT, false); // MFRA jquery hack
            }

            const contactInfoFields = [].slice.call(document.querySelectorAll('.contact-info-block input[required]'));

            const keysValues = {
                email: payerInfo.email,
                phoneNumber: payerInfo.phone,
                billingFirstName: payerInfo.first_name,
                billingLastName: payerInfo.last_name,
                billingAddressOne: billingAddress.line1,
                billingCountry: billingAddress.country_code,
                billingState: billingAddress.state,
                billingAddressCity: billingAddress.city,
                billingZipCode: decodeURIComponent(billingAddress.postal_code)
            };

            const $billinAddressBlock = document.querySelector('.billing-address-block');

            if ($billinAddressBlock.querySelector('#billingAddressSelector option:checked').value === 'new') {
                billingAddressFields = [].slice.call($billinAddressBlock.querySelectorAll('input[required], select[required]'));
            }

            // Rewrite phone number
            document.getElementById('phoneNumber').value = '';

            (contactInfoFields.concat(billingAddressFields)
                .filter(el => el.value.trim() === ''))
                .forEach(function(el) {
                    el.value = keysValues[el.id];
                });

            document.querySelector('button.submit-payment').click();
            const sameAttribute = [].slice.call($restPaypalAccountsList.options)
                .find(el => el.value === payerInfo.email);

            (sameAttribute && sameAttribute.id !== 'sessionPaypalAccount')
                ? clearSessionOption()
                : updateSessionOption(payerInfo.email);

            loader.hide();
        })
        .fail(() => {
            loader.hide();
        });
}

/**
 * Hides loader on paypal widget closing without errors
 */
function onCancel() {
    loader.hide();
}

/**
 * Shows errors if paypal widget was closed with errors
 */
function onError() {
    const AlertHandlerModel = require('../../models/alertHandler');
    const alertHandler = new AlertHandlerModel();

    loader.hide();
    alertHandler.showError(window.paypalConstants.FLASH_MESSAGE_ERROR_INTERNAL_SERVER);
}

/**
 * Inits paypal Billing Agreement button on billing checkout page
 */
function initPaypalBAButton() {
    loader.show();

    window.paypal.Buttons({
        createBillingAgreement,
        onApprove,
        onCancel,
        onError,
        style: getPaypalButtonStyle(document.querySelector('.paypal-checkout-ba-button'))
    }).render('.paypal-checkout-ba-button')
        .then(() => {
            const PayPalBaseModel = require('../../models/buttons/payPalBase');
            const PAYPAL_FS = window.paypal.FUNDING.PAYPAL;

            PayPalBaseModel.prototype.renderButtonMarks.call({
                fundingSource: PAYPAL_FS
            });

            loader.hide();

            PayPalBaseModel.prototype.showButtonTab(PAYPAL_FS);
        });
}

module.exports = initPaypalBAButton;
