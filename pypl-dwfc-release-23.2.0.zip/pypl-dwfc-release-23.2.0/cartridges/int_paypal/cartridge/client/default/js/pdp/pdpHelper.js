/**
 * Shows paypal PDP button/static image
 * @param {Object} $paypalPDPButton - paypal button element
 */
function showPayPalButton($paypalPDPButton) {
    $paypalPDPButton.style.display = '';
}

/**
 * Hides paypal PDP button/static image
 * @param {Object} $paypalPDPButton - paypal button element
 */
function hidePayPalButton($paypalPDPButton) {
    $paypalPDPButton.style.display = 'none';
}

/**
 * Check if PDP product price is zero
 * @returns {boolean} "true" in case if PDP product price is zero
 */
function isZeroPdpProductPrice() {
    const $productPriceSelector = document.querySelector('.price .sales .value');

    if ($productPriceSelector) {
        const price = parseInt($productPriceSelector.getAttribute('content'), 0);

        return price <= 0;
    }

    return true;
}

/**
 * Is add to cart button disabled
 * @returns {boolean} "true" in case if add to cart button disabled
 */
function isAddToCartButtonDisabled() {
    const $addToCartButton = document.querySelector('.js-add-to-cart, .js-add-to-cart-global');

    return $addToCartButton.disabled;
}

/**
 * Return mini cart quantity
 * @param {Object} $miniCartQuantitySelector Mini cart quantity selector
 * @returns {Int} Quantity
 */
function getMiniCartQuantity($miniCartQuantitySelector) {
    let quantity = null;

    if ($miniCartQuantitySelector) {
        quantity = parseInt($miniCartQuantitySelector.textContent, 0);
    }

    return quantity;
}

/**
 * Check if basket is empty
 * @returns {boolean} "true" in case if basket is not empty
 */
function isBasketNotEmpty() {
    const miniCartQuantityElement = document.querySelector('.minicart-quantity');

    return getMiniCartQuantity(miniCartQuantityElement) !== 0;
}

/**
 * Handles PP button behavior on Product/Cart update
 * @returns {void}
 */
function handlePayPalButtonOnUpdate() {
    const $paypalPDPButton = document.querySelector('.paypal-pdp-button');

    const addToCartButtonDisabled = isAddToCartButtonDisabled();
    const zeroProductPrice = isZeroPdpProductPrice();
    const basketNotEmpty = isBasketNotEmpty();

    if (addToCartButtonDisabled || zeroProductPrice || basketNotEmpty) {
        hidePayPalButton($paypalPDPButton);
    } else {
        showPayPalButton($paypalPDPButton);
    }
}

/**
 * Handling PDP button/static image behavior
 */
function initPaypalButtonBehaviorOnPdp() {
    const $paypalPDPButton = document.querySelector('.paypal-pdp-button');

    if ($paypalPDPButton) {
        const addToCartButtonDisabled = isAddToCartButtonDisabled();
        const zeroProductPrice = isZeroPdpProductPrice();
        const basketNotEmpty = isBasketNotEmpty();

        if (addToCartButtonDisabled || zeroProductPrice || basketNotEmpty) {
            hidePayPalButton($paypalPDPButton);
        }

        $('body').on('product:afterAddToCart', function() {
            hidePayPalButton($paypalPDPButton);
        });

        $('body').on('cart:update', handlePayPalButtonOnUpdate);
        $('body').on('product:statusUpdate', handlePayPalButtonOnUpdate);
    }
}

/**
 * Appends params to a url
 * @param {string} url - Original url
 * @param {Object} param - Parameters to append
 * @returns {string} result url with appended parameters
 */
function appendToUrl(url, param) {
    let newUrl = url;

    newUrl += (newUrl.indexOf('?') !== -1 ? '&' : '?') + Object.keys(param).map(function(key) {
        return [key, '=', encodeURIComponent(param[key])].join('');
    }).join('&');

    return newUrl;
}

export {
    appendToUrl,
    initPaypalButtonBehaviorOnPdp
};
