import {
    getBillingAgreementToken,
    createBillingAgreementCall,
    createCartBillingFormData
} from '../../api';
import {
    getPaypalButtonStyle,
    handleValidationAddressResult
} from '../../helper';

const loaderInstance = require('../../loader');
const $loaderContainer = document.querySelector('.paypalLoader');
const loader = loaderInstance($loaderContainer);

const AlertHandlerModel = require('../../models/alertHandler');
const alertHandler = new AlertHandlerModel();

let paypalInstance;

/**
 *  Create's Billing Agreement
 *
 * @returns {string} returns JSON response that includes an data token
 */
function createBillingAgreement() {
    loader.show();
    const isCartFlow = true;

    return getBillingAgreementToken(isCartFlow)
        .then((data) => data.token)
        .fail(err => {
            paypalInstance.close();
            loader.hide();

            alertHandler.showError(err.responseText);
        });
}

/**
 * Makes post call to create a BA and calls the returnFromCart endpoint, triggers checkout (stage = place order)
 * @returns {Object} JSON response that includes the billing agreement ID and information about the payer
 */
function onApprove() {
    return createBillingAgreementCall()
        .then(({ id, payer }) => {
            const cartBillingFormData = createCartBillingFormData({
                billingAgreementID: id,
                billingAgreementPayerEmail: payer.payer_info.email
            }, document.querySelector('.js-paypal-button-on-cart-page'));

            return $.ajax({
                type: 'POST',
                url: window.paypalUrls.returnFromCart,
                data: cartBillingFormData,
                contentType: false,
                processData: false,
                dataType: 'json'
            });
        })
        .then(() => {
            loader.hide();
            window.location.href = window.paypalUrls.placeOrderStage;
        })
        .fail((error) => {
            loader.hide();
            const errorResponse = error.responseJSON;

            if (handleValidationAddressResult(error) || errorResponse.errorName === 'shipping.address.invalid') {
                paypalInstance.close();

                if (errorResponse.message) {
                    alertHandler.showError(errorResponse.message);
                }
            } else {
                if (window.location.href !== window.paypalUrls.cartPage) {
                    window.location.href = window.paypalUrls.cartPage;
                }

                alertHandler.showError(error.responseText);
            }
        });
}

/**
 * Hides loader on paypal widget closing without errors
 */
function onCancel() {
    loader.hide();
}

/**
 * Shows errors if paypal widget was closed with errors
 */
function onError() {
    loader.hide();

    if (window.location.href !== window.paypalUrls.cartPage) {
        window.location.href = window.paypalUrls.cartPage;
    }

    alertHandler.showError(window.paypalConstants.FLASH_MESSAGE_ERROR_INTERNAL_SERVER);
}

/**
 *Inits paypal Billing Agreement button on billing checkout page
 */
function initPaypalBAButton() {
    loader.show();

    paypalInstance = window.paypal.Buttons({
        createBillingAgreement,
        onApprove,
        onCancel,
        onError,
        onClose: () => initPaypalBAButton(),
        style: getPaypalButtonStyle(document.querySelector('.js-paypal-button-on-cart-page'))
    });

    const paypalCartButtonContainer = document.querySelectorAll('.paypal-cart-button');

    setTimeout(() => {
        paypalCartButtonContainer.forEach((container)=>{
            const paypalFrame = container.querySelector('.paypal-buttons-context-iframe');

            if (!paypalFrame) {
                paypalInstance.render(container)
                    .then(() => {
                        loader.hide();
                    });
            }
        });
    });
}

export default initPaypalBAButton;
