import {
    hideContinueButton,
    isNewAccountSelected,
    showContinueButton,
    showPaypalBlock
} from '../billingHelper';

const dataAttributes = {
    ID: 'data-ba-id',
    APPEND: 'data-append',
    SAVED_ACCOUNT: 'data-has-saved-account',
    DEFAULT_ACCOUNT: 'data-has-default-account',
    LIMIT_REACHED: 'data-ba-limit-reached'
};

const querySelectors = {
    OPTION_CHECKED: 'option:checked'
};

const $billingBAbutton = document.querySelector('.paypal-checkout-ba-button');
const $restPaypalAccountsList = document.getElementById('restPaypalAccountsList');
const $paypalAccountSave = document.getElementById('savePaypalAccount');
const $paypalAccountMakeDefault = document.getElementById('paypalAccountMakeDefault');
const hasDefaultPaymentMethod = JSON.parse($restPaypalAccountsList.getAttribute(dataAttributes.DEFAULT_ACCOUNT));

/**
 * Change css classes to show element
 * @param {string} element - html object
*/
function showElement(element) {
    element.classList.remove('none');
    element.classList.add('block');
}

/**
 * Change css classes to hide element
 * @param {string} element - html object
*/
function hideElement(element) {
    element.classList.remove('block');
    element.classList.add('none');
}

/**
 * Sets BA id & email to form values
 * @param {string} baID - billing agreement active ID
 * @param {string} baEmail - billing agreement active email
*/
function setBAFormValues(baID, baEmail) {
    document.getElementById('billingAgreementID').value = baID;
    document.getElementById('billingAgreementPayerEmail').value = baEmail;
}

/** Put value of checkbox makeDefault/saveAccount for backend
*/
function saveCheckboxState() {
    const $paypalMakeDefault = document.getElementById('paypal_makeDefault');
    const $paypalSaveAccount = document.getElementById('paypal_saveAccount');

    $paypalMakeDefault.value = $paypalAccountMakeDefault.checked;
    $paypalSaveAccount.value = $paypalAccountSave.checked;
}

/** Handle makeDefault/saveAccount checkboxes state on change
*/
function handleCheckboxChange() {
    const $selectedAccount = $restPaypalAccountsList && $restPaypalAccountsList.querySelector(querySelectors.OPTION_CHECKED);
    const isSessionAccountAppended = $selectedAccount && JSON.parse($selectedAccount.getAttribute(dataAttributes.APPEND));

    if (isSessionAccountAppended || $selectedAccount.value === 'newaccount') {
        if (!$paypalAccountSave.checked) {
            $paypalAccountMakeDefault.checked = false;
            $paypalAccountMakeDefault.disabled = true;
        } else {
            $paypalAccountMakeDefault.disabled = false;

            if (!hasDefaultPaymentMethod) {
                $paypalAccountMakeDefault.checked = true;
            }
        }
    }

    saveCheckboxState();
}

/** Show/hide/check/disable if it is new account or new session account
*/
function handleCheckbox() {
    const $paypalAccountMakeDefaultContainer = document.getElementById('paypalAccountMakeDefaultContainer');
    const $paypalAccountSaveContainer = document.getElementById('savePaypalAccountContainer');
    const hasPPSavedAccount = JSON.parse($restPaypalAccountsList.getAttribute(dataAttributes.SAVED_ACCOUNT));
    const isBALimitReached = JSON.parse($restPaypalAccountsList.getAttribute(dataAttributes.LIMIT_REACHED));
    const $newSelectedAccount = $restPaypalAccountsList && $restPaypalAccountsList.querySelector(querySelectors.OPTION_CHECKED);
    const isSessionAccountAppended = $newSelectedAccount && JSON.parse($newSelectedAccount.getAttribute(dataAttributes.APPEND));
    const isNewAccount = $newSelectedAccount.value === 'newaccount';

    if (!hasPPSavedAccount) {
        hideElement($paypalAccountMakeDefaultContainer);
        $paypalAccountMakeDefault.checked = true;
        $paypalAccountMakeDefault.disabled = false;
        showElement($paypalAccountSaveContainer);

        if ((isNewAccount && (hasDefaultPaymentMethod || isSessionAccountAppended))
            || (isNewAccount && !isSessionAccountAppended)) {
            $paypalAccountSave.checked = true;
        } else {
            $paypalAccountSave.checked = false;
        }

        saveCheckboxState();

        return;
    }

    handleCheckboxChange();

    if (isBALimitReached) {
        hideElement($paypalAccountSaveContainer);
        hideElement($paypalAccountMakeDefaultContainer);
    } else {
        showElement($paypalAccountSaveContainer);
        showElement($paypalAccountMakeDefaultContainer);
    }

    if (hasDefaultPaymentMethod) {
        return;
    }

    if (hasPPSavedAccount) {
        hideElement($paypalAccountMakeDefaultContainer);
    }

    $paypalAccountMakeDefault.checked = true;
}

/** Show/hide/check/disable checkboxes depends on selected type of account
*/
function toggleCustomCheckbox() {
    const $paypalAccountMakeDefaultContainer = document.getElementById('paypalAccountMakeDefaultContainer');
    const $paypalAccountSaveContainer = document.getElementById('savePaypalAccountContainer');
    const hasPPSavedAccount = JSON.parse($restPaypalAccountsList.getAttribute(dataAttributes.SAVED_ACCOUNT));
    const $newSelectedAccount = $restPaypalAccountsList && $restPaypalAccountsList.querySelector(querySelectors.OPTION_CHECKED);
    const isSessionAccountAppended = $newSelectedAccount && JSON.parse($newSelectedAccount.getAttribute(dataAttributes.APPEND));

    if (!$paypalAccountSaveContainer) {
        return;
    }

    if ($newSelectedAccount.dataset.default === 'true') {
        hideElement($paypalAccountMakeDefaultContainer);
        $paypalAccountMakeDefault.checked = true;
        $paypalAccountMakeDefault.disabled = false;

        if (hasPPSavedAccount && !hasDefaultPaymentMethod) {
            $paypalAccountSave.checked = true;
        } else {
            hideElement($paypalAccountSaveContainer);
        }

        saveCheckboxState();
    }

    const isDataSetDefault = ['false', 'null'].includes($newSelectedAccount.dataset.default);
    const isNewAccount = $newSelectedAccount.value === 'newaccount';

    if (isDataSetDefault && isNewAccount && !isSessionAccountAppended) {
        showElement($paypalAccountMakeDefaultContainer);
        hideElement($paypalAccountSaveContainer);
        $paypalAccountSave.checked = false;
        $paypalAccountMakeDefault.disabled = false;
    }

    if (isNewAccount || isSessionAccountAppended) {
        handleCheckbox();
    }
}

/** Show billing agreement btn - hide paypal btn and vise versa
*/
function toggleBABtnVisibility() {
    toggleCustomCheckbox();

    if (isNewAccountSelected($restPaypalAccountsList)) {
        showElement($billingBAbutton);
        hideContinueButton();

        return;
    }

    hideElement($billingBAbutton);
    showContinueButton();
    showPaypalBlock();
}

/** Assign billing agreement emails on change into input field
*/
function assignEmailForSavedBA() {
    const $paypalActiveAccount = document.getElementById('paypal_activeAccount');
    const $selectedAccount = $restPaypalAccountsList && $restPaypalAccountsList.querySelector(querySelectors.OPTION_CHECKED);

    if (isNewAccountSelected($restPaypalAccountsList)) {
        $paypalActiveAccount.value = '';
        document.getElementById('billingAgreementID').value = '';
        document.getElementById('billingAgreementPayerEmail').value = '';
    } else {
        $paypalActiveAccount.value = $restPaypalAccountsList.querySelector(querySelectors.OPTION_CHECKED).value;
        setBAFormValues($selectedAccount.dataset.baId, $selectedAccount.value);
    }
}

/**
 *  Clear element to an Existing restPaypalAccountsList Collection
 *
 */
function clearSessionOption() {
    const $option = document.getElementById('sessionPaypalAccount');

    $option.text = '';
    $option.value = '';
    $option.setAttribute(dataAttributes.APPEND, false);
    $option.selected = false;
    hideElement($option);
    $option.setAttribute(dataAttributes.ID, '');
    document.getElementById('billingAgreementID').value = '';
    document.getElementById('billingAgreementPayerEmail').value = '';
    toggleBABtnVisibility();
}

/**
 *  Update element under restPaypalAccountsList Collection
 *
 * @param {string} email - billing agreement email
 */
function updateSessionOption(email) {
    const $option = document.getElementById('sessionPaypalAccount');

    $option.text = email;
    $option.value = email;
    $option.selected = 'selected';
    showElement($option);
    $option.setAttribute(dataAttributes.APPEND, true);
    document.getElementById('restPaypalAccountsList').value = email;
    hideElement($billingBAbutton);
    showContinueButton();
    showPaypalBlock();
}

export {
    toggleBABtnVisibility,
    assignEmailForSavedBA,
    handleCheckboxChange,
    clearSessionOption,
    updateSessionOption,
    setBAFormValues
};
