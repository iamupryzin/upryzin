const api = require('../../api');
const helper = require('../../helper');
const loaderInstance = require('../../loader');
const $loaderContainer = document.querySelector('.paypalLoader');
const loader = loaderInstance($loaderContainer);

const AlertHandlerModel = require('../../models/alertHandler');
const alertHandler = new AlertHandlerModel();

let paypalInstance;

/**
 * Creates Billing Agreement
 *
 * @param {string} selector PayPal button container selector
 * @returns {string} returns JSON response that includes a data token
 */
function createBillingAgreement(selector) {
    helper.addProductToCart(selector);

    const isCartFlow = true;

    loader.show();

    return api.getBillingAgreementToken(isCartFlow)
        .then((data) => data.token)
        .fail(err => {
            paypalInstance.close();
            loader.hide();

            alertHandler.showError(err.responseText);
        });
}

/**
 * Makes post call to create a BA and calls thereturnFromCart endpoint, triggers checkout (stage = place order)
 * @returns {Object} JSON response that includes the billing agreement ID and information about the payer
 */
function onApprove() {
    return api.createBillingAgreementCall()
        .then(({ id, payer }) => {
            const cartBillingFormData = api.createCartBillingFormData({
                billingAgreementID: id,
                billingAgreementPayerEmail: payer.payer_info.email
            }, document.querySelector('.js-paypal-button-on-product-page'));

            return $.ajax({
                type: 'POST',
                url: window.paypalUrls.returnFromCart,
                data: cartBillingFormData,
                contentType: false,
                processData: false,
                dataType: 'json'
            });
        })
        .then(() => {
            loader.hide();
            window.location.href = window.paypalUrls.placeOrderStage;
        })
        .fail((error) => {
            loader.hide();
            const errorResponse = error.responseJSON;

            if (helper.handleValidationAddressResult(error) || errorResponse.errorName === 'shipping.address.invalid') {
                helper.removeAllProductsFromCart();
                paypalInstance.close();

                if (errorResponse.message) {
                    alertHandler.showError(errorResponse.message);
                }
            } else {
                window.location.href = window.paypalUrls.cartPage;
            }
        });
}

/**
 * Hides loader on paypal widget closing without errors
 * If PDP flow, removes product from basket on cancel
 */
function onCancel() {
    $.ajax({
        url: helper.getUrlWithCsrfToken(window.paypalUrls.removeAllProductsFromCart),
        type: 'get',
        dataType: 'json',
        success: function() {
            $.spinner().stop();
        },
        error: function() {
            $.spinner().stop();
        }
    });
    loader.hide();
}

/**
 * Shows errors if paypal widget was closed with errors
 * If PDP flow, removes product from basket on error
 */
function onError() {
    $.ajax({
        url: helper.getUrlWithCsrfToken(window.paypalUrls.removeAllProductsFromCart),
        type: 'get',
        dataType: 'json',
        success: function() {
            $.spinner().stop();
        },
        error: function() {
            $.spinner().stop();
        }
    });

    loader.hide();
    window.location.href = window.paypalUrls.cartPage;
}

/**
 * Inits paypal Billing Agreement button on billing checkout page
 * @param {string} selector PayPal button container selector
 */
function initPaypalBAButton(selector = '.paypal-pdp-button') {
    loader.show();
    const createBillingAgreementCallback = createBillingAgreement.bind(this, selector);

    paypalInstance = window.paypal.Buttons({
        createBillingAgreement: createBillingAgreementCallback,
        onApprove,
        onCancel,
        onError,
        onClose: () => initPaypalBAButton(selector),
        style: helper.getPaypalButtonStyle(document.querySelector('.js-paypal-button-on-product-page'))
    });

    paypalInstance.render(selector)
        .then(() => {
            loader.hide();
        });
}

export { initPaypalBAButton };
