'use strict';

if (window.paypalPreferences.isCWPPEnabled) {
    const connectWithPayPal = require('../connectWithPayPal');

    connectWithPayPal.init();
}
