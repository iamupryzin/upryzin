'use strict';

const currentSite = require('dw/system/Site').current;

const allowedCurrencies = [
    'AUD',
    'BRL',
    'CAD',
    'CHF',
    'CZK',
    'DKK',
    'EUR',
    'HKD',
    'HUF',
    'INR',
    'ILS',
    'JPY',
    'MYR',
    'MXN',
    'TWD',
    'NZD',
    'NOK',
    'PHP',
    'PLN',
    'GBP',
    'RUB',
    'SGD',
    'SEK',
    'THB',
    'USD'
];

const disableFunds = [
    'sepa',
    'bancontact',
    'eps',
    'giropay',
    'ideal',
    'mybank',
    'p24',
    'sofort',
    'blik'
];

const paypalFraudNetScriptLink = 'https://c.paypal.com/da/r/fb.js';
const paypalStaticImageLink = 'https://www.paypalobjects.com/webstatic/en_US/i/buttons/checkout-logo-large.png';
const CWPPStaticImageLink = 'https://www.paypalobjects.com/webstatic/en_US/developer/docs/login/connectwithpaypalbutton.png';
const payPalExternalApiSdk = 'https://www.paypalobjects.com/js/external/api.js';

const smartButtonStyles = JSON.parse(currentSite.getCustomPreferenceValue('PP_API_Smart_Button_Styles'));
const cwppButtonStyles = JSON.parse(currentSite.getCustomPreferenceValue('CWPP_API_Button_Styles'));

module.exports = {
    disableFunds: disableFunds,
    paypalStaticImageLink: paypalStaticImageLink,
    CWPPStaticImageLink: CWPPStaticImageLink,
    paypalFraudNetScriptLink: paypalFraudNetScriptLink,
    allowedCurrencies: allowedCurrencies,
    paypalBillingButtonConfig: { style: smartButtonStyles.billing },
    paypalCartButtonConfig: { style: smartButtonStyles.cart },
    paypalPdpButtonConfig: { style: smartButtonStyles.pdp },
    paypalPvpButtonConfig: { style: smartButtonStyles.pvp },
    paypalMinicartButtonConfig: { style: smartButtonStyles.minicart },
    cwppButtonStyles: cwppButtonStyles,
    payPalExternalApiSdk: payPalExternalApiSdk,
    cwppScopes: 'openid profile email address'
};
