/* eslint-disable no-underscore-dangle */

'use strict';

const Site = require('dw/system/Site');
const dwSystem = require('dw/system/System');
const PaymentMgr = require('dw/order/PaymentMgr');

const sdkConfig = require('./sdkConfig');

const ALLOWED_PROCESSORS_IDS = 'PAYPAL';

const preferences = {};

/**
 * Returns paypal payment method ID
 * @returns {string} active paypal payment method id
 */
function getPaypalPaymentMethodId() {
    const activePaymentMethods = PaymentMgr.getActivePaymentMethods();

    let paypalPaymentMethodID;

    Array.some(activePaymentMethods, function(paymentMethod) {
        if (paymentMethod.paymentProcessor.ID === ALLOWED_PROCESSORS_IDS) {
            paypalPaymentMethodID = paymentMethod.ID;

            return true;
        }

        return false;
    });

    return paypalPaymentMethodID;
}

/**
 * Adds _whiteList object property with preferences which would be shown on client side
 */
const addWhiteListPrefs = function() {
    preferences._whiteListedForStorefront = {};

    // List of custom preferences keys that should be visible on client side
    const whiteList = ['billingAgreementEnabled', 'partnerAttributionId', 'isPayNowFlowEnabled', 'isCWPPEnabled'];

    // Make prefs from whiteList visible on client side
    whiteList.forEach(function(key) {
        preferences._whiteListedForStorefront[key] = JSON.parse(JSON.stringify(preferences[key]));
    });
};

/**
 * Returns PayPal custom and hardcoded preferences
 *
 * @returns {Object} statis preferences
 */
function getPreferences() {
    const site = Site.current;
    const isBaEnabled = site.getCustomPreferenceValue('PP_API_BA_Enabled');
    const isCapture = site.getCustomPreferenceValue('PP_API_PaymentAction');
    const isVenmoEnabled = site.getCustomPreferenceValue('PP_API_Venmo_Enabled');

    preferences.isCapture = isCapture;
    preferences.paypalPaymentMethodId = getPaypalPaymentMethodId();
    preferences.billingAgreementEnabled = isBaEnabled;
    preferences.billingAgreementDescription = site.getCustomPreferenceValue('PP_API_BA_Description');
    preferences.enabledLPMs = site.getCustomPreferenceValue('PP_API_APM_methods');
    preferences.paypalButtonLocation = site.getCustomPreferenceValue('PP_API_Button_Location').getValue();
    preferences.authorizationAndCaptureWhId = site.getCustomPreferenceValue('PP_WH_Authorization_And_Capture_Id');
    preferences.isVenmoEnabled = isVenmoEnabled;
    preferences.paypalCartButtonConfig = sdkConfig.paypalCartButtonConfig;
    preferences.paypalBillingButtonConfig = sdkConfig.paypalBillingButtonConfig;
    preferences.paypalPdpButtonConfig = sdkConfig.paypalPdpButtonConfig;
    preferences.paypalPvpButtonConfig = sdkConfig.paypalPvpButtonConfig;
    preferences.paypalMinicartButtonConfig = sdkConfig.paypalMinicartButtonConfig;
    preferences.paypalProcessorId = ALLOWED_PROCESSORS_IDS;
    preferences.paypalStaticImageLink = sdkConfig.paypalStaticImageLink;
    preferences.partnerAttributionId = 'SFCC_EC_B2C_23_2_0';
    preferences.debitCreditButtonEnabled = site.getCustomPreferenceValue('PP_Debit_Credit_Button_Enabled');
    preferences.paypalCreditOrPayLaterButtonEnabled = site.getCustomPreferenceValue('PP_Credit_Pay_Later_Button_Enabled');
    preferences.enableFundingList = site.getCustomPreferenceValue('PP_Enable_Funding_List');
    preferences.disableFundingList = site.getCustomPreferenceValue('PP_Disable_Funding_List');
    preferences.automaticPmAddingEnabled = site.getCustomPreferenceValue('PP_Automatic_PM_adding_enabled');
    preferences.isPayNowFlowEnabled = site.getCustomPreferenceValue('PP_API_PAY_NOW_ENABLED') && !isBaEnabled && isCapture;
    preferences.isFraudNetEnabled = site.getCustomPreferenceValue('PP_FRAUDNET_ENABLED');

    // Used only for 'Connect with Paypal' feature
    preferences.isCWPPEnabled = site.getCustomPreferenceValue('PP_CWPP_Button_Enabled');
    preferences.CWPPButtonUrl = site.getCustomPreferenceValue('PP_CWPP_Button_Url');
    preferences.CWPPStaticImageLink = sdkConfig.CWPPStaticImageLink;
    preferences.PP_CWPP_Agent_Login = site.getCustomPreferenceValue('PP_CWPP_Agent_Login');
    preferences.PP_CWPP_Agent_Password = site.getCustomPreferenceValue('PP_CWPP_Agent_Password');
    preferences.cwppButtonStyles = sdkConfig.cwppButtonStyles;
    preferences.payPalExternalApiSdk = sdkConfig.payPalExternalApiSdk;
    preferences.instanceType = dwSystem.instanceType === dwSystem.PRODUCTION_SYSTEM ? 'production' : 'sandbox';

    addWhiteListPrefs();

    return preferences;
}

module.exports = getPreferences();
