'use strict';

const {
    getPaypalPaymentInstrument
} = require('*/cartridge/scripts/paypal/helpers/paymentInstrumentHelper');

const BillingAgreementModel = require('*/cartridge/models/billingAgreement');

/**
 * This function is to handle the post payment authorization customizations
 * Updating of Saving Billing Agreement to DB
 * @param {Object} result - Authorization Result
 * @param {Object} order - Current order
 * @returns {Object} response {}
 */
function postAuthorization(result, order) { // eslint-disable-line no-unused-vars
    const paypalPaymentInstrument = getPaypalPaymentInstrument(order);
    const isActiveBillingAgreement = customer.authenticated
        && paypalPaymentInstrument
        && paypalPaymentInstrument.custom.PP_API_ActiveBillingAgreement;

    if (isActiveBillingAgreement) {
        const activeBillingAgreement = JSON.parse(paypalPaymentInstrument.custom.PP_API_ActiveBillingAgreement);
        const billingAgreementModel = new BillingAgreementModel();
        const isAccountAlreadyExist = billingAgreementModel.isAccountAlreadyExist(activeBillingAgreement.email);

        if (isAccountAlreadyExist) {
            billingAgreementModel.updateBillingAgreement(activeBillingAgreement);
        } else {
            billingAgreementModel.saveBillingAgreement(activeBillingAgreement);
        }
    }

    return {};
}

exports.postAuthorization = postAuthorization;
