'use strict';

const server = require('server');

const BasketMgr = require('dw/order/BasketMgr');
const PaymentMgr = require('dw/order/PaymentMgr');
const HookMgr = require('dw/system/HookMgr');
const Resource = require('dw/web/Resource');

const paymentInstrumentHelper = require('*/cartridge/scripts/paypal/helpers/paymentInstrumentHelper');
const paypalUtils = require('*/cartridge/scripts/paypal/paypalUtils');
const paypalPreferences = require('*/cartridge/config/paypalPreferences');
const accountHelpers = require('*/cartridge/scripts/helpers/accountHelpers');
const paypalConstants = require('*/cartridge/config/paypalConstants');
const paypalUrls = require('*/cartridge/config/paypalUrls');

const SERVER_SUBSCRIPTION_ROUTE_COMPLETE = 'route:Complete';

/**
 * Middleware to validate payment method and remove unnecessary
 * @param {Object} req - Request object
 * @param {Object} res - Response object
 * @param {Function} next - Next call in the middleware chain
 * @returns {void}
 */
function validatePaymentMethod(req, res, next) {
    const basket = BasketMgr.getCurrentBasket();

    if (!basket) {
        return next();
    }

    const paymentInstruments = basket.getPaymentInstruments();
    const paypalPaymentInstrument = paymentInstrumentHelper.getPaypalPaymentInstrument(basket);
    const billingForm = server.forms.getForm('billing');

    // if change payment from paypal to different one we remove paypal as payment instrument
    if (paypalPaymentInstrument && billingForm.paymentMethod.htmlValue !== paypalPreferences.paypalPaymentMethodId) {
        paymentInstrumentHelper.removePaypalPaymentInstrument(basket);

        return next();
    }

    // if change payment method from different one to paypal we remove already existing payment instrument
    if (!empty(paymentInstruments) && !paypalPaymentInstrument && billingForm.paymentMethod.htmlValue === paypalPreferences.paypalPaymentMethodId) {
        paymentInstrumentHelper.removeNonPayPalPaymentInstrument(basket);

        return next();
    }

    return next();
}

/**
 * Middleware to parse req.body
 * @param {Object} req - Request object
 * @param {Object} res - Response object
 * @param {Function} next - Next call in the middleware chain
 * @returns {void}
 */
function parseBody(req, res, next) {
    try {
        const data = req.body && JSON.parse(req.body);

        res.parsedBody = data;
    } catch (error) {
        paypalUtils.createErrorLog(error);
        res.setStatusCode(500);
        res.print(paypalUtils.createErrorMsg());

        return this.emit(SERVER_SUBSCRIPTION_ROUTE_COMPLETE, req, res);
    }

    return next();
}

/**
 * Middleware to validate processor
 * @param {Object} req - Request object
 * @param {Object} res - Response object
 * @param {Function} next - Next call in the middleware chain
 * @returns {void}
 */
function validateProcessor(req, res, next) {
    const processor = PaymentMgr.getPaymentMethod(paypalPreferences.paypalPaymentMethodId).getPaymentProcessor();

    if (processor) {
        return next();
    }

    paypalUtils.createErrorLog(Resource.msg('error.payment.processor.missing', 'checkout', null));
    res.setStatusCode(500);
    res.print(paypalUtils.createErrorMsg());

    return this.emit(SERVER_SUBSCRIPTION_ROUTE_COMPLETE, req, res);
}

/**
 * Middleware to remove non paypal payment
 * @param {Object} req - Request object
 * @param {Object} res - Response object
 * @param {Function} next - Next call in the middleware chain
 * @returns {void}
 */
function removeNonPaypalPayment(req, res, next) {
    const basket = BasketMgr.getCurrentBasket();

    if (!basket) {
        return next();
    }

    if (!empty(basket.paymentInstruments)) {
        paymentInstrumentHelper.removeNonPayPalPaymentInstrument(basket);
    }

    return next();
}

/**
 * Middleware to validate handle hook
 * @param {Object} req - Request object
 * @param {Object} res - Response object
 * @param {Function} next - Next call in the middleware chain
 * @returns {void}
 */
function validateHandleHook(req, res, next) {
    const processor = PaymentMgr.getPaymentMethod(paypalPreferences.paypalPaymentMethodId).getPaymentProcessor();

    if (HookMgr.hasHook('app.payment.processor.' + processor.ID.toLowerCase())) {
        return next();
    }

    paypalUtils.createErrorLog(Resource.msg('paypal.error.processoremisssing', 'paypalerrors', null));
    res.setStatusCode(500);
    res.print(paypalUtils.createErrorMsg());

    return this.emit(SERVER_SUBSCRIPTION_ROUTE_COMPLETE, req, res);
}

/**
 * Check if existed giftCert payment instruments fully cover total price of the order
* @param {Object} req - Request object
 * @param {Object} res - Response object
 * @param {Function} next - Next call in the middleware chain
 * @returns {void}
 */
function validateGiftCertificateAmount(req, res, next) {
    const basket = BasketMgr.getCurrentBasket();
    const calculatedNonGiftCertificateAmount = paymentInstrumentHelper.calculateNonGiftCertificateAmount(basket);

    if (calculatedNonGiftCertificateAmount.value !== 0) {
        return next();
    }

    if (basket.giftCertificatePaymentInstruments.length && calculatedNonGiftCertificateAmount.value === 0) {
        return next();
    }

    switch (this.name) {
        case 'SubmitPayment':
            res.json({
                form: server.forms.getForm('billing'),
                fieldErrors: [],
                serverErrors: [paypalUtils.createErrorMsg('order_covered_by_gift_ertificate')],
                error: true,
                redirectUrl: paypalUrls.paymentStage
            });
            this.emit(SERVER_SUBSCRIPTION_ROUTE_COMPLETE, req, res);

            break;
        case 'ReturnFromCart':
            res.setStatusCode(500);
            res.print(paypalUtils.createErrorMsg('order_covered_by_gift_ertificate'));
            this.emit(SERVER_SUBSCRIPTION_ROUTE_COMPLETE, req, res);

            break;
        default:
            next();

            break;
    }

    return next();
}

/**
 * Checks if 'connect with paypal window' was cancelled by buyer
* @param {Object} req - Request object
 * @param {Object} res - Response object
 * @param {Function} next - Next call in the middleware chain
 * @returns {void}
 */
function validateConnectWithPaypalUrl(req, res, next) {
    const error = request.httpParameterMap.get('error_description');

    if (!error.empty) {
        if (error.value === paypalConstants.CONNECT_WITH_PAYPAL_CONSENT_DENIED) {
            paypalUtils.createErrorLog(error.value);

            // Sets redirect endpoint depands of 'Connect with paypal' button location
            // req.querystring.state - oAuth reentry endpoint(1 or 2)
            res.redirect(accountHelpers.getLoginRedirectURL(req.querystring.state, req.session.privacyCache, false));

            return this.emit(SERVER_SUBSCRIPTION_ROUTE_COMPLETE, req, res);
        }
    }

    return next();
}

module.exports = {
    validatePaymentMethod: validatePaymentMethod,
    parseBody: parseBody,
    validateProcessor: validateProcessor,
    removeNonPaypalPayment: removeNonPaypalPayment,
    validateHandleHook: validateHandleHook,
    validateGiftCertificateAmount: validateGiftCertificateAmount,
    validateConnectWithPaypalUrl: validateConnectWithPaypalUrl
};
