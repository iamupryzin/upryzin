'use strict';

const Transaction = require('dw/system/Transaction');
const Money = require('dw/value/Money');
const Resource = require('dw/web/Resource');

const paypalRestService = require('*/cartridge/scripts/service/paypalRestService');
const paypalTokenService = require('*/cartridge/scripts/service/paypalTokenService');

const paypalPreferences = require('*/cartridge/config/paypalPreferences');

const {
    createErrorLog,
    createErrorMsg
} = require('*/cartridge/scripts/paypal/paypalUtils');

const paypalConstants = require('*/cartridge/config/paypalConstants');
const PATH_CHECKOUT_ORDERS = 'v2/checkout/orders/';
var messageOrderIdNotFound = Resource.msg('paypal.error.api_order_id_notfound', 'paypalerrors', null);

// A paypalTokenService instance
var service = paypalTokenService();

/**
 * Function to get information about an order
 *
 * @param {Object} paymentInstrument - paypalPaymentInstrument
 * @returns {Object} Call handling result
 */
function getOrderDetails(paymentInstrument) {
    try {
        if (!paymentInstrument.custom.paypalOrderID) {
            createErrorLog(messageOrderIdNotFound);
            throw new Error();
        }

        var resp = paypalRestService.call({
            path: PATH_CHECKOUT_ORDERS + paymentInstrument.custom.paypalOrderID,
            method: 'GET',
            body: {}
        });

        if (resp) {
            return {
                payer: resp.payer,
                purchase_units: resp.purchase_units
            };
        }

        createErrorLog('No payer info was found. Order ID ' + paymentInstrument.custom.paypalOrderID);
        throw new Error();
    } catch (err) {
        return { err: createErrorMsg(err.message) };
    }
}

/**
 * Function to update information about an order
 *
 * @param {Object} paymentInstrument - paypalPaymentInstrument
 * @param {Object} purchaseUnit - purchase unit
 * @returns {Object} Call handling result
 */
function updateOrderDetails(paymentInstrument, purchaseUnit) {
    try {
        if (!paymentInstrument.custom.paypalOrderID) {
            createErrorLog(messageOrderIdNotFound);
            throw new Error();
        }

        paypalRestService.call({
            path: PATH_CHECKOUT_ORDERS + paymentInstrument.custom.paypalOrderID,
            method: 'PATCH',
            body: [
                {
                    op: 'replace',
                    path: '/purchase_units/@reference_id==\'default\'',
                    value: purchaseUnit
                }
            ]
        });

        if (paymentInstrument.paymentTransaction.amount.value !== purchaseUnit.amount.value) {
            Transaction.wrap(function() {
                paymentInstrument.paymentTransaction.setAmount(new Money(purchaseUnit.amount.value, purchaseUnit.amount.currency_code));
            });
        }

        return { isOkUpdate: true };
    } catch (err) {
        return { err: createErrorMsg(err.message) };
    }
}

/**
 * Function to create transaction
 * If BA exists it is used as payment source in body
 *
 * @param {Object} paymentInstrument - paypalPaymentInstrument
 * @param {Object} bodyObj - payment source with BA id if BA exists
 * @returns {Object} Call handling result
 */
function createTransaction(paymentInstrument, bodyObj) {
    try {
        if (!paymentInstrument.custom.paypalOrderID) {
            createErrorLog(messageOrderIdNotFound);
            throw new Error();
        }

        var actionType = paypalPreferences.isCapture ? 'capture' : 'authorize';
        var response = paypalRestService.call({
            path: [PATH_CHECKOUT_ORDERS, paymentInstrument.custom.paypalOrderID, '/', actionType].join(''),
            body: bodyObj || {}
        });

        return {
            response: response
        };
    } catch (err) {
        return { err: createErrorMsg(err.message) };
    }
}

/**
 * Create a billing agreement token
 * Pass the agreement details including the description, payer, and billing plan in the JSON request body.
 *
 * @param {Object} restRequestData data
 * @returns {Object} Call returns the HTTP 201 Created status code and a JSON response that includes an approval URL:
 */
function getBillingAgreementToken(restRequestData) {
    try {
        var resp = paypalRestService.call(restRequestData);

        if (resp) {
            return { billingAgreementToken: resp.token_id };
        }

        createErrorLog('No billing agreement-tokens was found');
        throw new Error();
    } catch (err) {
        return { err: createErrorMsg(err.message) };
    }
}

/**
 * Makes post call using facilitator Access Token and transfers billingToken
 *  save's billingAgreementID & billingAgreementPayerEmail to input field
 *  and triggers checkout place order stage
 *
 * @param {string} billingToken - billing agreement token
 * @returns {Object} JSON response that includes the billing agreement ID and information about the payer
 */
function createBillingAgreement(billingToken) {
    try {
        if (!billingToken) {
            createErrorLog('No billing Token provided');
            throw new Error();
        }

        var resp = paypalRestService.call({
            path: 'v1/billing-agreements/agreements',
            method: 'POST',
            body: {
                token_id: billingToken
            }
        });

        if (resp) {
            return resp;
        }

        createErrorLog('No billing agreement ID was found');
        throw new Error();
    } catch (err) {
        return { err: createErrorMsg(err.message) };
    }
}

/**
 * Function to create order if BA exists
 * If BA exists it is used as payment source in body
 *
 * @param {Object} purchaseUnit - purchaseUnit
 * @param {dw.order.LineItemCtnr} lineItemCtnr - lineItemCntr basket/order
 * @returns {Object} Call handling result
 */
function createOrder(purchaseUnit, lineItemCtnr) {
    let payer = {};

    try {
        if (!purchaseUnit) {
            createErrorLog('No purchaseUnit was found');
            throw new Error();
        }

        // Adds a payer object to the request. Basically  is used for LPM payment method
        if (lineItemCtnr && lineItemCtnr.billingAddress) {
            const regExpPhone = new RegExp(paypalConstants.REGEXP_PHONE);
            const regExpEmail = new RegExp(paypalConstants.REGEXP_EMAIL);

            const billingAddress = lineItemCtnr.billingAddress;

            if (regExpPhone.test(billingAddress.phone) && billingAddress.countryCode) {
                payer = {
                    name: {
                        given_name: billingAddress.firstName,
                        surname: billingAddress.lastName
                    },
                    email_address: regExpEmail.test(lineItemCtnr.customerEmail) ? lineItemCtnr.customerEmail : '',
                    phone: {
                        phone_number: {
                            national_number: billingAddress.phone
                        }
                    },
                    address: {
                        address_line_1: billingAddress.address1,
                        address_line_2: billingAddress.address2 || '',
                        admin_area_2: billingAddress.city,
                        admin_area_1: billingAddress.stateCode,
                        postal_code: decodeURIComponent(billingAddress.postalCode),
                        country_code: billingAddress.countryCode.value
                    }
                };
            }
        }

        const resp = paypalRestService.call({
            path: 'v2/checkout/orders',
            body: {
                intent: paypalPreferences.isCapture ? 'CAPTURE' : 'AUTHORIZE',
                purchase_units: [purchaseUnit],
                payer: payer,
                application_context: {
                    shipping_preference: purchaseUnit.shipping_preference
                }
            },
            partnerAttributionId: paypalPreferences.partnerAttributionId
        });

        return {
            resp: resp
        };
    } catch (err) {
        return { err: createErrorMsg(err.message) };
    }
}

/**
 * Function to get BA details
 * If BA exists it is used as payment source in body
 *
 * @param {Object} paymentInstrument - paymentInstrument
 * @returns {Object} Call handling result
 */
function getBADetails(paymentInstrument) {
    try {
        if (!paymentInstrument.custom.PP_API_ActiveBillingAgreement) {
            createErrorLog('No active billing agreement was found');
            throw new Error();
        }

        var baID;

        try {
            baID = JSON.parse(paymentInstrument.custom.PP_API_ActiveBillingAgreement).baID;
        } catch (error) {
            createErrorLog(error);

            return new Error(error);
        }

        var resp = paypalRestService.call({
            path: '/v1/billing-agreements/agreements/' + baID,
            method: 'GET'
        });

        if (resp.state !== 'ACTIVE') {
            return { active: false };
        }

        return {
            id: resp.id,
            billing_info: resp.payer.payer_info,
            shipping_address: resp.shipping_address,
            active: true
        };
    } catch (err) {
        return { err: createErrorMsg(err.message) };
    }
}

/**
 * Function to get BA details by ID
 * @param {string} baID - Billing Agreements ID
 * @returns {Object} Call handling result
 */
function getBADetailsById(baID) {
    try {
        return paypalRestService.call({
            path: '/v1/billing-agreements/agreements/' + baID,
            method: 'GET'
        });
    } catch (err) {
        return { err: createErrorMsg(err.message) };
    }
}

/**
 * Function to cancel BA
 * If BA exists it is used as payment source in body
 *
 * @param {Object} baID - billing agreement ID to cancel
 * @returns {Object} Call handling result
 */
function cancelBillingAgreement(baID) {
    try {
        if (!baID) {
            createErrorLog('No billing agreement ID provided');
            throw new Error();
        }

        return paypalRestService.call({
            path: ['/v1/billing-agreements/agreements/', baID, '/cancel'].join(''),
            method: 'POST'
        });
    } catch (err) {
        return { err: createErrorMsg(err.message) };
    }
}

/**
 * Gets access token according a paypal user autherization code
 * @param {string} authCode Autherization code of paypal user
 * @returns {string} access token
 */
function exchangeAuthCodeForAccessToken(authCode) {
    var result = service.setThrowOnError().call({
        code: authCode,
        requestType: paypalConstants.ACCESS_TOKEN,
        path: 'oauth2/token',
        method: paypalConstants.METHOD_POST
    });

    if (!result.ok) {
        var errorObject = JSON.parse(result.errorMessage);
        var error = errorObject.error_description;

        createErrorLog(error);
        throw error;
    }

    return result.object.access_token;
}

/**
 * Gets paypal customer info according access token
 * @param {string} accessToken Access Token
 * @returns {Object} Object with the customer info
 */
function getPaypalCustomerInfo(accessToken) {
    const response = service.setThrowOnError().call({
        accessToken: accessToken,
        requestType: paypalConstants.USER_INFO,
        path: 'identity/oauth2/userinfo?schema=paypalv1.1',
        method: paypalConstants.METHOD_GET
    });

    const payPalCustomerInfo = response.isOk() ? response.object : null;

    if (!payPalCustomerInfo || !payPalCustomerInfo.emails || !payPalCustomerInfo.name || !payPalCustomerInfo.address) {
        return null;
    }

    const [firstName, middleName, lastName] = payPalCustomerInfo.name.trim().split(/\s+/);

    payPalCustomerInfo.firstName = firstName;
    payPalCustomerInfo.lastName = lastName || middleName;

    const primaryEmail = payPalCustomerInfo.emails.find(function(email) {
        return email.primary;
    });

    payPalCustomerInfo.email = primaryEmail.value;
    payPalCustomerInfo.emailConfirmed = primaryEmail.confirmed;

    delete payPalCustomerInfo.emails;

    payPalCustomerInfo.addressObjectFromPayPal = {
        id: [paypalConstants.LOGIN_PAYPAL, payPalCustomerInfo.address.postal_code].join(' - '),
        address1: payPalCustomerInfo.address.street_address,
        city: payPalCustomerInfo.address.locality,
        countryCode: payPalCustomerInfo.address.country,
        firstName: payPalCustomerInfo.firstName,
        lastName: payPalCustomerInfo.lastName,
        postalCode: payPalCustomerInfo.address.postal_code,
        stateCode: payPalCustomerInfo.address.region,
        phone: Resource.msg('paypal.account.address.phonenumber.notprovided', 'locale', null)
    };

    return payPalCustomerInfo;
}

module.exports = {
    createTransaction: createTransaction,
    updateOrderDetails: updateOrderDetails,
    getOrderDetails: getOrderDetails,
    getBillingAgreementToken: getBillingAgreementToken,
    createBillingAgreement: createBillingAgreement,
    createOrder: createOrder,
    getBADetails: getBADetails,
    getBADetailsById: getBADetailsById,
    cancelBillingAgreement: cancelBillingAgreement,
    exchangeAuthCodeForAccessToken: exchangeAuthCodeForAccessToken,
    getPaypalCustomerInfo: getPaypalCustomerInfo
};
