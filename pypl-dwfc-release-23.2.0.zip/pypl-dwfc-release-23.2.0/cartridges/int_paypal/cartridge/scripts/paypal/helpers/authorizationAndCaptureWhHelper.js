'use strict';

const Resource = require('dw/web/Resource');
const Transaction = require('dw/system/Transaction');
const CustomObject = require('dw/object/CustomObject');

const paypalHelper = require('*/cartridge/scripts/paypal/helpers/paypalHelper');
const {
    getPaypalPaymentInstrument
} = require('*/cartridge/scripts/paypal/helpers/paymentInstrumentHelper');

const autorizationAndCaptureWhHelper = {};

/**
 * Updates payment status of order in the Business manager
 * @param {dw.order.Order} order Order instance
 * @param {string} paymentStatus Payment Status
 * @param {Object} responseData Response data to API call
 */
autorizationAndCaptureWhHelper.updateOrderPaymentStatus = function(order, paymentStatus, responseData) {
    const requestData = {
        summary: Resource.msg('paypal.request.webhook.summary', 'locale', null)
    };

    responseData.paymentStatus = paymentStatus;

    Transaction.wrap(function() {
        // If the transaction was created through business manager - updates a custom object, through storefront - DW Payment Instrument.
        if (order instanceof CustomObject) {
            // Updates order custom payment status of a PayPalNewTransactions Custom Object
            order.custom.paymentStatus = paymentStatus;
            order.custom.paypalRequest = JSON.stringify(requestData);
            order.custom.paypalResponse = JSON.stringify(responseData);
            order.custom.paypalTransactionHistory = paypalHelper.prepareTransactionHistory(order, responseData);
        } else {
            const paymentInstrument = getPaypalPaymentInstrument(order);
            const paymentTransaction = paymentInstrument.paymentTransaction;

            // Updates order paypal payment status
            paymentInstrument.custom.paypalPaymentStatus = paymentStatus;
            paymentInstrument.custom.paypalRequest = JSON.stringify(requestData);
            paymentInstrument.custom.paypalResponse = JSON.stringify(responseData);

            paymentTransaction.custom.paypalTransactionHistory = paypalHelper.prepareTransactionHistory(paymentTransaction, responseData);
        }
    });
};

module.exports = autorizationAndCaptureWhHelper;
