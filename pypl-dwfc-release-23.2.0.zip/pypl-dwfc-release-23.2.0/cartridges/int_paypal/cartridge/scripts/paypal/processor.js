'use strict';

const Transaction = require('dw/system/Transaction');
const Resource = require('dw/web/Resource');
const Order = require('dw/order/Order');

const paymentInstrumentHelper = require('*/cartridge/scripts/paypal/helpers/paymentInstrumentHelper');
const billingAgreementHelper = require('*/cartridge/scripts/paypal/helpers/billingAgreementHelper');
const paypalHelper = require('*/cartridge/scripts/paypal/helpers/paypalHelper');
const paypalUtils = require('*/cartridge/scripts/paypal/paypalUtils');
const addressHelper = require('*/cartridge/scripts/paypal/helpers/addressHelper');
const paypalApi = require('*/cartridge/scripts/paypal/paypalApi');
const paypalConstants = require('*/cartridge/config/paypalConstants');

const paypalErrors = {
    GENERAL: 'paypal.error.general',
    ZEROAMOUNT: 'paypal.error.zeroamount'
};

/**
 * @param {dw.order.PaymentInstrument} paymentInstrument - the payment instrument
 */
function clearCustomPropertyCurrentPaypalEmail(paymentInstrument) {
    Transaction.wrap(function() {
        paymentInstrument.custom.currentPaypalEmail = null;
    });
}

/**
 * @param {Object} billingForm - a billing form data
 * @returns {boolean} - returns true if the value of billing agreement ID exists
 */
function isBillingAgreementID(billingForm) {
    return billingForm.paypal.billingAgreementID && !empty(billingForm.paypal.billingAgreementID.htmlValue);
}

/**
 * Processor Handle
 *
 * @param {dw.order.LineItemCtnr} basket - Current basket
 * @param {Object} paymentInformation - paymentForm from hook
 * @param {Object} shippingAddress - shippingAddress object
 * @returns {Object} Processor handling result
 */
function handle(basket, paymentInformation, shippingAddress) {
    const billingForm = paymentInformation.billingForm;

    let paymentInstrument = paymentInstrumentHelper.getPaypalPaymentInstrument(basket);

    if (!paymentInstrument) {
        paymentInstrument = paymentInstrumentHelper.createPaymentInstrument(basket, billingForm.paymentMethod.value);
    }

    let validationResult;

    if (isBillingAgreementID(billingForm)) {
        const activeBA = billingAgreementHelper.createBaFromForm(billingForm);
        let baFromPaymentInstrument;

        if (paymentInstrument.custom.PP_API_ActiveBillingAgreement) {
            baFromPaymentInstrument = JSON.parse(paymentInstrument.custom.PP_API_ActiveBillingAgreement);
        }

        Transaction.wrap(function() {
            paymentInstrument.custom.PP_API_ActiveBillingAgreement = JSON.stringify(activeBA);
            paymentInstrument.custom.currentPaypalEmail = activeBA.email;
            session.privacy.paypalPayerEmail = activeBA.email;
        });

        const billingAgreementDetails = paypalApi.getBADetails(paymentInstrument);

        if (baFromPaymentInstrument && !billingAgreementHelper.isSameBillingAgreement(baFromPaymentInstrument, activeBA)) {
            paypalHelper.updateBillingInfoIfAccountChanged({
                baFromPI: baFromPaymentInstrument,
                activeBA: activeBA,
                paypalPI: paymentInstrument,
                basket: basket,
                billing_info: billingAgreementDetails.billing_info,
                BADetailsError: billingAgreementDetails.err,
                handleError: paypalUtils.handleError(this.BADetailsError, paypalUtils.errorHandle, [this.BADetailsError])
            });
        } else {
            addressHelper.updateBABillingAddress(basket, billingAgreementDetails.billing_info);
        }

        if (billingAgreementDetails.err) {
            paypalUtils.createErrorLog(billingAgreementDetails.err);

            return {
                error: true,
                fieldErrors: [],
                serverErrors: [
                    Resource.msg(paypalErrors.GENERAL, 'paypalerrors', null)
                ]
            };
        }

        if (!shippingAddress || shippingAddress === 'undefined') {
            validationResult = addressHelper.validateBaPaypalAddresses(billingAgreementDetails);

            if (validationResult.error) {
                clearCustomPropertyCurrentPaypalEmail(paymentInstrument);

                return {
                    error: true,
                    errorName: validationResult.errorName,
                    statusCode: 422,
                    fieldErrors: [
                        validationResult.fields
                    ],
                    serverErrors: [
                        validationResult.message
                    ]
                };
            }

            // Empty shipping_address in case when only gift certificate in the basket
            if (!billingAgreementDetails.shipping_address) {
                billingAgreementDetails.shipping_address = billingAgreementDetails.billing_info.billing_address;
                billingAgreementDetails.shipping_address.recipient_name = [billingAgreementDetails.billing_info.first_name,
                    billingAgreementDetails.billing_info.last_name].join(' ');
            }

            billingAgreementDetails.shipping_address.phone = billingAgreementDetails.billing_info.phone;
            shippingAddress = billingAgreementDetails.shipping_address;
        }
    } else {
        Transaction.wrap(function() {
            paymentInstrument.custom.paypalOrderID = session.privacy.paypalOrderID;
        });

        const orderDetails = paypalApi.getOrderDetails(paymentInstrument);

        const {
            payer,
            purchase_units,
            err: OrderDetailsError
        } = orderDetails;

        if (OrderDetailsError) {
            paypalUtils.createErrorLog(OrderDetailsError);

            return {
                error: true,
                fieldErrors: [],
                serverErrors: [
                    Resource.msg(paypalErrors.GENERAL, 'paypalerrors', null)
                ]
            };
        }

        validationResult = addressHelper.validateCheckoutOrdersPaypalAddresses(orderDetails);

        if (validationResult.error) {
            clearCustomPropertyCurrentPaypalEmail(paymentInstrument);

            return {
                error: true,
                errorName: validationResult.errorName,
                statusCode: 422,
                fieldErrors: [
                    validationResult.fields
                ],
                serverErrors: [
                    validationResult.message
                ]
            };
        }

        addressHelper.updateOrderBillingAddress(basket, payer);

        Transaction.wrap(function() {
            paymentInstrument.custom.currentPaypalEmail = payer.email_address;
        });

        // in case of checkout via Venmo or PAYPAL Debit/Credit Card save it's name to payment instrument custom property
        if ([
            paypalConstants.PAYMENT_METHOD_ID_VENMO,
            paypalConstants.PAYMENT_METHOD_ID_Debit_Credit_Card,
            paypalConstants.PAYMENT_METHOD_ID_PAYPAL
        ].includes(billingForm.paypal.usedPaymentMethod.value)) {
            Transaction.wrap(function() {
                paymentInstrument.custom.paymentId = billingForm.paypal.usedPaymentMethod.value;
            });
        }

        session.privacy.paypalPayerEmail = payer.email_address;
        shippingAddress = purchase_units[0];
        shippingAddress.phone = payer.phone;
    }

    return {
        success: true,
        paymentInstrument: paymentInstrument,
        shippingAddress: shippingAddress
    };
}

/**
 * Create a request body object for createOrder call with BA
 * @param  {dw.order.OrderPaymentInstrument} paymentInstrument current active paypal payment instrument
 * @returns {Object} body for request
 */
function createBAReqBody(paymentInstrument) {
    const activeBillingAgreement = JSON.parse(paymentInstrument.custom.PP_API_ActiveBillingAgreement);
    const billingAgreementId = activeBillingAgreement.baID;

    return {
        payment_source: {
            token: {
                id: billingAgreementId,
                type: 'BILLING_AGREEMENT'
            }
        }
    };
}

/**
 * Save result of rest call and update order data
 *
 * @param {dw.order.LineItemCtnr} order - Order object
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument - current payment instrument
 * @returns {Object} Processor authorizing result
 */
function authorize(order, paymentInstrument) {
    const purchaseUnit = paypalHelper.getPurchaseUnit(order);
    const isUpdateRequired = paypalHelper.isPurchaseUnitChanged(purchaseUnit, paymentInstrument);

    delete session.privacy.paypalUsedOrderNo;
    let bodyObj = {};

    if (empty(paymentInstrument) || empty(order) || order.status === Order.ORDER_STATUS_FAILED) {
        return {
            error: true,
            fieldErrors: [],
            serverErrors: [
                Resource.msg(paypalErrors.GENERAL, 'paypalerrors', null)
            ]
        };
    }

    if (paymentInstrument.paymentTransaction.amount.value === 0) {
        return {
            error: true,
            fieldErrors: [],
            serverErrors: [
                Resource.msg(paypalErrors.ZEROAMOUNT, 'paypalerrors', null)
            ]
        };
    }

    if (paymentInstrument.custom.paypalOrderID && isUpdateRequired) {
        const {
            err: updateOrderDetailsError
        } = paypalApi.updateOrderDetails(paymentInstrument, purchaseUnit);

        if (updateOrderDetailsError) {
            paypalUtils.createErrorLog(updateOrderDetailsError);

            return {
                authorized: false,
                error: true,
                fieldErrors: [],
                serverErrors: [updateOrderDetailsError],
                message: updateOrderDetailsError
            };
        }

        session.privacy.orderDataHash = paypalUtils.encodeString(purchaseUnit);
    }

    if (paymentInstrument.custom.PP_API_ActiveBillingAgreement) {
        const {
            resp,
            err: createOrderError
        } = paypalApi.createOrder(purchaseUnit, order);

        if (createOrderError) {
            paypalUtils.createErrorLog(createOrderError);

            return {
                authorized: false,
                error: true,
                fieldErrors: [],
                serverErrors: [createOrderError],
                message: createOrderError
            };
        }

        Transaction.wrap(function() {
            paymentInstrument.custom.paypalOrderID = resp.id;
        });

        try {
            bodyObj = createBAReqBody(paymentInstrument);
        } catch (err) {
            paypalUtils.createErrorLog(err);

            return {
                error: true,
                authorized: false,
                fieldErrors: [],
                serverErrors: [err]
            };
        }
    }

    Transaction.wrap(function() {
        order.custom.paypalPaymentMethod = 'express';
    });

    const {
        response,
        err: createTransactionError
    } = paypalApi.createTransaction(paymentInstrument, bodyObj);

    if (createTransactionError) {
        paypalUtils.createErrorLog(createTransactionError);

        return {
            error: true,
            fieldErrors: [],
            serverErrors: [createTransactionError]
        };
    }

    const paymentTransaction = paymentInstrument.paymentTransaction;

    Transaction.wrap(function() {
        const transactionId = paypalHelper.getTransactionId(response);

        paymentInstrument.getPaymentTransaction().setTransactionID(transactionId);
        paymentInstrument.custom.paypalRequest = JSON.stringify(bodyObj);
        paymentInstrument.custom.paypalResponse = JSON.stringify(response);
        paymentInstrument.custom.paypalPaymentStatus = paypalHelper.getTransactionStatus(response);
        paymentTransaction.custom.paypalTransactionHistory = paypalHelper.prepareTransactionHistory(paymentTransaction, response);
        order.custom.PP_API_TransactionID = transactionId;
    });

    session.privacy.orderDataHash = null;

    return {
        authorized: true
    };
}

exports.handle = handle;
exports.authorize = authorize;
