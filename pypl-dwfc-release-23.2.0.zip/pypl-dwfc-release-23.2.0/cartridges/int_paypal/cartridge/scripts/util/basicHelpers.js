'use strict';

const basicHelpers = {};

/**
 * @param {mixed} value object key
 * @param {mixed} defaultValue default value
 * @returns {mixed} return current or default value
 */
basicHelpers.getValueOr = function(value, defaultValue) {
    return value || defaultValue;
};

/**
 * @param {Object} object object
 * @param {mixed} key object key
 * @param {mixed} defaultValue default value
 * @returns {mixed} return value by key or default value
 */
basicHelpers.getValueByKey = function(object, key, defaultValue) {
    if (typeof key === 'string' && key.indexOf('.') > 0) {
        const keys = key.split('.');
        const newObject = object[keys.shift()];

        if (!newObject) {
            return defaultValue;
        }

        return this.getValueByKey(newObject, keys.join('.'), defaultValue);
    }

    return this.getValueOr(object[key], defaultValue);
};

/**
 * @param {dw.order.Basket} basket current user's basket
 * @returns {dw.customer.CustomerAddress|null} preferred customer address
 */
basicHelpers.getPreferredAddress = function(basket) {
    return this.getValueByKey(basket, 'customer.addressBook.preferredAddress', null);
};

basicHelpers.isObject = function(obj) {
    return obj !== null && typeof obj === 'object' && Object.prototype.toString.call(obj) === '[object Object]';
};

basicHelpers.toCamelCase = function(value) {
    return value.toLowerCase().replace(/([-_ ][a-z])/g, function(group) {
        return group.toUpperCase().replace(/[-_ ]/g, '');
    });
};

basicHelpers.convertKeysToCamelCase = function(obj) {
    if (!this.isObject(obj)) {
        return obj;
    }

    const self = this;

    Object.keys(obj).forEach(function(key) {
        if (/[_-]/.test(key)) {
            const newKey = self.toCamelCase(key);

            obj[newKey] = obj[key];

            delete obj[key];

            key = newKey;
        }

        if (self.isObject(obj[key])) {
            self.convertKeysToCamelCase(obj[key]);
        }
    });

    return obj;
};

/**
 * Generates a random number in the specified range.
 * @param {Integer} min Start of the range.
 * @param {Integer} max End of the range.
 * @returns {Integer} Random number.
 */
basicHelpers.generateRandomNumber = function(min, max) {
    const SecureRandom = require('dw/crypto/SecureRandom');
    const randomValue = (new SecureRandom()).nextNumber();

    return Math.floor(randomValue * (max - min + 1)) + min;
};

/**
 * Generates a random string of characters in the length.
 * @param {Integer} stringLength length of the string.
 * @returns {string} Random string.
 */
basicHelpers.generateRandomString = function(stringLength) {
    const payPalConstants = require('*/cartridge/config/paypalConstants');

    let result = '';
    let counter = 0;

    while (counter < stringLength) {
        if (this.generateRandomNumber(0, 1) === 0) {
            result += payPalConstants.CHARACTERS.charAt(this.generateRandomNumber(0, payPalConstants.CHARACTERS.length));
        } else {
            result += this.generateRandomNumber(0, 9);
        }

        counter += 1;
    }

    return result;
};

/**
* @param {string} locale - a locale value
* @returns {string} - return a locale with hyphen
*/
basicHelpers.getLocaleWithHyphen = function(locale) {
    let currentLocale = locale;

    if (currentLocale === 'default') {
        currentLocale = require('dw/system/Site').current.defaultLocale;
    }

    if (currentLocale.split('_').length !== 2) {
        currentLocale = [currentLocale, currentLocale].join('-');
    }

    return currentLocale.toLowerCase().replace('_', '-');
};

/**
 * Determines whether the given input is valid JSON or not.
 *
 * @param {string} input - The input value to check.
 * @returns {boolean} - `true` if the input is valid JSON, `false` otherwise.
 */
basicHelpers.isJson = function(input) {
    if (typeof input !== 'string') {
        return false;
    }

    try {
        const parsedJson = JSON.parse(input);
        const parsedType = Object.prototype.toString.call(parsedJson);

        return parsedType === '[object Object]' || parsedType === '[object Array]';
    } catch (error) {
        return false;
    }
};

module.exports = basicHelpers;
