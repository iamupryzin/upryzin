 'use strict';

((win, doc, paypal) => {
    const buttonOptions = {
        theme: 'blue',
        buttonType: 'LWP',
        buttonSize: 'lg',
        buttonShape: 'rect'
    };

    const $loader = doc.getElementById('js-cwpp-loader');
    const $location = doc.getElementById('js-cwpp-location');

    const $form = doc.getElementById('js-cwpp-config-form');
    const $container = doc.getElementById('js-cwpp-button');

    const $theme = doc.getElementById('js-cwpp-theme-button');
    const $buttonType = doc.getElementById('js-cwpp-label');
    const $buttonSize = doc.getElementById('js-cwpp-size');
    const $buttonShape = doc.getElementById('js-cwpp-shape-button');

    const updateButtonStyle = (key, value) => {
        $container.innerHTML = '';

        if (key !== undefined) {
            buttonOptions[key] = value;
        }

        const payPalApiConfig = JSON.parse($form.getAttribute('data-paypal-api-config'));

        // https://developer.paypal.com/docs/log-in-with-paypal/integrate/generate-button
        paypal.use(['login'], function (login) {
            login.render({
                appid: payPalApiConfig.appid,
                scopes: 'openid profile email address',
                authend: payPalApiConfig.authend,
                containerid: 'js-cwpp-button',
                responseType: 'code',
                locale: payPalApiConfig.locale,
                theme: buttonOptions.theme,
                buttonType: buttonOptions.buttonType,
                buttonShape: buttonOptions.buttonShape,
                buttonSize: buttonOptions.buttonSize,
                fullPage: 'true',
                returnurl: payPalApiConfig.returnurl
            });
        });
    };

    const handleSize = () => {
        updateButtonStyle('buttonSize', $buttonSize.value);
    };

    const handleTheme = () => updateButtonStyle('theme', $theme.value);
    const handleType = () => updateButtonStyle('buttonType', $buttonType.value);
    const handleShape = () => updateButtonStyle('buttonShape', $buttonShape.value);

    const updateButtonOptionsByLocation = (locationKey) => {
        const data = JSON.parse($form.getAttribute('data-button-styles'))[locationKey];

        buttonOptions.theme = data.theme;
        buttonOptions.buttonType = data.buttonType;
        buttonOptions.buttonSize = data.buttonSize;
        buttonOptions.buttonShape = data.buttonShape;

        $theme.value = data.theme;
        $buttonType.value = data.buttonType;
        $buttonSize.value = data.buttonSize;
        $buttonShape.value = data.buttonShape;

        updateButtonStyle();
    };

    const handleLocation = () => {
        updateButtonOptionsByLocation($location.value);
    };

    const handleSubmitForm = (event) => {
        const alertHandler = new AlertHandlerModel();

        event.preventDefault();

        $loader.classList.remove('d-none');

        fetch(event.currentTarget.action, {
            method: 'POST',
            body: new FormData(event.currentTarget)
        })
            .then((response) => response.json())
            .then((response) => {
                win.location.href = response.redirectUrl;
            })
            .catch((error) => {
                alertHandler.showAlertMessage({
                    message: error.message,
                    type: 'danger'
                });
            })
            .finally(() => {
                $loader.classList.add('d-none');
            });
    };

    const cwppInit = () => {
        let location = 'login';

        const params = new URLSearchParams(win.location.search);

        if (params.get('tab') === 'cwpp' && params.has('location')) {
            location = params.get('location');
            win.history.replaceState(null, null, `${win.location.pathname}?tab=cwpp`);
        }

        $location.value = location;

        updateButtonOptionsByLocation(location);

        $theme.addEventListener('change', handleTheme);
        $buttonType.addEventListener('change', handleType);
        $buttonShape.addEventListener('change', handleShape);
        $buttonSize.addEventListener('change', handleSize);

        $form.addEventListener('submit', handleSubmitForm);
        $location.addEventListener('change', handleLocation);
    };

    doc.addEventListener('DOMContentLoaded', () => {
        if (!$container) {
            return;
        }

        const script = doc.createElement('script');

        script.src = $container.getAttribute('data-cwpp-sdk');

        script.onload = cwppInit;

        doc.body.appendChild(script);
    });
})(window, document, window.paypal);
