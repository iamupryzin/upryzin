'use strict';

((win, doc, $) => {
    const types = {
        flex: ['js-style-ratio', 'js-style-color'],
        text: ['js-style-text-color', 'js-style-logo-position', 'js-style-logo-type'],
        LogoPosition: ['js-style-logo-position']
    };

    const $styleLogoType = doc.getElementById('js-style-logo-type');
    const $styleLayout = doc.getElementById('js-style-layout');
    const $styleColor = doc.getElementById('js-style-color');
    const $styleRatio = doc.getElementById('js-style-ratio');
    const $styleTextColor = doc.getElementById('js-style-text-color');
    const $styleLogoPosition = doc.getElementById('js-style-logo-position');
    const $placement = doc.getElementById('js-placement');
    const $creditbannerConfigForm = doc.getElementById('js-creditbanner-form');
    const alertHandler = new AlertHandlerModel();

    /**
     * Looping through array
     * showing or hiding selected divs
     *
     * @param {Array} layout flex and text configurations
     * @param {string} display value none or block
     */
    function toggleDisplay(layout, display) {
        layout.forEach(element => {
            doc.getElementById(element).parentNode.style.display = display;
        });
    }

    /**
     * Toggle (Hide/Show) an Element's
     * @param {string} styleLayout value none or block
     */
    function toggleElement(styleLayout) {
        if (styleLayout) {
            toggleDisplay(types.text, 'block');
            toggleDisplay(types.flex, 'none');
        } else {
            toggleDisplay(types.text, 'none');
            toggleDisplay(types.flex, 'block');
        }
    }

    /**
     * Toggle (Hide/Show) an Logo Position values
     */
    function toggleLogoPosition() {
        const isLogoPosition = $styleLogoType.value;
        const isTextStyleLayout = $styleLayout.value === 'text';

        if (isTextStyleLayout) {
            if (isLogoPosition === 'primary' || isLogoPosition === 'alternative') {
                toggleDisplay(types.LogoPosition, 'block');
            } else {
                toggleDisplay(types.LogoPosition, 'none');
            }
        }
    }

    /**
     * Update html option values with saved Pay Pal, Banner Styles values from custom pref PP_API_Credit_Banner_Styles
     *
     * @param {Object} savedCreditBannerConfig object with styleColor, styleRatio, placement, styleLayout, styleTextColor, styleLogoPosition, styleLogoType configs
    */
    function updateValuesWithConfigs(savedCreditBannerConfig) {
        Object.keys(savedCreditBannerConfig).forEach(element => {
            doc.querySelector(`[name="${element}"]`).value = savedCreditBannerConfig[element];
        });
    }

    /**
     * Return style configurations for Credit Message
     * Available values type Text:
     * textColor: (string) black, white, monochrome, grayscale
     * logoPosition: (string) left, right, top
     * logoType: (string) primary, alternative, inline, none
     *
     * Available values type Flex:
     * styleRatio: (number) 1x1 1x4, 8x1, 20x1
     * styleColor: (string) glue, gray, white, black
     *
     * @returns {Object} object with styleColor, styleRatio, placement, styleLayout, styleTextColor, styleLogoPosition, styleLogoType
    */
    function getCreditMessageStyleConfigs() {
        return {
            styleColor: $styleColor.value,
            styleRatio: $styleRatio.value,
            styleLayout: $styleLayout.value,
            styleTextColor: $styleTextColor.value,
            styleLogoPosition: $styleLogoPosition.value,
            styleLogoType: $styleLogoType.value
        };
    }

    /**
     * Update html data attributes with saved Pay Pal, Banner Styles values from custom pref PP_API_Credit_Banner_Styles
     *
     * @param {Object} savedCreditBannerConfig object with styleColor, styleRatio, placement, styleLayout, styleTextColor, styleLogoPosition, styleLogoType configs
    */
    function updateAttributes(savedCreditBannerConfig) {
        const $creditMessagePDP = doc.querySelector('.js-credit-message-pdp');
        $creditMessagePDP.setAttribute('data-pp-style-color', savedCreditBannerConfig.styleColor);
        $creditMessagePDP.setAttribute('data-pp-style-ratio', savedCreditBannerConfig.styleRatio);
        $creditMessagePDP.setAttribute('data-pp-style-layout', savedCreditBannerConfig.styleLayout);
        $creditMessagePDP.setAttribute('data-pp-style-text-color', savedCreditBannerConfig.styleTextColor);
        $creditMessagePDP.setAttribute('data-pp-style-logo-position', savedCreditBannerConfig.styleLogoPosition);
        $creditMessagePDP.setAttribute('data-pp-style-logo-type', savedCreditBannerConfig.styleLogoType);
    }

    doc.addEventListener('DOMContentLoaded', function () {
        let pageType = $placement[0].value;
        const params = (new URLSearchParams(win.location.search));

        if (params.has('savedBannerStyles')) {
            pageType = params.get('savedBannerStyles');
            win.history.replaceState(null, null, win.location.pathname);
            win.scrollTo(0, 450);
        }

        const creditBannerConfig = JSON.parse($creditbannerConfigForm.getAttribute('data-banner-styles'))[pageType];
        creditBannerConfig.placement = pageType;

        updateAttributes(creditBannerConfig);
        updateValuesWithConfigs(creditBannerConfig);
        toggleElement(creditBannerConfig.styleLayout === 'text');
        toggleLogoPosition();
    });

    $styleColor.addEventListener('change', () => {
        alertHandler.fadeAlerts();
        updateAttributes(getCreditMessageStyleConfigs());
    });

    $styleRatio.addEventListener('change', () => {
        alertHandler.fadeAlerts();
        updateAttributes(getCreditMessageStyleConfigs());
    });

    $placement.addEventListener('change', () => {
        const pageType = $placement.value;
        const savedCreditBannerConfig = JSON.parse($creditbannerConfigForm.getAttribute('data-banner-styles'))[pageType];
        savedCreditBannerConfig.placement = pageType;
        updateAttributes(savedCreditBannerConfig);
        updateValuesWithConfigs(savedCreditBannerConfig);
        toggleElement(savedCreditBannerConfig.styleLayout === 'text');
        alertHandler.fadeAlerts();
    });

    $styleLayout.addEventListener('change', () => {
        const styleLayout = $styleLayout.value;
        toggleElement(styleLayout === 'text');
        alertHandler.fadeAlerts();
        updateAttributes(getCreditMessageStyleConfigs());
    });

    $styleTextColor.addEventListener('change', () => {
        alertHandler.fadeAlerts();
        updateAttributes(getCreditMessageStyleConfigs());
    });

    $styleLogoPosition.addEventListener('change', () => {
        alertHandler.fadeAlerts();
        updateAttributes(getCreditMessageStyleConfigs());
    });

    $styleLogoType.addEventListener('change', () => {
        // Text logo position is only available with logo.type values: primary, alternative
        alertHandler.fadeAlerts();
        updateAttributes(getCreditMessageStyleConfigs());
        toggleLogoPosition();
        alertHandler.showAlertMessage(win.resourcesAlertMessages.logoPosition);
    });

    $creditbannerConfigForm.addEventListener('submit', (e) => {
        e.preventDefault();

        // eslint-disable-next-line no-undef
        $.post(e.currentTarget.action, e.currentTarget.serialize())
            .done(function (data) {
                location.href = data.redirectUrl;
            })
            .fail(function (err) {
                alertHandler.showAlertMessage({
                    message: err.responseText,
                    type: 'danger'
                });
            });

        return false;
    });
})(window, document, window.jQuery);
