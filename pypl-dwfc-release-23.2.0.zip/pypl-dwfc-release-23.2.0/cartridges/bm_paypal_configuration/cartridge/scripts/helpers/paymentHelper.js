'use strict';

/**
 * @param {string} paymentMethodId - The payment method ID
 * @returns {?dw.order.PaymentMethod} - Returns the payment method for the specified ID or null if no such method exists in the current site.
 */
function getPaymentMethod(paymentMethodId) {
    return require('dw/order/PaymentMgr').getPaymentMethod(paymentMethodId);
}

module.exports = {
    getPaymentMethod: getPaymentMethod
};
