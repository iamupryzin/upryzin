'use strict';

const currentSite = require('dw/system/Site').current;

/**
 * Get client id
 * @returns {string} client id
 */
function getClientId() {
    const serviceName = 'int_paypal.http.rest';
    const paypalService = require('dw/svc/LocalServiceRegistry').createService(serviceName, {});

    return paypalService.configuration.credential.user;
}

module.exports = {
    clientId: getClientId(),
    buttonStylesApi: {
        cwpp: currentSite.getCustomPreferenceValue('CWPP_API_Button_Styles'),
        payPalSmart: currentSite.getCustomPreferenceValue('PP_API_Smart_Button_Styles'),
        payPalCredit: currentSite.getCustomPreferenceValue('PP_API_Credit_Banner_Styles')
    },
    payPalShowOnPdp: currentSite.getCustomPreferenceValue('PP_Show_On_PDP'),
    payPalShowOnCart: currentSite.getCustomPreferenceValue('PP_Show_On_Cart'),
    payPalShowOnCategory: currentSite.getCustomPreferenceValue('PP_Show_On_Category'),
    payPalButtonLocation: currentSite.getCustomPreferenceValue('PP_API_Button_Location').getValue()
};
