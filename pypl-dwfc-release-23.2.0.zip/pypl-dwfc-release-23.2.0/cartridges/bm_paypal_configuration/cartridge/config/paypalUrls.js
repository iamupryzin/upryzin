'use strict';

const URLUtils = require('dw/web/URLUtils');

module.exports = {
    cwppConfigUrl: URLUtils.url('CWPPConfig-Start').toString(),
    payPalSDK: 'https://www.paypal.com/sdk/js?client-id={0}&components=buttons,messages',
    payPalExternalSDK: 'https://www.paypalobjects.com/js/external/api.js'
};
