PayPal 23.2.0 Link Cartridge. Implemented for 6.3.0 SFRA.
Please check ./documentation/PayPal Integration guide.docx as the integration reference.

If you have any questions or concerns please contact the PayPal Braintree plugins team at braintreepaypalplugins@paypal.com
